#!/bin/bash
cd `dirname $0`
##################
XPROTO_ROOT=/home/work/xproto
rm -rf $XPROTO_ROOT
mkdir -p $XPROTO_ROOT
##################
protoc *.proto --cpp_out=${XPROTO_ROOT}
##################
