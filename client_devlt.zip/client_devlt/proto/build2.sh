#!/bin/bash
cd `dirname $0`
rm -f ../src/*
rm -f ../lib/*
rm -f ../include/*
###################
mkdir -p ../src/
mkdir -p ../lib/
mkdir -p ../include/
###################
protoc *.proto --cpp_out=../src/
cp ./Makefile ../src/
cd ../src
make
##################
cp ./*.pb.h ../include/
cp ./*.a ../lib/
# rm ./* -rf
# cd ../
#################
XPROTO_ROOT=/home/xproto
XPROTO_INC=/home/xproto/include
XPROTO_LIB=/home/xproto/lib
XPROTO_SRC=/home/xproto/src
#################
rm -rf $XPROTO_ROOT
mkdir -vp $XPROTO_ROOT
mkdir -vp $XPROTO_INC
mkdir -vp $XPROTO_LIB
mkdir -vp $XPROTO_SRC
#################
cp -vf ./*.pb.h  $XPROTO_INC
cp -vf ./*.a     $XPROTO_LIB
cp -vf ./*.pb.h  $XPROTO_SRC
cp -vf ./*.pb.cc $XPROTO_SRC
rm ./* -rf
#################
cd ../
