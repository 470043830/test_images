#!/bin/bash
rm -rf src
mkdir src
mkdir src/go
protoc --go_out=src/go ./*.proto
