import { SYS_EVENT } from "db://assets/scripts/framework/event/EventDefine";
import EventMgr from "db://assets/scripts/framework/event/EventMgr";
import { cardPool } from "./pool/cardPool";

//游戏包预加载完成初始化数据
EventMgr.Instance.on(SYS_EVENT.GAME_INIT_CONFIG, () => {
    cardPool.Instance.initPool(40);
}, this);
