import { _decorator, color, EventHandler, instantiate, Label, Node, ProgressBar, size, Size, sp, Toggle, ToggleContainer, Tween, tween, UIOpacity, UITransform, v3, Vec3, Widget } from 'cc';
import { BaseScene } from '../../../scripts/framework/base/BaseScene';
import { nodeList } from './ui/comm/nodeList';
import ridCrushModel from './model/ridCrushModel';
import { TimerMgr } from 'db://assets/scripts/framework/manager/TimeMgr';
import { ArrayUtils } from 'db://assets/scripts/framework/utils/ArrayUtils';
import { EnumPrefab } from './config/BundleConfig';
import { UIMgr } from 'db://assets/scripts/framework/manager/UIMgr';
import { GameApp } from 'db://assets/scripts/lobby/GameApp';
import { bigWinView } from './ui/bigWinView';
import { GAME_ADUIO_EVENT, RoundDataVo } from './const/EventDefine';
import { AudioMgr } from 'db://assets/scripts/framework/manager/AudioMgr';
import GlobalModel from 'db://assets/scripts/model/GlobalModel';
import EventMgr from 'db://assets/scripts/framework/event/EventMgr';
import { Constant, GAME_TOUCH_EVENT } from './const/enumConst';
import { Logger } from 'db://assets/scripts/framework/utils/Logger';
import { GAME_EVENT } from 'db://assets/scripts/framework/event/EventDefine';
import { HallReqManager } from 'db://assets/scripts/framework/net/HallReqManager';
import { EnumCodeID } from 'db://assets/scripts/framework/net/Messages';
import { cardItem } from './ui/comm/cardItem';
import { cardPool } from './pool/cardPool';
import { MathUtils } from 'db://assets/scripts/framework/utils/MathUtils';
import AccountModel from 'db://assets/scripts/model/AccountModel';
import { ToastMgr } from 'db://assets/scripts/framework/manager/ToastMgr';
const { ccclass, property } = _decorator;

@ccclass('ridCrushGameScene')
export class ridCrushGameScene extends BaseScene {
    @property(nodeList)
    nodeListArr: Array<nodeList> = [];
    /** 游戏是否开始 */
    private isGameOver: boolean = false;
    /** 是否自动游戏 */
    private isAuto: boolean = false;
    /** 动画速度 */
    private quickType: number = 0;
    /** 自动游戏次数 */
    private autoNum: number = 0;
    /** 是否是免费 */
    private scatterWin: boolean = false;
    /** 免费游戏次数 */
    private freeNum: number = 0;
    private totalScore: number = 0;
    /** 界面数据初始化 */
    protected initData(): void {
        EventMgr.Instance.emit(GAME_EVENT.ON_SHOW_LOADING);

    }
    /** 设置事件流程化异步消息map */
    protected initMessageMap(): void {
        this.asyncMsgs.set(EnumCodeID.betting, this.onBettingReq.bind(this));

    }
    /** 非异步网络消息处理 */
    protected onRecvNetMessage<T>(cmd_: string, param_: T) {

    }

    /** 界面视图初始化 */
    protected async initView() {
        this.loadToggle();
        AudioMgr.Instance.playBgMusic(GlobalModel.Instance.bundle, GAME_ADUIO_EVENT.BACKGROUND);
        this.Items.layoutAmountPop.active = false;
        this.setlbNumClocor();
        for (let i = 0; i < this.nodeListArr.length; i++) {
            this.playSound(GAME_ADUIO_EVENT.hua);
            await this.nodeListArr[i].init(i);
        }
        //
        this.updateAmount();
        this.updateBalance();
    }
    /** 界面语言初始化 */
    protected initLanguage() {

    }
    /** 界面事件绑定 */
    protected bindEventListener() {
        super.bindEventListener();
        EventMgr.Instance.on(GAME_TOUCH_EVENT.GAME_EVENT_END, this.onGameEventEnd, this);

        this.addButtonListener("btnStart", this.onSatrtClick, this);
        this.addButtonListener("btnAmount", this.onAmountClick, this);
        this.addButtonListener("btnAuto", this.onAutoClick, this);
        this.addButtonListener("btnQuick", this.onQuickClick, this);
        this.Items.toggContair.on("toggle", this.onToggContair, this);
        const container = this.Items.toggContair.getComponent(ToggleContainer);
        this.bindToggleContainerEvent(container, "ridCrushGameScene", "onToggContair");
    }
    /** */
    private bindToggleContainerEvent(container: ToggleContainer, component: string, handler: string, customEventData: string = "") {
        const containerEventHandler = new EventHandler();
        containerEventHandler.target = this.node; // 这个 node 节点是你的事件处理代码组件所属的节点
        containerEventHandler.component = component;// 这个是脚本类名
        containerEventHandler.handler = handler;
        if (customEventData != "")
            containerEventHandler.customEventData = customEventData;
        container.checkEvents.push(containerEventHandler);
    }
    /** 界面销毁 */
    protected OnDestroy() {
        Tween.stopAllByTarget(this.Items.lbCurrScore);
    }
    /** */
    private loadToggle() {
        for (let i = 0; i < GlobalModel.Instance.opt.length; i++) {
            let toggle = instantiate(this.Items.Toggle);
            toggle.active = true;
            toggle.getComponent(Toggle).isChecked = i == 0 ? true : false;
            if (i == 0) {
                ridCrushModel.Instance.amount = GlobalModel.Instance.opt[i];
            }
            toggle.name = "Toggle" + i;
            let label = toggle.getChildByName("Label").getComponent(Label);
            label.string = GlobalModel.Instance.opt[i].toString();
            this.Items.toggContair.addChild(toggle)
        }
    }
    /** */
    private onBettingReq(param_) {
        console.log(param_)
        if (param_.code == 200) {
            AccountModel.Instance.balance = ArrayUtils.fixPrecision(AccountModel.Instance.balance -= ridCrushModel.Instance.amount);
            this.updateBalance();
            ridCrushModel.Instance.setbettingData(param_.data);
            this.onSatrt();
        } else {
            console.log("余额不足")
            this.isAuto = false;
            this.Items.nodeAuto.active = false;
        }

        this.commandOver();
    }
    /** 启动游戏 */
    private onSatrtClick() {

        if (this.isGameOver == true) {
            ToastMgr.Instance.onRecvToast({ msg: "正在游戏中" });
            return console.log("正在游戏中")
        };
        this.isGameOver = true;
        if (this.scatterWin == true) {
            this.onSatrt();
        } else {
            HallReqManager.sendBetting(ridCrushModel.Instance.amount);
        }


    }
    /** 打开下注设置 */
    private onAmountClick() {
        if (this.isGameOver == true) { return console.log("正在游戏中") };
        if (this.scatterWin == true) { return console.log("免费游戏中") };
        if (this.isAuto == true) { return console.log("自动游戏中") };
        this.Items.layoutAmountPop.active = !this.Items.layoutAmountPop.active;
    }
    /** 设置自动对局 */
    private onAutoClick() {
        this.isAuto = !this.isAuto;
        this.Items.nodeAuto.active = this.isAuto;
        if (this.isAuto == true) {
            this.autoNum = 50;
            this.updateAuto();
            if (this.isGameOver == true) {
                ToastMgr.Instance.onRecvToast({ msg: "正在游戏中" });
                return console.log("正在游戏中")
            };
            if (this.scatterWin == true) {
                ToastMgr.Instance.onRecvToast({ msg: "免费游戏中" });
                return console.log("免费游戏中");
            };

            this.onSatrtClick();
        }

    }
    /** 设置动画速度 */
    private onQuickClick() {
        this.quickType++;
        if (this.quickType == 2)
            this.quickType = 0;
        this.Items.nodeQuick.active = this.quickType == 1;
    }
    /** */
    private onToggContair(event, customEventData: string) {
        console.log(event, customEventData)
        let node = event.node.getChildByName("Label");
        let number = parseFloat(node.getComponent(Label).string);
        this.Items.layoutAmountPop.active = false;
        ridCrushModel.Instance.amount = number;
        this.updateAmount();
    }

    /** 开始游戏 */
    private async onSatrt() {
        this.isGameOver = true;
        if (this.scatterWin == true) {
            this.freeNum--;
            ridCrushModel.Instance.currentRound++;
            ridCrushModel.Instance.round = 0;
            this.updateLayoutFree();
        } else {
            if (this.isAuto == true) {
                this.autoNum--;
                this.updateAuto();
            }
        }
        await this.result();
    }

    /** */
    private setlbNumClocor(index: number = 0) {
        if (index > 4) index = 4;
        for (let i = 0; i < 4; i++) {
            this.Items[`lbNum${i + 1}`].getComponent(Label).color = index == i ? color(255, 253, 167) : color(255, 255, 255);
        }
    }

    //更新免费游戏界面效果
    private updateLayoutFree() {
        this.Items.layoutFree.active = this.scatterWin;
        this.Items.lbFree.getComponent(Label).string = this.freeNum.toString();
    }

    /** 更新总分数分数 */
    private updateBalance() {
        this.Items.lbBalance.getComponent(Label).string = AccountModel.Instance.balance.toString();
    }
    /** 设置当前轮或得分数 */
    private updateCurrScore(score: number = -1) {
        Tween.stopAllByTarget(this.Items.lbCurrScore);
        tween(this.Items.lbCurrScore).delay(1).call(() => {
            this.Items.lbCurrScore.getComponent(Label).string = ''
        }).start()
        if (score == -1) this.Items.lbCurrScore.getComponent(Label).string = '';
        else this.Items.lbCurrScore.getComponent(Label).string = score.toString();
    }
    /** 更新本局获胜分数 */
    private updateWinScore() {
        this.Items.lbWin.getComponent(Label).string = this.totalScore.toString();
    }
    /** 更新底注 */
    private updateAmount() {
        this.Items.lbAmount.getComponent(Label).string = ridCrushModel.Instance.amount.toString();
    }
    /** 更新自动游戏次数 */
    private updateAuto() {
        this.Items.lbAuto.getComponent(Label).string = this.autoNum.toString();
    }
    /** */
    private async result() {
        let scatterWin = ridCrushModel.Instance.getScatterWin();
        let getTimesData = ridCrushModel.Instance.getTimesData();
        console.log(getTimesData)
        //
        for (let i = 0; i < this.nodeListArr.length; i++) {
            this.nodeListArr[i].reclaim();
        }
        //
        for (let i = 0; i < this.nodeListArr.length; i++) {
            await this.nodeListArr[i].result(scatterWin == true && i > 1);
        }
        //
        await TimerMgr.Instance.delayTime(0.6);
        await this.playRemove();
    }
    /** */
    private async playRemove() {
        ridCrushModel.Instance.initRemoveIndex();
        let timesData = ridCrushModel.Instance.getRoundData();
        this.setlbNumClocor(ridCrushModel.Instance.round)

        let bonus = timesData.roundBonus;
        this.updateCurrScore(bonus == 0 ? -1 : bonus);

        this.updateBalance();
        if (bonus != -1) this.totalScore = ArrayUtils.fixPrecision(this.totalScore += bonus);
        this.updateWinScore();
        if (timesData.bonusDataList.length > 0) {
            for (let i = 0; i < this.nodeListArr.length; i++) {
                this.nodeListArr[i].showHuiNode(true);
            }
            for (let i = 0; i < timesData.bonusDataList.length; i++) {
                let date = timesData.bonusDataList[i];
                let winEleLoc = date.winEleLoc;
                for (let k = 0; k < winEleLoc.length; k++) {
                    for (let z = 0; z < winEleLoc[k].length; z++) {
                        this.playwinEleLocRemove(k, winEleLoc[k][z])
                    }
                }
            }
        } else {
            if (timesData.scatterWin == true) {
                for (let i = 0; i < this.nodeListArr.length; i++) {
                    this.nodeListArr[i].showHuiNode(true);
                }
                await TimerMgr.Instance.delayTime(0.5);

                for (let i = 0; i < this.nodeListArr.length; i++) {
                    this.nodeListArr[i].showHuiNode();
                }
            }
            //
            ridCrushModel.Instance.round = 0;
            this.setlbNumClocor(ridCrushModel.Instance.round)
            if (timesData.scatterWin == true) {
                console.log("获取免费游戏");
                if (this.scatterWin == false) {
                    AudioMgr.Instance.playBgMusic(GlobalModel.Instance.bundle, GAME_ADUIO_EVENT.BG2);
                    console.log("增加免费游戏次数");
                    this.freeNum = 10;
                    //更新免费动画
                    this.scatterWin = true;
                    this.isGameOver = false;
                    this.updateLayoutFree();
                    return;
                } else {
                    console.log("在免费游戏中或得免费游戏增加次数")
                    this.freeNum += 5;
                }
            }
            //
            if (this.scatterWin == true) {
                //更新免费动画
                if (this.freeNum == 0) {
                    AudioMgr.Instance.playBgMusic(GlobalModel.Instance.bundle, GAME_ADUIO_EVENT.BACKGROUND);
                    this.scatterWin = false;
                    this.updateLayoutFree();
                    this.onOpenBigWinUI(this.totalScore)
                } else {
                    this.isGameOver = false;
                    this.onSatrtClick();
                }
                ///更新免费页面状态
            } else {
                if (this.totalScore > 0) {
                    this.onOpenBigWinUI(this.totalScore)
                } else {
                    this.onGameEventEnd();
                }
            }
        }
    }
    /** */
    public async playwinEleLocRemove(i: number, k: number) {
        let index = k + i * Constant.layHor;
        if (ridCrushModel.Instance.removeIndexArr.indexOf(index) != -1) return;
        ridCrushModel.Instance.removeIndexArr.push(index);
        this.nodeListArr[i].playRemoveIndex(k);
        let pos = this.nodeListArr[i].getPosition(k, true);
        let node = this.nodeListArr[i].creatorCardNode(this.Items.nodeAnimation);
        node.setPosition(pos);
        let cardItemCom: cardItem = node.getComponent(cardItem);
        cardItemCom.playScaleRemove(index, this.playwinEleLocRemoveEnd.bind(this));
    }
    /** */
    public async playwinEleLocRemoveEnd() {
        ridCrushModel.Instance.removeIndex++;
        if (ridCrushModel.Instance.removeIndex != ridCrushModel.Instance.removeIndexArr.length)
            return;
        //
        ridCrushModel.Instance.round++;
        //
        for (let i = 0; i < this.nodeListArr.length; i++) {
            this.nodeListArr[i].playAddIndex();
        }
        //
        for (let i = 0; i < this.nodeListArr.length; i++) {
            this.nodeListArr[i].showHuiNode();
        }
        //
        let timesData = ridCrushModel.Instance.getRoundData();
        if (timesData.matchSplitDataList.length != 0) {
            await TimerMgr.Instance.delayTime(0.4);
            for (let i = 0; i < timesData.matchSplitDataList.length; i++) {
                let date1 = timesData.matchSplitDataList[i];
                let pos = this.nodeListArr[date1.column].getPosition(date1.row, true);
                for (let k = 0; k < date1.list.length; k++) {
                    let date2 = date1.list[k];
                    let index1 = date2.row + date2.column * Constant.layHor;
                    let pos1 = this.nodeListArr[date2.column].getPosition(date2.row, true);
                    let node = this.nodeListArr[i].creatorCardNode(this.Items.nodeAnimation);
                    node.setPosition(pos);
                    let cardItemCom: cardItem = node.getComponent(cardItem);
                    cardItemCom.playScaleRemove(index1);
                    tween(node)
                        .to(0.2, { position: pos1 })
                        .call(() => {
                            console.log("刷新")
                            this.nodeListArr[date2.column].updateCardItemIndex(index1);
                        })
                        .delay(0.45)
                        .call(() => {
                            console.log("回收")
                            node.getComponent(cardItem).onPut();

                        })
                        .start();
                    await TimerMgr.Instance.delayTime(0.05);
                }
            }
            await TimerMgr.Instance.delayTime(0.2);
        }
        await TimerMgr.Instance.delayTime(1);
        await this.playRemove();
    }
    /** */
    private onGameEventEnd() {
        Logger.info("动画结束");
        this.totalScore = 0;
        this.updateBalance();
        this.updateWinScore();
        if (this.isAuto == true) {
            this.Items.nodeAuto.active = this.isAuto;
            this.updateAuto();
            this.isGameOver = false;
            if (this.autoNum == 0) {
                this.isAuto = false;
            } else {
                this.onSatrtClick();
            }
        } else {
            this.isGameOver = false;
        }
    }

    /** */
    private async onOpenBigWinUI(totalScore: number) {
        let view = await UIMgr.Instance.showView(EnumPrefab.bigWinUI, { data: totalScore }, GameApp.Instance.getDialogLayer(), EnumPrefab.bigWinUI, false);
        view.addComponent(bigWinView);
    }
}
