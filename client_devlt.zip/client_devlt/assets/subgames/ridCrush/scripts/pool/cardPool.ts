import { _decorator, Component, Node } from 'cc';
import ObjectPool from '../../../../scripts/framework/base/ObjectPool';
import { EnumPrefab } from '../config/BundleConfig';
import { cardItem } from '../ui/comm/cardItem';
const { ccclass, property } = _decorator;

@ccclass('cardPool')
export class cardPool extends ObjectPool {
    private constructor() {
        super();
        //必须赋值(预制体路径)
        this.prefabStr = EnumPrefab.cardItem;
        //可选
        this.MemberFlag = EnumPrefab.cardItem;
        this.script = cardItem;
        this.nodeName = EnumPrefab.cardItem;
        this.poolSize = 10;
    }
    //重写抽象类的方法
    static get Instance(): cardPool {
        return super.GetInstance<cardPool>();
    }
}

