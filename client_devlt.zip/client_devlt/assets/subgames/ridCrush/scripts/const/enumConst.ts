import { Node } from "cc";

/** 排行数据 */
export interface RankData {
    star?: number,
    id?: number,
    level?: number,
    icon?: string,
    name?: string,
    gold?: number,
    rank?: number,
    time?: string,
}

/** 全局常量 */
export let Constant = {
    /** x方向排数 */
    layHor: 4,
    /** y方向排数 */
    layVer: 5,
}

/** 轮次 */
export enum AroundType {
    own = 0,
    other = 1,
}

/** 玩家信息 */
export interface UserDataInter {
    name: string,
    icon: number | string,
    skill: number | string,
    score: number,
    level: number,
}

/** */
export interface ChessDataInter {
    /** 棋盘ID */
    index: number,
    /** 每一轮数据值 1-1 第一个值，第二个消除是否为万能牌(0普通1万能2下一轮生成万能)  */
    value: Array<string>
}

/** */
export interface removeDataInter {
    /** 轮数 */
    roud: number,
    /** 消除数据按条存储 如果有按条播放动画会需要 */
    obviateData: Array<obviateDataInter>;
    /** 总消除ID  会去除重复*/
    totalObviate: Array<number>;
    /** 总消除分数 */
    totalScore: number;
}

/** */
export interface obviateDataInter {
    /** 分数 */
    score: number,
    /** 消除值 index ';'分割 1;5;10;15  */
    value: string;
}

/** */
export interface listNodeDataInter {
    index: number,
    i: number,
    node: Node
}

/** */
export enum GAME_TOUCH_EVENT {
    /** 一轮结束刷新状态 */
    GAME_EVENT_END = "GAME_TOUCH_EVENT.GAME_EVENT_END",
}