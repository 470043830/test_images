export enum GAME_ADUIO_EVENT {
    /** 背景音乐 */
    BACKGROUND = "bg1",
    /** 免费 */
    BG2 = "bg2",
    kaiju = "kaiju",
    hua = "hua",
    kaijuhua = "kaijuhua",
    mianfei1 = "mianfei1",
    mianfei2 = "mianfei2",
    mianfei3 = "mianfei3",
    piao = "piao",
    xiao = "xiao",
    jiesuan1 = "jiesuan1",
    jiesuandajiang = "jiesuandajiang",
    jiesuandajiang1 = "jiesuandajiang1",
}

export interface TimesDataVo {
    /** 本次是否是免费旋转 */
    timesIsFree: boolean;
    /** 小回合数据 */
    roundDataVoList: Array<RoundDataVo>;
    /** 次总奖金 */
    timesBonus: number;
}

export interface RoundDataVo {
    /** 转轴元素结果 */
    wheelEle: Array<Array<number>>;
    /** 每个位置元素类型 0-普通 1-金卡 2-scatter */
    eleType: Array<Array<number>>;
    /** 百搭分裂数据 */
    matchSplitDataList: Array<MatchSplitData>;
    /** 是否scatter中奖 */
    scatterWin: boolean;
    /** 线路中奖数据 */
    bonusDataList: Array<BonusDataVo>;
    /** 基础奖金数 总和 */
    totalBasic: number;
    /** 当前回合数 */
    currentRound: number;
    /** 回合倍数 */
    roundMul: number;
    /** 回合总奖金数 */
    roundBonus: number;
}

export interface MatchSplitData {
    /**大百搭所在列*/
    column: number;
    /** 大百搭所在行 */
    row: number;
    /** 每个分裂出的百搭覆盖的位置 */
    list: Array<MatchSplitData1>;
}

export interface MatchSplitData1 {
    /**大百搭所在列*/
    column: number;
    /** 大百搭所在行 */
    row: number;
}

export interface BonusDataVo {
    /**中奖元素*/
    winEle: number;
    /** 中奖元素位置 每一列哪些行是中奖元素 */
    winEleLoc: Array<Array<number>>;
    /** 基础奖金 */
    bonus: number;
}