import { _decorator, Component, Label, Node, sp, Tween, tween, UIOpacity } from 'cc';
import { DialogView } from 'db://assets/scripts/framework/base/DialogView';
import { TimerMgr } from 'db://assets/scripts/framework/manager/TimeMgr';
import { GAME_ADUIO_EVENT } from '../const/EventDefine';
import EventMgr from 'db://assets/scripts/framework/event/EventMgr';
import { GAME_TOUCH_EVENT } from '../const/enumConst';
const { ccclass, property } = _decorator;

@ccclass('bigWinView')
export class bigWinView extends DialogView {
    //
    private big = "win_big";
    //
    private bigEnd = "win_big_js";
    //
    private mega = "win_big2";
    //
    private megaEnd = "win_big_js2";
    //
    private super = "win_big3";
    //
    private superEnd = "win_big_js3";
    //
    private EPS = Number.EPSILON;
    //
    private oneTimeVal: number;
    //
    private spine: sp.Skeleton = null;
    //
    time = 0;
    //
    aniIndex: number;
    //
    private isShow: boolean = false;
    //
    private aniArr = [this.big, this.mega, this.super];
    //
    protected initData(): void {

    }
    //
    protected initLanguage(): void {

    }
    //
    protected initMessageMap(): void {

    }
    //
    protected initView(): void {
        this.spine = this.Items.spine.getComponent(sp.Skeleton);
        this.show();
        this.Items.payOutLab.getComponent(UIOpacity).opacity = 255;

    }
    //
    protected bindEventListener(): void {
        super.bindEventListener();
    }
    //
    protected OnDestroy(): void {

    }
    //
    async show() {
        try {
            this.aniIndex = 0;
            this.spine.loop = false;
            let totalMult = this.viewParam.data;
            let dangci = 1;
            if (totalMult >= 5 && totalMult < 10) {
                this.time = 8;
                dangci = 1;
                this.playSound(GAME_ADUIO_EVENT.jiesuan1)
            } else if (totalMult >= 10 && totalMult < 25) {
                this.time = 16;
                dangci = 2;
                this.playSound(GAME_ADUIO_EVENT.jiesuan1)
            } else if (totalMult >= 25) {
                this.time = 24;
                dangci = 3;
                this.playSound(GAME_ADUIO_EVENT.jiesuandajiang1)
            }
            //
            this.Items.payOutLab.getComponent(Label).string = "0";
            this.spine.node.active = true;
            this.spine.animation = this.big;
            this.oneTimeVal = this.viewParam.data / this.time;
            this.schedule(this.updateCoin, 0.125 / 2);
            let index = await this.playAni();
            while (index < dangci) {
                index = await this.playAni();
            }
            //
            await TimerMgr.Instance.delayTime(1.2);
            tween(this.Items.payOutLab.getComponent(UIOpacity))
                .to(0.5, { opacity: 0 })
                .call(() => {
                    switch (dangci) {
                        case 1:
                            this.spine.setAnimation(0, this.bigEnd, false);
                            break;
                        case 2:
                            this.spine.setAnimation(0, this.megaEnd, false);
                            break;
                        case 3:
                            this.spine.setAnimation(0, this.superEnd, false);
                            break;
                    }
                    this.onClose();
                })
                .start()
        } catch (error) {

        }
        //
        return false;
    }

    playAni() {
        return new Promise<number>((resolve, reject) => {
            this.spine.animation = this.aniArr[this.aniIndex];
            this.aniIndex++;
            this.scheduleOnce(() => {
                resolve(this.aniIndex);
            }, 5)
        })
    }

    updateCoin() {
        let num = parseFloat(this.Items.payOutLab.getComponent(Label).string);
        if (!num || isNaN(num)) {
            num = 0;
        }
        num += this.oneTimeVal;
        if (num >= this.viewParam.data) {
            num = this.viewParam.data;
            this.unschedule(this.updateCoin);
            this.isShow = true;
        }
        //
        this.Items.payOutLab.getComponent(Label).string = num.toFixed(2);
    }

    spineComHandler() {
        switch (this.spine.animation) {
            case this.bigEnd:
            case this.megaEnd:
            case this.superEnd:
                this.unschedule(this.updateCoin);
                break;
        }
    }

    protected onClose(e: TouchEvent = null) {
        if (this.isShow == false)
            return;
        //
        this.unschedule(this.updateCoin);
        Tween.stopAllByTarget(this.Items.payOutLab);
        super.onClose();
        EventMgr.Instance.emit(GAME_TOUCH_EVENT.GAME_EVENT_END);
    }
}
