import { _decorator, Component, Node, Toggle } from 'cc';
import { AudioMgr } from '../../../../scripts/framework/manager/AudioMgr';
import { DialogView } from '../../../../scripts/framework/base/DialogView';
const { ccclass, property } = _decorator;

@ccclass('setUpUI')
export class setUpUI extends DialogView {
    protected initData(): void {

    }

    protected initView(): void {
        this.hideClick();
        this.Items.toggleMusic.getComponent(Toggle).isChecked = AudioMgr.Instance.isMusicMute;
        this.Items.toggleSound.getComponent(Toggle).isChecked = AudioMgr.Instance.isSoundMute;
    }

    protected initLanguage(): void {

    }

    protected bindEventListener(): void {
        super.bindEventListener();
        this.Items.toggleMusic.on("toggle", this.onToggleMusic.bind(this));
        this.Items.toggleSound.on("toggle", this.onToggleSoundMute.bind(this));
    }

    protected OnDestroy(): void {

    }

    private onToggleMusic(event) {
        AudioMgr.Instance.setMusicMute(event.isChecked)
    }

    private onToggleSoundMute(event) {
        AudioMgr.Instance.setSoundsMute(event.isChecked)
    }
}

