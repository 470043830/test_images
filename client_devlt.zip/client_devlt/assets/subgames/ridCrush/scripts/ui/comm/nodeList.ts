import { _decorator, CCBoolean, CCInteger, Component, Node, Tween, tween, UI, UITransform, v3, Vec3, } from 'cc';
import { cardPool } from '../../pool/cardPool';
import { cardItem } from './cardItem';
import { TimerMgr } from 'db://assets/scripts/framework/manager/TimeMgr';
import { Constant, listNodeDataInter } from '../../const/enumConst';
import ridCrushModel from '../../model/ridCrushModel';
import { AudioMgr } from 'db://assets/scripts/framework/manager/AudioMgr';
import GlobalModel from 'db://assets/scripts/model/GlobalModel';
import { EnumBundle } from 'db://assets/scripts/config/BundleConfig';
import { GAME_ADUIO_EVENT } from '../../const/EventDefine';
const { ccclass, property, executionOrder } = _decorator;


@ccclass('nodeList')
@executionOrder(-1) // 数值越小，执行越早
export class nodeList extends Component {
    @property(CCBoolean)
    isHor: boolean = false;
    @property(CCInteger)
    spacing: number = 0;
    listNodeData: Map<number, listNodeDataInter> = new Map<number, listNodeDataInter>();
    private key: number = -1;
    @property(Node)
    nodeParent1: Node = null;
    @property(Node)
    nodeParent2: Node = null;
    @property(Node)
    nodehui: Node = null;
    /** */
    async init(key: number) {
        this.key = key;
        for (let i = 0; i < 4; i++) {
            await TimerMgr.Instance.delayTime(0.1);
            let node: Node = this.creatorCardNode();
            let pos = this.getPosition(i);
            node.setPosition(pos);
            let index = i + key * Constant.layHor;
            this.listNodeData.set(index, {
                index: index,
                i: i,
                node: node
            });
            let cardItemCom = node.getComponent(cardItem);
            cardItemCom.init();
        }
    }
    /** 
     * 回收消除节点
     */
    public playRemoveIndex(i) {
        let index = i + this.key * Constant.layHor;
        let date = this.listNodeData.get(index);
        if (date && date.node == null) return;
        let cardItemCom = date.node.getComponent(cardItem);
        cardItemCom.onPut();
        date.node = null;
    }
    /**
     * 播放
    */
    public playAddIndex() {
        for (let i = 3; i >= 0; i--) {
            let pos = this.getPosition(i);
            let index = i + this.key * Constant.layHor;
            let date = this.listNodeData.get(index);
            if (date.node != null)
                continue;
            let node: Node = this.creatorCardNode();
            date.node = node;
            let cardItemCom: cardItem = node.getComponent(cardItem);
            this.listNodeData.set(index, { index: index, i: i, node: node });
            let startPos = this.startPos(i);
            node.setPosition(startPos);
            cardItemCom.setcardValue(index);
            cardItemCom.loadPic()
            this.playAnimation(node, pos, cardItemCom.symbol);
        }
    }

    /** */
    public updateCardItemIndex(index) {
        let date = this.listNodeData.get(index);
        console.log(this.listNodeData, index)
        if (date && date.node == null) {
            return;
        }
        //
        let cardItemCom: cardItem = date.node.getComponent(cardItem);
        cardItemCom.playScaleRemove1(index);
    }
    /** */
    public reclaim() {
        this.listNodeData.forEach((data) => {
            let cardItemCom = data.node.getComponent(cardItem);
            let pos = this.getPosition(data.i);
            data.node.setPosition(pos);
            if (this.isHor == true) {
                let width = cardPool.Instance.width;
                pos.x -= width * 4;
            } else {
                let height = cardPool.Instance.height;
                pos.y -= height * 4
            }
            cardItemCom.clean(pos);
        });
        this.listNodeData.clear();
    }
    /** */
    public async result(isShow: boolean = true) {
        await TimerMgr.Instance.delayTime(isShow == true ? 0.4 : 0.1);
        for (let i = 3; i >= 0; i--) {
            let pos = this.getPosition(i);
            let index = i + this.key * Constant.layHor;
            let node: Node = this.creatorCardNode();
            let cardItemCom: cardItem = node.getComponent(cardItem);
            this.listNodeData.set(index, { index: index, i: i, node: node });
            let startPos = this.startPos(i);
            node.setPosition(startPos);
            if (isShow == true) {
                cardItemCom.setcardValue(index);
                cardItemCom.loadPic()
                this.initFalling(node, pos, () => {
                    Tween.stopAllByTarget(node);
                    if (cardItemCom.symbol == 9)
                        node.parent = this.nodeParent2;
                    else
                        node.parent = this.nodeParent1;
                });
                this.scheduleOnce(() => {
                    this.playSound(GAME_ADUIO_EVENT.piao)
                }, 0.05 * i)
            } else {
                await TimerMgr.Instance.delayTime(0.1);
                this.playSound(GAME_ADUIO_EVENT.hua);
                cardItemCom.setcardValue(index);
                cardItemCom.loadPic()
                this.initWinFalling(node, pos, () => {
                    Tween.stopAllByTarget(node);
                    if (cardItemCom.symbol == 9)
                        node.parent = this.nodeParent2;
                    else
                        node.parent = this.nodeParent1;
                });
                this.playSound(GAME_ADUIO_EVENT.piao)
            }
        }
    }
    /** */
    public startPos(i): Vec3 {
        let pos = this.getPosition(i);
        if (this.isHor == true) {
            let width = cardPool.Instance.width;
            return (v3(pos.x + width * 4, 0));
        } else {
            let height = cardPool.Instance.height;
            return (v3(0, pos.y + height * 4));
        }
    }
    /** */
    public creatorCardNode(parent: Node = this.node): Node {
        let node = cardPool.Instance.getNode();
        parent.addChild(node)
        return node;
    }
    /** 播放声音 */
    playSound(audioName: string, bundle?: EnumBundle | string) {
        AudioMgr.Instance.playSound(bundle || GlobalModel.Instance.bundle, audioName);
    }
    /** */
    public showHuiNode(isShow: boolean = false) {
        this.nodehui.active = isShow;
    }
    /** */
    getPosition(value: number, isShow: boolean = false): Vec3 {
        let pos = ridCrushModel.getPosition(value, this.spacing, this.isHor);
        if (isShow == false) {
            return pos;
        }
        //
        if (this.isHor == true) {
            pos.y = this.node.getPosition().y;
            pos.x += this.node.getComponent(UITransform).width / 2;
        } else {
            pos.x = this.node.getPosition().x;
            pos.y += this.node.getComponent(UITransform).height / 2;
        }
        //
        return pos;
    }
    /** */
    private initFalling(node, pos, callback: Function = null) {
        tween(node)
            .to(0.2, { position: pos })
            .call(() => {
                if (callback) {
                    callback();
                }
            })
            .start()
    }
    /** 免费中奖数量大于等于2 掉落效果 */
    private initWinFalling(node, pos, callback: Function = null) {
        tween(node)
            .to(0.1, { position: pos })
            .call(() => {
                if (callback) {
                    callback();
                }
            })
            .start()
    }
    /** */
    private playAnimation(node, pos, symbol) {
        if (symbol == 10) {
            node.setPosition(pos);
            node.parent = this.nodeParent1;
        } else {
            tween(node)
                .to(0.2, { position: pos })
                .call(() => {
                    Tween.stopAllByTarget(node);
                    node.parent = symbol == 9 ? this.nodeParent2 : this.nodeParent1;
                })
                .start()
        }
    }
}

