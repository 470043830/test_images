import { _decorator, Component, easing, Label, Node, sp, Sprite, tween, Tween, v3, Vec3 } from 'cc';
import { BaseUI } from '../../../../../scripts/framework/base/BaseUI';
import { cardPool } from '../../pool/cardPool';
import { MathUtils } from '../../../../../scripts/framework/utils/MathUtils';
import { EnumBundle } from '../../../../../scripts/config/BundleConfig';
import ridCrushModel from '../../model/ridCrushModel';
import { Constant } from '../../const/enumConst';
import { Logger } from 'db://assets/scripts/framework/utils/Logger';
const { ccclass, property } = _decorator;

@ccclass('cardItem')
export class cardItem extends BaseUI {
    symbol: number = -1;
    type: number = -1;
    index: number = -1;
    get spinAnimationName() {
        let txt = "";
        switch (this.symbol) {
            case 1:
                txt = "MH"
                break;
            case 2:
                txt = "FK"
                break;
            case 3:
                txt = "HongT"
                break;
            case 4:
                txt = "HeiT"
                break;
            case 5:
                txt = "j"
                break;
            case 6:
                txt = "q"
                break;
            case 7:
                txt = "k"
                break;
            case 8:
                txt = "a"
                break;
            case 10:
                txt = "XW"
                break;

            default:
                break;
        }
        return txt;

    }
    protected initData(): void {

    }
    protected initView(): void {

    }
    protected initLanguage(): void {

    }
    protected bindEventListener(): void {
        super.bindEventListener();
    }
    protected onDestroy(): void {

    }
    public showNodeAn(isShow: boolean) {
        // this.Items.nodeAn.active = isShow;
    }
    /** 渲染文字内容 */
    private loadTxt(value) {
        this.Items.lbIndex.getComponent(Label).string = value == 10 ? "通用" : value;
    }
    /** 渲染图片内容 */
    public loadPic(state: number = 0, callback: Function = null) {
        console.log(state)
        this.Items.nodeSp.getComponent(sp.Skeleton).timeScale = 1;
        if (state == 0 || state == 3) {
            let isShow = this.symbol < 9;
            this.Items.nodeCard.active = isShow && this.type == 0;
            this.Items.nodeSp.active = !(isShow && this.type == 0);
            if (isShow == true) {
                if (this.type == 0) {
                    let txt = "texture/cards/" + this.symbol;
                    this.setSpriteFrame(this.Items.nodeCard, txt, EnumBundle.ridCrush);
                } else {
                    // txt = this.type == 1 ? txt + "_j" : txt;
                    let pathAnitmtion = "idle_j_" + this.spinAnimationName;
                    this.Items.nodeSp.getComponent(sp.Skeleton).loop = false;
                    this.Items.nodeSp.getComponent(sp.Skeleton).animation = pathAnitmtion;
                }
            } else {
                let isShow = ridCrushModel.Instance.isCalculateFenlie(this.index, 0);
                let pathAnitmtion = this.symbol == 9 ? "idle_jinbi" : isShow == true ? "fanpai_DW" : "fanpai_XW";
                console.log(pathAnitmtion, isShow)
                if (state == 3 && this.symbol == 10) this.Items.nodeSp.getComponent(sp.Skeleton).timeScale = 20;
                this.Items.nodeSp.getComponent(sp.Skeleton).loop = this.symbol == 9;
                this.Items.nodeSp.getComponent(sp.Skeleton).animation = pathAnitmtion;
            }
        } else if (state == 1) {
            this.Items.nodeCard.active = false;
            this.Items.nodeSp.active = true;
            let pathAnitmtion = "";
            if (this.type == 0) {
                pathAnitmtion = "kapai_xc_" + this.spinAnimationName;
            } else {
                pathAnitmtion = "kapai_j_xc_" + this.spinAnimationName;
                this.node.setSiblingIndex(999)
            }
            //
            if (this.symbol == 10) {
                let isShow = ridCrushModel.Instance.isCalculateFenlie(this.index, 0);
                pathAnitmtion = isShow == true ? "kapai_xc_DW" : "kapai_xc_XW";
            }
            //
            let nodeSpine = this.Items.nodeSp.getComponent(sp.Skeleton);
            this.Items.nodeSp.getComponent(sp.Skeleton).loop = false;
            nodeSpine.setCompleteListener((trackEntry: sp.spine.TrackEntry) => {
                //清空监听
                // this.heroSpine.setCompleteListener(null);
                if (callback) {
                    callback();
                    callback = null;
                }
                this.onPut();
            });
            //
            this.Items.nodeSp.getComponent(sp.Skeleton).animation = pathAnitmtion;
        }
        // this.setSpriteFrame(this.Items.nodeCard, "");
        // this.Items.nodeSp.active = symbol == 9;
        // this.Items.nodeCard.active = !(symbol == 9 || symbol == 10);
        // if (symbol == 10 || symbol == 9) return;
        // let txt = "texture/cards/" + symbol;

        // txt = type == 1 ? txt + "_j" : txt;
        // this.setSpriteFrame(this.Items.nodeCard, txt, EnumBundle.ridCrush)
    }
    /**
     * 
    */
    public setcardValue(index: number) {
        this.index = index;
        let y = index % Constant.layHor;
        let x = Math.floor(index / Constant.layHor);
        let symbol = ridCrushModel.Instance.getWheelEle(x, y);
        let type = ridCrushModel.Instance.getEleType(x, y);
        this.symbol = symbol; this.type = type;
        if (this.type == null) {
            console.log("------------------start-----------------")
            console.log("this.type", this.type, this.symbol)
            console.log("index", index)
            console.log("currentRound", ridCrushModel.Instance.currentRound)
            console.log("round", ridCrushModel.Instance.round)
            console.log("------------------end-----------------")
        }
    }

    /** 
     * 初始化游戏动画效果
     */
    public init() {
        /** 随机一个值 */
        this.symbol = MathUtils.randomInt(1, 6);
        this.type = 0;
        this.loadPic();
        tween(this.Items.nodeCard)
            .set({ scale: v3(0, 0) })
            .to(0.2, { scale: v3(1, 1) })
            .start()
    }
    /** 
     * 消除回收并播放动画
     */
    playScaleRemove(index, callback: Function = null) {
        this.setcardValue(index);
        this.loadPic(1, callback);

    }
    /**
     * 消除回收并播放动画
     */
    playScaleRemove1(index, callback: Function = null) {
        this.setcardValue(index);
        this.loadPic(3);
    }

    /**
     * 结束移动回收
     */
    public clean(pos: Vec3) {
        Tween.stopAllByTarget(this.node);
        tween(this.node)
            .to(0.2, { position: pos })
            .call(() => {
                this.onPut();
            })
            .start()
    }
    /** 
     * 回收对象池
     */
    public onPut() {
        this.Items.nodeSp.getComponent(sp.Skeleton).setCompleteListener(null);
        Tween.stopAllByTarget(this.Items.nodeCard);
        Tween.stopAllByTarget(this.node);
        this.Items.nodeCard.scale = Vec3.ONE;
        this.node.scale = Vec3.ONE;
        cardPool.Instance.putNode(this.node)
        this.node.parent = null;
    }
}


