import { _decorator, Component, isValid, Label, Node, tween, utils, v3 } from 'cc';
import { UIUtils } from '../../../../scripts/framework/utils/UIUtils';
import { BaseView } from '../../../../scripts/framework/base/BaseView';
import { RankConfig } from '../const/RankConfig';
import ridCrushModel from '../model/ridCrushModel';
import { TimerMgr } from 'db://assets/scripts/framework/manager/TimeMgr';
const { ccclass, property } = _decorator;

@ccclass('matchView')
export class matchView extends BaseView {
    //
    private count: number = 0;
    //
    private isDown: boolean = false;
    //
    private mathTimes: number = 20;
    //
    protected initData(): void {

    }
    //
    protected initLanguage(): void {

    }
    //
    protected initMessageMap(): void {

    }
    //
    protected initView(): void {
        this.playAutoAnimLable();
        this.startMatch();
    }
    //
    protected bindEventListener(): void {
        super.bindEventListener();
    }
    //
    protected OnDestroy(): void {

    }
    //
    public async startMatch() {
        if (this.isDown) return;
        let rand = Math.ceil(Math.random() * this.Items.otherHead.children.length);
        let randSkill = Math.ceil(Math.random() * 9);
        this.Items.otherHead.children.forEach(item => {
            item.active = +item.name == rand;
        });
        let name = RankConfig.getNameByHead(rand);
        this.Items.lbOtherName.getComponent(Label).string = name
        if (this.count > this.mathTimes) {
            this.Items.ok.active = true;
            this.isDown = true;
            this.Items.autoAnim.active = false;
            this.gotoGame();
            return;
        }
        await TimerMgr.Instance.delayTime(0.1 + Math.random() * 0.5);
        this.count++;
        this.startMatch();
    }
    /** 播放自动合成文字动画 */
    public async playAutoAnimLable() {
        if (!isValid(this.node))
            return;
        if (!this.Items.autoAnim)
            return;
        if (this.isDown)
            return;
        let gap = 10;
        let time = 0.2;
        for (let i = 0; i < this.Items.autoAnim.children.length; i++) {
            if (this.isDown)
                return;
            let item = this.Items.autoAnim.getChildByName(i + "");
            let pos = item.position;
            tween(item).to(time, { position: v3(pos.x, gap, pos.z) }).call(() => {
                tween(item).to(time, { position: v3(pos.x, 0, pos.z) }).start();
            }).start();
            if (this.isDown)
                return;
            await TimerMgr.Instance.delayTime(time * 0.5);
            if (this.isDown)
                return;
        }
        if (this.isDown)
            return;
        await TimerMgr.Instance.delayTime(time * 0.5);
        if (this.isDown)
            return;
        this.playAutoAnimLable();
    }
    ///
    public async gotoGame() {
        await TimerMgr.Instance.delayTime(3);
        this.isDown = true;
        this.onClose();
    }
}

