import Singleton from "../../../../scripts/framework/base/Singleton";
import { RoundDataVo, TimesDataVo } from "../const/EventDefine";
import { v3, Vec3 } from "cc";
import { cardPool } from "../pool/cardPool";
import AccountModel from "db://assets/scripts/model/AccountModel";
import { HallReqManager } from "db://assets/scripts/framework/net/HallReqManager";
import { Constant } from "../const/enumConst";

/**
 * 
 */
var timesDataList: Array<TimesDataVo> = [
    {
        "roundDataVoList": [
            {
                "bonusDataList": [
                    {
                        "bonus": 0.2,
                        "winEle": 5,
                        "winEleLoc": [[1], [0], [0], [], [0]]
                    },
                    {
                        "bonus": 0.1,
                        "winEle": 3,
                        "winEleLoc": [[3], [2, 3], [3], [], [2]]
                    }
                ],
                "currentRound": 1,
                "eleType": [
                    [0, 0, 0, 0],
                    [0, 0, 0, 0],
                    [1, 1, 0, 0],
                    [0, 0, 0, 0],
                    [0, 0, 0, 0]
                ],
                "matchSplitDataList": [],
                "roundBonus": 0.3,
                "roundMul": 1,
                "scatterWin": false,
                "totalBasic": 0.3,
                "wheelEle": [
                    [7, 5, 2, 3],
                    [5, 2, 3, 3],
                    [5, 6, 8, 3],
                    [4, 4, 2, 7],
                    [5, 6, 3, 7]
                ]
            },
            {
                "bonusDataList": [
                    {
                        "bonus": 0.3,
                        "winEle": 6,
                        "winEleLoc": [[1], [2, 3], [0, 1, 3], [], [1]]
                    }, {
                        "bonus": 0.15,
                        "winEle": 2,
                        "winEleLoc": [[2], [1], [0], [2], []
                        ]
                    }, {
                        "bonus": 0.1,
                        "winEle": 3,
                        "winEleLoc": [[3], [0], [0], [], []
                        ]
                    }],
                "currentRound": 2,
                "eleType": [
                    [0, 0, 0, 0],
                    [0, 0, 0, 0],
                    [0, 1, 0, 0],
                    [0, 0, 0, 0],
                    [2, 0, 0, 0]
                ],
                "matchSplitDataList": [],
                "roundBonus": 1.1,
                "roundMul": 2,
                "scatterWin": false,
                "totalBasic": 0.55,
                "wheelEle": [
                    [7, 6, 2, 3],
                    [3, 2, 6, 6],
                    [10, 6, 8, 6],
                    [4, 4, 2, 7],
                    [9, 6, 4, 7]
                ]
            },
            {
                "bonusDataList": [],
                "currentRound": 3,
                "eleType": [
                    [0, 0, 0, 0],
                    [0, 2, 1, 2],
                    [0, 0, 0, 0],
                    [0, 0, 0, 0],
                    [2, 0, 0, 0]
                ],
                "matchSplitDataList": [],
                "roundBonus": 0,
                "roundMul": 6,
                "scatterWin": true,
                "totalBasic": 0,
                "wheelEle": [
                    [7, 5, 5, 5],
                    [7, 9, 8, 9],
                    [5, 10, 8, 3],
                    [4, 4, 2, 7],
                    [9, 7, 4, 7]
                ]
            }],
        "timesBonus": 1.4,
        "timesIsFree": false
    },
    {
        "roundDataVoList": [{
            "bonusDataList": [{
                "bonus": 1.5,
                "winEle": 6,
                "winEleLoc": [[1, 2], [2, 3], [1], [0], [0, 2]
                ]
            },
            {
                "bonus": 0.4,
                "winEle": 7,
                "winEleLoc": [[3], [0], [2], [], []
                ]
            }],
            "currentRound": 1,
            "eleType": [
                [0, 0, 0, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 1],
                [0, 0, 0, 1],
                [0, 0, 0, 0]
            ],
            "matchSplitDataList": [],
            "roundBonus": 3.8,
            "roundMul": 2,
            "scatterWin": false,
            "totalBasic": 1.9,
            "wheelEle": [
                [5, 6, 6, 7],
                [7, 8, 6, 6],
                [8, 6, 7, 3],
                [6, 8, 1, 4],
                [6, 8, 6, 4]
            ]
        }, {
            "bonusDataList": [{
                "bonus": 0.2,
                "winEle": 5,
                "winEleLoc": [[0], [2], [1], [], []
                ]
            }, {
                "bonus": 2.5,
                "winEle": 8,
                "winEleLoc": [[1], [0, 1], [0], [1], [1]
                ]
            }],
            "currentRound": 2,
            "eleType": [
                [0, 0, 0, 2],
                [0, 0, 0, 0],
                [0, 0, 0, 1],
                [0, 0, 0, 1],
                [0, 0, 0, 0]
            ],
            "matchSplitDataList": [],
            "roundBonus": 10.8,
            "roundMul": 4,
            "scatterWin": false,
            "totalBasic": 2.7,
            "wheelEle": [
                [5, 8, 1, 9],
                [8, 8, 5, 7],
                [8, 5, 1, 3],
                [4, 8, 1, 4],
                [1, 8, 6, 4]
            ]
        }, {
            "bonusDataList": [{
                "bonus": 0.4,
                "winEle": 7,
                "winEleLoc": [[0], [3], [0], [], [1]
                ]
            }, {
                "bonus": 0.25,
                "winEle": 1,
                "winEleLoc": [[2], [2], [2], [2], [0]
                ]
            }],
            "currentRound": 3,
            "eleType": [
                [0, 0, 0, 2],
                [0, 0, 0, 0],
                [0, 0, 0, 1],
                [0, 0, 0, 1],
                [0, 0, 0, 0]
            ],
            "matchSplitDataList": [],
            "roundBonus": 3.9,
            "roundMul": 6,
            "scatterWin": false,
            "totalBasic": 0.65,
            "wheelEle": [
                [7, 8, 1, 9],
                [3, 2, 1, 7],
                [7, 6, 1, 3],
                [4, 8, 1, 4],
                [1, 7, 6, 4]
            ]
        }, {
            "bonusDataList": [],
            "currentRound": 4,
            "eleType": [
                [0, 0, 0, 2],
                [0, 0, 0, 0],
                [1, 0, 1, 1],
                [0, 0, 0, 1],
                [0, 0, 0, 0]
            ],
            "matchSplitDataList": [],
            "roundBonus": 0,
            "roundMul": 10,
            "scatterWin": false,
            "totalBasic": 0,
            "wheelEle": [
                [5, 8, 8, 9],
                [3, 2, 1, 4],
                [3, 6, 2, 3],
                [4, 8, 8, 4],
                [6, 3, 6, 4]
            ]
        }],
        "timesBonus": 18.5,
        "timesIsFree": true
    },
    {
        "roundDataVoList": [{
            "bonusDataList": [],
            "currentRound": 1,
            "eleType": [
                [0, 0, 0, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 0]
            ],
            "matchSplitDataList": [],
            "roundBonus": 0,
            "roundMul": 2,
            "scatterWin": false,
            "totalBasic": 0,
            "wheelEle": [
                [5, 7, 2, 8],
                [3, 6, 8, 6],
                [2, 3, 1, 6],
                [3, 3, 7, 7],
                [1, 7, 1, 2]
            ]
        }],
        "timesBonus": 0,
        "timesIsFree": true
    },
    {
        "roundDataVoList": [{
            "bonusDataList": [{
                "bonus": 2,
                "winEle": 7,
                "winEleLoc": [[1], [2], [0, 2], [3], [2]
                ]
            }],
            "currentRound": 1,
            "eleType": [
                [0, 0, 0, 0],
                [2, 0, 0, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 0]
            ],
            "matchSplitDataList": [],
            "roundBonus": 4,
            "roundMul": 2,
            "scatterWin": false,
            "totalBasic": 2,
            "wheelEle": [
                [8, 7, 3, 4],
                [9, 4, 7, 5],
                [7, 8, 7, 8],
                [8, 8, 6, 7],
                [1, 1, 7, 4]
            ]
        }, {
            "bonusDataList": [],
            "currentRound": 2,
            "eleType": [
                [0, 0, 0, 0],
                [2, 0, 0, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 0]
            ],
            "matchSplitDataList": [],
            "roundBonus": 0,
            "roundMul": 4,
            "scatterWin": false,
            "totalBasic": 0,
            "wheelEle": [
                [8, 1, 3, 4],
                [9, 4, 5, 5],
                [8, 8, 6, 8],
                [8, 8, 6, 4],
                [1, 1, 8, 4]
            ]
        }],
        "timesBonus": 4,
        "timesIsFree": true
    },
    {
        "roundDataVoList": [{
            "bonusDataList": [],
            "currentRound": 1,
            "eleType": [
                [0, 0, 0, 0],
                [0, 0, 0, 1],
                [1, 0, 1, 2],
                [0, 0, 0, 0],
                [0, 0, 0, 0]
            ],
            "matchSplitDataList": [],
            "roundBonus": 0,
            "roundMul": 2,
            "scatterWin": false,
            "totalBasic": 0,
            "wheelEle": [
                [7, 4, 3, 6],
                [5, 6, 7, 8],
                [8, 8, 3, 9],
                [4, 4, 6, 5],
                [5, 4, 7, 3]
            ]
        }],
        "timesBonus": 0,
        "timesIsFree": true
    },
    {
        "roundDataVoList": [{
            "bonusDataList": [],
            "currentRound": 1,
            "eleType": [
                [0, 0, 0, 0],
                [0, 0, 0, 0],
                [0, 1, 0, 0],
                [0, 1, 0, 0],
                [0, 0, 0, 0]
            ],
            "matchSplitDataList": [],
            "roundBonus": 0,
            "roundMul": 2,
            "scatterWin": false,
            "totalBasic": 0,
            "wheelEle": [
                [5, 8, 8, 3],
                [1, 1, 7, 3],
                [5, 1, 5, 8],
                [8, 5, 8, 2],
                [4, 7, 5, 8]
            ]
        }],
        "timesBonus": 0,
        "timesIsFree": true
    },
    {
        "roundDataVoList": [{
            "bonusDataList": [],
            "currentRound": 1,
            "eleType": [
                [0, 0, 0, 0],
                [0, 0, 0, 2],
                [1, 0, 0, 0],
                [0, 0, 0, 1],
                [0, 0, 0, 0]
            ],
            "matchSplitDataList": [],
            "roundBonus": 0,
            "roundMul": 2,
            "scatterWin": false,
            "totalBasic": 0,
            "wheelEle": [
                [3, 2, 3, 8],
                [7, 5, 1, 9],
                [3, 1, 1, 1],
                [7, 3, 7, 4],
                [8, 6, 4, 7]
            ]
        }],
        "timesBonus": 0,
        "timesIsFree": true
    },
    {
        "roundDataVoList": [{
            "bonusDataList": [],
            "currentRound": 1,
            "eleType": [
                [0, 0, 0, 0],
                [0, 1, 0, 0],
                [0, 0, 0, 0],
                [0, 0, 1, 1],
                [0, 0, 0, 0]
            ],
            "matchSplitDataList": [],
            "roundBonus": 0,
            "roundMul": 2,
            "scatterWin": false,
            "totalBasic": 0,
            "wheelEle": [
                [7, 1, 8, 7],
                [2, 6, 5, 3],
                [6, 4, 4, 8],
                [1, 6, 1, 7],
                [8, 6, 5, 8]
            ]
        }],
        "timesBonus": 0,
        "timesIsFree": true
    },
    {
        "roundDataVoList": [{
            "bonusDataList": [{
                "bonus": 0.3,
                "winEle": 6,
                "winEleLoc": [[0, 1], [0], [3], [], [3]
                ]
            }],
            "currentRound": 1,
            "eleType": [
                [0, 0, 0, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 0],
                [0, 0, 2, 0],
                [0, 0, 0, 0]
            ],
            "matchSplitDataList": [],
            "roundBonus": 0.6,
            "roundMul": 2,
            "scatterWin": false,
            "totalBasic": 0.3,
            "wheelEle": [
                [6, 6, 5, 2],
                [6, 7, 8, 8],
                [5, 1, 7, 6],
                [7, 4, 9, 4],
                [7, 5, 8, 6]
            ]
        }, {
            "bonusDataList": [],
            "currentRound": 2,
            "eleType": [
                [0, 0, 0, 0],
                [1, 0, 0, 0],
                [0, 0, 0, 0],
                [0, 0, 2, 0],
                [0, 0, 0, 0]
            ],
            "matchSplitDataList": [],
            "roundBonus": 0,
            "roundMul": 4,
            "scatterWin": false,
            "totalBasic": 0,
            "wheelEle": [
                [8, 6, 5, 2],
                [1, 7, 8, 8],
                [5, 1, 7, 7],
                [7, 4, 9, 4],
                [7, 5, 8, 4]
            ]
        }],
        "timesBonus": 0.6,
        "timesIsFree": true
    },
    {
        "roundDataVoList": [{
            "bonusDataList": [],
            "currentRound": 1,
            "eleType": [
                [0, 2, 0, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 0]
            ],
            "matchSplitDataList": [],
            "roundBonus": 0,
            "roundMul": 2,
            "scatterWin": false,
            "totalBasic": 0,
            "wheelEle": [
                [1, 9, 1, 7],
                [8, 1, 1, 1],
                [5, 8, 7, 6],
                [6, 7, 1, 2],
                [2, 6, 6, 3]
            ]
        }],
        "timesBonus": 0,
        "timesIsFree": true
    },
    {
        "roundDataVoList": [{
            "bonusDataList": [{
                "bonus": 0.3,
                "winEle": 4,
                "winEleLoc": [[3], [0], [2], [3], []
                ]
            }],
            "currentRound": 1,
            "eleType": [
                [0, 0, 0, 0],
                [0, 0, 0, 0],
                [1, 0, 0, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 0]
            ],
            "matchSplitDataList": [],
            "roundBonus": 0.6,
            "roundMul": 2,
            "scatterWin": false,
            "totalBasic": 0.3,
            "wheelEle": [
                [1, 7, 8, 4],
                [4, 2, 7, 6],
                [5, 6, 4, 5],
                [6, 5, 7, 4],
                [7, 2, 1, 5]
            ]
        }, {
            "bonusDataList": [],
            "currentRound": 2,
            "eleType": [
                [0, 0, 0, 0],
                [0, 0, 0, 0],
                [1, 0, 0, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 0]
            ],
            "matchSplitDataList": [],
            "roundBonus": 0,
            "roundMul": 4,
            "scatterWin": false,
            "totalBasic": 0,
            "wheelEle": [
                [1, 7, 8, 2],
                [3, 2, 7, 6],
                [5, 6, 6, 5],
                [6, 5, 7, 2],
                [7, 2, 1, 5]
            ]
        }],
        "timesBonus": 0.6,
        "timesIsFree": true
    }
]
var timesDataList1: Array<TimesDataVo> = [
    {
        "roundDataVoList": [
            {
                "bonusDataList": [
                    {
                        "bonus": 0.25,
                        "winEle": 1,
                        "winEleLoc": [[2], [3], [1], [0, 1], [3]]
                    }
                ],
                "currentRound": 1,
                "eleType": [[0, 0, 0, 0], [0, 0, 1, 0], [0, 1, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]],
                "matchSplitDataList": [],
                "roundBonus": 0.25,
                "roundMul": 1,
                "scatterWin": false,
                "totalBasic": 0.25,
                "wheelEle": [[2, 8, 1, 2], [2, 2, 6, 1], [5, 1, 8, 7], [1, 1, 3, 6], [7, 8, 3, 1]]
            },
            {
                "bonusDataList": [
                    {
                        "bonus": 0.15,
                        "winEle": 2,
                        "winEleLoc": [[0, 3], [0, 1], [0, 1], [2], []]
                    },
                    {
                        "bonus": 2.5,
                        "winEle": 8,
                        "winEleLoc": [[1, 2], [1], [0, 1, 2], [2], [1]]
                    }
                ],
                "currentRound": 2,
                "eleType": [[0, 0, 0, 0], [0, 0, 1, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]],
                "matchSplitDataList": [
                    {
                        "column": 2,
                        "list": [
                            { "column": 2, "row": 0 },
                            { "column": 3, "row": 2 },
                            { "column": 1, "row": 1 }
                        ],
                        "row": 1
                    }
                ],
                "roundBonus": 5.3,
                "roundMul": 2,
                "scatterWin": false,
                "totalBasic": 2.65,
                "wheelEle": [[2, 8, 8, 2], [2, 10, 6, 6], [10, 10, 8, 7], [1, 6, 10, 6], [7, 8, 3, 4]]
            },
            {
                "bonusDataList": [],
                "currentRound": 3,
                "eleType": [[0, 0, 0, 0], [0, 0, 1, 0], [1, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]],
                "matchSplitDataList": [],
                "roundBonus": 0,
                "roundMul": 3,
                "scatterWin": false,
                "totalBasic": 0,
                "wheelEle": [[8, 5, 8, 8], [1, 5, 6, 6], [4, 7, 8, 7], [1, 6, 7, 6], [7, 5, 3, 4]]
            }
        ],
        "timesBonus": 5.55,
        "timesIsFree": false
    }
]

var betting = {
    "after": 6993226.85,
    "mulEle": 0,
    "scatter": 0,
    "spacial": 0,
    "timesDataList": timesDataList1,
    "totalBonus": 25.1
}



export default class ridCrushModel extends Singleton {

    static get Instance() {
        return super.GetInstance<ridCrushModel>();
    }
    public amount: number = 0.3;
    /** 余额 */
    public after: number = 0;
    /** 本次总奖金 */
    public totalBonus: number = 0;
    /** 总数据 */
    public timesDataList: Array<TimesDataVo> = [];
    /** 当前回合 */
    public currentRound: number = 0;
    /** 总回合 */
    public totalRound: number = 0;
    /** 小回合 */
    public round: number = 0;
    /** 移除索引数组 */
    removeIndexArr: Array<number> = [];
    /** 移除索引 */
    removeIndex: number = 0;
    /** 是否免费 */
    isFree: boolean = false;
    /**
     * 初始化移除索引
     */
    initRemoveIndex() {
        this.removeIndex = 0;
        this.removeIndexArr = [];
    }
    /**
     * 初始化
     */
    init() {
        this.setbettingData(betting);
    }
    /**
     * 获取下注数据
     * @param data 
     */
    setbettingData(data) {
        console.log(data)
        this.round = 0;
        this.currentRound = 0;
        AccountModel.Instance.balance = data.after;
        this.totalBonus = data.totalBonus;
        this.timesDataList = data.timesDataList;
        this.totalRound = this.timesDataList.length;
        // let isShow = false;
        // for (let i = 0; i < this.timesDataList.length; i++) {
        //     let date = this.timesDataList[i];
        //     for (let k = 0; k < date.roundDataVoList.length; k++) {
        //        let date1 = date.roundDataVoList[k];
        //        if(date1.matchSplitDataList.length!=0){
        //         isShow = true;
        //         break;
        //        }
        //     }
        // }
        // if(isShow == false)HallReqManager.sendBetting(ridCrushModel.Instance.amount);
    }
    /** 
     * 当前回合数据
     */
    getTimesData(): TimesDataVo {
        try {

            return this.timesDataList[this.currentRound]
        } catch (error) {
            return null;
        }
    }
    /**
     * 1
     * @returns 
     */
    getRoundData(): RoundDataVo {
        try {
            return this.timesDataList[this.currentRound].roundDataVoList[this.round];
        } catch (error) {
            return null;
        }

    }
    /** 
     * 1
    */
    getScatterWin(): boolean {
        try {
            let data = this.getRoundData();
            return data.scatterWin;
        } catch (error) {
            return false;
        }
    }
    /**
     * 1
     * @param x 
     * @param y 
     * @returns 
     */
    getWheelEle(x, y) {

        try {
            let data = this.getRoundData();
            return data.wheelEle[x][y]
        } catch (error) {
            return null;
        }
    }
    /** 
     * 获取元素类型
    */
    getEleType(x, y) {

        try {
            let data = this.getRoundData();
            return data.eleType[x][y]
        } catch (error) {
            return null;
        }

    }
    /** 
     * 获取位置
    */
    static getPosition(value: number, spacing: number = 0, isHor: boolean = false): Vec3 {
        if (isHor == true) {
            let width = cardPool.Instance.width + spacing;
            let posX = 0 - width / 2 + (value * width);
            return v3(posX, 0);
        } else {
            let height = cardPool.Instance.height + spacing;
            let posY = 0 - height / 2 - (value * height);
            return v3(0, posY);
        }
    }
    /** 当前回合 */
    isCalculateFenlie(index, value: number = 0): boolean {
        try {
            let data = this.getTimesData();
            let date: RoundDataVo = data.roundDataVoList[this.round + value];
            console.log(this.round, value)
            if (date.matchSplitDataList.length == 0) return false;
            let arr = [];
            for (let i = 0; i < date.matchSplitDataList.length; i++) {
                let date1 = date.matchSplitDataList[i];
                let index = date1.row + date1.column * Constant.layHor;
                if (arr.indexOf(index) == -1) {
                    arr.push(index);
                }
                for (let k = 0; k < date1.list.length; k++) {
                    let date2 = date1.list[k];
                    let index1 = date2.row + date2.column * Constant.layHor;
                    if (arr.indexOf(index1) == -1) {
                        arr.push(index1);
                    }
                }
            }
            console.log("kkk", arr, index)
            return arr.indexOf(index) != -1;
        } catch (error) {
            return false;
        }
    }
}

