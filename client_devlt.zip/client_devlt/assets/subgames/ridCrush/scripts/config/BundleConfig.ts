import { AudioClip, Prefab, SpriteFrame } from "cc";
import { BundleConfig, EnumBundle } from "../../../../scripts/config/BundleConfig";
//
export enum EnumPrefab {
    cardItem = "cardItem",
    bigWinUI = "bigWinUI"
    // end
}
//
BundleConfig.bundleAssets.set(EnumPrefab.cardItem, {
    ABName: EnumBundle.ridCrush,
    is_sub_game: false,
    name: EnumPrefab.cardItem,
    path: "prefabs/comm/cardItem"
});
//
BundleConfig.bundleAssets.set(EnumPrefab.bigWinUI, {
    ABName: EnumBundle.ridCrush,
    is_sub_game: false,
    name: EnumPrefab.bigWinUI,
    path: "prefabs/ui/bigWinUI"
});
//
BundleConfig.bundlePrepkg.set(EnumBundle.ridCrush, {
    ABName: EnumBundle.ridCrush,
    src: [{
        assetType: Prefab, isLoadAll: true, path: "prefabs/"
    }, {
        assetType: SpriteFrame, isLoadAll: true, path: "texture/cards/"
    }, {
        assetType: AudioClip, isLoadAll: true, path: "sounds/"
    }]
})