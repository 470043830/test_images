import { Label, Quat, tween, Tween, UIOpacity, UITransform } from 'cc';
import { BaseUI } from '../framework/base/BaseUI';
import { ToastMgr } from '../framework/manager/ToastMgr';
import { StringUtils } from '../framework/utils/StringUtils';

export interface IToastMsg {
    /** 倒计时 */
    time: number;
    /** 消息内容 */
    msg: string;
    /** 窗体名字 */
    name: string;
}

export class ToastView extends BaseUI {
    /** */
    private timer: number = null;
    /** */
    private isShow: boolean = false;

    /** 界面数据初始化 */
    initData() {

    }

    /** 界面视图初始化 */
    initView() {
        let str = StringUtils.truncate(this.viewParam.data.msg, 15)
        this.Items.lbMsg.getComponent(Label).string = str;
        this.Items.lbMsg.getComponent(Label).updateRenderData();
        const textWidth = this.Items.lbMsg.getComponent(UITransform).width;
        this.node.getComponent(UITransform).width = textWidth + 300;
        this.node.getComponent(UIOpacity).opacity = 255;
        this.playTween();
    }

    /** 界面语言初始化 */
    initLanguage() {

    }

    /** 界面事件绑定 */
    bindEventListener() {

    }

    /** */
    public updateOpacity(index) {
        if (this.isShow == false) {
            this.node.getComponent(UIOpacity).opacity = 255 - index * 50;
        }
    }

    /** */
    public onPut() {
        Tween.stopAllByTarget(this.node);
        this.node.setRotation(Quat.IDENTITY); // {x:0, y:0, z:0, w:1}
        this.node.destroy();
    }

    /** */
    private playTween() {
        tween(this.node.getComponent(UIOpacity))
            .delay(1)
            .call(() => {
                this.isShow = true;
            })
            .to(0.3, { opacity: 0 }, { easing: "fade" })
            .call(() => {
                ToastMgr.Instance.onPop();
            })
            .start();
    }
}
