import { Label, ProgressBar } from "cc";
import { EnumBundle, EnumScene } from "../config/BundleConfig";
import { BaseUI } from "../framework/base/BaseUI";
import { ResMgr } from "../framework/manager/ResMgr";
import { TimerMgr } from "../framework/manager/TimeMgr";
import EventMgr from "../framework/event/EventMgr";
import { SYS_EVENT } from "../framework/event/EventDefine";

export class LoadingView extends BaseUI {
    /** */
    timerId: number;
    /** */
    list: Array<EnumBundle> = [];

    /** 界面数据初始化 */
    initData() {

    }

    /** 界面视图初始化 */
    initView() {
        // this.timerId = TimerMgr.Instance.Schedule(this.toRock.bind(this), 5)
        // this.Items.btnContinue.active = true;
        // this.Items.lbPro.active = false;

        this.laodRes();
    }

    /** 界面语言初始化 */
    initLanguage() {

    }

    /** 界面事件绑定 */
    bindEventListener() {
        super.bindEventListener();
        // this.addButtonListener("btnLeft", this.onRightClick, this);
        // this.addButtonListener("btnRight", this.onLeftClick, this);
        // this.addButtonListener("btnContinue", this.onBtnContiue, this);
    }

    /** 界面销毁 */
    OnDestroy() {
        if (this.timerId != null) {
            TimerMgr.Instance.Unschedule(this.timerId);
            this.timerId = null;
        }
    }

    /** 界面继续 */
    // onBtnContiue() {
    laodRes() {
        console.log("start game...");
        // this.Items.btnContinue.active = false;
        this.Items.lbPro.active = true;
        this.setPrecent(0);
        console.log("resList: " + this.list);
        ResMgr.Instance.preLoadPkgRes(this.list, (now, total) => {
            this.setPrecent(now / total);
        }, async () => {
            console.log("game loaded.")
            this.setPrecent(1);
            // 资源预加载完成

            // await TimerMgr.Instance.delayTime(0.3);
            EventMgr.Instance.emit(SYS_EVENT.LOADGAME_FINISH);
        })
    }

    // /** 右边点击 */
    // onRightClick() {
    //     if (this.timerId != null) {
    //         TimerMgr.Instance.Unschedule(this.timerId);
    //         this.timerId = null;
    //     }
    //     this.Items.scrollView.getComponent(ScrollView).scrollToRight(0.5);
    //     this.timerId = TimerMgr.Instance.Schedule(this.toRock.bind(this), 5)
    // }

    // /** 左边点击 */
    // onLeftClick() {
    //     if (this.timerId != null) {
    //         TimerMgr.Instance.Unschedule(this.timerId);
    //         this.timerId = null;
    //     }
    //     this.Items.scrollView.getComponent(ScrollView).scrollToLeft(0.5);
    //     this.timerId = TimerMgr.Instance.Schedule(this.toRock.bind(this), 5)

    // }

    /** */
    // toRock() {
    //     let v2 = this.Items.scrollView.getComponent(ScrollView).getScrollOffset();
    //     if (v2.x < -200) {
    //         this.Items.scrollView.getComponent(ScrollView).scrollToLeft(0.5);
    //     } else {
    //         this.Items.scrollView.getComponent(ScrollView).scrollToRight(0.5);
    //     }
    // }

    /** */
    public showResult(list: Array<EnumBundle>) {
        this.list = list;
    }

    /** */
    public ShowAnim(flag_: boolean = true) {
        this.node.active = flag_;
    }

    /** */
    public showPercent(percent) {
        this.setPrecent(percent / 100)
    }

    /** */
    private setPrecent(percent: number): void {
        let num = Math.ceil(percent * 100);
        this.Items.lbPro.getComponent(Label).string = `${num}%`;
        this.Items.lbSize.getComponent(Label).string = `0.0MB`;
        this.Items.ProgressBar.getComponent(ProgressBar).progress = percent;

    }
}
