import * as cc from 'cc';
const { ccclass, property } = cc._decorator;

/**
 * 
 * Waiting
 * Waiting
 * chonger8888
 * Mon Sep 29 2025 19:45:57 GMT+0800 (中国标准时间)
 * Waiting.ts
 * Waiting
 * <%URL%>
 * https://docs.cocos.com/creator/3.8/manual/zh/
 *
 */

@ccclass('Waiting')
export class Waiting extends cc.Component {
    @property({ type: cc.Node, tooltip: "动画节点" })
    animNode: cc.Node = null;

    onLoad() {
        cc.tween(this.animNode)
            .repeatForever(
                cc.tween(this.animNode)
                    .to(0.5, { scale: cc.v3(0, 1, 1) }, { easing: cc.easing.sineOut })
                    .delay(0.2)
                    .to(0.5, { scale: cc.v3(1, 1, 1) }, { easing: cc.easing.sineOut })
            )
            .start()
    }
}