import { _decorator } from 'cc';
import { BaseUI } from '../framework/base/BaseUI';
import { TimerMgr } from '../framework/manager/TimeMgr';
import { Logger } from '../framework/utils/Logger';
import { GameApp } from '../lobby/GameApp';

const { ccclass, property } = _decorator;

@ccclass('NetworkMaskView')
export class NetworkMaskView extends BaseUI {
    /** */
    private timer: number = null;

    /** 界面数据初始化 */
    initData() {

    }

    /** 界面视图初始化 */
    initView() {
        // let node:Node = this.node;
        //
    }

    /** 界面语言初始化 */
    initLanguage() {

    }

    /** 界面事件绑定 */
    bindEventListener() {
        super.bindEventListener();
    }

    /** 界面销毁 */
    OnDestroy() {
        if (this.timer != null) {
            TimerMgr.Instance.Unschedule(this.timer);
            this.timer = null;
        }
    }

    /** */
    public showResult() {

    }

    /** */
    public ShowAnim(flag_: boolean) {
        this.node.active = flag_;
        if (flag_ == false) {
            Logger.info("关闭网络遮罩")
            if (this.timer != null) {
                TimerMgr.Instance.Unschedule(this.timer);
                this.timer = null;
            }
            //
            this.Items.nodeAnimation.active = false;
        } else if (flag_ == true) {
            this.node.setSiblingIndex(GameApp.Instance.MyAppLayer.children.length - 1);
            Logger.info("打开网络遮罩")
            if (this.timer != null) {
                TimerMgr.Instance.Unschedule(this.timer);
                this.timer = null;
            }
            //
            this.timer = TimerMgr.Instance.ScheduleOnce(() => {
                if (this.Items.nodeAnimation)
                    this.Items.nodeAnimation.active = true;
            }, 3);
        }
    }
}

