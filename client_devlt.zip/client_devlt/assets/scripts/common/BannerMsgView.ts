import { RichText, UITransform } from "cc";
import { BaseUI } from "../framework/base/BaseUI";
import ArrayQueue from "../framework/queue/ArrayQueue";

interface IBannerMsg {
    times?: number;
    msg: string,
}

export class BannerMsgView extends BaseUI {
    /**公告数组
     *notices 公告数组每个元素结构是{content,priority,times} content:string,     priority:number,times:number  文本内容，优先级，重复次数
     */
    private notices: object[] = [];
    //
    private speed: number = 150;
    //
    private index: number = 0;
    //
    private msgQueue: ArrayQueue<IBannerMsg> = new ArrayQueue<IBannerMsg>();
    //
    private lbMsgText: RichText = null;
    //
    private maskTran: UITransform = null;

    /** 界面数据初始化 */
    initData() {
        this.index = 0;
    }

    /** 界面视图初始化 */
    initView() {
        this.lbMsgText = this.Items.lbMsg!.getComponent(RichText);
        this.lbMsgText.string = "";
        this.maskTran = this.Items.mask!.getComponent(UITransform);
    }

    /** 界面语言初始化 */
    initLanguage() {

    }

    /** 界面事件绑定 */
    bindEventListener() {
        super.bindEventListener();
    }

    /** 界面销毁 */
    OnDestroy() {

    }

    /**更新广播 */
    pushOne(content: string, times: number = 1, priority: number = 0) {
        this.msgQueue.push({ times: times, msg: content });
    }

    /*** */
    nextOne() {
        if (this.msgQueue.isEmpty()) {
            return;
        }
        let msg = this.msgQueue.peek();
        if (msg.element.times >= 1) {
            msg.element.times--;
            let pos = this.Items.lbMsg.getPosition();
            this.Items.lbMsg.setPosition(this.maskTran.contentSize.width / 2, pos.y);
            this.lbMsgText.string = msg.element.msg;
            if (msg.element.times == 0) {
                this.msgQueue.pop();
            }
        }
    }

    /** */
    clearAll() {
        this.index = 0;
        this.notices = [];
    }

    /** */
    update(dt) {
        let pos = this.Items.lbMsg.getPosition();
        let contentSize = this.Items.lbMsg.getComponent(UITransform).contentSize;
        this.Items.lbMsg.setPosition(pos.x - this.speed * dt, pos.y);
        if (this.Items.lbMsg.getPosition().x <= -this.maskTran.contentSize.width / 2 - contentSize.width) {
            this.nextOne();
        }
    }
}
