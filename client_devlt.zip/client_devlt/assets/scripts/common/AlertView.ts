import { Label, RichText, v3, Vec3 } from 'cc';
import { DialogView } from '../framework/base/DialogView';

export enum EnumAlertStyle {
    /** 确认取消关闭 */
    confirm_cancel_close,
    /** 确认取消 */
    confirm_cancel,
    /** 确认关闭 */
    confirm_close,
    /** 取消 */
    confirm
}

export interface IAlertMsg {
    /** 弹窗模式 */
    style?: EnumAlertStyle,
    /** 倒计时 */
    time?: number;
    /** 消息内容 */
    msg: string;
    /** 行高 */
    lineHeight: number;
    /** 窗体名字 */
    name?: string;
    /** 右侧按钮回调 */
    right_callback?: Function;
    /** 左侧按钮回调 */
    left_callback?: Function;
    /** 关闭回调 */
    close_callback?: Function;
    /** 标题 */
    title?: string;
    /** 确认文字 */
    conRihth_str?: string;
    /** 取消文字 */
    canLeft_str?: string;
    /** 是否允许点击透明区域关闭 */
    isMaskClose: boolean;
}

export class AlertView extends DialogView {
    private timer: number = null;
    private conRight_pos: Vec3;
    private canLeft_pos: Vec3;

    /** 界面数据初始化 */
    initData() {

    }

    /** 界面视图初始化 */
    initView() {
        this.hideClick();
        this.conRight_pos = this.Items.btnRight.getPosition();
        this.canLeft_pos = this.Items.btnLeft.getPosition();
        this.Items.nodeOnClick.active = !this.viewParam.data.isMaskClose;

        let time = this.viewParam.data.time || 0;
        this.Items.lbMsg.getComponent(RichText).lineHeight = this.viewParam.data.lineHeight;
        this.Items.lbMsg.getComponent(RichText).string = this.viewParam.data.msg;
        if (0 < time) {
            this.timer = this.ScheduleOnce(() => {
                if (this.viewParam.data.close_callback) {
                    this.viewParam.data.close_callback();
                }
                this.onClose();
            }, time);
        }
        //
        let style = this.viewParam.data.style || EnumAlertStyle.confirm_cancel_close;
        this.Items.lbTitle.getComponent(Label).string = this.viewParam.data.title || "Tips";
        switch (style) {
            case EnumAlertStyle.confirm_cancel_close:
                this.Items.btnLeft.active = true;
                this.Items.btnRight.active = true;
                this.Items.btnClose.active = true;
                this.Items.btnRight.setPosition(this.conRight_pos);
                this.Items.btnLeft.setPosition(this.canLeft_pos);
                break;
            case EnumAlertStyle.confirm_cancel:
                this.Items.btnLeft.active = true;
                this.Items.btnRight.active = true;
                this.Items.btnClose.active = false;
                this.Items.btnRight.setPosition(this.conRight_pos);
                this.Items.btnLeft.setPosition(this.canLeft_pos);

                break;
            case EnumAlertStyle.confirm_close:
                this.Items.btnLeft.active = false;
                this.Items.btnRight.active = true;
                this.Items.btnClose.active = true;
                this.Items.btnRight.setPosition(v3(0, this.conRight_pos.y));
                break;
            case EnumAlertStyle.confirm:
                this.Items.btnLeft.active = false;
                this.Items.btnRight.active = true;
                this.Items.btnClose.active = false;
                this.Items.btnRight.setPosition(v3(0, this.conRight_pos.y));
                break;
        }
        this.setBtnName(this.Items.btnLeft, this.viewParam.data.canLeft_str || "Cancel");
        this.setBtnName(this.Items.btnRight, this.viewParam.data.conRihth_str || "Confirm");
    }

    /** 界面语言初始化 */
    initLanguage() {
        // this.Items.lbLeft.getComponent(Label).string = "Cancel";
        // this.Items.lbRight.getComponent(Label).string = "Confirm";

    }

    /** 界面事件绑定 */
    bindEventListener() {
        super.bindEventListener();
        this.addButtonListener("btnLeft", () => {
            if (this.viewParam.data.left_callback) {
                this.viewParam.data.left_callback();
            }

        }, this);
        this.addButtonListener("btnRight", () => {
            if (this.viewParam.data.right_callback) {
                this.viewParam.data.right_callback();
            }

        }, this);
        this.addButtonListener("btnClose", () => {
            if (this.viewParam.data.close_callback) {
                this.viewParam.data.close_callback();
            }
            this.onClose();
        }, this);
    }

    /** 界面销毁 */
    OnDestroy() {

    }
}
