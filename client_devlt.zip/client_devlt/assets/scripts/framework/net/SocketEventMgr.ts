import { _decorator, Component } from 'cc';
import { TimerMgr } from '../manager/TimeMgr';
import { Logger } from '../utils/Logger';
import EventMgr from '../event/EventMgr';
import { NET_EVENT, TYPE_NET_WORK_STATUS } from '../event/EventDefine';
import SocketMgr from './SocketMgr';
import { Writer, Reader } from "protobufjs";
import { EnumServiceType, Messages, ProParam } from './Messages';
import ProtoMgr from './ProtoMgr';
import * as pb from '../../protobuf/pb.js';
import MessageRespHandler from './MessageRespHandler';
import AccountModel from '../../model/AccountModel';
import { ToastMgr } from '../manager/ToastMgr';


const { ccclass, property } = _decorator;

/**
 * 消息数据结构
 */
interface NetRecvData {
    nMsgID: number,
    // name: number,
    code: number,
    data: any
}

/** 网络事件管理*/
@ccclass('SocketEventMgr')
export class SocketEventMgr extends Component {
    //
    public static Instance: SocketEventMgr = null as unknown as SocketEventMgr;
    //
    timer: number = null;
    /** 网络延时重新请求时间 */
    time: number = 5;
    /** 重读发送接口数据 */
    sendData: Map<number, { timer: number, isShow: boolean }> = new Map<number, { timer: number, isShow: boolean }>();
    /** 待分发数据 */
    netMessList: Array<NetRecvData> = [];

    //
    private _isDistribution: boolean = true;

    /** 是否允许分发 */
    public get isDistribution(): boolean {
        return this._isDistribution;
    }

    /**
     *
     * @returns
     */
    onLoad(): void {
        if (SocketEventMgr.Instance === null) {
            SocketEventMgr.Instance = this;
            // this.timer = TimerMgr.Instance.Schedule(this.execute.bind(this), 1 / 60);
        } else {
            this.destroy();
            return;
        }
    }

    /** 
     * 发送消息
    */
    sendMessages(code, msg: any = null): Uint8Array {
        if (!SocketMgr.Instance.isConnected()) {
            return;
        }

        Logger.net("请求ID号 ====> " + code, JSON.stringify(msg));
        //处理数据加密start
        let vecMsgData: Uint8Array[] = [];
        let proParam: ProParam = Messages.get(code);
        if (msg != null) {
            let proto = ProtoMgr.Instance.getPbByName(proParam.pbFile, proParam.name);
            vecMsgData = [proto.encode(msg).finish()];
        }

        //消息头
        let vecMsgHead: pb.XGameComm.TMsgHead = {
            nMsgID: code,
            nMsgType: pb.XGameComm.MSGTYPE.MSGTYPE_REQUEST,
            serviceType: proParam ? proParam.type : EnumServiceType.LOGIN,
            nResultID: 0
        };

        let message = pb.XGameComm.TPackage.create({
            iVersion: 123,   //客户端版本
            stUid: {
                lUid: AccountModel.Instance.userId,    //用户id
                sToken: AccountModel.Instance.token,  //用户token
            },   //用户标识
            iGameID: 0,   //游戏ID
            sRoomID: "0",   //RoomID
            iRoomServerID: 0,   //RoomServerID
            iSequence: 0,   //序列号
            iFlag: 0,   //标志位
            vecMsgHead: [vecMsgHead],   //消息头数据
            iActiveCount: 0,  //当前连接活跃次数
            vecMsgData: vecMsgData,   //消息体数据
        });

        let msgBuff = pb.XGameComm.TPackage.encode(message).finish();
        var buf = new ArrayBuffer(2);
        let dataView = new DataView(buf); // 创建2字节的数据视图
        let byteLength = msgBuff.length + 2;
        // 设置数据长度到数据视图
        dataView.setUint16(0, byteLength, false); // 写入数据长度，小端字节序
        // 合并头部和消息数据
        let combined = new Uint8Array(2 + msgBuff.length);
        combined.set(new Uint8Array(dataView.buffer)); // 设置头部数据
        combined.set(msgBuff, 2); // 设置protobuf消息数据

        return combined;//combined;
    }

    /** 
     * 接收数据
    */
    public onRecvData<T>(param_: T) {
        let tdata = param_["data"];
        // 直接根据pb网关协议解出网关包体
        let uint8Buf: Uint8Array = new Uint8Array(tdata);
        // Logger.info(`收到的字节`, tdata);
        let newUint8 = uint8Buf.subarray(2);
        let message = pb.XGameComm && pb.XGameComm.TPackage && pb.XGameComm.TPackage.decode(newUint8);
        let vecMsgHead = message.vecMsgHead[0];
        let nMsgID = vecMsgHead.nMsgID;
        let nMsgType = vecMsgHead.nMsgType;
        let serviceType = vecMsgHead.serviceType;
        let nResultID = vecMsgHead.nResultID;
        // end

        // Logger.net("接受消息 message ===>>>", message);
        // Logger.net("接受消息 nMsgID ===>>>" + nMsgID + " code状态 nResultID   ===>>> " + nResultID);
        //根据规则解析数据包数据
        let proParam = Messages.get(nMsgID);
        let data = null;
        if (proParam == null) {
            Logger.warning("网络协议没有解析规则")
            // this.decodeMsg(nMsgID, nResultID, data);
            // this.execute();
            return;
        }

        if (nResultID != 0) {
            //统一处理错误码
            ToastMgr.Instance.onRecvToast({ msg: `服务器错误:${nResultID}` });
        }

        //
        if (nMsgID == pb.XGameComm.Eum_Comm_Msgid.E_MSGID_KEEP_ALIVE_RESP) {
            //心跳包接口直接json转译
            data = this.arrayBufferToJson(message.vecMsgData[0]);
            // this.closeWeakNetTimer();
            // EventMgr.Instance.emit(NET_EVENT.ON_RECV_DATA, { cmd: nMsgID, name: nMsgID, param: { code: nResultID, param: data } });
            MessageRespHandler.Instance.dispatch(nMsgID, nResultID, data);
        } else {
            if (proParam.name != "") {
                //使用pb协议解析二进制数据
                let uint8Buf: Uint8Array = new Uint8Array(message.vecMsgData[0]);
                data = ProtoMgr.Instance.decode(proParam.pbFile + "." + proParam.name, uint8Buf);
                Logger.net(`${proParam.prompt}: ===>>> `, `nMsgID: ${nMsgID}, ` + JSON.stringify(data));
            }
            //如果发送sendID存在就注销重复请求定时器
            // this.closeSendMsgTimer(ProParam);
            // this.decodeMsg(nMsgID, nResultID, data);
            // this.execute();

            MessageRespHandler.Instance.dispatch(nMsgID, nResultID, data);
        }
    }

    /**
     * 发送消息
     */
    public sendMsg(code, msg: any = null) {
        if (SocketMgr.Instance.netWorkStatus != TYPE_NET_WORK_STATUS.two) {
            Logger.error(`网络未连接，发送数据失败`);
            return;
        }

        let combined = this.sendMessages(code, msg);
        // if (SocketMgr.Instance.netWorkType != NETWORK_TYPE.Weak) {
        //     /** 网络重发有特殊的数据结构 */
        //     this.createSendMsgTimer(code, combined);
        //     if (SocketMgr.Instance.netWorkStatus == TYPE_NET_WORK_STATUS.two) {
        //         this.createWeakNetTimer(code);
        //         if (this.weakNetWorkType == TYPE_NET_WRAKWORK.two) {
        //             this.weakNetWorkType = TYPE_NET_WRAKWORK.three;
        //             EventMgr.Instance.emit(SYS_EVENT.NET_NETERROR, { type: Type_NET_NETERROR.one });
        //         }
        //     } else {
        //         //网络断开执行断线重连逻辑
        //         if (SocketMgr.Instance.netWorkStatus == TYPE_NET_WORK_STATUS.three) {
        //             SocketMgr.Instance.netWorkStatus = TYPE_NET_WORK_STATUS.four;
        //             ReLoginProxy.Instance.reconnect();
        //         }
        //     }
        // }
        // if (SocketMgr.Instance.netWorkStatus == TYPE_NET_WORK_STATUS.two) {
        //     if (code == EnumCodeID.LoginReq || (code != EnumCodeID.LoginReq && SocketMgr.Instance.isLogin == true))
        // }
        SocketMgr.Instance.sendData(combined);
    }

    /**
     * code错误码处理消息分发处理
     * @param nMsgID 接口消息号
     * @param code 错误码
     * @param data 数据
     * @returns
     */
    private decodeMsg(nMsgID, code, data: any) {
        // this.netMessList.push({ nMsgID: nMsgID, name: nMsgID, code: data.payload.code, data: data.payload })
        this.netMessList.push({ nMsgID: nMsgID, code: code, data: data })
    }

    /**
     * 数据直接json转换解析
     */
    private arrayBufferToJson(arrayBuffer) {
        var view = new Uint8Array(arrayBuffer);
        var chars = new Array();
        for (var i = 0; i < view.length; i++) {
            chars.push(String.fromCharCode(view[i]));
        }
        //
        var str = chars.join('');
        try {
            return JSON.parse(str);
        } catch (e) {
            Logger.warning('Parsing error:', e);
            return null;
        }
    }

    /**
     * 网络分发中转处理
     */
    private async execute() {
        if (this.isDistribution == false) {
            return;
        }
        //网络断开执行断线重连逻辑
        if (SocketMgr.Instance.netWorkStatus == TYPE_NET_WORK_STATUS.three) {
            SocketMgr.Instance.netWorkStatus = TYPE_NET_WORK_STATUS.four;
            // ReLoginProxy.Instance.reconnect();
            // var tview: Node = await UIMgr.Instance.showView(EnumPrefab.reconnect, null, GameApp.Instance.MyAppLayer, EnumPrefab.reconnect, false);
            // tview.addComponent(ReconnectView);
        }
        //执行网络中转分发
        if (this.netMessList.length == 0) {
            return;
        }
        //
        let netRecvDataArray: Array<NetRecvData> = this.netMessList.splice(0, 1); // 从 index 处开始删除一个元素
        let netRecvData: NetRecvData = netRecvDataArray[0]
        if (netRecvData.nMsgID != 0) {
            Logger.net("中转消息分发 nMsgID ===>>>" + netRecvData.nMsgID + " code状态 nResultID   ===>>> " + netRecvData.code);
        }
        //
        Logger.net("data 数据 =======> " + JSON.stringify(netRecvData.data));
        EventMgr.Instance.emit(NET_EVENT.ON_RECV_DATA, netRecvData);
    }
}
