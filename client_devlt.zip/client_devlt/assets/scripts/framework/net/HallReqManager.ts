import { _decorator } from 'cc';
import { SocketEventMgr } from './SocketEventMgr';
import { EnumCodeID } from './Messages';
import { LobbyProto, PlatformProto } from '../../protobuf/pb.js';
import AccountModel from '../../model/AccountModel';

const { ccclass, property } = _decorator;

@ccclass('HallReqManager')
export class HallReqManager {
    /**
     * 登陆
     */
    public static sendLogin() {
        SocketEventMgr.Instance.sendMsg(EnumCodeID.LoginReq,);
    }

    /**
     * 心跳
     */
    public static sendHeartbeat() {
        SocketEventMgr.Instance.sendMsg(EnumCodeID.HeartbeatReq);
    }

    /**
     * 请求用户信息
     */
    public static sendUserInfo() {
        let data = new PlatformProto.GetPlatformAccountDetailReq();
        data.lPid = AccountModel.Instance.userId;
        SocketEventMgr.Instance.sendMsg(EnumCodeID.UserDetailsReq, data);
    }

    /**
     * 请求VIP配置
     */
    public static sendVipConfig() {
        let data = new LobbyProto.VipConfigGetReq();
        SocketEventMgr.Instance.sendMsg(EnumCodeID.VIPconfigReq, data);
    }

    /**
     * 请求创建订单
     */
    public static sendCreateOrder() {
        let data = new LobbyProto.OrderCreateReq();
        data.deposit = 123; //测试
        SocketEventMgr.Instance.sendMsg(EnumCodeID.OrderCreateReq, data);
    }

    /**
     * 请求领取订单奖励
     */
    public static sendRecvOrderReward(orderNo: string) {
        let data = new LobbyProto.OrderReceiveRewardReq();
        data.orderNo = orderNo;
        SocketEventMgr.Instance.sendMsg(EnumCodeID.OrderRewardRecvReq, data);
    }

    /**
     * 请求游戏分类数据
     * @param  gameType 0 大厅的分类，其他值为二级游戏分类
     */
    public static sendHallGameType(gameType: number) {
        let data = new LobbyProto.HallGameTypeInfoReq();
        data.lParentId = gameType;
        SocketEventMgr.Instance.sendMsg(EnumCodeID.hallGameTypeReq, data);
    }

    /**
     * 获取游戏一级界面请求
     */
    public static sendHallHomeGames() {
        let data = new LobbyProto.HallGameOneInfoReq();
        data.lPid = 0;
        SocketEventMgr.Instance.sendMsg(EnumCodeID.hallHomeGamesReq, data);
    }

    /**
    * 获取游戏二级界面请求（各个厂商的推荐游戏）
    */
    public static sendRecommendGames(suppliersID: number[]) {
        let data = new LobbyProto.HallGameTwoInfoReq();
        data.vParentIds = suppliersID;
        SocketEventMgr.Instance.sendMsg(EnumCodeID.hallRecommedGamesReq, data);
    }

    /**
    * 获取游戏三级界面请求(指定厂商的所有游戏)
    */
    public static sendSupplierAllGames(supplierId: number) {
        let data = new LobbyProto.HallGameThreeInfoReq();
        data.lParentId = supplierId;
        SocketEventMgr.Instance.sendMsg(EnumCodeID.hallSupplierAllGamesReq, data);
    }

    /**
     * 请求绑定邀请码
     * @param code 
     */
    public static sendBindInviteCode(code: string) {
        let data = new LobbyProto.BindInviteCodeReq();
        data.inviteCode = code;
        SocketEventMgr.Instance.sendMsg(EnumCodeID.BindInviteCodeReq, data);
    }

    /**
     * 请求绑定手机号码
     * @param areaCode 
     * @param phoneNum 
     * @param verifyCode 
     */
    public static sendBindPhone(areaCode: string, phoneNum: string, verifyCode: string) {
        let data = new PlatformProto.PlatformAccountBindingPhoneReq();
        data.sPhoneAreaCode = areaCode;
        data.sPhoneNumber = phoneNum;
        data.sPhoneCode = verifyCode;
        SocketEventMgr.Instance.sendMsg(EnumCodeID.BindPhoneReq, data);
    }

    /**
     * 请求设置/修改登录密码
     * @param areaCode 
     * @param phoneNum 
     * @param verifyCode 
     */
    public static sendSetPassword(password: string, verifyCode: string) {
        let data = new PlatformProto.PlatformAccountSetPasswordReq();
        data.sPassword = password;
        data.sPhoneCode = verifyCode;
        SocketEventMgr.Instance.sendMsg(EnumCodeID.SetAccountPasswordReq, data);
    }

    /**
     * 请求代理系统配置
     */
    public static sendClubConfig() {
        let data = new LobbyProto.GetClubConfReq();
        SocketEventMgr.Instance.sendMsg(EnumCodeID.ClubConfigReq, data);
    }

    /**
     * 请求我的俱乐部信息
     */
    public static sendMyClubInfo() {
        let data = new LobbyProto.GetMyClubInfoReq();
        SocketEventMgr.Instance.sendMsg(EnumCodeID.MyClubInfoReq, data);
    }

    /**
     * 请求我的俱乐部成员信息
     * @param level 
     */
    public static sendMyClubTeamInfo(level: number) {
        let data = new LobbyProto.GetCLubMemberReq();
        data.level = level;
        SocketEventMgr.Instance.sendMsg(EnumCodeID.MyClubMembersReq, data);
    }

    /**
     * 请求俱乐部分享配置
     * @param level 
     */
    public static sendClubShareConfig() {
        let data = new LobbyProto.GetClubSharePosterConfReq();
        SocketEventMgr.Instance.sendMsg(EnumCodeID.MyClubShareConfigReq, data);
    }

    /** */
    public static sendBetting(num) {

        // let data = {
        //     "cmd": EnumCodeID.betting,
        //     "payload": {
        //         "num": num,//= 下注数量，值，非下标
        //         "mode": 0,//= 0-普通 1-购买旋转
        //         "buyNum": 1,// = quantity 购买旋转有效 ，买几次
        //     }
        // }
        // SocketEventMgr.Instance.sendMsg(EnumCodeID.betting, data);
    }


    /**
     * 获取邮件列表请求
     *  
        int64 offset =2; // 偏移
        int64 limit =3; // 限制条数
     */
    public static sendMailList(offset = 0, limit = 10) {
        let data = new LobbyProto.GetUserEmailDigestReq();
        data.offset = offset;
        data.limit = limit;
        console.log('sendMailList: ', data);
        SocketEventMgr.Instance.sendMsg(EnumCodeID.getEmailListReq, data);
    }

    /**
     * 获取邮件详情信息
     * @param eid 
     */
    public static sendMailInfo(eid, et) {
        let data = new LobbyProto.GetUserEmailReq();
        data.eid = eid;
        data.et = et;
        console.log('sendMailInfo: ', data);
        SocketEventMgr.Instance.sendMsg(EnumCodeID.getEmailDetailReq, data);
    }

    public static sendAlterUserEmailStatusReq(eid, et) {
        let data = new LobbyProto.AlterUserEmailStatusReq();
        data.eid = eid;
        data.et = et;
        console.log('sendAlterUserEmailStatusReq: ', data);
        SocketEventMgr.Instance.sendMsg(EnumCodeID.alterUserEmailStatusReq, data);
    }

    public static sendUserRemoveEmailReq(eid, et) {
        let data = new LobbyProto.UserRemoveEmailReq();
        data.eid = eid;
        data.et = et;
        console.log('sendUserRemoveEmailReq: ', data);
        SocketEventMgr.Instance.sendMsg(EnumCodeID.removeUserEmailReq, data);
    }

    public static sendUserRemoveAllEmailReq() {
        let data = new LobbyProto.UserEmailRemoveAllReq();
        console.log('sendUserRemoveAllEmailReq: ', data);
        SocketEventMgr.Instance.sendMsg(EnumCodeID.removeAllUserEmailReq, data);
    }

    public static sendMarkAllReadEmailReq() {
        let data = new LobbyProto.UserMarkAllReadEmailReq();
        console.log('sendMarkAllReadEmailReq: ', data);
        SocketEventMgr.Instance.sendMsg(EnumCodeID.markAllReadEmailReq, data);
    }
}

