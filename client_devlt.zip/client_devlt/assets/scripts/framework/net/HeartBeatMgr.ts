import { _decorator } from "cc";
import { Logger } from "../utils/Logger";
import { HallReqManager } from "./HallReqManager";

const { ccclass, property } = _decorator;

@ccclass
class HeartBeatMgr {
    //周期秒数
    timedown: number = 30000;
    //心跳频率 10秒
    timeOut: number = 10000;
    //重连间隔时间
    reconnectTime: number = 5;
    //重连次数
    reconnectNum: number = 0;
    //客户端定时器
    private timer: any = null;
    //服务端定时器
    private serverTimer: any = null;

    /**
     * 启动
     */
    start() {
        // EventMgr.Instance.emit(GAME_EVENT.ON_LOADING_CIRCLE_HIDE)
        //清除延时器
        this.close();
        // Logger.info("====>>>>发送心跳包")
        this.reconnectNum = 0;
        this.timer = setInterval(() => {
            Logger.debug("====>>>> 发送心跳包");
            HallReqManager.sendHeartbeat();
        }, this.timeOut)
    }

    /**
     * 关闭
     */
    close() {
        Logger.info("====>>>> 关闭心跳")
        this.timer && clearInterval(this.timer);
        this.serverTimer && clearInterval(this.serverTimer);
    }
}

//
export default new HeartBeatMgr();
