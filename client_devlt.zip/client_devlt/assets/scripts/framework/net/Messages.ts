import * as pb from '../../protobuf/pb.js';


export interface ProParam {
    /** 消息解析方法名 */
    name: string;
    /** 中文注释 */
    prompt: string;
    /** 消息解析文件名 */
    pbFile: string;
    /** 是否重复请求 */
    isRepat?: boolean
    /** EnumServiceType */
    type?: number;
    /** 请求的ID 返回使用 */
    sendID?: number;
    /** 消息响应回调 */
    func?: Function;
}
export enum EnumServiceType {
    DEFAULT = pb.XGameComm.SERVICE_TYPE.SERVICE_TYPE_DEFAULT,       //默认
    LOGIN = pb.XGameComm.SERVICE_TYPE.SERVICE_TYPE_LOGIN,       //登录服务
    GAME = pb.XGameComm.SERVICE_TYPE.SERVICE_TYPE_GAME,       //游戏服务
    ROOM = pb.XGameComm.SERVICE_TYPE.SERVICE_TYPE_ROOM,       //房间服务
    MATCH = pb.XGameComm.SERVICE_TYPE.SERVICE_TYPE_MATCH,       //比赛服务
    RECORD = pb.XGameComm.SERVICE_TYPE.SERVICE_TYPE_RECORD,       //战绩服务
    PUSH = pb.XGameComm.SERVICE_TYPE.SERVICE_TYPE_PUSH,       //推送服务
    BINGO = pb.XGameComm.SERVICE_TYPE.SERVICE_TYPE_BINGO,       //bingo
    COOKIE = pb.XGameComm.SERVICE_TYPE.SERVICE_TYPE_COOKIE,       //cookie
    SOLITAIRE = pb.XGameComm.SERVICE_TYPE.SERVICE_TYPE_SOLITAIRE, //solitaire
    UNO = pb.XGameComm.SERVICE_TYPE.SERVICE_TYPE_ROOM,       //uno

    CASH21 = pb.XGameComm.SERVICE_TYPE.SERVICE_TYPE_ROOM,      //cash21
    TETRIS = pb.XGameComm.SERVICE_TYPE.SERVICE_TYPE_ROOM,      //tetris
    TILE = pb.XGameComm.SERVICE_TYPE.SERVICE_TYPE_ROOM,      //tile
    WATER = pb.XGameComm.SERVICE_TYPE.SERVICE_TYPE_ROOM,  //waterCash
    BUBBLE = pb.XGameComm.SERVICE_TYPE.SERVICE_TYPE_ROOM,  //bubble

    ////////////////////////////////////////////
    CHAT = pb.XGameComm.SERVICE_TYPE.SERVICE_TYPE_CHAT,     //聊天服务
    MAIL = pb.XGameComm.SERVICE_TYPE.SERVICE_TYPE_MAIL,     //邮箱服务
    MALL = pb.XGameComm.SERVICE_TYPE.SERVICE_TYPE_MALL,     //商城服务
    SIGNIN = pb.XGameComm.SERVICE_TYPE.SERVICE_TYPE_SIGNIN,     //每日签到
    USER_STATE = pb.XGameComm.SERVICE_TYPE.SERVICE_TYPE_USER_STATE,     //用户状态
}
export enum EnumCodeID {
    // 大厅协议
    /** 登录大厅消息请求 */
    LoginReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_LOGIN_HALL_REQ,
    /** 登录大厅消息响应 */
    LoginResp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_LOGIN_HALL_RESP,
    /** 心跳消息请求 */
    HeartbeatReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_KEEP_ALIVE_REQ,
    /** 心跳消息返回 */
    HeartbeatResp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_KEEP_ALIVE_RESP,
    /** 用户详情请求 */
    UserDetailsReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_PLATFORM_ACCOUNT_DETAIL_REQ,
    /** 用户详情返回 */
    UserDetailsResp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_PLATFORM_ACCOUNT_DETAIL_RSP,
    /** VIP 配置请求 */
    VIPconfigReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_VIP_CONFIG_GET_REQ,
    /** VIP 配置响应 */
    VIPconfigResp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_VIP_CONFIG_GET_RSP,

    /** 创建充值订单请求 */
    OrderCreateReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_ORDER_CREATE_REQ,
    /** 创建充值订单响应 */
    OrderCreateResp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_ORDER_CREATE_RSP,

    /** 领取订单奖励的请求和响应 */
    OrderRewardRecvReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_ORDER_RECEIVE_REWARD_REQ,
    OrderRewardRecvRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_ORDER_RECEIVE_REWARD_RSP,

    /** 获取大厅游戏分类请求和响应 */
    hallGameTypeReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_PLATFORM_HALL_GAME_TYPE_REQ,
    hallGameTypeRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_PLATFORM_HALL_GAME_TYPE_RSP,

    /** 获取大厅游戏一级界面请求和回复 */
    hallHomeGamesReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_PLATFORM_HALL_GAME_ONE_REQ,
    hallHomeGamesRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_PLATFORM_HALL_GAME_ONE_RSP,

    /** 获取大厅游戏二级界面请求/回复 */
    hallRecommedGamesReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_PLATFORM_HALL_GAME_TWO_REQ,
    hallRecommedGamesRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_PLATFORM_HALL_GAME_TWO_RSP,

    /** 获取大厅游戏三级界面请求/回复 */
    hallSupplierAllGamesReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_PLATFORM_HALL_GAME_THREE_REQ,
    hallSupplierAllGamesRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_PLATFORM_HALL_GAME_THREE_RSP,
    /** 获取邮件请求和回复 */
    getEmailListReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_EMAIL_DIGEST_LIST_REQ,
    getEmailListRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_EMAIL_DIGEST_LIST_RSP,
    getEmailDetailReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_USER_EMAIL_DETAIL_REQ,
    getEmailDetailRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_USER_EMAIL_DETAIL_RSP,

    alterUserEmailStatusReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_ALTER_USER_EMAIL_STATUS_REQ,
    alterUserEmailStatusRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_ALTER_USER_EMAIL_STATUS_RSP,
    removeUserEmailReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_REMOVE_USER_EMAIL_REQ,
    removeUserEmailRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_REMOVE_USER_EMAIL_RSP,

    // 一键删除已读邮件
    removeAllUserEmailReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_REMOVE_ALL_USER_REQ,
    removeAllUserEmailRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_REMOVE_ALL_USER_RSP,

    // 一键标记所有已读邮件
    markAllReadEmailReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_MARK_ALL_READ_REQ,
    markAllReadEmailRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_MARK_ALL_READ_RSP,


    /** 绑定邀请码请求/响应 */
    BindInviteCodeReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_CLUB_BIND_INVITE_CODE_REQ,
    BindInviteCodeRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_CLUB_BIND_INVITE_CODE_RSP,

    /** 已登录账号绑定手机号请求/响应 */
    BindPhoneReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_PLATFORM_ACCOUNT_BINDING_PHONE_REQ,
    BindPhoneRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_PLATFORM_ACCOUNT_BINDING_PHONE_RSP,

    /** 已登录账号设置密码请求/响应 */
    SetAccountPasswordReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_PLATFORM_ACCOUNT_SET_PASSWORD_REQ,
    SetAccountPasswordRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_PLATFORM_ACCOUNT_SET_PASSWORD_RSP,

    /** 获取代理相关配置请求/响应 */
    ClubConfigReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_CLUB_CONFIG_GET_REQ,
    ClubConfigRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_CLUB_CONFIG_GET_RSP,

    /** 我的俱乐部信息请求/响应 */
    MyClubInfoReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_CLUB_GET_INFO_REQ,
    MyClubInfoRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_CLUB_GET_INFO_RSP,

    /** 我的俱乐部成员请求/响应 */
    MyClubMembersReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_CLUB_GET_MEMBER_REQ,
    MyClubMembersRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_CLUB_GET_MEMBER_RSP,

    /** 代理邀请分享请求/响应 */
    MyClubShareConfigReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_CLUB_POSTER_CONFIG_GET_REQ,
    MyClubShareConfigRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_CLUB_POSTER_CONFIG_GET_RSP,

    /** 获取用户状态请求 */
    UserStatusReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_USER_STATUS_REQ,
    /** 获取用户状态响应 */
    UserStatusResp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_USER_STATUS_RESP,
    /** 用户信息更新通知 */
    UserInfoUpNotify = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_USER_INFO_UPDATE_NOTIFY,
    /** 获取语言描述列表请求 */
    GetLocaleReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_LOCALE_REQ,
    /** 获取语言描述列表响应 */
    GetLocaleResp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_LOCALE_RSP,
    /** 更新语言请求 */
    upDateLocaleReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_UPDATE_LOCALE_REQ,
    /** 更新语言响应 */
    upDateLocaleResp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_UPDATE_LOCALE_RSP,
    /** 获取用户等级配置表请求 */
    GetUseLevelReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_USER_LEVELUP_REQ,
    /** 获取用户等级配置表响应 */
    GetUseLevelResp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_USER_LEVELUP_RESP,
    /** 获取多语言配置表请求 */
    GetForeignReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_FOREIGN_REQ,
    /** 获取多语言配置表响应 */
    GetForeignResp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_FOREIGN_RESP,
    /** 获取常量配置表请求 */
    GetConstReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_CONST_REQ,
    /** 获取常量配置表响应 */
    GetConstResp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_CONST_RESP,
    /** 获取配置表打包请求 */
    GetConfigReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_CONFIG_PACKAGE_REQ,
    /** 获取配置表打包响应 */
    GetConfigResp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GET_CONFIG_PACKAGE_RESP,
    /** 系统消息通知 */
    upDateMessage = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_SYSTEM_MESSAGE_NOTIFY,









    ///////////////////// SERVICE_TYPE_ROOM(3000~3999) ////////////////////////////////////////
    /** 玩家 房间进入请求 */
    RoomPlayerEnterReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_ROOM_PLAYER_ENTER_REQ,
    /** 玩家 房间进入返回 */
    RoomPlayerEnterRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_ROOM_PLAYER_ENTER_RSP,
    /** 玩家 房间退出请求 */
    RoomPlayerExitReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_ROOM_PLAYER_EXIT_REQ,
    /** 玩家 房间退出返回 */
    RoomPlayerExitRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_ROOM_PLAYER_EXIT_RSP,
    /** 房间 游戏开始请求 */
    RoomGameStartReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_ROOM_GAME_START_REQ,
    /** 房间 游戏开始返回 */
    RoomGameStartRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_ROOM_GAME_START_RSP,
    /** 房间 游戏暂停请求 */
    RoomGamePauseReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_ROOM_GAME_PAUSE_REQ,
    /** 房间 游戏暂停返回 */
    RoomGamePauseRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_ROOM_GAME_PAUSE_RSP,
    /** 房间 游戏唤醒请求 */
    RoomGameResumeReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_ROOM_GAME_RESUME_REQ,
    /** 房间 戏唤醒返回 */
    RoomGameResumeRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_ROOM_GAME_RESUME_RSP,
    /** 快速进入游戏请求 */
    RoomGameFastReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_ROOM_GAME_FAST_REQ,
    /** 快速进入游戏返回 */
    RoomGameFastRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_ROOM_GAME_FAST_RSP,
    /** 大奖赛次数 */
    GameCountNotify = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GAME_BIGAWARDMATCH_COUNT_NOTIFY,



    ///////////////////// SERVICE_TYPE_ROOM(4000~4999) ////////////////////////////////////////
    /** 游戏匹配列表请求 */
    GameMatchListReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GAME_MATH_LIST_REQ,
    /** 游戏匹配列表响应 */
    GameMatchListRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GAME_MATH_LIST_RSP,
    /** 游戏开始匹配请求 */
    GameMatchBeginReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GAME_MATH_BEGIN_REQ,
    /** 游戏开始匹配响应 */
    GameMatchBeginRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GAME_MATH_BEGIN_RSP,
    /** 游戏取消匹配请求 */
    GameMatchCancelReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GAME_MATH_CANCEL_REQ,
    /** 游戏取消匹配返回 */
    GameMatchCancelRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GAME_MATH_CANCEL_RSP,
    /** 匹配超时通知请求 */
    GameMatchTimeoutNotify = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GAME_MATH_TIMEOUT_NOTIFY,
    /** 匹配成功通知返回 */
    GameMatchSucceedNotify = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GAME_MATH_SUCCEED_NOTIFY,
    /** 推送进入房间的人 */
    GameMatchPushNotify = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GAME_MATH_PUSH_NOTIFY,
    /** 获取匹配队列中人 断线重连请求 */
    GameMatchGetNotifyReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GAME_MATH_GET_NOTIFY_REQ,
    /** 获取匹配队列中人 断线重连返回 */
    GameMatchGetNotifyRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_GAME_MATH_GET_NOTIFY_RSP,

    ///////////////////// SERVICE_TYPE_RECORD(5000~5999) ////////////////////////////////////////
    /** 游戏战绩列表请求 */
    GameRecordsListOfReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_RECORD_SUMMARIZE_LIST_REQ,
    /** 游戏战绩列表返回 */
    GameRecordsListOfRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_RECORD_SUMMARIZE_LIST_RSP,
    /** 游戏战绩信息请求 */
    GameRecordsPlayerReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_RECORD_PLAYER_MOREINFO_REQ,
    /** 游戏战绩信息返回 */
    GameRecordsPlayerRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_RECORD_PLAYER_MOREINFO_RSP,


    /** 大奖赛分数请求 */
    GameRecordsScoreReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_RECORD_PLAYER_SCORE_INFO_REQ,
    /** 大奖赛分数返回 */
    GameRecordsScoreRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_RECORD_PLAYER_SCORE_INFO_RSP,

    /** 更新红点请求(已读) */
    GameRecordsUpDataReq = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_RECORD_UPDATE_REDSTATE_REQ,
    ///////////////////// SERVICE_TYPE_PUSH(6000~6999) ////////////////////////////////////////
    /** 顶号推送 */
    PushMultipleLoginNotifyRsp = pb.XGameComm.Eum_Comm_Msgid.E_MSGID_PUSH_MULTIPLE_LOGIN_NOTIFY,//顶号
}


export const Messages: Map<number | string, ProParam> = new Map<number | string, ProParam>();

/** LOGIN */
Messages.set(EnumCodeID.LoginReq, { name: "", pbFile: 'XGameComm', prompt: "登录大厅消息请求", type: EnumServiceType.LOGIN, isRepat: true });
Messages.set(EnumCodeID.LoginResp, { name: "TMsgRespLoginHall", pbFile: 'XGameComm', prompt: "登录大厅消息响应", type: EnumServiceType.LOGIN, sendID: EnumCodeID.LoginReq });
Messages.set(EnumCodeID.HeartbeatReq, { name: "", pbFile: 'XGameComm', prompt: "心跳消息请求", type: EnumServiceType.LOGIN });
Messages.set(EnumCodeID.HeartbeatResp, { name: "", pbFile: 'XGameComm', prompt: "心跳消息返回", type: EnumServiceType.LOGIN });

/** GAME */
Messages.set(EnumCodeID.UserDetailsReq, { name: "GetPlatformAccountDetailReq", pbFile: 'PlatformProto', prompt: "用户详情请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.UserDetailsResp, { name: "GetPlatformAccountDetailRsp", pbFile: 'PlatformProto', prompt: "用户详情返回", type: EnumServiceType.GAME, sendID: EnumCodeID.UserDetailsReq });

/** VIP */
Messages.set(EnumCodeID.VIPconfigReq, { name: "VipConfigGetReq", pbFile: 'LobbyProto', prompt: "VIP配置请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.VIPconfigResp, { name: "VipConfigGetRsp", pbFile: 'LobbyProto', prompt: "VIP配置返回", type: EnumServiceType.GAME, sendID: EnumCodeID.VIPconfigReq });

/** 创建订单 */
Messages.set(EnumCodeID.OrderCreateReq, { name: "OrderCreateReq", pbFile: 'LobbyProto', prompt: "创建订单请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.OrderCreateResp, { name: "OrderCreateRsp", pbFile: 'LobbyProto', prompt: "创建订单返回", type: EnumServiceType.GAME, sendID: EnumCodeID.OrderCreateReq });

/** 领取订单奖励 */
Messages.set(EnumCodeID.OrderRewardRecvReq, { name: "OrderReceiveRewardReq", pbFile: 'LobbyProto', prompt: "领取订单奖励请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.OrderRewardRecvRsp, { name: "OrderReceiveRewardRsp", pbFile: 'LobbyProto', prompt: "创建订单返回", type: EnumServiceType.GAME, sendID: EnumCodeID.OrderRewardRecvReq });

/** 获取大厅游戏分类请求和响应 */
Messages.set(EnumCodeID.hallGameTypeReq, { name: "HallGameTypeInfoReq", pbFile: 'LobbyProto', prompt: "获取大厅游戏分类请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.hallGameTypeRsp, { name: "HallGameTypeInfoRsp", pbFile: 'LobbyProto', prompt: "获取大厅游戏分类回复", type: EnumServiceType.GAME, sendID: EnumCodeID.hallGameTypeReq });

/** 获取大厅游戏一级界面请求和回复 */
Messages.set(EnumCodeID.hallHomeGamesReq, { name: "HallGameOneInfoReq", pbFile: 'LobbyProto', prompt: "获取大厅游戏一级界面请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.hallHomeGamesRsp, { name: "HallGameOneInfoRsp", pbFile: 'LobbyProto', prompt: "获取大厅游戏一级界面回复", type: EnumServiceType.GAME, sendID: EnumCodeID.hallHomeGamesReq });

/** 获取大厅游戏二级界面请求 */
Messages.set(EnumCodeID.hallRecommedGamesReq, { name: "HallGameTwoInfoReq", pbFile: 'LobbyProto', prompt: "获取大厅游戏二级界面请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.hallRecommedGamesRsp, { name: "HallGameTwoInfoRsp", pbFile: 'LobbyProto', prompt: "获取大厅游戏二级界面回复", type: EnumServiceType.GAME, sendID: EnumCodeID.hallRecommedGamesReq });

/** 获取大厅游戏三级界面请求 */
Messages.set(EnumCodeID.hallSupplierAllGamesReq, { name: "HallGameThreeInfoReq", pbFile: 'LobbyProto', prompt: "获取大厅游戏三级界面请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.hallSupplierAllGamesRsp, { name: "HallGameThreeInfoRsp", pbFile: 'LobbyProto', prompt: "获取大厅游戏三级界面回复", type: EnumServiceType.GAME, sendID: EnumCodeID.hallSupplierAllGamesReq });

/** 获取邮件列表的请求和回复 */
Messages.set(EnumCodeID.getEmailListReq, { name: "GetUserEmailDigestReq", pbFile: 'LobbyProto', prompt: "获取邮件列表请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.getEmailListRsp, { name: "GetUserEmailDigestRsp", pbFile: 'LobbyProto', prompt: "获取邮件列表回复", type: EnumServiceType.GAME, sendID: EnumCodeID.getEmailListReq });
Messages.set(EnumCodeID.getEmailDetailReq, { name: "GetUserEmailReq", pbFile: 'LobbyProto', prompt: "获取邮件请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.getEmailDetailRsp, { name: "GetUserEmailRsp", pbFile: 'LobbyProto', prompt: "获取邮件回复", type: EnumServiceType.GAME, sendID: EnumCodeID.getEmailDetailReq });

Messages.set(EnumCodeID.alterUserEmailStatusReq, { name: "AlterUserEmailStatusReq", pbFile: 'LobbyProto', prompt: "用户提交服务器状态变化", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.alterUserEmailStatusRsp, { name: "AlterUserEmailStatusRsp", pbFile: 'LobbyProto', prompt: "用户提交服务器状态变化 回复", type: EnumServiceType.GAME, sendID: EnumCodeID.alterUserEmailStatusReq });
Messages.set(EnumCodeID.removeUserEmailReq, { name: "UserRemoveEmailReq", pbFile: 'LobbyProto', prompt: "用户删除邮件请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.removeUserEmailRsp, { name: "UserRemoveEmailRsp", pbFile: 'LobbyProto', prompt: "用户删除邮件回复", type: EnumServiceType.GAME, sendID: EnumCodeID.removeUserEmailReq });
Messages.set(EnumCodeID.removeAllUserEmailReq, { name: "UserEmailRemoveAllReq", pbFile: 'LobbyProto', prompt: "用户删除已读邮件请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.removeAllUserEmailRsp, { name: "UserEmailRemoveAllRsp", pbFile: 'LobbyProto', prompt: "用户删除已读邮件回复", type: EnumServiceType.GAME, sendID: EnumCodeID.removeAllUserEmailReq });
Messages.set(EnumCodeID.markAllReadEmailReq, { name: "UserMarkAllReadEmailReq", pbFile: 'LobbyProto', prompt: "一键标记已读邮件请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.markAllReadEmailRsp, { name: "UserMarkAllReadEmailRsp", pbFile: 'LobbyProto', prompt: "一键标记已读邮件回复", type: EnumServiceType.GAME, sendID: EnumCodeID.markAllReadEmailReq });

/** 绑定邀请码请求/响应 */
Messages.set(EnumCodeID.BindInviteCodeReq, { name: "BindInviteCodeReq", pbFile: 'LobbyProto', prompt: "绑定邀请码请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.BindInviteCodeRsp, { name: "BindInviteCodeRsp", pbFile: 'LobbyProto', prompt: "绑定邀请码响应", type: EnumServiceType.GAME, sendID: EnumCodeID.BindInviteCodeReq });

/** 已登录账号绑定手机号请求/响应 */
Messages.set(EnumCodeID.BindPhoneReq, { name: "PlatformAccountBindingPhoneReq", pbFile: 'PlatformProto', prompt: "已登录账号绑定手机号请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.BindPhoneRsp, { name: "PlatformAccountBindingPhoneRsp", pbFile: 'PlatformProto', prompt: "已登录账号绑定手机号响应", type: EnumServiceType.GAME, sendID: EnumCodeID.BindPhoneReq });

/** 已登录账号设置密码请求/响应 */
Messages.set(EnumCodeID.SetAccountPasswordReq, { name: "PlatformAccountSetPasswordReq", pbFile: 'PlatformProto', prompt: "已登录账号设置密码请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.SetAccountPasswordRsp, { name: "PlatformAccountSetPasswordRsp", pbFile: 'PlatformProto', prompt: "已登录账号设置密码响应", type: EnumServiceType.GAME, sendID: EnumCodeID.SetAccountPasswordReq });

/** 代理系统配置请求/响应 */
Messages.set(EnumCodeID.ClubConfigReq, { name: "GetClubConfReq", pbFile: 'LobbyProto', prompt: "代理系统配置请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.ClubConfigRsp, { name: "GetClubConfRsp", pbFile: 'LobbyProto', prompt: "代理系统配置响应", type: EnumServiceType.GAME, sendID: EnumCodeID.ClubConfigReq });

/** 我的俱乐部信息请求/响应 */
Messages.set(EnumCodeID.MyClubInfoReq, { name: "GetMyClubInfoReq", pbFile: 'LobbyProto', prompt: "我的俱乐部信息请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.MyClubInfoRsp, { name: "GetMyClubInfoRsp", pbFile: 'LobbyProto', prompt: "我的俱乐部信息响应", type: EnumServiceType.GAME, sendID: EnumCodeID.MyClubInfoReq });

/** 我的俱乐部成员请求/响应 */
Messages.set(EnumCodeID.MyClubMembersReq, { name: "GetCLubMemberReq", pbFile: 'LobbyProto', prompt: "我的俱乐部成员请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.MyClubMembersRsp, { name: "GetCLubMemberRsp", pbFile: 'LobbyProto', prompt: "我的俱乐部成员响应", type: EnumServiceType.GAME, sendID: EnumCodeID.MyClubMembersReq });

/** 代理分享配置 */
Messages.set(EnumCodeID.MyClubShareConfigReq, { name: "GetClubSharePosterConfReq", pbFile: 'LobbyProto', prompt: "代理分享配置请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.MyClubShareConfigRsp, { name: "GetClubSharePosterConfRsp", pbFile: 'LobbyProto', prompt: "代理分享配置响应", type: EnumServiceType.GAME, sendID: EnumCodeID.MyClubShareConfigReq });

Messages.set(EnumCodeID.UserInfoUpNotify, { name: "UserInfoUpdateNotify", pbFile: 'GameProto', prompt: "用户信息更新通知", type: EnumServiceType.GAME });

Messages.set(EnumCodeID.GetLocaleReq, { name: "GetLocaleReq", pbFile: 'GameProto', prompt: "获取语言描述列表请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.GetLocaleResp, { name: "GetLocaleResp", pbFile: 'GameProto', prompt: "获取语言描述列表响应", type: EnumServiceType.GAME, sendID: EnumCodeID.GetLocaleReq });

Messages.set(EnumCodeID.upDateLocaleReq, { name: "UpdateLocaleReq", pbFile: 'GameProto', prompt: "更新语言请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.upDateLocaleResp, { name: "UpdateLocaleResp", pbFile: 'GameProto', prompt: "更新语言响应", type: EnumServiceType.GAME, sendID: EnumCodeID.upDateLocaleReq });

Messages.set(EnumCodeID.GetUseLevelReq, { name: "GetUserLevelUpInfoReq", pbFile: 'GameProto', prompt: "获取用户等级配置表请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.GetUseLevelResp, { name: "GetUserLevelUpInfoResp", pbFile: 'GameProto', prompt: "获取用户等级配置表响应", type: EnumServiceType.GAME, sendID: EnumCodeID.GetUseLevelReq });

Messages.set(EnumCodeID.GetForeignReq, { name: "GetForeignInfoReq", pbFile: 'GameProto', prompt: "获取多语言配置表请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.GetForeignResp, { name: "GetForeignInfoResp", pbFile: 'GameProto', prompt: "获取多语言配置表响应", type: EnumServiceType.GAME, sendID: EnumCodeID.GetForeignReq });

Messages.set(EnumCodeID.GetConstReq, { name: "GetConstInfoReq", pbFile: 'GameProto', prompt: "获取常量配置表请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.GetConstResp, { name: "GetConstInfoResp", pbFile: 'GameProto', prompt: "获取常量配置表响应", type: EnumServiceType.GAME, sendID: EnumCodeID.GetConstReq });

Messages.set(EnumCodeID.GetConfigReq, { name: "GetConfigPackageReq", pbFile: 'GameProto', prompt: "获取配置表打包请求", type: EnumServiceType.GAME, isRepat: true });
Messages.set(EnumCodeID.GetConfigResp, { name: "GetConfigPackageResp", pbFile: 'GameProto', prompt: "获取配置表打包响应", type: EnumServiceType.GAME, sendID: EnumCodeID.GetConfigReq });

Messages.set(EnumCodeID.upDateMessage, { name: "SystemMessageNotify", pbFile: 'GameProto', prompt: "系统消息通知", type: EnumServiceType.GAME });

Messages.set(EnumCodeID.GameCountNotify, { name: "GameBigAwardMatchCountNotify", pbFile: 'GameProto', prompt: "更新大奖赛次数", type: EnumServiceType.GAME });


/** ROOM */
Messages.set(EnumCodeID.RoomPlayerEnterReq, { name: "RoomEnterReq", pbFile: 'RoomProto', prompt: "玩家房间进入请求", type: EnumServiceType.ROOM, isRepat: true });
Messages.set(EnumCodeID.RoomPlayerEnterRsp, { name: "RoomEnterRsp", pbFile: 'RoomProto', prompt: "玩家房间进入回包", type: EnumServiceType.ROOM, sendID: EnumCodeID.RoomPlayerEnterReq });

Messages.set(EnumCodeID.RoomGameStartReq, { name: "RoomGameStartReq", pbFile: 'RoomProto', prompt: "开始游戏请求", type: EnumServiceType.ROOM, isRepat: true });
Messages.set(EnumCodeID.RoomGameStartRsp, { name: "RoomGameStartRsp", pbFile: 'RoomProto', prompt: "开始游戏回包", type: EnumServiceType.ROOM, sendID: EnumCodeID.RoomGameStartReq });

Messages.set(EnumCodeID.RoomGamePauseReq, { name: "RoomGamePauseReq", pbFile: 'RoomProto', prompt: "游戏暂停请求", type: EnumServiceType.ROOM, isRepat: true });
Messages.set(EnumCodeID.RoomGamePauseRsp, { name: "RoomGamePauseRsp", pbFile: 'RoomProto', prompt: "游戏暂停返回", type: EnumServiceType.ROOM, sendID: EnumCodeID.RoomGamePauseReq });

Messages.set(EnumCodeID.RoomGameResumeReq, { name: "RoomGameResumeReq", pbFile: 'RoomProto', prompt: "游戏唤醒请求", type: EnumServiceType.ROOM, isRepat: true });
Messages.set(EnumCodeID.RoomGameResumeRsp, { name: "RoomGameResumeRsp", pbFile: 'RoomProto', prompt: "游戏唤醒返回", type: EnumServiceType.ROOM, sendID: EnumCodeID.RoomGameResumeReq });

/** MATCH */
Messages.set(EnumCodeID.GameMatchListReq, { name: "GameMatchListReq", pbFile: 'MatchProto', prompt: "游戏匹配列表请求", type: EnumServiceType.MATCH, isRepat: true });
Messages.set(EnumCodeID.GameMatchListRsp, { name: "GameMatchListRsp", pbFile: 'MatchProto', prompt: "游戏匹配列表响应", type: EnumServiceType.MATCH, sendID: EnumCodeID.GameMatchListReq });

Messages.set(EnumCodeID.GameMatchBeginReq, { name: "GameMatchBeginReq", pbFile: 'MatchProto', prompt: "游戏开始匹配请求", type: EnumServiceType.MATCH, isRepat: true });
Messages.set(EnumCodeID.GameMatchBeginRsp, { name: "GameMatchBeginRsp", pbFile: 'MatchProto', prompt: "游戏开始匹配响应", type: EnumServiceType.MATCH, sendID: EnumCodeID.GameMatchBeginReq });

Messages.set(EnumCodeID.GameMatchCancelReq, { name: "GameMatchCancelReq", pbFile: 'MatchProto', prompt: "游戏取消匹配请求", type: EnumServiceType.MATCH, isRepat: true });
Messages.set(EnumCodeID.GameMatchCancelRsp, { name: "GameMatchCancelRsp", pbFile: 'MatchProto', prompt: "游戏取消匹配返回", type: EnumServiceType.MATCH, sendID: EnumCodeID.GameMatchCancelReq });

Messages.set(EnumCodeID.GameMatchTimeoutNotify, { name: "GameMatchTimeoutNotify", pbFile: 'MatchProto', prompt: "匹配超时通知", type: EnumServiceType.MATCH });
Messages.set(EnumCodeID.GameMatchSucceedNotify, { name: "GameMatchSucceedNotify", pbFile: 'MatchProto', prompt: "匹配成功通知", type: EnumServiceType.MATCH });
Messages.set(EnumCodeID.GameMatchPushNotify, { name: "GameMatchPushNotify", pbFile: 'MatchProto', prompt: "推送进入房间的人", type: EnumServiceType.MATCH });


Messages.set(EnumCodeID.GameMatchGetNotifyReq, { name: "GameMatchGetNotifyReq", pbFile: 'MatchProto', prompt: "获取匹配队列中人 断线重连请求", type: EnumServiceType.MATCH, isRepat: true });
Messages.set(EnumCodeID.GameMatchGetNotifyRsp, { name: "GameMatchGetNotifyRsp", pbFile: 'MatchProto', prompt: "获取匹配队列中人 断线重连返回", type: EnumServiceType.MATCH, sendID: EnumCodeID.GameMatchGetNotifyReq });

/** RECORD */
Messages.set(EnumCodeID.GameRecordsListOfReq, { name: "GameSummarizeListReq", pbFile: 'RecordProto', prompt: "游戏战绩列表请求", type: EnumServiceType.RECORD, isRepat: true });
Messages.set(EnumCodeID.GameRecordsListOfRsp, { name: "GameSummarizeListRsp", pbFile: 'RecordProto', prompt: "游戏战绩列表响应", type: EnumServiceType.RECORD, sendID: EnumCodeID.GameRecordsListOfReq });
Messages.set(EnumCodeID.GameRecordsPlayerReq, { name: "GamePlayerMoreInfoReq", pbFile: 'RecordProto', prompt: "游戏战绩信息请求", type: EnumServiceType.RECORD, isRepat: true });
Messages.set(EnumCodeID.GameRecordsPlayerRsp, { name: "GamePlayerMoreInfoRsp", pbFile: 'RecordProto', prompt: "游戏战绩信息响应", type: EnumServiceType.RECORD, sendID: EnumCodeID.GameRecordsPlayerReq });



Messages.set(EnumCodeID.GameRecordsScoreReq, { name: "GamePlayerScoreInfoReq", pbFile: 'RecordProto', prompt: "大奖赛分数请求", type: EnumServiceType.RECORD, isRepat: true });
Messages.set(EnumCodeID.GameRecordsScoreRsp, { name: "GamePlayerScoreInfoRsp", pbFile: 'RecordProto', prompt: "大奖赛分数返回", type: EnumServiceType.RECORD, sendID: EnumCodeID.GameRecordsScoreReq });


Messages.set(EnumCodeID.GameRecordsUpDataReq, { name: "GameUpdaeRedStateReq", pbFile: 'RecordProto', prompt: "更新红点(已读)", type: EnumServiceType.RECORD });



Messages.set(EnumCodeID.PushMultipleLoginNotifyRsp, { name: "", pbFile: 'pb.XGameComm', prompt: "顶号响应", type: EnumServiceType.PUSH });

