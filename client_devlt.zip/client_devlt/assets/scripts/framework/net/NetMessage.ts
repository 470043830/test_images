import { XGameComm } from "../../protobuf/pb.js";
import Singleton from "../base/Singleton";
import { Logger } from "../utils/Logger";

export interface MessageStruct {
    callFunc: Function,
    protoStruct: any
}



export default class NetMessage extends Singleton {
    protected handler: Map<Number, MessageStruct> = new Map();

    init() {

    }

    clear() {
        this.handler.forEach((e) => {
            e.callFunc = null;
        });

        this.handler.clear();
    }

    register(msgCode: number, protoStruct: any, func: Function = null) {
        if (this.handler.has(msgCode)) {
            Logger.warning(`消息事件重复: ${msgCode}`);
            return;
        }

        this.handler.set(msgCode, { callFunc: func, protoStruct: protoStruct });
    }


    dispatch(msgCode: number, resultId: number, msgData: any) {
        let func = this.handler.get(msgCode);
        if (!func) {
            Logger.warning(`消息事件未注册: ${msgCode}`);
            return;
        }

        func.callFunc(resultId, msgData);
    }

    getMessageProto(msgCode: number): MessageStruct {
        if (!this.handler.has(msgCode)) {
            return null;
        }

        return this.handler.get(msgCode);
    }
}