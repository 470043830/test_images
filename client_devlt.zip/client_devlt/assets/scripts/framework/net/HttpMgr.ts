/**
 * Http 请求封装
 */
import Singleton from "../base/Singleton";
import { EncryptUtil } from "../utils/EncryptUtil";
import { Logger } from "../utils/Logger";
import { ToastMgr } from "../manager/ToastMgr";
import { StringUtils } from "../utils/StringUtils";
import { AppConfig, gameConfig } from "../../config/Config";

// type HTTPFunction = (url: string, opts: Options) => Promise<Response>;
export enum HttpUrlEnum {
    login = "login"
}

/** */
export interface IHttpData {
    url?: string;
    method?: "POST" | "GET";
    data: any;
}

/**
 *
 */
export default class HttpMgr extends Singleton {
    /**
     * API地址
     */
    baseUrl: string = gameConfig.api_url; // test

    /**
     * 实例
     */
    static get Instance() {
        return super.GetInstance<HttpMgr>();
    }

    /**
     *
     * @param param_
     * @returns
     */
    params(param_) {
        const timestamps = Date.now();
        let str = '';
        let result = '';
        let sign = "";
        if (param_.data == null) {
            //
        } else {
            if (param_.method = "POST") {
                str = JSON.stringify(param_.data);
            } else {
                Object.keys(param_.data).forEach(key => {
                    str += key + '=' + param_.data[key] + '&';
                })
            }
            //
            result = str.slice(0, -1);
        }
        str += timestamps + AppConfig.md5_key;
        // 升序排序健 ， 作签名
        // 拼接时间 拼接签名
        sign = EncryptUtil.md5(str);
        return { result: result, str: str, sign: sign, timestamps: timestamps };
    }

    /**
     * http请求
     * @param {string} url
     * @param {function} callback
     */
    httpRequestJson<T>(url_: string, data_?: IHttpData): Promise<T> {
        // Log.table(data_.data, "request data:" + url_)
        let requestdata;
        let method = data_.method;
        requestdata = this.params(data_);
        //
        return new Promise<any>((resolve, reject) => {
            var httpRequest = new XMLHttpRequest();//第一步：创建需要的对象
            let url = ((data_ && data_.url) ? data_.url : this.baseUrl) + url_;
            if (data_.method == "GET" && data_.data != null)
                url += "?" + StringUtils.deepCopy(requestdata.result);
            ;
            Logger.info("url == >" + url)
            Logger.info("method == >" + method)
            httpRequest.open(method, url); //第二步：打开连接
            httpRequest.setRequestHeader("Content-type", "application/json;charset=utf-8;multipart/form-data");
            // httpRequest.setRequestHeader("token", AccountModel.Instance.token);
            // httpRequest.setRequestHeader('businessType', AppConfig.businessType);
            // httpRequest.setRequestHeader('os', AppConfig.os);
            // httpRequest.setRequestHeader('timestamps', requestdata.timestamps.toString());
            // httpRequest.setRequestHeader('sign', requestdata.sign);
            let data = null;
            const formData = new FormData();
            if (data_.method == "POST" && data_.data != null) {
                data = JSON.stringify(data_.data)
            }
            //发送请求 将情头体写在send中
            httpRequest.send(data);
            /**
             * 获取数据后的处理程序
             */
            httpRequest.onreadystatechange = function () {
                //请求后的回调接口，可将请求成功后要执行的程序写在其中
                if (httpRequest.readyState == 4) {//验证请求是否发送成功
                    if (httpRequest.status >= 200 && httpRequest.status < 300) {
                        var json = httpRequest.responseText;//获取到服务端返回的数据
                        try {
                            Logger.debug("http 未解密数据==》》》", json);
                            // json = AesEcb.decrypt(json, PHP_KEY);
                            // Logger.debug("http 解密后数据==》》》",json);
                            let ret = JSON.parse(json);
                            // let code = Number(ret.r);
                            // let data = ret.p;
                            // if (code === 0) {
                            //     resolve(data);
                            // } else {
                            resolve(ret);
                            // }
                        } catch (err) {
                            Logger.info('ajax err', err)
                        }
                    } else if (httpRequest.status == 400) {
                        var data = JSON.parse(httpRequest.responseText)
                        ToastMgr.Instance.onRecvToast({ msg: data.message });
                        reject(data);
                    } else if (httpRequest.status == 401) {
                        var data = JSON.parse(httpRequest.responseText)
                        ToastMgr.Instance.onRecvToast({ msg: data.message });
                        reject(data);
                    } else {
                        let msg = `[${httpRequest.status}]`;
                        ToastMgr.Instance.onRecvToast({ msg: msg });
                        reject(msg);
                    }
                }
            };
            //请求后的回调接口，可将请求成功后要执行的程序写在其中
            httpRequest.onerror = function (error) {
                reject(httpRequest.status);
            };
            //超时接口
            httpRequest.ontimeout = function () {
                reject(httpRequest.status);
            };
        })
    }
}
