import { GAME_EVENT, LOBBY_EVENT, SYS_EVENT } from "../event/EventDefine";
import { XGameComm, PlatformProto, LobbyProto } from "../../protobuf/pb.js";
import EventMgr from "../event/EventMgr";
import { Logger } from "../utils/Logger";
import { HallReqManager } from "./HallReqManager";
import MessageHandler from "./NetMessage";
import { EnumCodeID } from "./Messages";
import AccountModel from "../../model/AccountModel";
import { EnumScene } from "../../config/BundleConfig";
import GlobalModel from "../../model/GlobalModel";
import VIPModel from "../../model/VIPModel";
import { Utils } from "../utils/Utils";
import GameModel from "../../model/GameModel";
import MailModel from "../../model/MailMode";
import { LoginMgr } from "../manager/LoginMgr";
import { ToastMgr } from "../manager/ToastMgr";
import { LoginType } from "../../Const";
import ClubModel from "../../model/ClubModel";
import RuleModel from "../../model/RuleModel";


export default class MessageRespHandler extends MessageHandler {
    static get Instance() {
        return super.GetInstance<MessageRespHandler>();
    }

    init() {
        this.register(EnumCodeID.HeartbeatResp, null, this.onRespHeartbeat.bind(this));
        this.register(EnumCodeID.LoginResp, XGameComm.TMsgRespLoginHall, this.onRespLogin.bind(this));
        this.register(EnumCodeID.UserDetailsResp, PlatformProto.GetPlatformAccountDetailRsp, this.onRespUserDetail.bind(this));
        this.register(EnumCodeID.VIPconfigResp, LobbyProto.VipConfigGetRsp, this.onRespVipConfig.bind(this));
        this.register(EnumCodeID.OrderCreateResp, LobbyProto.OrderCreateRsp, this.onRespOrderCreate.bind(this));
        this.register(EnumCodeID.OrderRewardRecvRsp, LobbyProto.OrderReceiveRewardRsp, this.onRespRecvOrderReward.bind(this));
        this.register(EnumCodeID.hallGameTypeRsp, LobbyProto.HallGameTypeInfoRsp, this.onRespHallGameType.bind(this));
        this.register(EnumCodeID.hallHomeGamesRsp, LobbyProto.HallGameOneInfoRsp, this.onRespHallHomeGames.bind(this));
        this.register(EnumCodeID.hallRecommedGamesRsp, LobbyProto.HallGameTwoInfoRsp, this.onRespHallRecommendGames.bind(this));
        this.register(EnumCodeID.hallSupplierAllGamesRsp, LobbyProto.HallGameThreeInfoRsp, this.onRespSuppliersAllGames.bind(this));
        this.register(EnumCodeID.getEmailListRsp, LobbyProto.GetUserEmailDigestRsp, this.onRespMailList.bind(this));
        this.register(EnumCodeID.getEmailDetailRsp, LobbyProto.GetUserEmailRsp, this.onRespUserEmail.bind(this));
        this.register(EnumCodeID.BindInviteCodeRsp, LobbyProto.BindInviteCodeRsp, this.onRespBindInviteCode.bind(this));
        this.register(EnumCodeID.alterUserEmailStatusRsp, LobbyProto.AlterUserEmailStatusRsp, this.onRespAlterUserEmailStatus.bind(this));
        this.register(EnumCodeID.removeUserEmailRsp, LobbyProto.UserRemoveEmailRsp, this.onRespRemoveUserEmailRsp.bind(this));
        this.register(EnumCodeID.removeAllUserEmailRsp, LobbyProto.UserEmailRemoveAllRsp, this.onRespUserEmailRemoveAllRsp.bind(this));
        this.register(EnumCodeID.BindPhoneRsp, PlatformProto.PlatformAccountBindingPhoneRsp, this.onRespBindPhoneNum.bind(this));
        this.register(EnumCodeID.SetAccountPasswordRsp, PlatformProto.PlatformAccountSetPasswordRsp, this.onRespSetPassword.bind(this));
        this.register(EnumCodeID.ClubConfigRsp, LobbyProto.GetClubConfRsp, this.onRespClubConfig.bind(this));
        this.register(EnumCodeID.MyClubInfoRsp, LobbyProto.GetMyClubInfoRsp, this.onRespMyClubInfo.bind(this));
        this.register(EnumCodeID.MyClubMembersRsp, LobbyProto.GetCLubMemberRsp, this.onRespMyClubMembers.bind(this));
        this.register(EnumCodeID.MyClubShareConfigRsp, LobbyProto.GetClubSharePosterConfRsp, this.onRespClubShareConfig.bind(this));
        this.register(EnumCodeID.markAllReadEmailRsp, LobbyProto.UserMarkAllReadEmailRsp, this.onResMarkAllReadMailRsp.bind(this));
    }

    /**
     * 切换到大厅时，请求一些必要的数据
     */
    reuestNecessaryData() {
        //请求配置VIP信息
        HallReqManager.sendVipConfig();
    }

    onRespLogin(resultId: number, msgData: XGameComm.TMsgRespLoginHall) {
        if (resultId == 0) {
            //请求用户信息
            HallReqManager.sendUserInfo();
        } else {
            ToastMgr.Instance.onRecvToast({ msg: `连接服务器失败:(${resultId})"` });
        }
    }

    onRespUserDetail(resultId: number, msgData: PlatformProto.GetPlatformAccountDetailRsp) {
        AccountModel.Instance.userId = Utils.longToNumber(msgData.lPid);
        AccountModel.Instance.userName = msgData.sNickname;
        AccountModel.Instance.avater = msgData.sAvatar;
        AccountModel.Instance.bindPhoneNum = msgData.sPhoneNumber;
        AccountModel.Instance.vipLevel = Utils.longToNumber(msgData.lVipLevel);
        AccountModel.Instance.vipExp = Utils.longToNumber(msgData.lVipExp);
        AccountModel.Instance.cash = Utils.longToNumber(msgData.lCash);
        AccountModel.Instance.bonus = Utils.longToNumber(msgData.lBonus);
        AccountModel.Instance.diamond = Utils.longToNumber(msgData.lDiamond);
        AccountModel.Instance.passWord = msgData.sPassword == "" ? "" : "********";

        //切换到大厅场景
        LoginMgr.Instance.onLoginFinished();

        /** 接下来可以提前请求一些必要的数据 */
        this.reuestNecessaryData();
    }

    onRespHeartbeat(resultId: number, msgData: string) {
        Logger.info(`心跳包返回, 服务器时间戳: ${msgData}`);

        GlobalModel.Instance.serverTimeStamp = Number(msgData) * 1000;
    }

    onRespVipConfig(resultId: number, msgData: LobbyProto.VipConfigGetRsp) {
        if (resultId != 0) {
            return;
        }

        VIPModel.Instance.parseVipList(msgData.level);
        VIPModel.Instance.parseVipPrivilList(msgData.privileges);
    }

    onRespOrderCreate(resultId: number, msgData: LobbyProto.OrderCreateRsp) {
        if (resultId != 0) {
            return;
        }

        //测试
        HallReqManager.sendRecvOrderReward(msgData.orderNo);
    }

    onRespRecvOrderReward(resultId: number, msgData: LobbyProto.OrderReceiveRewardRsp) {
        if (resultId != 0) {
            return;
        }
    }

    onRespHallGameType(resultId: number, msgData: LobbyProto.HallGameTypeInfoRsp) {
        if (resultId != 0) {
            return;
        }

        if (msgData.lParentId == 0) {
            //请求一级页面游戏分类数据
            GameModel.Instance.parseHomeGameStyles(msgData.vInfo);
            EventMgr.Instance.emit(LOBBY_EVENT.HALL_GAME_TYPE_INFO);
            HallReqManager.sendHallHomeGames();
        } else {
            //请求二级页面游戏分类数据
            GameModel.Instance.parseRecommendGameStyles(msgData.vInfo);
            EventMgr.Instance.emit(LOBBY_EVENT.HALL_REMCOMMEND_TYPE_INFO);
            HallReqManager.sendRecommendGames(GameModel.Instance.getRecommendSuppliers());
        }
    }

    onRespHallHomeGames(resultId: number, msgData: LobbyProto.HallGameOneInfoRsp) {
        if (resultId != 0) {
            return;
        }

        GameModel.Instance.parseHomePageGames(msgData.vInfo);
        EventMgr.Instance.emit(LOBBY_EVENT.HALL_HOME_GAMES_INFO);
    }

    onRespHallRecommendGames(resultId: number, msgData: LobbyProto.HallGameTwoInfoRsp) {
        if (resultId != 0) {
            return;
        }

        GameModel.Instance.parseRecommendGames(msgData.vInfo);
        EventMgr.Instance.emit(LOBBY_EVENT.HALL_RECOMMEND_GAMES_INFO);
    }


    onRespSuppliersAllGames(resultId: number, msgData: LobbyProto.HallGameThreeInfoRsp) {
        Logger.info(`获取大厅三级游戏分类回复`);
        if (resultId != 0) {
            return;
        }

        GameModel.Instance.parseSupplierAllGames(msgData.vInfo);
        EventMgr.Instance.emit(LOBBY_EVENT.HALL_SUPPLIER_ALL_GAMES);
    }



    /**
     * 邮件摘要列表
     * @param resultId 
     * @param msgData 
     * @returns 
     */
    onRespMailList(resultId: number, msgData: LobbyProto.GetUserEmailDigestRsp) {
        Logger.info(`获取邮件列表回复, msgData:`, resultId, msgData, msgData.list);
        MailModel.Instance.parseMailList(msgData.list);
        EventMgr.Instance.emit(LOBBY_EVENT.USER_MAIL_LIST_INFO);
        return;

        // console.log('msgData.email: ', msgData.email);
        // for (let index = 0; index < msgData.email.length; index++) {
        //     const element = msgData.email[index];
        //     const { eid, type, status, head, digest, body, pictureUrl, hasRewards, taskIds, taskExpireType, taskExpireTime, jumpType, jumpDst } = element;
        //     console.log('element: ', index, { eid, type, status, head, digest, body, pictureUrl, hasRewards, taskIds, taskExpireType, taskExpireTime, jumpType, jumpDst });
        // }

    }

    /**
     * 邮件详情页数据
     * @param resultId 
     * @param msgData 
     * @returns 
     */
    onRespUserEmail(resultId: number, msgData: LobbyProto.GetUserEmailRsp) {
        Logger.info(`onRespUserEmail, msgData:`, resultId, msgData);
        if (resultId != 0) {
            return;
        }
        EventMgr.Instance.emit(LOBBY_EVENT.USER_MAIL_DETAIL_INFO, msgData.email);
    }

    /**
     * 用户读邮件
     * @param resultId 
     * @param msgData 
     * @returns 
     */
    onRespAlterUserEmailStatus(resultId: number, msgData: LobbyProto.AlterUserEmailStatusRsp) {
        Logger.info(`onRespAlterUserEmailStatus, msgData:`, resultId, msgData);
        if (resultId != 0) {
            return;
        }
        EventMgr.Instance.emit(LOBBY_EVENT.USER_ALTER_EMAIL_STATUS, msgData);
    }


    /***
     * 用户删除邮件
     */
    onRespRemoveUserEmailRsp(resultId: number, msgData: LobbyProto.UserRemoveEmailRsp) {
        Logger.info(`onRespRemoveUserEmailRsp, msgData:`, resultId, msgData);
        if (resultId != 0) {
            return;
        }
        EventMgr.Instance.emit(LOBBY_EVENT.USER_REMOVE_EMAIL, msgData);
    }


    /**
     * 一键删除已读邮件
     */
    onRespUserEmailRemoveAllRsp(resultId: number, msgData: LobbyProto.UserEmailRemoveAllRsp) {
        Logger.info(`onRespUserEmailRemoveAllRsp, msgData:`, resultId, msgData);
        if (resultId != 0) {
            return;
        }
        EventMgr.Instance.emit(LOBBY_EVENT.USER_REMOVE_READ_EMAIL, msgData);
    }

    /**
     * 一键标记所有邮件为已读
     * @param resultId 
     * @param msgData 
     * @returns 
     */
    onResMarkAllReadMailRsp(resultId: number, msgData: LobbyProto.UserMarkAllReadEmailRsp) {
        Logger.info(`onResMarkAllReadMailRsp, msgData:`, resultId, msgData);
        if (resultId != 0) {
            return;
        }
        EventMgr.Instance.emit(LOBBY_EVENT.USER_MARK_ALL_READ_EMAIL, msgData);
    }

    /**
     * 绑定邀请码结果
     * @param resultId 
     * @param msgData 
     */
    onRespBindInviteCode(resultId: number, msgData: LobbyProto.BindInviteCodeRsp) {
        if (resultId != 0) {
            return;
        }

        AccountModel.Instance.inviteCode = msgData.inviteCode;
        EventMgr.Instance.emit(LOBBY_EVENT.ACCOUNT_BIND_INVITE_CODE);
        ToastMgr.Instance.onRecvToast({ msg: "绑定成功" });
    }

    /**
     * 绑定手机号码结果
     * @param resultId 
     * @param msgData 
     * @returns 
     */
    onRespBindPhoneNum(resultId: number, msgData: PlatformProto.PlatformAccountBindingPhoneRsp) {
        if (resultId != 0) {
            return;
        }
        AccountModel.Instance.bindPhoneNum = msgData.sPhoneNumber;

        //重新设置登录方式为账号登录方式
        LoginMgr.Instance.saveLoginType(LoginType.Account);
        LoginMgr.Instance.saveLoginInfo(msgData.sPhoneNumber, "");

        EventMgr.Instance.emit(LOBBY_EVENT.ACCOUNT_BINDPHONE_RET);
        ToastMgr.Instance.onRecvToast({ msg: "绑定手机号码成功" });
    }

    /**
     * 设置/修改密码结果
     * @param resultId 
     * @param msgData 
     * @returns 
     */
    onRespSetPassword(resultId: number, msgData: PlatformProto.PlatformAccountSetPasswordRsp) {
        if (resultId != 0) {
            return;
        }
        AccountModel.Instance.passWord = "********";
        EventMgr.Instance.emit(LOBBY_EVENT.ACCOUNT_MODIFY_PW);
        ToastMgr.Instance.onRecvToast({ msg: "修改密码成功" });
    }

    /**
     * 代理（俱乐部）系统配置
     * @param resultId 
     * @param msgData 
     * @returns 
     */
    onRespClubConfig(resultId: number, msgData: LobbyProto.GetClubConfRsp) {
        if (resultId != 0) {
            return;
        }

        ClubModel.Instance.parseBaseConfig(msgData.level);
        ClubModel.Instance.parseTeamConfig(msgData.bindLevel);
        ClubModel.Instance.parseRebateInfo(msgData.rebate);
        // RuleModel.Instance.parseBaseConfig(msgData.rule);

        HallReqManager.sendMyClubInfo();
    }

    /**
     * 我的俱乐部信息
     * @param resultId 
     * @param msgData 
     * @returns 
     */
    onRespMyClubInfo(resultId: number, msgData: LobbyProto.GetMyClubInfoRsp) {
        if (resultId != 0) {
            return;
        }

        ClubModel.Instance.parseMyClubInfo(msgData);
        EventMgr.Instance.emit(LOBBY_EVENT.CLUB_GET_CLUB_BASE_CONFIG);
    }

    /**
     * 我的俱乐部成员
     * @param resultId 
     * @param msgData 
     * @returns 
     */
    onRespMyClubMembers(resultId: number, msgData: LobbyProto.GetCLubMemberRsp) {
        if (resultId != 0) {
            return;
        }
        ClubModel.Instance.parseMyClubTeamInfo(msgData);

        EventMgr.Instance.emit(LOBBY_EVENT.CLUB_GET_MYCUB_TEAM_INFO, [msgData.level]);
    }

    /**
     * 俱乐部分享配置
     * @param resultId 
     * @param msgData 
     * @returns 
     */
    onRespClubShareConfig(resultId: number, msgData: LobbyProto.GetClubSharePosterConfRsp) {
        if (resultId != 0) {
            return;
        }
        ClubModel.Instance.parseSharedInfo(msgData);
        EventMgr.Instance.emit(LOBBY_EVENT.SHARED_CONFIG);
    }

}

MessageRespHandler.Instance.init();