import { _decorator, sys } from "cc";
import { GAME_EVENT, TYPE_NET_WORK_STATUS } from "../event/EventDefine";
import { Logger } from "../utils/Logger";
import Singleton from "../base/Singleton";
import HeartBeatMgr from "./HeartBeatMgr";
import AccountModel from "../../model/AccountModel";
import { SocketEventMgr } from "./SocketEventMgr";
import { UIMgr } from "../manager/UIMgr";
import { EnumPrefab } from "../../config/BundleConfig";
import EventMgr from "../event/EventMgr";

const { ccclass, property } = _decorator;


export default class SocketMgr extends Singleton {
    /** 当前网络链接状态 */
    public netWorkStatus: TYPE_NET_WORK_STATUS = TYPE_NET_WORK_STATUS.one;
    /** */
    public isLogin: boolean = false;
    /** */
    private socket: WebSocket = null;
    /** 当前网络链接状态 */
    // public netWorkType: NETWORK_TYPE = NETWORK_TYPE.Login;
    private isShow: boolean = false;

    //当前断线重连次数
    private curReconnectCount: number = 0;

    //断线重连限制次数
    private reconnenctLimit: number = 5;

    //是否允许断线重连
    private bAllowReconnnect: boolean = true;

    //重连定时器
    private reconnectTimer = 0;

    //重连间隔
    private reconnectInterval = 5000;



    /**
     * 实例
     */
    static get Instance() {
        return super.GetInstance<SocketMgr>();
    }

    /**
     * 连接服务器
     * @param url 
     * @param callBack 
     * @returns 
     */
    connect(url: string, callBack: Function = null): Promise<boolean> {
        return new Promise<boolean>(async (resolve, reject) => {
            Logger.info("ws链接 ===>>> ", url);
            this.isShow = true;
            if (this.socket) {
                this.socket.onopen = null;
                this.socket.onmessage = null;
                this.socket.onclose = null;
                this.socket.onerror = null;
                this.socket = null;
            }
            this.socket = new WebSocket(url);
            this.socket.binaryType = "arraybuffer";
            this.socket.onopen = (evt) => {
                Logger.info("连接成功");
                this.onOpened(evt);
                if (this.isShow == true) {
                    this.isShow = false;
                    resolve(true);
                }
                EventMgr.Instance.emit(GAME_EVENT.ON_LOADING_CIRCLE, false);
            };
            //
            this.socket.onmessage = (evt) => {
                SocketEventMgr.Instance.onRecvData(evt);
            };
            //
            this.socket.onerror = (evt) => {
                Logger.info("失败")
                this.onError(evt);
                if (this.isShow == true) {
                    this.isShow = false;
                    resolve(false);
                }
            }
            //
            this.socket.onclose = (evt) => {
                Logger.info("关闭")
                HeartBeatMgr.close();
                this.onSocketClose(evt);
                if (this.isShow == true) {
                    this.isShow = false;
                    resolve(false);
                }
            };
        })
    };

    /** 
     * 是否打开
    */
    isOpen() {
        if (this.socket && sys.isObjectValid(this.socket)) {
            return this.socket.readyState === WebSocket.OPEN;
        } else {
            return false;
        }
    }

    /**
     * 打开连接
     */
    onOpened(evt) {
        SocketMgr.Instance.netWorkStatus = TYPE_NET_WORK_STATUS.two;
        this.curReconnectCount = 0;
        this.bAllowReconnnect = true;
        // ReLoginProxy.Instance.isInFailed = true;
        //首次登陆成功
        // this.netWorkStatus = TYPE_NET_WORK_STATUS.two;
        //开启心跳
        HeartBeatMgr.start();
    }

    /**
     * 发送消息
     */
    sendData(buf) {
        if (this.socket && this.socket.readyState == 1) {
            this.socket.send(buf);
        }
    }

    /**
     * 错误处理
     */
    onError(event) {
        Logger.warning("连接异常发生错误", event);
        if (this.netWorkStatus == TYPE_NET_WORK_STATUS.two) {
            this.netWorkStatus = TYPE_NET_WORK_STATUS.three;
        }
    }

    /**
     * 连接关闭回调
     */
    onSocketClose(event_) {
        Logger.warning("连接关闭", event_);
        if (this.socket) {
            this.socket.onopen = null;
            this.socket.onmessage = null;
            this.socket.onclose = null;
            this.socket.onerror = null;
            this.socket = null;
        }

        SocketMgr.Instance.isLogin = false;
        if (this.netWorkStatus == TYPE_NET_WORK_STATUS.two) {
            this.netWorkStatus = TYPE_NET_WORK_STATUS.three;
        }

        if (this.curReconnectCount == 0) {
            this.tryReconnect();
            return;
        }

        if (this.curReconnectCount <= this.reconnenctLimit) {
            if (this.reconnectTimer > 0) {
                clearTimeout(this.reconnectTimer);
                this.reconnectTimer = 0;
            }

            this.reconnectTimer = setTimeout(() => {
                this.tryReconnect();
            }, this.reconnectInterval);
        } else {
            this.cancelReconnect();
            Logger.debug("重连失败");
        }
    }

    /**
     * 关闭连接
     */
    close() {
        if (this.socket) {
            let tempSocket = this.socket;
            this.socket.onopen = null;
            this.socket.onmessage = null;
            this.socket.onclose = null;
            this.socket.onerror = null;
            this.socket = null;

            tempSocket.close();
        }
        HeartBeatMgr.close();
    }


    tryReconnect() {
        if (this.isConnected()) {
            return;
        }

        this.doReconnect();
    }

    isConnected() {
        if (this.socket && this.socket.readyState === WebSocket.OPEN) {
            return true;
        }
        return false;
    }

    setReconnectAble(v: boolean) {
        this.bAllowReconnnect = v;
    }


    doReconnect() {
        //不允许断线重连
        if (this.bAllowReconnnect == false) {
            return;
        }

        if (this.isConnected()) {
            return;
        }

        Logger.debug('尝试重连', this.bAllowReconnnect, this.curReconnectCount, this.isConnected());
        //showLoadingUI();
        Logger.debug(`重连第${this.curReconnectCount}次, 共 ${this.reconnenctLimit} 次`);

        //创建新的链接
        this.close();
        this.curReconnectCount++;
        let wsHost = AccountModel.Instance.host;
        SocketMgr.Instance.connect(wsHost);
    }

    cancelReconnect() {
        EventMgr.Instance.emit(GAME_EVENT.ON_LOADING_CIRCLE, false);

        this.netWorkStatus = TYPE_NET_WORK_STATUS.one;
        if (this.reconnectTimer > 0) {
            clearTimeout(this.reconnectTimer);
            this.reconnectTimer = 0;
        }
    }

}
