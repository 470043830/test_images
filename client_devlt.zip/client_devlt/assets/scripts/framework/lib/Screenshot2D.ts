
import { _decorator, native, Component, Node, Camera, RenderTexture, director, gfx, ImageAsset, renderer, view, Size, Texture2D, SpriteFrame, Sprite, UITransform, spriteAssembler, sys, Vec2, Canvas, warnID, log, error, Button, assetManager, instantiate, Vec3, Label, v3, tween } from 'cc';
import { Canvas2Image } from './Canvas2Image';
import { Logger } from '../utils/Logger';
import { ToastMgr } from '../manager/ToastMgr';
const { ccclass, property } = _decorator;

@ccclass('Screenshot2D')
export class Screenshot2D extends Component {

    @property(Camera)
    copyCamera: Camera = null!;

    @property(Node)
    targetNode: Node = null!;

    @property(Button)
    downloaderBtn: Button = null!;

    @property(Node)
    copyNode: Node = null!;

    rt: RenderTexture = null;

    _canvas: HTMLCanvasElement = null!;

    _buffer: ArrayBufferView = null!;

    canvas2image: Canvas2Image = null!;

    private _captureEndCall = null;

    start() {
        this.canvas2image = Canvas2Image.getInstance();
        this.rt = new RenderTexture();
        this.rt.reset({
            width: view.getVisibleSize().width,
            height: view.getVisibleSize().height,
        })
        this.copyCamera.targetTexture = this.rt;
    }

    capture(targetNode: Sprite, callback) {
        this.targetNode = targetNode.node;
        this._captureEndCall = callback;

        this.copyRenderTex();
    }

    copyRenderTex() {
        var width = this.targetNode.getComponent(UITransform).width;
        var height = this.targetNode.getComponent(UITransform).height;
        var worldPos = this.targetNode.getWorldPosition();

        this._buffer = this.rt.readPixels(Math.round(worldPos.x - width * 0.5), Math.round(worldPos.y - height * 0.5), width, height);
        this.showImage(width, height);
    }

    showImage(width, height) {
        let img = new ImageAsset();
        img.reset({
            _data: this._buffer,
            width: width,
            height: height,
            format: Texture2D.PixelFormat.RGBA8888,
            _compressed: false
        });
        let texture = new Texture2D();
        texture.image = img;
        let sf = new SpriteFrame();
        sf.texture = texture;
        sf.packable = false;

        if (this.copyNode) {
            let cpSprite = instantiate(this.copyNode);
            this.copyNode.parent.addChild(cpSprite);

            cpSprite.getComponent(Sprite).spriteFrame = sf;
            cpSprite.getComponent(Sprite).spriteFrame.flipUVY = true;
            if (sys.isNative && (sys.os === sys.OS.IOS || sys.os === sys.OS.OSX)) {
                cpSprite.getComponent(Sprite).spriteFrame.flipUVY = false;
            }
            cpSprite.getComponent(UITransform)?.setContentSize(new Size(width, height));

            tween(cpSprite)
                .delay(1)
                .to(0.25, { scale: v3(0, 0, 1) })
                .destroySelf()
                .start();
        }

        // this.downloaderBtn.node.active = true;
        Logger.debug(`截图成功`);
        ToastMgr.Instance.onRecvToast({ msg: `截图成功` });
        this.onSaveImageBtnClicked();
    }

    savaAsImage(width, height, arrayBuffer) {
        if (sys.isBrowser) {
            if (!this._canvas) {
                this._canvas = document.createElement('canvas');
                this._canvas.width = width;
                this._canvas.height = height;
            } else {
                this.clearCanvas();
            }
            let ctx = this._canvas.getContext('2d')!;
            let rowBytes = width * 4;
            for (let row = 0; row < height; row++) {
                let sRow = height - 1 - row;
                let imageData = ctx.createImageData(width, 1);
                let start = sRow * width * 4;
                for (let i = 0; i < rowBytes; i++) {
                    imageData.data[i] = arrayBuffer[start + i];
                }
                ctx.putImageData(imageData, 0, row);
            }
            //@ts-ignore
            let filePath = this.canvas2image.saveAsPNG(this._canvas, width, height);
            Logger.debug(`保存图片成功`);
            return filePath;
        } else if (sys.isNative) {
            let filePath = native.fileUtils.getWritablePath() + 'render_to_sprite_image.png';
            //@ts-ignore
            if (jsb.saveImageData) {
                //@ts-ignore
                jsb.saveImageData(this._buffer, width, height, filePath).then(() => {
                    assetManager.loadRemote<ImageAsset>(filePath, (err, imageAsset) => {
                        if (err) {
                            console.log("show image error")
                        } else {
                            var newNode = instantiate(this.targetNode);
                            newNode.setPosition(new Vec3(-newNode.position.x, newNode.position.y, newNode.position.z));
                            this.targetNode.parent.addChild(newNode);

                            const spriteFrame = new SpriteFrame();
                            const texture = new Texture2D();
                            texture.image = imageAsset;
                            spriteFrame.texture = texture;
                            newNode.getComponent(Sprite).spriteFrame = spriteFrame;
                            spriteFrame.packable = false;
                            spriteFrame.flipUVY = true;
                            if (sys.isNative && (sys.os === sys.OS.IOS || sys.os === sys.OS.OSX)) {
                                spriteFrame.flipUVY = false;
                            }

                            Logger.debug(`成功保存在设备目录并加载成功: ${filePath}`);
                        }
                    });
                    log("save image data success, file: " + filePath);
                    Logger.debug(`成功保存在设备目录: ${filePath}`);
                }).catch(() => {
                    error("save image data failed!");
                    Logger.debug(`保存图片失败`);
                });
            }

            return filePath;
        } else if (sys.platform === sys.Platform.WECHAT_GAME) {
            if (!this._canvas) {
                //@ts-ignore
                this._canvas = wx.createCanvas();
                this._canvas.width = width;
                this._canvas.height = height;
            } else {
                this.clearCanvas();
            }
            var ctx = this._canvas.getContext('2d');

            var rowBytes = width * 4;

            for (var row = 0; row < height; row++) {
                var sRow = height - 1 - row;
                var imageData = ctx.createImageData(width, 1);
                var start = sRow * width * 4;

                for (var i = 0; i < rowBytes; i++) {
                    imageData.data[i] = arrayBuffer[start + i];
                }

                ctx.putImageData(imageData, 0, row);
            }
            //@ts-ignore
            this._canvas.toTempFilePath({
                x: 0,
                y: 0,
                width: this._canvas.width,
                height: this._canvas.height,
                destWidth: this._canvas.width,
                destHeight: this._canvas.height,
                fileType: "png",
                success: (res) => {
                    //@ts-ignore
                    wx.showToast({
                        title: "截图成功"
                    });
                    Logger.debug(`截图成功`);
                    //@ts-ignore
                    wx.saveImageToPhotosAlbum({
                        filePath: res.tempFilePath,
                        success: (res) => {
                            //@ts-ignore              
                            wx.showToast({
                                title: "成功保存到设备相册",
                            });
                            Logger.debug(`成功保存在设备目录: ${res.tempFilePath}`);
                        },
                        fail: () => {
                            Logger.debug(`保存图片失败`);
                        }
                    })
                },
                fail: () => {
                    //@ts-ignore
                    wx.showToast({
                        title: "截图失败"
                    });
                    Logger.debug(`截图失败`);
                }
            })
        }
    }

    clearCanvas() {
        let ctx = this._canvas.getContext('2d');
        ctx.clearRect(0, 0, this._canvas.width, this._canvas.height);
    }

    onSaveImageBtnClicked() {
        var width = this.targetNode.getComponent(UITransform).width;
        var height = this.targetNode.getComponent(UITransform).height;
        let savePath = this.savaAsImage(width, height, this._buffer);

        this._captureEndCall && this._captureEndCall(savePath);

    }
}
