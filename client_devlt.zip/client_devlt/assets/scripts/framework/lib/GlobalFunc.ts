import * as cc from "cc";
import { Utils } from "../utils/Utils";
import { ToastMgr } from "../manager/ToastMgr";

export function performWithDelay(node, callFunc, delayTime) {
    if (node && callFunc) {
        cc.tween(node)
            .delay(delayTime)
            .call(() => {
                callFunc && callFunc();
            })
            .start()
    }
}

export function schedule(node: cc.Node, callFunc, delayTime) {
    if (node && callFunc) {
        cc.tween(node)
            .repeatForever(
                cc.tween(node)
                    .delay(delayTime)
                    .call(() => {
                        callFunc && callFunc();
                    }))
            .start()
    }
}

/**
 * 倒计时
 * @param lab 
 * @param leftTime 
 */
export function StartTimeCountDown(lab: cc.Label, leftTime: number, endCall = null, fmt = "00:00:00", descFmt = "%s", stepCall = null) {
    StopTimeCountDown(lab);
    lab.string = cc.js.formatStr(descFmt, Utils.formatTimeString(leftTime, fmt));
    let startTime = Date.now();
    cc.tween(lab.node)
        .repeatForever(
            cc.tween(lab.node)
                .call(() => {
                    let nowTime = Date.now();
                    let delta = (nowTime - startTime) / 1000;
                    leftTime -= delta;

                    startTime = nowTime;

                    if (leftTime >= 0) {
                        lab.string = cc.js.formatStr(descFmt, Utils.formatTimeString(Math.floor(leftTime), fmt));
                        stepCall && stepCall(Math.floor(leftTime));
                    } else {
                        lab.string = cc.js.formatStr(descFmt, Utils.formatTimeString(0, fmt));
                        StopTimeCountDown(lab);
                        if (endCall) {
                            endCall()
                        }
                    }
                })
                .delay(1)
        )
        .start()
}

/**
 * 停止倒计时
 * @param lab 
 */
export function StopTimeCountDown(lab: cc.Label | cc.RichText) {
    if (cc.isValid(lab)) {
        cc.Tween.stopAllByTarget(lab.node)
    }
}

/**
 * 生成指定长度的随机字符串
 * @param length 
 * @returns 
 */
export function generateRandomString(length) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
}

/**
 * 加载远程图片
 * @param sp 
 * @param url 
 * @param callback 
 */
export function loadRemoteImg(sp: cc.Sprite, url: string, callback = null) {
    cc.assetManager.loadRemote(url, null, (err, data: cc.Texture2D) => {
        if (!err) {
            if (data) {
                let frame = cc.SpriteFrame.createWithImage(data as any);
                sp.spriteFrame = frame;

                callback && callback();
            }
        }
    })
}


/**
* 校验数字格式
* @param txt 输入的文字
* @param len 需要数字的长度
*/
export function checkNumber(txt: string, len: number, emptyTips: string, failTips: string, lenStric = false) {
    let ret = false;
    if (txt == "" && emptyTips) {
        ToastMgr.Instance.onRecvToast({ msg: emptyTips });
        return ret;
    }

    let vf = txt.match(/^\d+$/g)
    if (lenStric) {
        ret = (vf && vf[0].length == len);
    } else {
        ret = (vf && vf[0].length >= len);
    }

    if (!ret) {
        ToastMgr.Instance.onRecvToast({ msg: failTips });
    }

    return ret;
}

export function checkPhoneNumber(txt: string, emptyTips: string, failTips: string) {
    let ret = false;
    if (emptyTips == "" && emptyTips) {
        ToastMgr.Instance.onRecvToast({ msg: emptyTips });
        return ret;
    }

    let vf = txt.match(/^[1-9]{2}\-?[1-9]{1}\-?\d{3,4}\-?\d{4}$/); //请与后台保持一致的验证格式
    if (vf && vf[0].length >= 0) {
        ret = true;
    }

    if (!ret) {
        ToastMgr.Instance.onRecvToast({ msg: failTips });
    }

    return ret;
}

/**
 * 校验邮件格式
 * @param txt 
 */
export function checkEmail(txt: string, failTips: string) {
    let ret = false;
    let reg = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
    ret = reg.test(txt);

    if (!ret) {
        ToastMgr.Instance.onRecvToast({ msg: failTips });
    }

    return ret;
}

/**
 * 取得某月有几天
 * @returns 
 */
export function getDaysInMonth(year, month) {
    return new Date(year, month, 0).getDate();
}


/**
 * 两个时间戳是否为同一天
 * @param timestamp1 
 * @param timestamp2 
 * @returns 
 */
export function isSameDay(timestamp1, timestamp2) {
    const date1 = new Date(timestamp1);
    const date2 = new Date(timestamp2);

    return (
        date1.getFullYear() === date2.getFullYear() &&
        date1.getMonth() === date2.getMonth() &&
        date1.getDate() === date2.getDate()
    );
}
