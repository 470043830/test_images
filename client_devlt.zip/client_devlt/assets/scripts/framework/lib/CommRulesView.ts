import * as cc from 'cc';
import RuleModel from '../../model/RuleModel';
import { Logger } from '../utils/Logger';
import { loadRemoteImg } from './GlobalFunc';

const { ccclass, property } = cc._decorator;


/**
 * 通用规则页面
 */
@ccclass('CommRulesView')
export class CommRulesView extends cc.Component {
    @property({ type: cc.Layout, tooltip: "布局节点" })
    layout: cc.Layout = null;

    @property({ type: cc.RichText, tooltip: "富文本" })
    richTextTemp: cc.RichText = null;

    @property({ type: cc.Button, tooltip: "按钮" })
    btnTemp: cc.Button = null;

    @property({ type: cc.Sprite, tooltip: "图片" })
    imgTemp: cc.Sprite = null;

    @property({ type: cc.Node, tooltip: "底部空间" })
    bottomNode: cc.Node = null;

    protected onLoad(): void {
        this.richTextTemp.node.active = false;
        this.btnTemp.node.active = false;
        this.imgTemp.node.active = false;
        this.bottomNode.active = false;
    }

    initView(rulePageID: string) {
        let info = RuleModel.Instance.getRules(rulePageID);
        if (!info) {
            return;
        }

        info.forEach(e => {
            if (e.showButton === 1) {
                if (e.buttonDesc != "") {
                    this.addButton(e.buttonDesc, e.buttonEvent, e.buttonParam);
                }
            }

            if (e.imgUrl != "") {
                this.addImage(e.imgUrl);
            }

            if (e.richText != "") {
                this.addRichText(e.richText);
            }
        })

        this.bottomNode.removeFromParent();
        this.layout.node.addChild(this.bottomNode);
        this.bottomNode.active = true;
    }

    addButton(desc: string, clickEvent, eventParam) {
        let newBtn = cc.instantiate(this.btnTemp.node);
        newBtn.active = true;
        this.layout.node.addChild(newBtn);

        newBtn.on(cc.Button.EventType.CLICK, () => {
            Logger.info(`跳转到指定页面`);
        })

        newBtn.getComponentInChildren(cc.Label).string = desc;
    }

    addRichText(text: string) {
        let richText = cc.instantiate(this.richTextTemp.node);
        richText.active = true;
        this.layout.node.addChild(richText);

        richText.getComponent(cc.RichText).string = text;
    }

    addImage(imgUrl: string) {
        let img = cc.instantiate(this.imgTemp.node);
        img.active = true;
        this.layout.node.addChild(img);

        loadRemoteImg(img.getComponent(cc.Sprite), imgUrl);
    }

}