import * as cc from "cc"
import { performWithDelay } from "./GlobalFunc"

export interface IComlistData {
    scrollView: cc.ScrollView
    itemPrefab: cc.Prefab | cc.Node
    itemClass: any
    dataList: any[]
    dataEx: any,
    space?: number
    top?: number,
    bottom?: number
    left?: number
    right?: number
    createInterval?: number
    scrollToIndex?: number
    callFuncRollingToLeft?: any
    callFuncRollingToRight?: any
    callFuncRollingToBottom?: any
    callFuncRollingToTop?: any
    onMoving?: any
}

enum ScrollDirector {
    Left,
    Right,
    Top,
    Bottom,
    None
}

/**
 * 使用ComListView的item 需要实现的接口
 */

export interface IComListItem {
    updateItem(idx: number, data: any, dataExt: any);
}


/**
 * 列表界面优化
 */
const { ccclass, property, menu } = cc._decorator;

`
应用举例:

    let viewData = {
        scrollView: this.scrollView,
        content: this.scrollView.content,
        itemPrefab: this.pfItem,
        itemClass: ExchangeRecordItem,
        dataList: listData,
        dataEx: null,
        space: 0,
        createInterval: 0.05,
    }

    let comListView = this.scrollView.getComponent(ComListView);
    (comListView == null) && (comListView = this.scrollView.addComponent(ComListView))
    comListView.initParams(viewData)
    comListView.initScrollView(true);
`

@ccclass
@menu("自定义/ComListView")
export class ComListView extends cc.Component {
    public static CachesNum: number = 1;

    // 传参
    mScrollView: cc.ScrollView = null;
    mContent: cc.Node = null;
    mItemPrefab: cc.Prefab | cc.Node = null;
    mItemClass: any = null;
    mDataList: Array<any> = null;   //列表数据
    mDataEx: Array<any> = null;     //扩展数据
    mSpace: number = 0;
    mTop: number = 0;
    mBottom: number = 0;
    mLeft: number = 0;
    mRight: number = 0;
    mCreateInterval: number = 0;    //item创建间隔
    mScrollToIndex: number = 0;     //创建完成后，自动滚动至index

    mScrollLeftCallFunc = null;         //滚动结束后的回调（左边）
    mScrollRightCallFunc = null;        //滚动结束后的回调（右边）
    mScrollBottomCallFunc = null;       //滚动结束后的回调（底边）
    mScrollTopCallFunc = null;          //滚动结束后的回调（顶边）
    mFuncOnMoving = null;               //滚动回调

    prefabCellWidth: number = 0;  //itemprefab的宽度
    prefabCellHeight: number = 0; //itemprefab的高度
    lastContentPosX: number = 0;  //上次的坐标
    lastContentPosY: number = 0;
    _showZone: number = 0;        //显示区域大小
    _cellSize: number = 0;         //itemprefab的宽度和高度，根据列表滑动方向决定
    _EdgeBottom: number = 0;
    _EdgeTop: number = 0;
    _EdgeLeft: number = 0;
    _EdgeRight: number = 0;

    // 子项总数量
    rowAllNum: number = 0;
    // 可视区域内部填充的item数量
    rowItemCounts: number = 0;
    // 可视个数+缓冲个数
    rowCacheNum: number = 0;
    // 创建的item节点的数组（总缓存元素）
    itemViewList: Array<cc.Node> = new Array<cc.Node>();

    // 控制更新
    _isUpdate: boolean = false;
    updateTimer: number = 0;
    updateInterval: number = 0.00;

    private _createFinished = false;
    private _scrollDir: ScrollDirector = ScrollDirector.None;       //滑动方向


    /**
     * @param data.scrollView - 列表视图节点
     * @param data.content - 列表内容节点
     * @param data.itemPrefab - 列表子元素的prefab
     * @param data.itemClass - 列表子元素的实现类，需要重写updateItem方法
     * @param data.dataList - 列表所有数据
     * @param data.dataEx - 扩展数据
     * @param data.space - 子元素的间距
     * @param data.top - 与列表顶端的间距
     * @param data.bottom - 与列表底部的间距
     * @param data.createInterval - item创建间隔
     * @param data.mScrollToIndex - 创建完成后，自动滚动至index
     */
    public initParams(data: any | IComlistData): void {
        this.mScrollView = data.scrollView;
        this.mContent = data.scrollView.content;
        this.mItemPrefab = data.itemPrefab;
        this.mItemClass = data.itemClass;
        this.mDataList = data.dataList || [];
        this.mDataEx = data.dataEx;
        this.mSpace = data.space || 0;
        this.mTop = data.top || 0;
        this.mBottom = data.bottom || 0;
        this.mLeft = data.left || 0;
        this.mRight = data.right || 0;
        this.mCreateInterval = data.createInterval || 0;
        this.mScrollToIndex = data.scrollToIndex || 0;

        this.mScrollLeftCallFunc = data.callFuncRollingToLeft;
        this.mScrollRightCallFunc = data.callFuncRollingToRight;
        this.mScrollBottomCallFunc = data.callFuncRollingToBottom;
        this.mScrollTopCallFunc = data.callFuncRollingToTop;
        this.mFuncOnMoving = data.onMoving;
    }

    /**
     * 重设列表数据，以保证列表滚动后，使用最新数据刷新item
     * @param newListData 
     */
    public refreshItemsWithData(newListData) {
        this.mDataList = newListData || []
        // console.log("重置列表数据", this.mDataList)

        this.refreshItems();
    }

    public refreshItemsWithDataEx(dataEx) {
        this.mDataEx = dataEx
        // console.log("重置扩展数据", this.mDataEx)
        this.refreshItems();
    }

    public refreshItemsWithAllData(newListData, dataEx) {
        this.mDataList = newListData || []
        this.mDataEx = dataEx
        // console.log("重置列表数据", this.mDataList)

        this.refreshItems();
    }

    public initScrollView(imme: boolean = false): void {
        this.initListData();

        if (imme) {
            this.initItemListToIndex(this.mScrollToIndex);
        } else {
            this.initItemList();
        }
        this._EdgeBottom = this._showZone * (0.0 - this.mScrollView.node.getComponent(cc.UITransform).anchorY);
        this._EdgeTop = this._showZone * (1.0 - this.mScrollView.node.getComponent(cc.UITransform).anchorY);
        this._EdgeLeft = this._showZone * (0.0 - this.mScrollView.node.getComponent(cc.UITransform).anchorX);
        this._EdgeRight = this._showZone * (1.0 - this.mScrollView.node.getComponent(cc.UITransform).anchorX);
    }

    private initListData(): void {
        //计算元素大小       
        if (this.mItemPrefab instanceof (cc.Prefab)) {
            this.prefabCellWidth = this.mItemPrefab.data.getComponent(cc.UITransform).width || 1;
            this.prefabCellHeight = this.mItemPrefab.data.getComponent(cc.UITransform).height || 1;
        } else if (this.mItemPrefab instanceof (cc.Node)) {
            this.prefabCellWidth = this.mItemPrefab.getComponent(cc.UITransform).width || 1;
            this.prefabCellHeight = this.mItemPrefab.getComponent(cc.UITransform).height || 1;
        }

        // 获取显示区域
        if (this.mScrollView.vertical) {
            // 列表视图的大小
            this._showZone = this.mScrollView.node.getComponent(cc.UITransform).height;
            // console.log("区域大小", this._showZone)
            // 子元素的大小
            this._cellSize = this.prefabCellHeight;
            // 可视区域内部填充的元素数量
            this.rowItemCounts = Math.ceil(this._showZone / (this._cellSize + this.mSpace));
        } else {
            this._showZone = this.mScrollView.node.getComponent(cc.UITransform).width;
            this._cellSize = this.prefabCellWidth;
            this.rowItemCounts = Math.ceil(this._showZone / (this._cellSize + this.mSpace));
        }

        // 元素全部的总数
        this.rowAllNum = this.mDataList.length;
        // 总缓存元素数量 = 可视元素个数+缓冲个数
        this.rowCacheNum = this.rowItemCounts + ComListView.CachesNum;

        // 监听滑动事件
        this.mScrollView.node.on(cc.ScrollView.EventType.SCROLLING, this.scrolling.bind(this), this);
        this.mScrollView.node.on(cc.ScrollView.EventType.SCROLL_ENDED, this.scrollEnded.bind(this), this);
        // this.mScrollView.node.on(cc.ScrollView.EventType.SCROLL_TO_LEFT, this.scrollEndedToLeft.bind(this), this);
        // this.mScrollView.node.on(cc.ScrollView.EventType.SCROLL_TO_RIGHT, this.scrollEndedToRight.bind(this), this);
        // this.mScrollView.node.on(cc.ScrollView.EventType.SCROLL_TO_BOTTOM, this.scrollEndedToBottom.bind(this), this);
        // this.mScrollView.node.on(cc.ScrollView.EventType.SCROLL_TO_TOP, this.scrollEndedToTop.bind(this), this);
    }

    private initItemList(): void {
        this._isUpdate = false;
        this.clearItem();
        this.mContent.removeComponent(cc.Layout); //一定不能有layout

        if (this.mItemPrefab && this.mDataList && this.mItemClass) {
            for (let i = 0; i < this.rowCacheNum; i++) {
                performWithDelay(this.node, () => {
                    this.createItem(i, this.mDataList[i]);
                    if (i == this.rowCacheNum - 1) {
                        this._createFinished = true;
                        // console.log("item动作", "finish")
                        this.ScrollTo(this.mScrollToIndex, this.mScrollToIndex * 0.1);
                    }
                }, this.mCreateInterval * i)
            }
            // 设置ScrollView的大小, 不设置无法滑动
            if (this.mScrollView.vertical) {
                this.mContent.getComponent(cc.UITransform).height = this.rowAllNum * (this.prefabCellHeight + this.mSpace) + this.mTop + this.mBottom;
            } else {
                this.mContent.getComponent(cc.UITransform).width = this.rowAllNum * (this.prefabCellWidth + this.mSpace) + this.mTop + this.mBottom;
            }
        }
    }

    private initItemListToIndex(toIdx: number = 0): void {
        this._isUpdate = false;
        this.clearItem();
        this.mContent.removeComponent(cc.Layout); //一定不能有layout
        if (toIdx <= 0) {
            toIdx = 0
        } else if (toIdx > this.mDataList.length - this.rowCacheNum) {
            toIdx = this.mDataList.length - this.rowCacheNum
        }

        let dataList = this.mDataList.slice(toIdx, this.mDataList.length)

        if (this.mItemPrefab && dataList && this.mItemClass) {
            for (let i = 0; i < this.rowCacheNum; i++) {
                performWithDelay(this.node, () => {
                    this.createItem(i + toIdx, dataList[i]);
                    if (i == this.rowCacheNum - 1) {
                        this._createFinished = true;
                        this.ScrollTo(this.mScrollToIndex, 0);
                        this.mScrollView.scrollToOffset(new cc.Vec2(0, this.calScrollOffset(toIdx)))
                    }
                }, this.mCreateInterval * i)
            }
            // 设置ScrollView的大小, 不设置无法滑动
            if (this.mScrollView.vertical) {
                this.mContent.getComponent(cc.UITransform).height = this.rowAllNum * (this.prefabCellHeight + this.mSpace) + this.mTop + this.mBottom;
            } else {
                this.mContent.getComponent(cc.UITransform).width = this.rowAllNum * (this.prefabCellWidth + this.mSpace) + this.mTop + this.mBottom;
            }
        }
    }


    private createItem(idx, data) {
        let item = this.itemViewList[idx];

        if (data != undefined && data != null) {
            if (!item) {
                // 实例化元素
                item = cc.instantiate(this.mItemPrefab) as cc.Node;
                if (this.mContent) {
                    this.mContent.addChild(item);
                    item.setSiblingIndex(idx);
                    // 添加到视图列表
                    this.itemViewList.push(item);
                }
            }
            item.active = true;

            // 设置ID
            (item as any).__itemID = idx;

            //设置坐标
            let cellSize = (this._cellSize + this.mSpace);
            if (this.mScrollView.vertical) {
                //列表内容是top_center对齐，原点位于列表顶端（注：content不能设置为layout对齐 ）
                item.setPosition(cc.v3(0, -idx * cellSize - cellSize / 2 - this.mTop))
            } else {
                //列表内容是left_center对齐，原点位于列表左端（注：content不能设置为layout对齐 ）
                item.setPosition(cc.v3(idx * cellSize + cellSize / 2 + this.mLeft, 0))
            }

            let cls = item.getComponent(this.mItemClass) as any;
            if (cls && cls.updateItem) {
                cls.updateItem(idx, data, this.mDataEx);
            }
        }
    }

    /**
     * 数据被修改后，主动刷新列表
     */
    private refreshItems() {
        this.itemViewList.forEach((item) => {
            let cls = item.getComponent(this.mItemClass) as any;
            if (cls && cls.updateItem) {
                let itemID = (item as any).__itemID;
                let itemData = this.mDataList[itemID];
                if (itemData) {
                    cls.updateItem(itemID, itemData, this.mDataEx);
                }
            }
        })
    }


    /**
     * 获取item在scrollview中的位置
     * @param item item位置
     */
    private getPositionInView(item: cc.Node) {
        // get item position in scrollview's node space
        let worldPos = item.parent.getComponent(cc.UITransform).convertToWorldSpaceAR(item.position);
        let viewPos = this.mScrollView.node.getComponent(cc.UITransform).convertToNodeSpaceAR(worldPos);
        return viewPos;
    }

    calScrollOffset(toIndex) {
        let scorllDis = 0;
        if (this.mItemPrefab instanceof cc.Node) {
            scorllDis = toIndex == 0 ? 0 : this.mTop + (this.mItemPrefab.getComponent(cc.UITransform).height + this.mSpace) * toIndex
        } else {
            scorllDis = toIndex == 0 ? 0 : this.mTop + (this.mItemPrefab.data.getComponent(cc.UITransform).height + this.mSpace) * toIndex
        }
        return scorllDis
    }

    /**
     * 滚动到指定cell所在索引
     * @param toIndex 
     */
    ScrollTo(toIndex, scrollTime: number = 0) {

        // let itemSize = 0
        // if (this.mItemPrefab instanceof (cc.Prefab)) {
        //     itemSize = this.mScrollView.vertical ? this.mItemPrefab.data.height : this.mItemPrefab.data.width;
        // } else if (this.mItemPrefab instanceof (cc.Node)) {
        //     itemSize = this.mScrollView.vertical ? this.mItemPrefab.getComponent(cc.UITransform).height : this.mItemPrefab.getComponent(cc.UITransform).width;
        // }

        // let scorllDisX = toIndex == 0 ? 0 : this.mLeft + (itemSize + this.mSpace) * toIndex
        // let scorllDisY = toIndex == 0 ? 0 : this.mTop + (itemSize + this.mSpace) * toIndex

        // this.mScrollView.stopAutoScroll()
        // this.mScrollView.scrollToOffset(new cc.Vec2(scorllDisX + 5, scorllDisY + 5), scrollTime + 0.1)
        // this.mScrollView.scrollTo(new cc.Vec2(scorllDisX + 5, scorllDisY + 5), scrollTime + 0.1)
        let pct = toIndex / (this.mDataList.length - 1);
        pct *= 1.05;
        if (this.mScrollView.vertical) {
            this.mScrollView.scrollToPercentVertical(pct, scrollTime);
        } else {
            this.mScrollView.scrollToPercentHorizontal(pct, scrollTime, true);
        }
        this.scrolling()
    }

    /**
     * 计算要滚动的距离
     * @param cellHeight 
     * @param curIndx 滚动至哪个cell
     * @param maxShowCount scrollview能看显示最大cell的数量
     * @returns 
     */
    calScrollDistance(cellHeight, curIndx, maxShowCount = 3) {
        let scrollDis = 0;
        if (curIndx >= maxShowCount) {
            scrollDis = (curIndx - 1) * cellHeight;    //要移动的距离 = （要展示的cell所在索引 -1）* cell高度
        }
        return scrollDis;
    }

    /**
     * 监听：滚动时更新
     */
    private scrolling() {
        this._isUpdate = true;
    }

    // /**
    //  * 拖拽至左右上下边界
    //  */
    // scrollEndedToLeft() {
    //     console.log("拖住至左边")
    //     this.mScrollLeftCallFunc && this.mScrollLeftCallFunc();
    // }

    // scrollEndedToRight() {
    //     console.log("拖住至右边")
    //     this.mScrollRightCallFunc && this.mScrollRightCallFunc();
    // }

    // scrollEndedToBottom() {
    //     console.log("拖住至底边")
    //     this.mScrollBottomCallFunc && this.mScrollBottomCallFunc();
    // }

    // scrollEndedToTop() {
    //     console.log("拖住至上边")
    //     this.mScrollTopCallFunc && this.mScrollTopCallFunc();
    // }


    /**
     * 监听：滚动停止时不执行逻辑
     */
    private scrollEnded() {
        // console.log("滚动结束")
        this._isUpdate = false;
        let contentSize = this.mScrollView.content.getComponent(cc.UITransform);
        if (this.mScrollView.vertical) {
            let y = this.mScrollView.content.getPosition().y
            let t = 0;
            let b = contentSize.height - this.mScrollView.view.getComponent(cc.UITransform).height;
            if (y - 1 <= t) {
                // console.log("到达顶部")
                this.mScrollTopCallFunc && this.mScrollTopCallFunc();
            } else if (y + 1 >= b) {
                // console.log("到达底部")
                this.mScrollBottomCallFunc && this.mScrollBottomCallFunc();
            }
        } else {
            let x = this.mScrollView.content.getPosition().x
            let l = 0;
            let r = -(contentSize.width - this.mScrollView.view.getComponent(cc.UITransform).width)
            // console.log("宽度, x, l, r ==>", contentSize.width, x, l, r);
            if (x + 1 >= l) {
                // console.log("到达左边")
                this.mScrollLeftCallFunc && this.mScrollLeftCallFunc();
            } else if (x - 1 <= r) {
                // console.log("到达右边")
                this.mScrollRightCallFunc && this.mScrollRightCallFunc();
            }
        }

        // if (this._scrollDir == ScrollDirector.Left) {
        //     console.log("滚动方向: 左")
        //     this.mScrollRightCallFunc && this.mScrollRightCallFunc();
        // } else if (this._scrollDir == ScrollDirector.Right) {
        //     console.log("滚动方向: 右")
        //     this.mScrollLeftCallFunc && this.mScrollLeftCallFunc();
        // } else if (this._scrollDir == ScrollDirector.Bottom) {
        //     console.log("滚动方向: 下")
        //     this.mScrollTopCallFunc && this.mScrollTopCallFunc();
        // } else if (this._scrollDir == ScrollDirector.Top) {
        //     console.log("滚动方向: 上")
        //     this.mScrollBottomCallFunc && this.mScrollBottomCallFunc();
        // }
    }

    update(dt) {
        // 滚动时刷新
        if (!this._isUpdate || !this.itemViewList || !this.mScrollView || !this._createFinished) {
            return;
        }

        this._isUpdate = this.mScrollView.isAutoScrolling() || this.mScrollView.isScrolling();

        //不需要每一帧都刷新
        this.updateTimer += dt;
        if (this.updateTimer < this.updateInterval) {
            return;
        }

        this.updateTimer = 0;
        let itemList = this.itemViewList;
        let showZone = this._showZone;

        if (this.mScrollView.vertical) {
            //是否下滑，滑动方向
            this._scrollDir = this.mScrollView.content.getPosition().y < this.lastContentPosY ? ScrollDirector.Bottom : ScrollDirector.Top;

            let offset = (this._cellSize + this.mSpace) * (this.rowCacheNum);

            // 计算坐标是否超过<所有缓存元素总大小>的一半

            for (let i = 0; i < this.rowCacheNum; i++) {
                let itemNode = itemList[i];
                if (cc.isValid(itemNode)) {
                    let viewPos = this.getPositionInView(itemNode);
                    // console.log("getPositionInView()"+`i=${i}`+`, x=${viewPos.x}`+`, y=${viewPos.y}`);

                    if (this._scrollDir == ScrollDirector.Bottom) {
                        // 下滑，判断当前item的坐标是否超过底部

                        if (viewPos.y + (this._cellSize + this.mSpace) / 2 < this._EdgeBottom) {
                            // 获取新的id和数据
                            let newId = (itemNode as any).__itemID - this.rowCacheNum;
                            if (newId < 0) {
                                continue;
                            }
                            (itemNode as any).__itemID = newId;
                            let data = this.mDataList[newId];

                            // console.log("滑到了底部");
                            //设置新坐标，放在最顶部
                            itemNode.setPosition(itemNode.getPosition().x, itemNode.getPosition().y + offset);
                            itemNode.setSiblingIndex(newId);

                            // 刷新元素的显示
                            let cls = itemNode.getComponent(this.mItemClass) as any;
                            if (cls && cls.updateItem) {
                                cls.updateItem(newId, data, this.mDataEx);
                            }
                        }
                    } else {
                        // 上滑，当前item的坐标是否大于顶部最大Y
                        // let topMax = showZone / 2  + (this._cellSize + this.mSpace) / 2;
                        // if((viewPos.y > topMax) && (itemNode.y - offset > this.mContent.height)){

                        if (viewPos.y - (this._cellSize + this.mSpace) / 2 > this._EdgeTop) {
                            // //Logger.info("getPositionInView() max "+`, __itemID=${(itemNode as any).__itemID}`);
                            // 获取新的id和数据
                            let newId = (itemNode as any).__itemID + this.rowCacheNum;
                            if (newId >= this.rowAllNum) {
                                continue;
                            }

                            (itemNode as any).__itemID = newId;
                            let data = this.mDataList[newId];

                            // console.log("滑到了顶部");
                            //设置新坐标，放在最底部
                            itemNode.setPosition(itemNode.getPosition().x, itemNode.getPosition().y - offset);
                            itemNode.setSiblingIndex(newId);

                            // 刷新元素的显示
                            let cls = itemNode.getComponent(this.mItemClass) as any;
                            if (cls && cls.updateItem) {
                                cls.updateItem(newId, data, this.mDataEx);
                            }
                        }
                    }
                }
            }
            // 保存上次的Y坐标
            this.lastContentPosY = this.mScrollView.content.getPosition().y;
            this.mFuncOnMoving && this.mFuncOnMoving(this.lastContentPosY);
        } else {
            //滑动方向
            this._scrollDir = this.mScrollView.content.getPosition().x < this.lastContentPosX ? ScrollDirector.Left : ScrollDirector.Right;
            let offset = (this._cellSize + this.mSpace) * (this.rowCacheNum);

            for (let i = 0; i < this.rowCacheNum; i++) {
                let itemNode = itemList[i];
                if (cc.isValid(itemNode)) {
                    let viewPos = this.getPositionInView(itemNode);
                    // console.log("getPositionInView()"+`i=${i}`+`, x=${viewPos.x}`+`, y=${viewPos.y}`);

                    if (this._scrollDir == ScrollDirector.Left) {
                        // 左滑
                        // 计算坐标是否超过<所有缓存元素总大小>的一半
                        // console.log("左滑, ", viewPos.x, leftMax);
                        if (viewPos.x + (this._cellSize + this.mSpace) / 2 < this._EdgeLeft) {
                            // 获取新的id和数据
                            let newId = (itemNode as any).__itemID + this.rowCacheNum;
                            if (newId >= this.rowAllNum) {
                                continue;
                            }
                            (itemNode as any).__itemID = newId;
                            let data = this.mDataList[newId];

                            // console.log("滑到了左边", newId);
                            //设置新坐标
                            itemNode.setPosition(itemNode.getPosition().x + offset, itemNode.getPosition().y);
                            itemNode.setSiblingIndex(newId);

                            // 刷新元素的显示
                            let cls = itemNode.getComponent(this.mItemClass) as any;
                            if (cls && cls.updateItem) {
                                cls.updateItem(newId, data, this.mDataEx);
                            }
                        }
                    } else {
                        // 右滑
                        if (viewPos.x - (this._cellSize + this.mSpace) / 2 > this._EdgeRight) {
                            // //Logger.info("getPositionInView() max "+`, __itemID=${(itemNode as any).__itemID}`);
                            // 获取新的id和数据
                            let newId = (itemNode as any).__itemID - this.rowCacheNum;
                            if (newId < 0) {
                                continue;
                            }

                            // console.log("滑到了右边", newId);
                            (itemNode as any).__itemID = newId;
                            let data = this.mDataList[newId];

                            //设置新坐标
                            itemNode.setPosition(itemNode.getPosition().x - offset, itemNode.getPosition().y);
                            itemNode.setSiblingIndex(newId);

                            // 刷新元素的显示
                            let cls = itemNode.getComponent(this.mItemClass) as any;
                            if (cls && cls.updateItem) {
                                cls.updateItem(newId, data, this.mDataEx);
                            }
                        }
                    }
                }
            }
            // 保存上次的X坐标
            this.lastContentPosX = this.mScrollView.content.getPosition().x;
            this.mFuncOnMoving && this.mFuncOnMoving(this.lastContentPosX);
        }
    }

    // 方法2，加快显示速度（暂时不用）
    handleUpdateOpacity() {
        if (this.mContent && this.mScrollView) {
            // 计算可视区域
            let viewRect = cc.rect(- this.mScrollView.node.getComponent(cc.UITransform).width / 2, - this.mContent.getPosition().y - this.mContent.getComponent(cc.UITransform).height / 2,
                this.mScrollView.node.getComponent(cc.UITransform).width, this.mScrollView.node.getComponent(cc.UITransform).height);

            // 将可视范围外节点的opacity属性设置为0，从而避免绘制，可以有效的降低DrawCall
            for (let i = 0; i < this.mContent.children.length; i++) {
                const node = this.mContent.children[i];
                if (node) {
                    let box = node.getComponent(cc.UITransform).getBoundingBox();
                    if (viewRect.intersects(box)) {
                        node.getComponent(cc.UIOpacity).opacity = 255;
                    } else {
                        node.getComponent(cc.UIOpacity).opacity = 0;
                    }
                }
            }
        }
    }

    clearItem() {
        this.itemViewList.forEach(item => {
            item.active = false;
        })
    }

}
