import * as cc from 'cc';
// import { QRCode, QRErrorCorrectLevel } from '../../3rd/qrcode.js';
import qr from 'qrcode-generator';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("自定义/QRCodeComponent")
export class QRCodeComponent extends cc.Component {

    @property(cc.CCString)
    url: string = "";

    @property(cc.Sprite)
    qrSprite: cc.Sprite = null;

    onLoad() {
        this.refreshQRCode(this.url);
    }

    refreshQRCode(url) {
        // let ctx = this.node.getComponent(cc.Graphics);
        // if (!ctx) {
        //     ctx = this.node.addComponent(cc.Graphics);
        // }

        // this.GenQRCode(ctx, url)

        // let s = this.node.getComponent(cc.UITransform);
        // this.node.position = cc.v3(-s.width * 0.5, -s.height * 0.5)

        this.generateQRCode(url);
    }

    /**
     * 生成二维码
     */
    public GenQRCode(ctx: cc.Graphics, url) {
        // ctx.clear();

        // var qrcode = new QRCode(-1, QRErrorCorrectLevel.H);
        // qrcode.addData(url);
        // qrcode.make();

        // ctx.fillColor = cc.Color.BLACK;
        // //块宽高
        // var tileW = this.node.getComponent(cc.UITransform).width / qrcode.getModuleCount();
        // var tileH = this.node.getComponent(cc.UITransform).height / qrcode.getModuleCount();

        // // draw in the Graphics
        // for (var row = 0; row < qrcode.getModuleCount(); row++) {
        //     for (var col = 0; col < qrcode.getModuleCount(); col++) {
        //         if (qrcode.isDark(row, col)) {
        //             // ctx.fillColor = cc.Color.BLACK;
        //             var w = (Math.ceil((col + 1) * tileW) - Math.floor(col * tileW));
        //             var h = (Math.ceil((row + 1) * tileW) - Math.floor(row * tileW));
        //             ctx.rect(Math.round(col * tileW), Math.round(row * tileH), w, h);
        //             ctx.fill();
        //         }
        //     }
        // }
    }

    generateQRCode(url: string) {
        const qrCode = qr(0, 'M');
        qrCode.addData(url);
        qrCode.make();

        const dataURL = qrCode.createDataURL(4, 4);
        const img = new Image();
        img.src = dataURL;

        cc.assetManager.loadRemote(dataURL, { ext: '.png' }, (err, imageAsset: cc.ImageAsset) => {
            if (err) {
                console.error(err);
                return;
            }

            const spriteFrame = new cc.SpriteFrame();
            const texture = new cc.Texture2D();
            texture.image = imageAsset;
            spriteFrame.texture = texture;
            this.qrSprite.spriteFrame = spriteFrame;
        });
    }
}

