export class Stack {
    /**
     * 
     */
    items: any[];

    constructor() {
        this.items = []; // 使用数组来存储堆栈元素
    }

    /** 
     * 入栈
    */
    push(element) {
        this.items.push(element); // 向数组末尾添加元素，模拟压栈
    }

    /** 
     * 出栈
    */
    pop() {
        if (this.isEmpty()) return null; // 如果堆栈为空，返回null或其他值
        return this.items.pop(); // 移除并返回数组最后一个元素，模拟弹出
    }

    /** 
     * 顶端元素
     */
    peek() {
        return this.items[this.items.length - 1]; // 返回顶部元素，不移除
    }

    /**
     * 是否为空
    */
    isEmpty() {
        return this.items.length === 0; // 判断堆栈是否为空
    }

    /**
     * 栈大小
     */
    size() {
        return this.items.length; // 返回堆栈内元素数量
    }
}
