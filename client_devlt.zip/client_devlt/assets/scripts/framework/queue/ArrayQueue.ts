/** 队列模板接口 */
export interface IQueueUnit<T> {
    //
    uid: number;
    //
    element: T;
}

/** 列表模板接口 */
export interface IList<T> {
    //
    peek(): IQueueUnit<T> | undefined;
    //
    isEmpty(): boolean;
    //
    get size(): number;
}

/** 
 * 队列模板接口
*/
export interface IQueue<T> extends IList<T> {
    //
    push(element: T): void;
    //
    pop(): IQueueUnit<T> | undefined;
}

/**
 * 数组队列模板
*/
class ArrayQueue<T = any> implements IQueue<T> {
    /**
     * 内部通过数组保存
     */
    private data: IQueueUnit<T>[] = [];

    /** 
     * 队列长度
     */
    get size(): number {
        return this.data.length;
    }

    /** 
     * 清空队列
    */
    clear() {
        this.data = [];
    }

    // 队列常见操作
    /**
     * enqueue(element):向队列尾部添加一个（或者多个）新的项。
     * dequeue():移除队列的第一（即排在队列最前面的）项，也是最先移除的元素；
     * front/peek():返回队列中第一个元素——最先被添加，也是最先被移除的元素。队列不做任何变动（不移除元素，只返回元素信息）
     * isEmpty():如果队列中不包含任何元素，返回true，否则返回false；
     * size():返回队列包含的元素个数，与数组的length属性类似
     */
    push(element: T): void {
        let item: IQueueUnit<T> = {
            uid: this.size + 1,
            element: element
        }
        //
        this.data.push(item);
    }

    /** 
     * 获取头部元素
    */
    getFront(): IQueueUnit<T> | undefined {
        if (0 < this.data.length) {
            return this.data[0];
        }
    }

    /** 
     * 获取尾部元素
    */
    getRear(): IQueueUnit<T> | undefined {
        if (1 < this.data.length)
            return this.data[1];
    }

    /**
     * 弹出元素
     */
    pop(): IQueueUnit<T> | undefined {
        let data = this.data.shift();
        if (0 < this.data.length) {
            for (var i = 0; i < this.data.length; ++i) {
                this.data[i].uid = i + 1;
            }
        }
        return data;
    }

    /** 
     * 检查有效性
    */
    peek(): IQueueUnit<T> | undefined {
        return this.data[0];
    }

    /**
     * 是否为空
     */
    isEmpty(): boolean {
        return this.data.length === 0;
    }
}

export default ArrayQueue;

