import {
    assetManager,
    Button,
    Component,
    director,
    ImageAsset,
    IViewParam,
    Label,
    Node,
    NodeEventType,
    Sprite,
    SpriteAtlas,
    SpriteFrame,
    Texture2D
} from "cc";

import ArrayQueue from "../queue/ArrayQueue";
import { EnumBundle, EnumPrefab } from "../../config/BundleConfig";
import { IMessage, ProcessCtrl } from "../event/ProcessCtrl";
import { GAME_ADUIO_EVENT, GAME_EVENT, NET_EVENT, SYS_EVENT } from "../event/EventDefine";
import EventMgr from "../event/EventMgr";
import { TimerMgr } from "../manager/TimeMgr";
import { ResMgr } from "../manager/ResMgr";
import { AudioMgr } from "../manager/AudioMgr";
import { UIMgr } from "../manager/UIMgr";
import GlobalModel from "../../model/GlobalModel";
import { GameApp } from "../../lobby/GameApp";


/**
 * Item里面是根据节点名字存储的，所以如果节点有使用就要保持名字的唯一性
 * 场景基类文件
 * myapp 是常驻节点
 * viewParam 场景传递参数
 * Items 界面所有节点集合
 * abName 当前的子包
 */
export class BaseScene extends Component {
    /**myapp常驻节点*/
    protected myapp: Node = null;
    /**场景参数*/
    protected viewParam: IViewParam = null;
    /**当前场景下所有的节点*/
    protected Items: { [key: string]: Node } = {};
    /**当前场景子包名字*/
    protected bundle: EnumBundle | string = EnumBundle.resources;
    /** 消息队列 */
    protected asyncMsgQueue: ArrayQueue<IMessage> = new ArrayQueue();
    /** */
    protected asyncMsgs: Map<string, Function> = new Map<string, Function>();
    /** */
    protected forceMsgs: Map<string, string[]> = new Map<string, string[]>();
    /** */
    protected prcssCtrl: ProcessCtrl = null;
    /** 计时器 */
    private timers: Set<number> = new Set<number>();

    /** 获取app 背景层 */
    getAppLayer() {
        return this.Items.UIAppLayer || this.node;
    }

    /** 获取app游戏层 */
    getGameLayer() {
        return this.Items.UIGameLayer || this.node;
    }

    /** 获取app弹窗层 */
    getDialogLayer() {
        return this.Items.UIDialogLayer || this.node;
    }

    /** 获取app加载层 */
    getLoadingLayer() {
        return this.Items.UILoadingLayer || this.node;
    }

    onLoad() {
        this.myapp = this.myapp || director.getScene().getChildByName("myapp");
        this.viewParam = this.myapp["viewParam"];
        this.bundle = this.viewParam.bundle || EnumBundle.resources;

        this.initData();

        this.timers.clear();

        this.Items = {};
        this.loadAllObject(this.node, "");

        // 消息队列
        this.asyncMsgQueue.clear();
        this.forceMsgs.clear();
        this.prcssCtrl = new ProcessCtrl(this.asyncMsgQueue);
        this.initMessageMap();
    }

    start() {

        this.initLanguage();
        this.bindEventListener();
        this.initView();
        // 恢复网络
        // SocketMgr.Instance.resume();
    }

    onDestroy() {
        EventMgr.Instance.offTarget(this);
        this.timers.forEach(element => {
            TimerMgr.Instance.Unschedule(element);
        });
        this.timers.clear();
        this.prcssCtrl.onDestroy();

        this.OnDestroy();
    }

    /** 初始化数据函数 */
    protected initData(): void {
    }

    /** 初始化界面 */
    protected initView(): void {
    }

    /**
     * 初始化消息map
     * this.forceMsgs
     * this.asyncMsgs.set("E_MTT_MSGID_ROOM_CHANGE_2C", (this.onRecvRoomChange.bind(this)));
     */
    protected initMessageMap(): void {
    }

    /** 初始化多语言 */
    protected initLanguage(): void {

    }

    /** 绑定事件 */
    protected bindEventListener(): void {
        EventMgr.Instance.on(NET_EVENT.ON_RECV_DATA, this.onRecvNetData, this);
        EventMgr.Instance.on(SYS_EVENT.ON_EXCHANGE_LANGAUE, this.initLanguage, this);
        EventMgr.Instance.on(SYS_EVENT.RECONNECT_SUCCESS, this.onReconnect, this);
    }

    /** 销毁事件 */
    protected OnDestroy(): void {

    }

    /** 消息处理流程化 */
    protected prcssCtrlCmp<T>(param_: T): boolean {
        // 收到异步消息添加到流程列表
        if (this.asyncMsgs.has(param_["name"])) {
            let msg: IMessage = {
                name: param_["name"],
                handle: this.asyncMsgs.get(param_["name"]),
                param: param_["data"],
                force: this.forceMsgs.get(param_["name"])
            }
            this.asyncMsgQueue.push(msg);
        }
        return this.asyncMsgs.has(param_["name"]);
    }

    /** 处理一条消息 */
    protected commandOver() {
        this.prcssCtrl.commandOver();
    }

    /** 收到网络消息 */
    protected onRecvNetData<T>(param_: T) {
        let cmd: string = param_["name"];
        if (0 >= this.asyncMsgs.size || false === this.prcssCtrlCmp(param_)) {
            // 非异步消息直接处理
            this.onRecvNetMessage(cmd, param_);
        }
    }

    /** 非异步网络消息处理 */
    protected onRecvNetMessage<T>(cmd_: string, param_: T) {
    }

    /** 重连成功 */
    protected onReconnect() {
        this.asyncMsgQueue.clear();
        this.forceMsgs.clear();
    }

    /** 加载界面节点 */
    protected loadAllObject(root: Node, path) {
        for (var i = 0; i < root.children.length; ++i) {
            this.Items[root.children[i].name] = root.children[i];
            root["Items"] = root["Items"] || {}
            root["Items"][root.children[i].name] = root.children[i];
            this.loadAllObject(root.children[i], path + root.children[i].name + "/");
        }
    }

    /** 按钮事件绑定 */
    protected addButtonListener(name, callback, caller, isPlaySound: boolean = true) {
        var tnode = this.Items[name];
        if (!tnode) {
            return;
        }
        //
        tnode.getComponent(Button) ?? tnode.addComponent(Button);
        //
        tnode.on(NodeEventType.TOUCH_START, (e) => {
            if (tnode.getChildByName("lbBright")) tnode.getChildByName("lbBright").active = false;
            if (tnode.getChildByName("lbDark")) tnode.getChildByName("lbDark").active = true;
        }, caller);
        //
        tnode.on(NodeEventType.TOUCH_END || NodeEventType.TOUCH_CANCEL, (e) => {
            if (tnode.getChildByName("lbBright")) tnode.getChildByName("lbBright").active = true;
            if (tnode.getChildByName("lbDark")) tnode.getChildByName("lbDark").active = false;
        }, caller);
        //
        tnode.on(NodeEventType.TOUCH_END, (e) => {
            if (isPlaySound == true) this.playSound(GAME_ADUIO_EVENT.CLICK);
            callback.bind(caller)(e);
        }, caller);
    }

    /** 每隔多久执行一次 */
    protected Schedule(func_: any, duration_: number = 0, repeat_: number = 0, delay_: number = 0, param_: any = null): number {
        let timer = TimerMgr.Instance.Schedule(func_, duration_, repeat_, delay_, param_);
        this.timers.add(timer);
        return timer;
    }

    /** 定时器多久后执行一次 */
    protected ScheduleOnce(func_: any, delay_: number, param_: any = null): number {
        let timer = TimerMgr.Instance.ScheduleOnce(func_, delay_, param_);
        this.timers.add(timer);
        return timer;
    }

    /** 移除计时器 */
    protected Unschedule(timerId_: number): void {
        if (this.timers.has(timerId_)) {
            TimerMgr.Instance.Unschedule(timerId_);
            this.timers.delete(timerId_);
        }
    }

    /** 显示弹窗 */
    protected showView<T>(prefab_: string, param_?: T, isAnim_: boolean = true, parent_: Node = GameApp.Instance.getDialogLayer(), name_?: string) {
        return new Promise<Node>((resolve, reject) => {
            UIMgr.Instance.showView(prefab_, param_, parent_, name_, isAnim_).then((res) => {
                resolve(res);
            }).catch(e => {
                reject(e);
            })
        })
    }

    /** 加载远程图片 */
    protected async setLoadRemote(node: Node, path: string) {
        let sprite = node.getComponent(Sprite);
        if (!path) {
            sprite.spriteFrame = null
            return
        }
        assetManager.loadRemote<ImageAsset>(path, { ext: '.png' }, function (err, imageAsset) {
            const spriteFrame = new SpriteFrame();
            const texture = new Texture2D();
            texture.image = imageAsset;
            if (sprite == null || sprite.node == null) return;
            spriteFrame.texture = texture;
            sprite.spriteFrame = spriteFrame
            // ...
        });

    }

    /** 散图设置图片精灵 */
    protected setSpriteFrame(node: Node, path: string, bundle?: EnumBundle | string) {
        let sprite = node.getComponent(Sprite);
        ResMgr.Instance.loadAsset<SpriteFrame>(bundle || this.bundle, SpriteFrame, path + "/spriteFrame").then(res => {
            sprite.spriteFrame = res;
        })
    }

    /** 合集设置图片精灵 */
    protected setSpriteAtlas(node: Node, path: string, key: string, bundle?: EnumBundle | string) {
        let sprite = node.getComponent(Sprite);
        ResMgr.Instance.loadAsset<SpriteAtlas>(bundle || this.bundle, SpriteAtlas, path).then((res) => {
            sprite.spriteFrame = res.getSpriteFrame(key);
        });
    }

    /** 播放声音 */
    protected playSound(audioName: string, bundle?: EnumBundle | string) {
        AudioMgr.Instance.playSound(bundle || GlobalModel.Instance.bundle, audioName);
    }

    /** 切换场景 */
    protected changeScene(name: string, param?) {
        EventMgr.Instance.emit(SYS_EVENT.CHANGE_SCENE, { name: name, param: param });
    }

    protected showClick() {
        EventMgr.Instance.emit(GAME_EVENT.ON_CIRCLE_SHOW, true)
    }

    protected hideClick() {
        EventMgr.Instance.emit(GAME_EVENT.ON_CIRCLE_SHOW, false)
    }

    protected setBtnName(node: Node, name: string) {
        if (!node) return;
        if (node.getChildByName("lbBright")) {
            let lbBright = node.getChildByName("lbBright").getComponent(Label);
            if (lbBright) {
                lbBright.string = name;
            }
        }
        if (node.getChildByName("lbDark")) {
            let lbDark = node.getChildByName("lbDark").getComponent(Label);
            if (lbDark) {
                lbDark.string = name;
            }
        }
    }

    showWating() {
        EventMgr.Instance.emit(GAME_EVENT.ON_LOADING_CIRCLE, true);
    }

    removeWaiting() {
        EventMgr.Instance.emit(GAME_EVENT.ON_LOADING_CIRCLE, false);
    }

}
