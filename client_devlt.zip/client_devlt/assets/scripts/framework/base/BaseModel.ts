export class BaseModel {
    /** */
    constructor(data: { [key: string]: any }) {
        // 使用对象的解构赋值语法，将传入的对象的所有属性赋给类的成员变量
        Object.assign(this, data);
    }

    /** */
    setData(data) {
        Object.assign(this, data);
    }
}

