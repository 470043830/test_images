import * as cc from 'cc';
import { PREVIEW } from 'cc/env';
const { ccclass, property } = cc._decorator;

@ccclass('AdaptScreen')
export class AdaptScreen extends cc.Component {
    @property({ type: cc.Sprite, tooltip: "底层大背景" })
    rootBg: cc.Sprite = null;

    onLoad() {
        if (PREVIEW) {
            //预览阶段
            return;
        }
        let design = cc.view.getDesignResolutionSize(); // 设计分辨率，。就是设置的 750 1334 根据不同端做适配
        if (!cc.sys.isMobile) {
            // pc端
            cc.view.setDesignResolutionSize(design.width, design.height, cc.ResolutionPolicy.FIXED_HEIGHT);
        }
        else {
            // 手机端
            cc.view.setDesignResolutionSize(design.width, design.height, cc.ResolutionPolicy.FIXED_WIDTH);
        }

        this.updateSizeFit();
        let _this = this;
        // 监听浏览器窗口大小变化
        cc.view.setResizeCallback(function () {
            _this.updateSizeFit();
        });
    }

    // 根据浏览器窗口变化适配
    updateSizeFit() {
        var rect = cc.view.getVisibleSize();// 获取实际显示的尺寸
        var design = cc.view.getDesignResolutionSize();// 获取设计分辨率
        let ratioDesign = design.width / design.height;  //宽高比
        // console.log('rect:', rect, 'design:', design, 'ratioWH:', ratioWH, 'ratioDesign:', ratioDesign);
        let wi = this.node.getComponent(cc.Widget);
        //高度固定铺满，计算新的宽度
        let newWidth = rect.height * ratioDesign;
        //屏幕宽度与新的宽度之差
        let offWidth = rect.width - newWidth;

        //修改对齐数据
        if (!cc.sys.isMobile) {
            wi.right = offWidth / 2;
            wi.left = offWidth / 2;
            wi.top = 0;
            wi.bottom = 0;
            wi.updateAlignment();
        } else {
            // 手机端 屏幕宽度高，就是canvas的宽高。，距离是0就可以
            wi.right = 0;
            wi.left = 0;
            wi.top = 0;
            wi.bottom = 0;
            wi.updateAlignment();
        }

        if (this.rootBg && offWidth > newWidth) {
            let rootWidget = this.rootBg.node.getComponent(cc.Widget);
            rootWidget.right = offWidth * 2;
            rootWidget.left = offWidth * 2;
            rootWidget.top = 0;
            rootWidget.bottom = 0;
        }
    }
}


