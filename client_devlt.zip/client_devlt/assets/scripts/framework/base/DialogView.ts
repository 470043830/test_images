import { BaseUI } from "./BaseUI";

export class DialogView extends BaseUI {
    /** 界面数据初始化 */
    protected initData() {
    }

    /** 界面视图初始化 */
    protected initView() {
    }

    /** 界面事件绑定 */
    protected bindEventListener() {
        super.bindEventListener();
        if (this.Items.mask) {
            this.addButtonListener("mask", this.onClose, this);
        }
    }
}
