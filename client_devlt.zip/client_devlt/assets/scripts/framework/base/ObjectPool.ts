import { _decorator, instantiate, Node, NodePool, Prefab, UITransform } from "cc";
import { ResMgr } from "../manager/ResMgr";
import Singleton from "./Singleton";
import { Logger } from "../utils/Logger";

const { ccclass, property } = _decorator;

@ccclass
export default class ObjectPool extends Singleton {
    //预制体加载名称
    prefabStr: string;
    /** */
    public nodeName: string = "";
    //(可选)VIP标记 回收判定是否本池实例
    MemberFlag: string = "";
    /** */
    public width: number = 0;
    /** */
    public height: number = 0;
    /** 预制体 */
    private _prefab: Prefab = null;
    /** */
    private _pool: NodePool = new NodePool();

    /** */
    static get Instance() {
        return super.GetInstance<ObjectPool>();
    }

    /** 代码数量 */
    private _script: any = null;

    /** */
    public get script(): any {
        return this._script;
    }

    /** */
    public set script(v: any) {
        this._script = v;
    }

    /** 初始化对象池数量 */
    private _poolSize: number = 10;

    /** */
    public get poolSize(): number {
        return this._poolSize;
    }

    /** */
    public set poolSize(v: number) {
        this._poolSize = v;
    }

    /** */
    async initPool(size) {
        this.clean();
        this._prefab = await ResMgr.Instance.loadPrefab(this.prefabStr);
        if (this._prefab == null) {
            Logger.warning(`预制体不存在: 加载 ${this.prefabStr} 对象池失败`);
            return;
        }
        let node: Node = instantiate(this._prefab);
        this.width = node.getComponent(UITransform).width;
        this.height = node.getComponent(UITransform).height;
        this.initPoolSize(size);
    }

    /**
     * 获取成员对象
     */
    getNode(): Node {
        let obj: Node;
        if (this._pool.size() > 0) {
            obj = this._pool.get();
            // log(`BasePool Tip: 获取${this.MemberFlag}Pool 成员成功,当前池容量剩余:${this._pool.size()}`);
        } else {
            obj = this.buildNode();
            // log(`BasePool Tip: 获取${this.MemberFlag}Pool 成员成功,该池容量不足,产生新成员`);
        }
        if (!obj) {
            throw new Error(`BasePool Tip: 获取${this.MemberFlag}Pool 成员失败`);
        }
        obj.active = true;
        return obj;
    }

    /**
     * 清空对象池
     */
    clean() {
        if (this._pool) {
            this._pool.clear();
            // cc.log(`BasePool Tip: 清空${this.MemberFlag}Pool成功,当前池容量:${this._pool.size()}`);
        }
        //释放预制体组件资源
        if (this._prefab) {
            this._prefab.decRef();
            this._prefab = null;
            // cc.log(`BasePool Tip: 释放${this.MemberFlag}Pool 资源数据`);
        }
    }

    /**
     * 回收对象接口
     * @param obj 回收对象
     */
    putNode(obj: Node) {
        if (this.isPoolMember(obj)) {
            //回收对象
            this._pool.put(obj);
            obj.active = false;
            // log(`BasePool Tip: ${this.MemberFlag}Pool回收对象成功,当前池容量提升至:${this._pool.size()}`);
        } else {
            if (obj && obj.name) {
                // warn(`BasePool Tip: ${this.MemberFlag}Pool回收对象错误,${obj.name}并该对象池成员,回收失败`,obj.parent);
            } else {
                throw new Error(`BasePool Tip: 获取${this.MemberFlag}Pool回收对象错误,对象不存在`);
            }
        }
    }

    /**
     * 获取组件名字
     */
    getNodeName(): string {
        return this.nodeName ? this.nodeName : this.nodeName;
    }

    /**
     * 初始化对象池
     * @param size 数量
     */
    private initPoolSize(size?: number) {
        if (size > 0) {
            this._poolSize = size;
        }
        //对象池
        if (this._prefab) {
            if (!this.MemberFlag) {
                this.MemberFlag = this.constructor.name;
            }
            this._pool = new NodePool();
            for (let i = 0; i < this._poolSize; i++) {
                let obj = this.buildNode();
                this._pool.put(obj);
            }
            // cc.log(`BasePool Tip: 初始化对象池(${this.MemberFlag}Pool)完成,初始容量为:${this._pool.size()}`);
        } else {
            // cc.error(`BasePool Tip: ${this.MemberFlag}pool 初始化失败`)
        }
    }

    /**
     * 实例化对象并标记为VIP
     */
    private buildNode(): Node {
        let node: Node = instantiate(this._prefab);
        node["memberFlag"] = this.MemberFlag;
        node.addComponent(this._script);
        if (this.nodeName) {
            node.name = this.nodeName;
        }
        return node;
    }

    /**
     * 判定是否VIP
     * @param node 回收对象
     */
    private isPoolMember(node: Node): boolean {
        return node instanceof Node && this.MemberFlag == node["memberFlag"];
    }
}
