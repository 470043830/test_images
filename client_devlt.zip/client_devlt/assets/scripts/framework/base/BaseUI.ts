import {
    assetManager,
    Button,
    Component,
    ImageAsset,
    IViewParam,
    Label,
    Node,
    NodeEventType,
    Sprite,
    SpriteAtlas,
    SpriteFrame,
    Texture2D
} from "cc";

import { EnumBundle } from "../../config/BundleConfig";
import { GAME_ADUIO_EVENT, GAME_EVENT, SYS_EVENT } from "../event/EventDefine";
import { TimerMgr } from "../manager/TimeMgr";
import EventMgr from "../event/EventMgr";
import { ResMgr } from "../manager/ResMgr";
import { AudioMgr } from "../manager/AudioMgr";
import GlobalModel from "../../model/GlobalModel";
import { UIMgr } from "../manager/UIMgr";


/**
 * 视图管理基类
 * */
export class BaseUI extends Component {
    /** */
    protected Items: { [key: string]: Node } = {};
    /** */
    protected viewParam: IViewParam = {};
    /**当前场景子包名字*/
    protected bundle: EnumBundle | string = EnumBundle.resources;
    /** 计时器 */
    private timers: Set<number> = new Set<number>();

    /* 绑定按钮点击事件
     * @param node 按钮节点
     * @param listener 监听方法
     * @param thisArg this实例
     */
    public addButtonListener(name, callback: Function, caller: any = null, isPlaySound = true) {
        var tnode = this.Items[name];
        if (!tnode) {
            return;
        }
        //
        var node = tnode.getComponent(Button);
        if (!node) {
            tnode.addComponent(Button);
        }
        //
        tnode.on(NodeEventType.TOUCH_START, (e) => {
            if (tnode.getChildByName("lbBright")) tnode.getChildByName("lbBright").active = false;
            if (tnode.getChildByName("lbDark")) tnode.getChildByName("lbDark").active = true;
        }, caller);
        //
        tnode.on(NodeEventType.TOUCH_END || NodeEventType.TOUCH_CANCEL, (e) => {
            if (tnode.getChildByName("lbBright")) tnode.getChildByName("lbBright").active = true;
            if (tnode.getChildByName("lbDark")) tnode.getChildByName("lbDark").active = false;
        }, caller);
        //
        tnode.on(NodeEventType.TOUCH_END, (e) => {
            if (isPlaySound == true) this.playSound(GAME_ADUIO_EVENT.CLICK, GlobalModel.Instance.bundle);
            callback.bind(caller)(e);
        }, caller);
    }

    /** 每隔多久执行一次 */
    protected Schedule(func_: any, duration_: number = 0, repeat_: number = 0, param_: any = null, delay_: number = 0,): number {
        let timer = TimerMgr.Instance.Schedule(func_, duration_, repeat_, param_, delay_);
        this.timers.add(timer);
        return timer;
    }

    /** 定时器多久后执行一次 */
    protected ScheduleOnce(func_: any, delay_: number, param_: any = null): number {
        let timer = TimerMgr.Instance.ScheduleOnce(func_, delay_, param_);
        this.timers.add(timer);
        return timer;
    }

    /** 移除计时器 */
    protected Unschedule(timerId_: number): void {
        if (this.timers.has(timerId_)) {
            TimerMgr.Instance.Unschedule(timerId_);
            this.timers.delete(timerId_);
        }
    }

    /** */
    protected LoadAllObject(root: Node, path): void {
        for (var i = 0; i < root.children.length; ++i) {
            this.Items[root.children[i].name] = root.children[i];
            root.Items = root.Items || {}
            root.Items[root.children[i].name] = root.children[i];
            this.LoadAllObject(root.children[i], path + root.children[i].name + "/");
        }
    }

    /** */
    protected onLoad(): void {
        this.viewParam = this.node["viewParam"] || {};
        this.bundle = this.viewParam.bundle || EnumBundle.resources;
        this.LoadAllObject(this.node, "");
        this.initData();
        this.preloadRes();
        this.bindEventListener();
    }

    /** */
    protected start() {
        this.initView();
        this.initLanguage();
    }

    /** */
    protected initData(): void {
    }

    /** */
    protected preloadRes(): void {
    }

    /** */
    protected initView(): void {
    }

    /** */
    protected initLanguage(): void {
    }

    /** */
    protected bindEventListener(): void {
        EventMgr.Instance.on(SYS_EVENT.ON_EXCHANGE_LANGAUE, this.initLanguage, this);
    }

    /** */
    protected OnDestroy(): void {

    }

    /** */
    protected onDestroy(): void {
        this.timers.forEach(element => {
            TimerMgr.Instance.Unschedule(element);
        });
        this.timers.clear();
        EventMgr.Instance.offTarget(this);
        this.OnDestroy();
    }

    /** 散图设置图片精灵 */
    protected setSpriteFrame(node: Node, path: string, bundle?: EnumBundle | string) {
        let sprite = node.getComponent(Sprite);
        if (path == "") {
            sprite.spriteFrame = null;
            return;
        }
        ResMgr.Instance.loadAsset<SpriteFrame>(bundle || this.bundle, SpriteFrame, path + "/spriteFrame").then(res => {
            sprite.spriteFrame = res;
        })
    }

    /** 合集设置图片精灵 */
    protected setSpriteAtlas(node: Node, path: string, key: string, bundle?: EnumBundle | string) {
        let sprite = node.getComponent(Sprite);
        ResMgr.Instance.loadAsset<SpriteAtlas>(bundle || this.bundle, SpriteAtlas, path).then((res) => {
            sprite.spriteFrame = res.getSpriteFrame(key);
        });
    }

    /** 加载远程图片 */
    protected async setLoadRemote(node: Node, path: string) {
        let sprite = node.getComponent(Sprite);
        if (!path) {
            sprite.spriteFrame = null
            return
        }
        //
        assetManager.loadRemote<ImageAsset>(path, { ext: '.png' }, function (err, imageAsset) {
            const spriteFrame = new SpriteFrame();
            const texture = new Texture2D();
            texture.image = imageAsset;
            if (sprite == null || sprite.node == null) return;
            spriteFrame.texture = texture;
            sprite.spriteFrame = spriteFrame
            // ...
        });
        // sprite.spriteFrame = spriteFrame;
        //  .then(res => {
        //         const spriteFrame = new SpriteFrame();
        //         spriteFrame.texture = res;
        //         if(sprite==null)return;
        //         sprite.spriteFrame = spriteFrame;
        //     }).catch(()=>{
        //         Logger.debug("加载远程图片 加载错误")
        //     })
    }

    /** 播放声音 */
    protected playSound(audioName: string, bundle?: EnumBundle | string) {
        AudioMgr.Instance.playSound(bundle || GlobalModel.Instance.bundle, audioName);
    }

    /** 切换场景 */
    protected changeScene(name: string, param?) {
        EventMgr.Instance.emit(SYS_EVENT.CHANGE_SCENE, { name: name, param: param });
    }

    /** */
    protected onClose(e: TouchEvent = null) {
        UIMgr.Instance.removeView(this.node);
    }

    /** */
    protected showClick() {
        EventMgr.Instance.emit(GAME_EVENT.ON_CIRCLE_SHOW, true)
    }

    /** */
    protected hideClick() {
        EventMgr.Instance.emit(GAME_EVENT.ON_CIRCLE_SHOW, false)
    }

    /** */
    protected setBtnName(node: Node, name: string) {
        if (!node) {
            return;
        }
        //
        if (node.getChildByName("lbLeft")) {
            let lbBright = node.getChildByName("lbLeft").getComponent(Label);
            if (lbBright) {
                lbBright.string = name;
            }
        }
        //
        if (node.getChildByName("lbRight")) {
            let lbDark = node.getChildByName("lbRight").getComponent(Label);
            if (lbDark) {
                lbDark.string = name;
            }
        }
    }
}
