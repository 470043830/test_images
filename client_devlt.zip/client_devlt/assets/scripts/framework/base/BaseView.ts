import { _decorator } from 'cc';
import { BaseUI } from './BaseUI';
import ArrayQueue from '../queue/ArrayQueue';
import { IMessage, ProcessCtrl } from '../event/ProcessCtrl';
import EventMgr from '../event/EventMgr';
import { NET_EVENT, SYS_EVENT } from '../event/EventDefine';

const { ccclass, property } = _decorator;

@ccclass('BaseView')
export class BaseView extends BaseUI {
    /** 消息队列 */
    protected asyncMsgQueue: ArrayQueue<IMessage> = new ArrayQueue();
    /** */
    protected asyncMsgs: Map<number, Function> = new Map<number, Function>();
    /** */
    protected forceMsgs: Map<number, string[]> = new Map<number, string[]>();
    /** */
    protected prcssCtrl: ProcessCtrl = null;

    /** */
    start() {
        super.start();
    }

    /** */
    protected initData(): void {

    }

    /** */
    protected initView(): void {

    }

    /** */
    protected initLanguage(): void {

    }

    /** */
    protected bindEventListener(): void {
        EventMgr.Instance.on(NET_EVENT.ON_RECV_DATA, this.onRecvNetData, this);
        EventMgr.Instance.on(SYS_EVENT.RECONNECT_SUCCESS, this.onReconnect, this);
        super.bindEventListener();
    }

    /** */
    protected onLoad(): void {
        super.onLoad();
        // 消息队列
        this.asyncMsgQueue.clear();
        this.forceMsgs.clear();
        this.prcssCtrl = new ProcessCtrl(this.asyncMsgQueue);
        this.initMessageMap();
    }

    /** */
    protected onDestroy(): void {
        EventMgr.Instance.offTarget(this);
        super.onDestroy();
    }

    /**
     * 初始化消息map
     * this.forceMsgs
     * this.asyncMsgs.set("E_MTT_MSGID_ROOM_CHANGE_2C", (this.onRecvRoomChange.bind(this)));
     */
    protected initMessageMap(): void {

    }

    /** 消息处理流程化 */
    protected prcssCtrlCmp<T>(param_: T): boolean {
        // 收到异步消息添加到流程列表
        if (this.asyncMsgs.has(param_["name"])) {
            let msg: IMessage = {
                name: param_["name"],
                handle: this.asyncMsgs.get(param_["name"]),
                param: param_["data"],
                force: this.forceMsgs.get(param_["name"])
            }
            this.asyncMsgQueue.push(msg);
        }
        return this.asyncMsgs.has(param_["name"]);
    }

    /** 处理一条消息 */
    protected commandOver() {
        this.prcssCtrl.commandOver();
    }

    /** 收到网络消息 */
    protected onRecvNetData<T>(param_: T) {
        let cmd: number = param_["name"];
        if (0 >= this.asyncMsgs.size || false === this.prcssCtrlCmp(param_)) {
            // 非异步消息直接处理
            this.onRecvNetMessage(cmd, param_["data"]);
        }
    }

    /** 非异步网络消息处理 */
    protected onRecvNetMessage<T>(cmd_: number, param_: T) {
    }

    /** 重连成功 */
    protected onReconnect() {
        this.asyncMsgQueue.clear();
        this.forceMsgs.clear();
    }
}

