import * as cc from 'cc';

const { ccclass, property } = cc._decorator;


/**
 * 不阻止触摸事件向下传递
 */
@ccclass('TouchEventSwallowDisable')
export class TouchEventSwallowDisable extends cc.Component {
    //事件是否穿透
    @property({ type: cc.CCBoolean, tooltip: "事件是否传递" })
    penetration: boolean = false;

    protected onEnable(): void {
        this.node.on(cc.Node.EventType.TOUCH_START, this.onTouch, this);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouch, this);
        this.node.on(cc.Node.EventType.TOUCH_END, this.onTouch, this);
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouch, this);
    }

    protected onDisable(): void {
        this.node.off(cc.Node.EventType.TOUCH_START, this.onTouch, this);
        this.node.off(cc.Node.EventType.TOUCH_MOVE, this.onTouch, this);
        this.node.off(cc.Node.EventType.TOUCH_END, this.onTouch, this);
        this.node.off(cc.Node.EventType.TOUCH_CANCEL, this.onTouch, this);
    }

    onTouch(event: cc.EventTouch) {
        event.preventSwallow = this.penetration;
    }
}