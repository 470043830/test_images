import { BaseUI } from "./BaseUI";

/**
 * 节点默认挂载脚本
 */
export class UIDefaultCtrl extends BaseUI {
    //
    viewParam: any = {}
    //
    protected onLoad(): void {
        this.Items = {};
        this.LoadAllObject(this.node, "");
    }
}
