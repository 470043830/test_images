import * as cc from 'cc';

const { ccclass, property } = cc._decorator;


/**
 * 触摸则隐藏/关闭
 */
@ccclass('TouchToClose')
export class TouchToClose extends cc.Component {
    @property({ type: cc.CCBoolean, tooltip: "是否销毁" })
    destory: boolean = false;

    protected onEnable(): void {
        this.node.on(cc.Node.EventType.TOUCH_START, this.onTouch, this);

    }

    protected onDisable(): void {
        this.node.off(cc.Node.EventType.TOUCH_START, this.onTouch, this);
    }

    onTouch(event: cc.EventTouch) {
        event.preventSwallow = true;
        if (this.destory) {
            this.node.destroy();
        } else {
            this.node.active = false;
        }
    }
}