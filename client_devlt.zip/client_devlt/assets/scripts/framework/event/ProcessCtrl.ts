import { TimerMgr } from "../manager/TimeMgr";
import ArrayQueue from "../queue/ArrayQueue";
import { Logger } from "../utils/Logger";
import { Utils } from "../utils/Utils";

/**
 * 消息队列处理
 */
export interface IMessage {
    cmd?: number;
    name: string;
    force?: string[];
    param?: any;
    handle?: Function;
}

/** */
export class ProcessCtrl {
    private uid: number = -1;
    private timer: number = null;
    private asyncMsg: ArrayQueue<IMessage> = new ArrayQueue();

    constructor(args_: ArrayQueue<IMessage>) {
        this.asyncMsg = args_;
        //
        if (this.timer) {
            clearInterval(this.timer);
            this.timer = null;
        }
        //
        this.timer = TimerMgr.Instance.Schedule(() => {
            this.execute();
        }, 1 / 60);
    }

    /** */
    clear(cmd_: string = null) {
        if (cmd_) {
            while (null != this.asyncMsg.getFront() && undefined != this.asyncMsg.getFront()) {
                let msg = Utils.deepCopy(this.asyncMsg.getFront());
                if (msg.element.name === cmd_) {
                    this.asyncMsg.clear();
                    this.asyncMsg.push(msg.element);
                    break;
                }
            }
        } else {
            this.asyncMsg.clear();
        }
    }

    /**  */
    execute() {
        // 空的时候返回
        if (this.asyncMsg.isEmpty()) {
            return;
        }
        //
        let front = this.asyncMsg.getFront();
        let rear = this.asyncMsg.getRear();
        // 当下一条强制关闭上一条的时候执行
        if (rear) {
            if (front.element.force && 0 < front.element.force.length) {
                for (var i = 0; i < front.element.force.length; ++i) {
                    if (rear.element.name === front.element.force[i]) {
                        this.asyncMsg.pop();
                        Logger.info("强行关闭协议===》", front.element.name, rear.element.name);
                        this.uid = rear.uid;
                        if (rear.element.handle)
                            rear.element.handle(rear.element.param);
                        return;
                    }
                }
            }
        }
        //
        if (this.uid != front.uid) {
            this.uid = front.uid;
            Logger.info(`处理协议${front.element.name}`);
            if (front.element.handle) {
                front.element.handle(front.element.param);
            }
        }
    }

    /** */
    commandOver() {
        if (this.asyncMsg.isEmpty()) {
            Logger.info("当前队列里面没有消息")
            return;
        }
        //
        let front = this.asyncMsg.getFront();
        Logger.info(`处理协议${front.element.name}完成===》`);
        this.asyncMsg.pop();
        this.uid = -1;
    }

    /** */
    onDestroy() {
        if (this.timer) {
            TimerMgr.Instance.Unschedule(this.timer);
            this.timer = null;
        }
    }
}
