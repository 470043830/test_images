// 网络事件
export enum NET_EVENT {
    SOCKET_CONNECTING = "NET_EVENT.SOCKET_CONNECTING",
    SOCKET_CONNECTED = "NET_EVENT.SOCKET_CONNECTED",
    SOCKET_CONNFAIL = "NET_EVENT.SOCKET_CONNFAIL",
    SOCKET_CLOSED = "NET_EVENT.SOCKET_CLOSED",
    SOCKET_CLOSE = "NET_EVENT.SOCKET_CLOSE",
    SOCKET_MESSAGE = "NET_EVENT.SOCKET_MESSAGE",
    SOCKET_ERROR = "NET_EVENT.SOCKET_ERROR",
    SEND_MSG = "NET_EVENT.SEND_MSG",
    ON_RECV_DATA = "NET_EVENT.ON_RECV_DATA",
    ON_NET_MESSAGE = "NET_EVENT.ON_NET_MESSAGE",
}

// end

// 热更事件
export enum HOT_UPDATE_EVENT {
    ON_UPDATE_PROCESS = "HOT_UPDATE_EVENT.ON_UPDATE_PROCESS",              // 更新
    ON_UPDATE_FINISH = "HOT_UPDATE_EVENT.ON_UPDATE_FINISH",                // 完成
    ON_UPDATE_CHECK_VERSION = "HOT_UPDATE_EVENT.ON_UPDATE_CHECK_VERSION",  // 检测版本
}

// end
// 系统事件d
export enum SYS_EVENT {
    ON_ENTER_BACKGROUND = "SYS_EVENT.ON_ENTER_BACKGROUND",      // 切后台
    ON_ENTER_FOREGROUND = "SYS_EVENT.ON_ENTER_FOREGROUND",      //
    NET_NETERROR = "SYS_EVENT.NET_NETERROR", 			        // 网络错误
    NETWORK_BAD = "SYS_EVENT.NETWORK_BAD",				        // 网络状况不好
    GAME_INIT_CONFIG = "SYS_EVENT.GAME_INIT_CONFIG",            //初始化自包
    CHANGE_SCENE = "SYS_EVENT.CHANGE_SCENE",                    // 场景切换
    CHANGE_SCENE_FINISH = "SYS_EVENT.CHANGE_SCENE_FINISH",      // 场景切换完成
    ENTER_MOD = "SYS_EVENT.ENTER_MOD",
    START_RECONNECT = "SYS_EVENT.START_RECONNECT",			    // 开始重连
    RECONNECT_SUCCESS = "SYS_EVENT.RECONNECT_SUCCESS",		    // 重连成功
    RECOVER_ROOMDATA = "SYS_EVENT.RECOVER_ROOMDATA",		    // 重连后 恢复房间数据
    RESTART_GAME = "SYS_EVENT.RESTART_GAME",                    // 桌面游戏一键重启
    LOADGAME_PROGRESS = "SYS_EVENT.LOADGAME_PROGRESS",          // 游戏加载进度
    LOADGAME_FINISH = "SYS_EVENT.LOADGAME_FINISH",			    // 游戏加载完成
    RECHARGE_SUCCEEDED = "SYS_EVENT.RECHARGE_SUCCEEDED",        // 充值成功
    ERROR_CODE = "SYS_EVENT.ERROR_CODE",                        // 系统错误
    ON_EXCHANGE_LANGAUE = "SYS_EVENT.ON_EXCHANGE_LANGAUE",      // 切换语言
    UPDATW_USER_INFORMATION = "SYS_EVENT.UPDATW_USER_INFORMATION",      // 更新用户信息
}

/** 游戏公共事件 */
export enum GAME_EVENT {
    TOAST = "GAME_EVENT.TOAST",
    ALERT = "GAME_EVENT.ALERT",
    ON_SHOW_LOADING = "GAME_EVENT.ON_SHOW_LOADING",
    ON_SET_LOADING_PROGRESS = "GAME_EVENT.ON_SET_LOADING_PROGRESS",
    ON_SHOW_UPDATE = "GAME_EVENT.ON_SHOW_UPDATE",
    ON_CIRCLE_SHOW = "GAME_EVENT.ON_CIRCLE_SHOW",           //防暴力点击 弹框显示
    ON_LOADING_CIRCLE = "GAME_EVENT.ON_LOADING_CIRCLE",   //加载转圈
    GAME_THE_CLOSE = "GAME_THE_CLOSE",
}

/** 大厅公共音乐 */
export enum GAME_ADUIO_EVENT {
    /** 点击音效 */
    CLICK = "button_click",
    /** 背景音乐 */
    BACKGROUND = "background2",
}

/** 网络状态*/
export enum TYPE_NET_WORK_STATUS {
    /** 网络未连接 */
    one = 0,
    /** 网络正常 */
    two,
    /** 网络链接失败 */
    three,
    /** 断线重连中 */
    four,
    /** 不允许断线重连 */
    five,
}

/**
 * 大厅事件
 */
export enum LOBBY_EVENT {
    SWICH_LOBBY_VIEW = "LOBBY_EVENT.SWICH_LOBBY_VIEW",                          //切换大厅子页面
    SCROLL_TO_GAME_FILTER = "LOBBY_EVENT.SCROLL_TO_GAME_FILTER",                //滚动至某类型游戏

    ACCOUNT_BINDPHONE_RET = "LOBBY_EVENT.ACCOUNT_BINDPHONE_RET",                //服务器绑定手机结果
    ACCOUNT_MODIFY_PW = "LOBBY_EVENT.ACCOUNT_MODIFY_PW",                        //修改密码成功
    ACCOUNT_RETRIEVE_PHONE_RET = "LOBBY_EVENT.ACCOUNT_RETRIEVE_PHONE_RET",      //找回密码服务器手机验证结果
    ACCOUNT_RETRIEVE_NEW_PW_RET = "LOBBY_EVENT.ACCOUNT_RETRIEVE_NEW_PW_RET",    //找回密码服务器设置新密码结果
    ACCOUNT_UPDATE_MY_INFO = "LOBBY_EVENT.ACCOUNT_UPDATE_MY_INFO",              //更新我的信息
    ACCOUNT_BIND_INVITE_CODE = "LOBBY_EVENT.ACCOUNT_BIND_INVITE_CODE",          //绑定邀请码成功

    HALL_GAME_TYPE_INFO = "LOBBY_EVENT.HALL_GAME_TYPE_INFO",                    //大厅游戏分类信息
    HALL_REMCOMMEND_TYPE_INFO = "LOBBY_EVENT.HALL_REMCOMMEND_TYPE_INFO",        //大厅游戏二级分类信息
    HALL_HOME_GAMES_INFO = "LOBBY_EVENT.HALL_HOME_GAMES_INFO",                  //大厅游戏一级界面游戏信息
    HALL_RECOMMEND_GAMES_INFO = "LOBBY_EVENT.HALL_RECOMMEND_GAMES_INFO",        //大厅游戏二级界面游戏信息(各个厂商推荐的游戏)
    HALL_SUPPLIER_ALL_GAMES = "LOBBY_EVENT.HALL_SUPPLIER_ALL_GAMES",            //大厅游戏三级界面游戏信息(指定厂商的所有游戏)

    USER_MAIL_LIST_INFO = "LOBBY_EVENT.USER_MAIL_LIST_INFO",                    //用户邮件列表信息
    USER_MAIL_DETAIL_INFO = "LOBBY_EVENT.USER_MAIL_DETAIL_INFO",                    //用户邮件详情信息
    USER_ALTER_EMAIL_STATUS = "LOBBY_EVENT.USER_ALTER_EMAIL_STATUS",                    //用户读邮件
    USER_REMOVE_EMAIL = "LOBBY_EVENT.USER_REMOVE_EMAIL",                    //用户删除邮件
    USER_REMOVE_READ_EMAIL = "LOBBY_EVENT.USER_REMOVE_READ_EMAIL",                    //用户删除已读邮件

    CLUB_GET_CLUB_BASE_CONFIG = "LOBBY_EVENT.CLUB_GET_CLUB_BASE_CONFIG",        //取得俱乐部基本信息
    CLUB_GET_MYCUB_TEAM_INFO = "LOBBY_EVENT.CLUB_GET_MYCUB_TEAM_INFO",          //取得我的俱乐部团队信息
    CLUB_REWARD_RECORD = "LOBBY_EVENT.CLUB_REWARD_RECORD",                      //取得我的奖励详情数据
    CLUB_WITHDRAW_RECORD = "LOBBY_EVENT.CLUB_WITHDRAW_RECORD",                  //取得我的withdraw记录数据
    USER_MARK_ALL_READ_EMAIL = "LOBBY_EVENT.USER_MARK_ALL_READ_EMAIL",                    //用户标记所有已读邮件
    SHARED_CONFIG = "LOBBY_EVENT.SHARED_CONFIG",                                //分享配置
}

