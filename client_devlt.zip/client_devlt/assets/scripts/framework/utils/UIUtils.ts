import {
    Animation,
    Button,
    Canvas,
    instantiate,
    Label,
    Node,
    NodeEventType,
    Prefab,
    Size,
    sp,
    Sprite,
    SpriteAtlas,
    SpriteFrame,
    tween,
    UITransform,
    v2,
    Vec3,
    view
} from 'cc';
import { UIMgr } from '../manager/UIMgr';
import { ResMgr } from '../manager/ResMgr';
import { Utils } from './Utils';
import { BundleConfig, EnumPrefab, IBundleAsset } from '../../config/BundleConfig';
import { GameApp } from '../../lobby/GameApp';

/** */
export interface ISpineAnimParam {
    /** 帧通道 */
    trackIndex?: number;
    /** 包名字 */
    abName?: string;
    /** 路径 */
    path: string;
    /** 动画名字 */
    name?: string;
    /** 父节点 */
    parent?: Node;
    /** 是否循环 */
    loop?: boolean;
    /**倒序*/
    reverse?: boolean;
    /** 完成后事件 */
    callback?: Function;
}

/**
 * 创建FrameAnimation
 */
type IFrameAnimationParam = {
    /**父节点 */
    parent?: Node
    /**资源 */
    res: string | EnumPrefab
    /**动画名称 */
    animName?: string
    loop?: boolean;
    // /**动画循环方式 */
    // wrapMode?: AnimationClip.WrapMode
    /**Animation对象（无需传入，创建成功后自动赋值） */
    anim?: Animation
    /**创建成功回调 */
    callback?: (data: IFrameAnimationParam) => void
    /**开始播放时触发 */
    events?: { eventName: Animation.EventType, callback: (anim: Animation, data: IFrameAnimationParam) => void }[]
}

export class UIUtils {

    static changeCoins(node: Node, newGold: number, preFix: string = null, sufFix: string = null, timestamp: number = 100) {
        // 计算差值
        let label = node.getComponent(Label);
        if (node["changeLabelTimer"]) {
            clearInterval(node["changeLabelTimer"]);
            node["changeLabelTimer"] = null;
        }

        let start = (preFix == null) ? 0 : (preFix.length);
        let end = (sufFix == null) ? label.string.length : (label.string.length - sufFix.length);
        let numStr = label.string.substring(start, end);

        let curGold = Number(numStr);
        let delGold = newGold - curGold;

        node["changeLabelTimer"] = setInterval(() => {
            if (curGold >= newGold) {
                clearInterval(node["changeLabelTimer"]);
                node["changeLabelTimer"] = null;
            } else {
                curGold++;
                label.string = curGold.toString();
            }
        }, timestamp / delGold)
    }

    /**
     * 创建菜单
     * @l 按钮节点有一点命名要求
     * @l 1、必须包涵两个关键节点（nodeFocus，nodeComm）
     */
    static createMenu(node: Node, callback, caller, defaultIndex: number = 0) {
        let children = node.children;
        let titem: any
        let titem1: any;
        for (var i = 0; i < children.length; ++i) {
            titem = children[i];
            titem.index = i;
            titem.getChildByName("nodeFocus").active = (defaultIndex === i);
            titem.getChildByName("nodeComm").active = !(defaultIndex === i);
            if (defaultIndex === i) {
                callback.bind(caller)(titem);
            }
            titem.getComponent(Button) ?? titem.addComponent(Button);
            // callback.bind(caller)(e);
            titem.on(NodeEventType.TOUCH_END, (e: TouchEvent) => {
                let index = e.target["index"];
                for (var j = 0; j < children.length; ++j) {
                    titem1 = children[j];

                    titem1.getChildByName("nodeFocus").active = (index === titem1.index);
                    titem1.getChildByName("nodeComm").active = !(index === titem1.index);
                    if (index === titem1.index) {
                        callback.bind(caller)(titem1);
                    }
                }
            }, caller);
        }
    }

    static createSprite(parent: Node, abName: string, path: string, key?: string) {
        // return new Promise<Node>((resolve, reject) => {
        // })
        let tnode = new Node();
        tnode.parent = parent;
        let sprite = tnode.addComponent(Sprite);
        if (!key) {
            ResMgr.Instance.loadAsset(abName, SpriteFrame, path + "/spriteFrame").then(e => {
                sprite.spriteFrame = e;
            });
        } else {
            ResMgr.Instance.loadAsset(abName, SpriteAtlas, path).then(e => {
                sprite.spriteFrame = e.getSpriteFrame(key);
            });
        }

        return tnode;
    }

    /** 创建一个canvas */
    static createCanvas(): Node {
        let viewSize = view.getVisibleSize();
        let node = new Node();
        node.setPosition(viewSize.width / 2, viewSize.height / 2);
        let canvas = node.addComponent(Canvas);
        canvas.alignCanvasWithScreen = true;
        // node.layer = Layers.Enum.UI_2D;
        let trans = node.getComponent(UITransform);
        if (!trans) {
            trans = node.addComponent(UITransform);
        }
        trans.contentSize = viewSize;
        return node;
    }

    // 创建一个节点
    static createNode(name: string, parent?: Node): Node {
        const node = new Node(name);
        if (parent) {
            node.parent = parent;
        }
        return node;
    }

    // 设置节点的位置
    static setPosition(node: Node, position: Vec3): void {
        if (node) {
            node.setPosition(position);
        }
    }

    // 设置节点的大小
    static setSize(node: Node, size: Size): void {
        const uiTransform = node.getComponent(UITransform);
        if (uiTransform) {
            uiTransform.setContentSize(size);
        }
    }

    static closeWindow(node: Node) {
        UIMgr.Instance.removeView(node);
    }

    // 自定义场景切换效果
    static customTransition(currentScene, newScene) {
        // 编写你的自定义过渡效果逻辑
        // 比如淡入淡出的效果
        tween(currentScene).to(0.5, { opacity: 0 }).call(() => {
            // 加载新场景
            // SceneManager.loadScene('YourSceneName', () => {
            //     // 执行过渡动画，比如淡入
            //     tween(newScene).to(0.5, { opacity: 255 }).start();
            // });
        }).start();
    }

    /**
     * 水平翻转（卡片翻转）
     * @param node 节点
     * @param duration 总时长
     * @param onMiddle 中间状态回调
     * @param onComplete 完成回调
     */
    public static flipX(node: Node, duration: number, round: number = 1, onMiddle?: Function, onComplete?: Function): Promise<void> {
        return new Promise<void>(res => {
            const time = 1 * round,
                t = tween,
                { x, z } = node.eulerAngles,
                eulerAngles = new Vec3(x, -360 * round, z);
            t(node)
                .by(time, { eulerAngles }, { easing: 'quadOut' })
                .call(res)
                .start();
        });
    }

    /**
     * 水平翻转（卡片翻转）
     * @param node 节点
     * @param duration 总时长
     * @param onMiddle 中间状态回调
     * @param onComplete 完成回调
     */
    public static flipY(node: Node, duration: number, round: number = 1, onMiddle?: Function, onComplete?: Function): Promise<void> {
        return new Promise<void>(res => {
            const time = 1 * round,
                t = tween,
                { x, y, z } = node.eulerAngles,
                eulerAngles = new Vec3(360 * round, y, z);
            t(node)
                .by(time, { eulerAngles }, { easing: 'quadOut' })
                .call(res)
                .start();
        });
    }

    /**添加spine动画*/
    public static addSpineAnim(param_: ISpineAnimParam): Promise<Node> {
        return new Promise<Node>((resolve, reject) => {
            ResMgr.Instance.loadAsset(param_.abName, sp.SkeletonData, param_.path).then((spineAsset) => {
                let parent = Utils.isNull(param_.parent) ? GameApp.Instance.getGameLayer() : param_.parent;
                let name = Utils.isNull(param_.name) ? "animation" : param_.name;
                let loop = (Utils.isNull(param_.loop) || false === param_.loop) ? false : param_.loop;
                let node = new Node()
                let trans = node.addComponent(UITransform)
                trans.anchorPoint = v2(0, 0);

                let comp = node.addComponent(sp.Skeleton);
                parent.addChild(node)

                comp.skeletonData = spineAsset!;

                let ani = comp.setAnimation(param_.trackIndex || 0, name, loop);
                if (param_.reverse)
                    ani.timeScale = -1;

                comp.setCompleteListener((trackEntry) => {
                    let aniName = trackEntry.animation ? trackEntry.animation.name : "";
                    if (aniName == name && param_.callback) {
                        param_.callback();
                    }
                })
                resolve(node);
            }).catch(e => {
                // reject(e)
                throw "error type"
            });
        })
    }
    /**
     * 
    */
    public static addFrameAnimation(data: IFrameAnimationParam): Promise<Node> {
        let bundleAsset: IBundleAsset = BundleConfig.getBundleAsset(data.res);
        return new Promise<Node>(async (resolve, reject) => {
            ResMgr.Instance.loadAsset<Prefab>(bundleAsset.ABName, Prefab, bundleAsset.path).then((res) => {
                //是否新建节点
                let node = data.parent ??= new Node();
                let animNode = instantiate(res);
                animNode.parent = node;
                //animetion
                let animation = data.anim = animNode.getComponent(Animation);
                //播放指定动画
                let animName = data.animName ?? `animation`;
                if (!Utils.isNull(data.loop)) {
                    animation.getState(animName).wrapMode = data.loop ? 2 : 1;
                }
                animation.play(animName);
                //事件
                data.events && data.events.forEach(element => {
                    animation.on(element.eventName, () => {
                        element.callback(animation, data);
                    });
                });
                //回调
                data.callback && data.callback(data);
                resolve(animNode);
            })
        })
    }
}