export class ArrayUtils {

    //
    static fixPrecision(num) {
        return Math.round((num + Number.EPSILON) * 100) / 100;
    }

    // 判断数组是否为空
    static isEmpty<T>(arr: T[]): boolean {
        return arr.length === 0;
    }

    // 获取数组的长度
    static size<T>(arr: T[]): number {
        return arr.length;
    }

    // 查找数组中是否包含指定元素
    static contains<T>(arr: T[], item: T): boolean {
        return arr.indexOf(item) !== -1;
    }

    // 过滤数组，返回符合条件的元素数组
    static filter<T>(arr: T[], predicate: (value: T, index: number, array: T[]) => boolean): T[] {
        return arr.filter(predicate);
    }

    // 查找数组中符合条件的第一个元素
    static find<T>(arr: T[], predicate: (value: T, index: number, array: T[]) => boolean): T | undefined {
        return arr.find(predicate);
    }

    // 对数组进行排序
    static sort<T>(arr: T[], compareFn?: (a: T, b: T) => number): T[] {
        return arr.slice().sort(compareFn);
    }

    // 获取数组中指定索引范围内的子数组
    static slice<T>(arr: T[], start?: number, end?: number): T[] {
        return arr.slice(start, end);
    }

    // 将数组转换为字符串，指定分隔符
    static join<T>(arr: T[], separator?: string): string {
        return arr.join(separator);
    }

    // 在数组的末尾添加一个或多个元素，并返回新的长度
    static push<T>(arr: T[], ...items: T[]): number {
        return arr.push(...items);
    }

    // 删除数组末尾的元素，并返回该元素
    static pop<T>(arr: T[]): T | undefined {
        return arr.pop();
    }

    // 将数组转换为对象，key为数组元素的属性值
    static toObject<T extends { [key: string]: any }>(arr: T[], key: string): { [key: string]: T } {
        return arr.reduce((obj, item) => {
            obj[item[key]] = item;
            return obj;
        }, {} as { [key: string]: T });
    }

    // 数组去重
    static unique<T>(arr: T[]): T[] {
        return Array.from(new Set(arr));
    }

    // 求数组交集
    static intersection<T>(arr1: T[], arr2: T[]): T[] {
        return arr1.filter(item => arr2.includes(item));
    }

    // 求数组并集
    static union<T>(arr1: T[], arr2: T[]): T[] {
        return Array.from(new Set([...arr1, ...arr2]));
    }

    // 求数组差集
    static difference<T>(arr1: T[], arr2: T[]): T[] {
        return arr1.filter(item => !arr2.includes(item));
    }

    // 打乱排序
    static shuffleArray<T>(array: T[]): T[] {
        return array.sort(() => Math.random() - 0.5);
    }

    // 将一个数组拆分成相同个数的多个数组
    static splitArray<T>(arr: T[], chunkSize: number): T[][] {
        const result: T[][] = [];
        const len = arr.length;
        let start = 0;
        while (start < len) {
            result.push(arr.slice(start, start + chunkSize));
            start += chunkSize;
        }
        return result;
    }

    //组合总和允许重复选项数
    static findCombination(arr, target, currentCombination = [], combinations = []) {
        const sum = currentCombination.reduce((acc, val) => acc + val, 0);
        if (sum === target) {
            combinations.push(currentCombination);
            return;
        }
        //
        if (sum > target) {
            return;
        }
        //
        for (let i = 0; i < arr.length; i++) {
            this.findCombination(arr, target, currentCombination.concat(arr[i]), combinations);
        }
        //
        return combinations;
    }

    // 将给定值拆分成若干小筹码：循环取
    //--根据下注总分数 拆分筹码分数
    static splitUserBetChipScore(chips, score: any, count: number = 10): number[] {
        let publicScore = chips
        let chipScore = score;
        let tempCount = 0;
        let userScore: number[] = [];
        for (let i = 0; i < 5; i++) {
            tempCount = Math.floor(chipScore / publicScore[i]);
            chipScore = publicScore[i];
            //--print("拆分筹码分数：", tempCount, i);
            if (tempCount > count) {
                tempCount = Math.floor(count / (i + 1));
            }
            //--print("拆分筹码循环：", tempCount, i);
            for (let j = 0; j < tempCount; j++) {
                userScore.push(chipScore);
            }
            chipScore = score - (userScore.length * 100);
        }
        //
        return userScore;
    }
}


