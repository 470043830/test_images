import { _decorator, Node, Sprite, Tween, tween, v3, Vec3 } from 'cc';
import { GIF } from '../../3rd/GIF';
import { TimerMgr } from '../manager/TimeMgr';
import { GifMgr } from '../manager/GifMgr';

const { ccclass, property } = _decorator;

@ccclass('CocosUtils')
export class CocosUtils {
    /** 
     * bezier
    */
    public static bezierTo<T>(target: any, duration: number, c1: Vec3, c2: Vec3, to: Vec3, opts?: any): Tween<T> {
        opts = opts || Object.create(null);
        /*
        * @desc 二阶贝塞尔
        * @param {number} t 当前百分比
        * @param {} p1 起点坐标
        * @param {} cp 控制点
        * @param {} p2 终点坐标
        * @returns {any}
        */
        let twoBezier = (t: number, p1: Vec3, cp: Vec3, p2: Vec3) => {
            let x = (1 - t) * (1 - t) * p1.x + 2 * t * (1 - t) * cp.x + t * t * p2.x;
            let y = (1 - t) * (1 - t) * p1.y + 2 * t * (1 - t) * cp.y + t * t * p2.y;
            return v3(x, y, 1);
        };
        opts.onUpdate = (arg: Vec3, ratio: number) => {
            target.position = twoBezier(ratio, c1, c2, to);
        };
        return tween(target).to(duration, {}, opts)
    }

    /** 
     * shake
    */
    public static shakeTo<T>(target: any, duration: number = 0): Tween<T> {
        const original = {
            pos: target.position.clone(),
            scale: target.scale.clone(),
            angle: target.angle
        };
        //
        return tween(target).parallel(
            // 位置抖动
            tween()
                .by(0.05, { position: v3(15, 5, 0) })
                .by(0.05, { position: v3(-25, -10, 0) })
                .by(0.05, { position: v3(20, 5, 0) })
                .by(0.05, { position: v3(-10, 0, 0) }),
            // 旋转抖动
            tween()
                .by(0.05, { angle: 8 })
                .by(0.05, { angle: -15 })
                .by(0.05, { angle: 7 }),
            // 缩放抖动
            tween()
                .to(0.05, { scale: v3(1.05, 0.95, 1) })
                .to(0.05, { scale: v3(0.95, 1.05, 1) })
                .to(0.05, { scale: v3(1.02, 0.98, 1) })
        ).to(0.1, {
            position: original.pos,
            scale: original.scale,
            angle: original.angle
        })
    }

    /**
     * load git
     */
    static async loadGif<T>(node: Node, url: string = '') {
        let sprite = node.getComponent(Sprite);
        if (sprite == null) {
            return;
        }
        //
        let data = await GifMgr.Instance.load(url);
        if (data == null) {
            sprite.spriteFrame = null;
            return
        }
        //
        if (data.type == "gif") {
            this.initView(sprite, data.gif, 0)
        } else {
            sprite.spriteFrame = data.img.img;
        }
    }

    /** 
     * init view 
     */
    static async initView(sprite: Sprite, gif: GIF, value: number) {
        if (!sprite || !sprite.node) return;
        let time = gif.delays[value];
        let spriteFrames = gif.spriteFrames[value];
        sprite.spriteFrame = spriteFrames;
        value++;
        if (gif.delays.length == value) value = 0;
        await TimerMgr.Instance.delayTime(time / 100);
        this.initView(sprite, gif, value)
    }
}
