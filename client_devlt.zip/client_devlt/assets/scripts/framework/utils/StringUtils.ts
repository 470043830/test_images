import { MonthEn } from "../../Const";

export class StringUtils {
    /**
     * 判断字符串是否为空或者只包含空白字符
     * @param str 要检查的字符串
     * @returns 如果为空或者只包含空白字符，返回true；否则返回false
     */
    static isNullOrSpace(str: string): boolean {
        return !str || str.trim() === '';
    }

    /**
     * 将字符串转换为首字母大写的形式
     * @param str 要转换的字符串
     * @returns 转换后的字符串
     */
    static capitalize(str: string): string {
        if (!str) return str;
        return str.charAt(0).toUpperCase() + str.slice(1);
    }

    /**
     * 将字符串转换为首字母小写的形式
     * @param str 要转换的字符串
     * @returns 转换后的字符串
     */
    static decapitalize(str: string): string {
        if (!str) return str;
        return str.charAt(0).toLowerCase() + str.slice(1);
    }

    /**
     * 格式化字符串，替换占位符为对应的值
     * @param template 带有占位符的模板字符串，例如 "Hello, {0}!"
     * @param args 替换占位符的值列表
     * @returns 格式化后的字符串
     */
    static format(template: string, ...args: any[]): string {
        return template.replace(/\{(\d+)\}/g, (match, index) => {
            const arg = args[parseInt(index, 10)];
            return arg !== undefined ? arg.toString() : match;
        });
    }

    /**
     * 将字符串转换为驼峰命名格式
     * @param str 要处理的字符串
     * @returns 处理后的字符串
     */
    static toCamelCase(str: string): string {
        return str.replace(/([-_][a-z])/ig, ($1) => {
            return $1.toUpperCase()
                .replace('-', '')
                .replace('_', '');
        });
    }

    /**
     * 将字符串转换为驼峰命名格式
     * @param str 要处理的字符串
     * @returns 处理后的字符串
     */
    static toSnake(camelCase: string): string {
        return camelCase.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`).slice(1);
    }

    // 字符串截取长度
    static truncate(str: string, maxLength: number = 6, suffix: string = '...'): string {
        if (str.length > maxLength) {
            return str.substring(0, maxLength) + suffix;
        }
        return str;
    }


    // 检查字符串是否以指定前缀开头
    static startsWith(str: string, prefix: string): boolean {
        return str.startsWith(prefix);
    }

    // 检查字符串是否以指定后缀结尾
    static endsWith(str: string, suffix: string): boolean {
        return str.endsWith(suffix);
    }

    // 移除字符串两端的空格
    static trim(str: string): string {
        return str.trim();
    }

    // 替换字符串中的所有匹配项
    static replaceAll(str: string, searchValue: string, replaceValue: string): string {
        return str.split(searchValue).join(replaceValue);
    }


    /**
     * 日期格式化。 dateFormat("yyyy-MM-dd hh:mm:ss", date)
     * @param fmt 
     * @param date 
     * @returns 
     */
    public static dateFormat(fmt, date: Date) {
        var o = {
            "M+": date.getMonth() + 1,               //月份 
            "d+": date.getDate(),                    //日 
            "h+": date.getHours(),                   //小时 
            "m+": date.getMinutes(),                 //分 
            "s+": date.getSeconds(),                 //秒 
            "q+": Math.floor((date.getMonth() + 3) / 3), //季度 
            "S": date.getMilliseconds()             //毫秒 
        };
        if (/(y+)/.test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
        }
        for (var k in o) {
            if (new RegExp("(" + k + ")").test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
            }
        }
        return fmt;
    }

    // 数组转object
    static arrayToObject<T>(array: T[], keyFn: (item: T) => string): Record<string, T> {
        return array.reduce((acc, item) => {
            const key = keyFn(item);
            acc[key] = item;
            return acc;
        }, {} as Record<string, T>);
    }

    static encodeBase64(data: string): string {
        return btoa(data);
    }

    static decodeBase64(encodedData: string): string {
        return atob(encodedData);
    }

    static padStart(str: string | number, targetLength: number, padChar: string = '0'): string {
        const strVal = String(str);
        if (strVal.length >= targetLength) return strVal;
        return padChar.repeat(targetLength - strVal.length) + strVal;
    }

    static padEnd(str, targetLength, padChar = ' ') {
        str = String(str);
        if (str.length >= targetLength) return str;
        padChar = String(padChar);
        let padded = '';
        while (padded.length < targetLength - str.length) {
            padded += padChar;
        }
        return str + padded.slice(0, targetLength - str.length);
    }

    /** 数字转时间分秒 */
    static convertToTimeFormat(minutes) {
        // 计算小时和分钟
        const hours = Math.floor(minutes / 60);
        const mins = minutes % 60;

        // 格式化为两位数
        const formattedHours = hours.toString().padStart(2, '0');
        const formattedMins = mins.toString().padStart(2, '0');

        // 组合成时间字符串
        return `${formattedHours}:${formattedMins}`;
    }

    /**格式化数值：1 => `01`，1 => `001` ... */
    static formatNumberForZore(value1: number | string, length: number = 2): string {
        return this.padStart(value1, length, `0`);
    }

    /**格式化数值：1 => `1.0`，1 => `1.00` ... */
    static formatFloatForZore(value1: number | string, length: number = 2): string {
        let num = `${value1}`.split(`.`);
        return this.padEnd(`${num[0]}.${`${num[1] ?? 0}`}`.slice(0, length), length, `0`);
    }

    /**获得当前时间戳 (秒) */
    static time(needMS = false): number {
        if (needMS) {
            return new Date().getTime() / 1000;
        }
        return parseInt((new Date().getTime() / 1000).toString());
    }

    /**毫秒级时间戳 -> 格式化时间 年-月-日 */
    static time_YMD(time?: number | string): string {
        let tempTime = new Date(time ?? new Date());
        return `${StringUtils.formatNumberForZore(tempTime.getFullYear())}-${StringUtils.formatNumberForZore(tempTime.getMonth() + 1)}-${StringUtils.formatNumberForZore(tempTime.getDate())}`
    }

    /**毫秒级时间戳 -> 格式化时间 年-月-日 时:分:秒 */
    static time_YMDHMS(time?: number | string): string {
        let tempTime = new Date(time ?? new Date());
        return `${StringUtils.formatNumberForZore(tempTime.getFullYear())}-${StringUtils.formatNumberForZore(tempTime.getMonth() + 1)}-${StringUtils.formatNumberForZore(tempTime.getDate())} ${StringUtils.formatNumberForZore(tempTime.getHours())}:${StringUtils.formatNumberForZore(tempTime.getMinutes())}:${StringUtils.formatNumberForZore(tempTime.getSeconds())}`
    }

    /**毫秒级时间戳 -> 格式化时间 时:分:秒 */
    static time_HMS(time?: number | string): string {
        let tempTime = new Date(time ?? new Date());
        return `${StringUtils.formatNumberForZore(tempTime.getHours())}:${StringUtils.formatNumberForZore(tempTime.getMinutes())}:${StringUtils.formatNumberForZore(tempTime.getSeconds())}`
    }

    /**毫秒级时间戳 -> 格式化时间 时:分:秒 */
    static time_MS(time?: number | string): string {
        let tempTime = new Date(time ?? new Date());
        return `${StringUtils.formatNumberForZore(tempTime.getMinutes())}:${StringUtils.formatNumberForZore(tempTime.getSeconds())}`
    }

    /**毫秒级时间戳 -> 格式化时间 时:分(AP, PM), 日 月(英文月份) */
    static time_HM_DM(time?: number | string): string {
        let tempTime = new Date(time ?? new Date());
        let nHValue = tempTime.getHours();
        let half = nHValue > 12 ? `PM` : `AM`;
        let hours = StringUtils.formatNumberForZore(nHValue % 12);
        let minutes = StringUtils.formatNumberForZore(tempTime.getMinutes());
        let date = StringUtils.formatNumberForZore(tempTime.getDate());
        return `${hours}:${minutes}${half}, ${date} ${MonthEn[tempTime.getMonth()]}`;
    }

    /**金额用','隔开，例如：10000 => 10,000 千分 */
    static formatNumberForComma(data: number | string) {
        let list = [];
        let str = `${data}`;
        for (let i = str.length - 1, j = 1; i >= 0; --i, ++j) {
            list.unshift(str[i]);
            j % 3 == 0 && list.unshift(`,`);
        }
        if (list[0] == `,`) {
            list.shift();
        }
        return list.join(``);
    }

    /** 检测是否是一个邮箱地址 */
    static isValidEmail(email: string): boolean {
        // 正则表达式用于匹配邮箱地址的模式
        const emailRegex: RegExp = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        return emailRegex.test(email);
    }

    /** 检测是否是一个有效的身份证号码 */
    static isValidIDCard(idCard: string): boolean {
        //
        const regExp: RegExp = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
        if (!regExp.test(idCard)) {
            return false; // 不符合身份证号码的基本格式
        }
        //
        const provinceCode: string[] = [
            '11', '12', '13', '14', '15', '21', '22', '23', '31', '32', '33', '34', '35', '36', '37', '41',
            '42', '43', '44', '45', '46', '50', '51', '52', '53', '54', '61', '62', '63', '64', '65', '71',
            '81', '82', '91'
        ];
        //
        const province = idCard.substring(0, 2);
        if (provinceCode.indexOf(province) === -1) {
            return false; // 省份信息不符合
        }
        //
        if (idCard.length === 18) {
            // 18位身份证需要校验最后一位
            const factors: number[] = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2];
            const parity: string[] = ['1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2'];
            let sum: number = 0;
            for (let i = 0; i < 17; i++) {
                sum += parseInt(idCard[i]) * factors[i];
            }
            //
            const mod: number = sum % 11;
            if (parity[mod] !== idCard[17].toUpperCase()) {
                return false; // 校验位不符合
            }
        }
        //
        return true; // 符合身份证号码的格式和校验规则
    }

    /** 检测是否是一个有效的手机号码 */
    static isValidPhoneNumber(phoneNumber: string): boolean {
        const regExp: RegExp = /^1[3456789]\d{9}$/;
        return regExp.test(phoneNumber);
    }

    /** 检测是否是一个有特殊字符 */
    static hasSpecialCharacters(input: string): boolean {
        const regExp: RegExp = /[^\w\s]/;
        return regExp.test(input);
    }

    /** 检测是否是有效的url */
    static isValidUrl(input: string): boolean {
        const regExp: RegExp = /^(https?|ftp):\/\/[^\s/$.?#].[^\s]*$/i;
        return regExp.test(input);
    }

    /** 检测是否是不是IPv4 */
    static isIPv4(input: string): boolean {
        const regExp: RegExp = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
        return regExp.test(input);
    }

    /** HTML 标签提取 */
    static htmlTag(input: string): any {
        const regExp: RegExp = /<("[^"]*"|'[^']*'|[^'">])*>/;
        return regExp.test(input);
    }

    /**去掉非法字符*/
    static filterIllegalChars(input) {
        // 定义合法字符的正则表达式
        const regex = /[^a-zA-Z0-9 ]/g;
        // 使用replace()方法移除非法字符
        return input.replace(regex, '');
    }

    /** */
    static hasSpace(str) {
        return /\s/.test(str);
    }

    /** */
    static deepCopy(obj, hash = new WeakMap()) {
        // 处理基本数据类型和null/undefined
        if (obj === null || typeof obj !== 'object') {
            return obj;
        }
        // 处理循环引用
        if (hash.has(obj)) {
            return hash.get(obj);
        }
        // 处理Date对象
        if (obj instanceof Date) {
            return new Date(obj);
        }
        // 处理RegExp对象
        if (obj instanceof RegExp) {
            return new RegExp(obj);
        }
        // 处理Map
        if (obj instanceof Map) {
            const copy = new Map();
            hash.set(obj, copy);
            obj.forEach((value, key) => {
                copy.set(this.deepCopy(key, hash), this.deepCopy(value, hash));
            });
            return copy;
        }
        // 处理Set
        if (obj instanceof Set) {
            const copy = new Set();
            hash.set(obj, copy);
            obj.forEach(value => {
                copy.add(this.deepCopy(value, hash));
            });
            return copy;
        }
        // 处理数组和普通对象
        const copy = Array.isArray(obj) ? [] : Object.create(Object.getPrototypeOf(obj));
        hash.set(obj, copy);
        for (let key in obj) {
            if (obj.hasOwnProperty(key)) {
                copy[key] = this.deepCopy(obj[key], hash);
            }
        }
        // 处理Symbol属性
        const symbolKeys = Object.getOwnPropertySymbols(obj);
        for (let key of symbolKeys) {
            copy[key] = this.deepCopy(obj[key], hash);
        }
        //
        return copy;
    }
}
