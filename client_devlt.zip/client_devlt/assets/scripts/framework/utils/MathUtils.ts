import { Vec3 } from "cc";

export class MathUtils {
    // 加法操作
    static add(arg1: number, arg2: number) {
        const base = 10 ** Math.max(
            arg1.toString().split('.')[1]?.length || 0,
            arg2.toString().split('.')[1]?.length || 0
        );
        return (arg1 * base + arg2 * base) / base;
    }

    // 求两个数的最大公约数
    static gcd(a: number, b: number): number {
        if (b === 0) {
            return a;
        } else {
            return this.gcd(b, a % b);
        }
    }

    // 求两个数的最小公倍数
    static lcm(a: number, b: number): number {
        return Math.abs(a * b) / this.gcd(a, b);
    }

    // 求一个数的阶乘
    static factorial(n: number): number {
        if (n === 0 || n === 1) {
            return 1;
        } else {
            return n * this.factorial(n - 1);
        }
    }

    // 判断一个数是否为素数
    static isPrime(n: number): boolean {
        if (n <= 1) {
            return false;
        }
        //
        if (n <= 3) {
            return true;
        }
        //
        if (n % 2 === 0 || n % 3 === 0) {
            return false;
        }
        //
        let i = 5;
        while (i * i <= n) {
            if (n % i === 0 || n % (i + 2) === 0) {
                return false;
            }
            i += 6;
        }
        //
        return true;
    }

    // 求一个数的平方根
    static sqrt(n: number): number {
        return Math.sqrt(n);
    }

    // 将一个数限制在指定范围内
    static clamp(value: number, min: number, max: number): number {
        return Math.max(min, Math.min(max, value));
    }

    // 生成指定范围内的随机整数
    static randomInt(min: number, max: number): number {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    // 生成指定范围内的随机浮点数
    static randomFloat(min: number, max: number): number {
        return Math.random() * (max - min) + min;
    }

    // 获得两点之间的距离
    static getTwoPointDistance(start: Vec3, end: Vec3) {
        let dx = Math.abs(end.x - start.x)
        let dy = Math.abs(end.y - start.y)
        let dis = Math.sqrt(Math.pow(dx, 2) + Math.pow(dy, 2))
        return dis
    }

    //获得两个坐标的中间点
    static getCentralCoordinate(start: Vec3, end: Vec3) {
        return new Vec3((start.x + end.x) / 2, (start.y + end.y) / 2, (start.z + end.z) / 2)
    }

    //获得两点之间的中心弧点坐标
    static getCentralHuCoordinate(start: Vec3, end: Vec3, py: number = 0) {  //py 是两点距离一半时 是等距离圆弧
        let coordinate = this.getCentralCoordinate(start, end)
        let y_ = coordinate.y + py / 2
        let x_ = (Math.pow(end.x, 2) - Math.pow(start.x, 2) - 2 * y_ * (end.y - start.y)) / (2 * (end.x - start.x))
        return new Vec3(x_, y_, 0)
    }
}
