import { Logger } from "./Logger"

/** 翻转对象键与值 */
export type Flip<Obj extends Record<string, string | number>> = {
    [Key in keyof Obj as Obj[Key]]: Key
}

/** 可用于 `${}` 的类型 */
export type Stringable = string | number | bigint | boolean | null | undefined

/** 更宽松的键值 */
export type FlipLoose<Obj extends Record<string | number, Stringable>> = {
    [Key in keyof Obj as Obj[Key] extends keyof any ? Obj[Key] : Obj[Key] extends Stringable ? `${Obj[Key]}` : never]: Key extends Stringable ? `${Key}` : never
}

// 以下注释部分被 Flip 取代
/** 获取 value 类型 */
// export type ValueOf<O extends Record<keyof any, any>> = O[keyof O]
/** 工具类型 根据值获取键 */
// type KeysMatching<Obj, Val> = { [Key in keyof Obj]-?: Obj[Key] extends Val ? Key : never }[keyof Obj]
/** 工具类型 把值转换成键类型 */
// type SetValuesTokeyType<T extends Record<keyof any, keyof any | boolean | null | undefined>> = {
//   [K in keyof T]: T[K] extends keyof any
//     ? T[K]
//     : T[K] extends bigint | boolean | undefined | null
//       ? `${T[K]}`
//       : never
// }
/** 工具类型 反转对象值与键 */
// export type Reverse<Obj extends Record<keyof Obj, Obj[keyof Obj]>> = { [Val in ValueOf<Obj>]: KeysMatching<Obj, Val> }
// export type ReverseLoose<T extends Record<keyof any, keyof any | boolean | null | undefined>> = Reverse<SetValuesTokeyType<T>>

/** 生成双向映射  */
export function BidirectionalMap<T extends Record<string | number, string | number | boolean | null | undefined>>(obj: T)
    : Readonly<
        & T
        & FlipLoose<T>
        & { [Symbol.iterator](): IterableIterator<[keyof T, T[keyof T]]> }
    > {
    const newObj = Object.create(null)

    // 创建自定义迭代器 可以 for(const [key, val] of myEnum) {  }
    Object.defineProperty(newObj, Symbol.iterator, {
        enumerable: false,
        value: () => Object.entries(obj)[Symbol.iterator]()
    })
    //
    for (const key in obj) {
        newObj[String(newObj[key] = obj[key])] = key
    }
    //
    return Object.freeze(newObj)
}

/** */
export enum CloneType {
    Object = "Object",
    Array = "Array",
    Date = "Date",
    RegExp = "RegExp",
    Function = "Function",
    String = "String",
    Number = "Number",
    Boolean = "Boolean",
    Undefined = "Undefined",
    Null = "Null",
    Symbol = "Symbol",
    Set = "Set",
    Map = "Map",
}

export type _CloneType = keyof typeof CloneType;
export const tzCountry = "Asia/Kolkata";

/** */
export class Utils {
    static getUrlParams(url): any {
        // 通过 ? 分割获取后面的参数字符串
        let urlStr = url.split("?")[1];
        if (!urlStr) return;
        // 创建空对象存储参数
        let obj: any = {};
        // 再通过 & 将每一个参数单独分割出来
        let paramsArr = urlStr.split("&");
        for (let i = 0, len = paramsArr.length; i < len; i++) {
            // 再通过 = 将每一个参数分割为 key:value 的形式
            let arr = paramsArr[i].split("=");
            obj[arr[0]] = arr[1];
        }
        //
        return obj;
    }

    /** */
    static isNull(data_) {
        if (
            data_ === undefined ||
            data_ === null ||
            (typeof data_ == `number` && isNaN(data_)) ||
            (typeof data_ == `object` && Object.keys(data_).length === 0)
        ) {
            return true;
        }
        return false;
    }

    /**
     * 检测数据类型
     * @param type cloneType
     * @param obj 检测的数据源
     * @returns Boolean
     */
    static isType<T>(type: _CloneType, obj: T) {
        return Object.prototype.toString.call(obj) === `[object ${type}]`;
    }

    /** */
    static longToNumber(long) {
        const high = long.high;
        const low = long.low;
        // 组合高低位（使用乘法避免位运算限制）
        let result = high * 0x100000000 + low;
        // 处理负数（当最高位为1时）
        if (high & 0x80000000) {
            result += 0x10000000000000000; // 添加 2^64
        }
        //
        return result;
    }

    /**
     * 深拷贝
     * @param obj 要克隆的对象
     * @param cache 缓存对象，用于解决循环引用的问题
     *  */
    static deepCopy<T>(obj: T, cache = new WeakMap()): T {
        // 如果不是对象或者是null，直接返回（终止条件）
        if (typeof obj !== "object" || obj === null) {
            return obj;
        }
        // 如果类型是Symbol，直接返回一个新的Symbol
        if (this.isType(CloneType.Symbol, obj)) {
            return obj.constructor((obj as unknown as Symbol).description);
        }
        // 如果已经缓存过，直接返回缓存的值
        if (cache.has(obj)) {
            return cache.get(obj);
        }
        // 初始化返回结果
        let temp: T, param: T;
        // 如果是日期对象，直接返回一个新的日期对象
        if (
            this.isType(CloneType.Date, obj) ||
            this.isType(CloneType.RegExp, obj)
        ) {
            param = obj;
        }
        // @ts-ignore
        temp = new obj!.constructor(param);
        // 如果是数组或者对象，需要遍历
        if (this.isType(CloneType.Array, obj) || this.isType(CloneType.Object, obj)) {
            Object.keys(obj).forEach((key) => {
                if (obj.hasOwnProperty(key)) {
                    temp[key] = this.deepCopy(obj[key], cache);
                }
            });
        }
        // 如果是Set
        if (this.isType(CloneType.Set, obj)) {
            for (let value of obj as unknown as Set<T>) {
                (temp as Set<T>).add(this.deepCopy(value, cache));
            }
        }
        // 如果是Map
        if (this.isType(CloneType.Map, obj)) {
            for (let [key, value] of obj as unknown as Map<T, T>) {
                (temp as Map<T, T>).set(
                    this.deepCopy(key, cache),
                    this.deepCopy(value, cache)
                );
            }
        }
        // 缓存值
        cache.set(obj, temp);
        return temp;
    }

    /** */
    static mergeObject<T extends object>(target: T, ...sources: Partial<T>[]): T {
        for (const source of sources) {
            for (const key in source) {
                if (source.hasOwnProperty(key)) {
                    (target as any)[key] = source[key];
                }
            }
        }
        //
        return target;
    }

    /** */
    static guid(len = 32, firstU = true, radix = null) {
        const chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split("");
        const uuid = [];
        radix = radix || chars.length;
        //
        if (len) {
            // 如果指定uuid长度,只是取随机的字符,0|x为位运算,能去掉x的小数位,返回整数位
            for (let i = 0; i < len; i++) {
                uuid[i] = chars[0 | (Math.random() * radix)];
            }
        } else {
            let r;
            // rfc4122标准要求返回的uuid中,某些位为固定的字符
            uuid[8] = uuid[13] = uuid[18] = uuid[23] = "-";
            uuid[14] = "4";
            for (let i = 0; i < 36; i++) {
                if (!uuid[i]) {
                    r = 0 | (Math.random() * 16);
                    uuid[i] = chars[i == 19 ? (r & 0x3) | 0x8 : r];
                }
            }
        }
        // 移除第一个字符,并用u替代,因为第一个字符为数值时,该guuid不能用作id或者class
        if (firstU) {
            uuid.shift();
            return `u${uuid.join("")}`;
        }
        //
        return uuid.join("");
    }

    /** */
    static getQueryString(name) {
        let search = "";
        try {
            search = window.location.search.substr(1) || window.location.hash.split("?")[1];
            if (!search) {
                return null;
            }
            //
            const reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
            const r = search.match(reg);
            if (r != null) return unescape(r[2]);
            return null;
        } catch (err) {
            Logger.info(err);
        }
    };

    /**
         * 格式化时间格式，参数为number的字符，
         * 显示格式: 00:00:00 或 00:00
         * type=00:00:00, 或者 00:00
         * @param date 
         */
    static formatTimeString(time: number, type?: string) {
        let strTime = "";
        if (time != null) {
            let hour = 0;
            let min = 0;
            let sec = 0;

            if (type) {
                if (type == "00:00:00") {
                    hour = Math.floor(time / 3600);
                    min = Math.floor((time % 3600) / 60);
                    sec = Math.floor((time % 3600) % 60);
                    strTime = `${this.padTime(hour)}:${this.padTime(min)}:${this.padTime(sec)}`;
                } else if (type == "00:00") {
                    min = Math.floor(time / 60);
                    sec = Math.floor(time % 60);
                    strTime = `${this.padTime(min)}:${this.padTime(sec)}`;
                } else if (type == "00") {
                    sec = Math.floor(time % 60);
                    strTime = `${this.padTime(sec)}`;
                } else if (type == "0") {
                    sec = Math.floor(time % 60);
                    strTime = `${sec}`;
                }
            }
            if (strTime.length == 0) {
                if (time >= 3600) {
                    hour = Math.floor(time / 3600);
                    min = Math.floor((time % 3600) / 60);
                    sec = Math.floor((time % 3600) % 60);
                    strTime = `${this.padTime(hour)}:${this.padTime(min)}:${this.padTime(sec)}`;
                } else {
                    min = Math.floor(time / 60);
                    sec = Math.floor(time % 60);
                    if (min == 0) {
                        strTime = `${sec}`;
                    } else {
                        strTime = `${this.padTime(min)}:${this.padTime(sec)}`;
                    }
                }
            }
        }
        return strTime;
    }


    static padTime(num: number) {
        if (num < 10) {
            return `0${num}`;
        } else {
            return `${num}`;
        }
    }
}
