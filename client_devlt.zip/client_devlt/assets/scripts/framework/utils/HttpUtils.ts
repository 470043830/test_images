import HttpMgr from "../net/HttpMgr";
import AccountModel from "../../model/AccountModel";
import { Logger } from "./Logger";
import { sys } from "cc";
import { LocalStorageKey } from "../../LocalStorageKey";
import { generateRandomString } from "../lib/GlobalFunc";
import { LoginType, PhoneAreaCode } from "../../Const";
import { UIMgr } from "../manager/UIMgr";
import { EnumPrefab } from "../../config/BundleConfig";
import { GameApp } from "../../lobby/GameApp";
import EventMgr from "../event/EventMgr";
import { GAME_EVENT } from "../event/EventDefine";

/** */
enum SKILLType {
    /** 重置 */
    RESET = "RESET",
    /** 超级技能 */
    CLEAR = "CLEAR",
}

/** */
export class HttpUtils {
    /** 
    * 路由操作
    */
    static async hello(callBack: Function = null) {
        let ret: any = await HttpMgr.Instance.httpRequestJson("/hello", {
            method: "POST", data: {
                "token": "89588889999",
                "version": "1.0.0",
                "channel": "10000",
                "deviceID": "x12345",
            }
        })
        Logger.info("====》请求路由: ", ret)
        if (callBack) {
            callBack(ret);
        }
    }

    /**
     * 游客登录操作
     * @param customDevice 设备ID
     * @param callBack 
     */
    static async loginByGuest(customDevice: string, callBack: Function = null) {
        let deviceID = null;
        if (customDevice && customDevice != "") {
            deviceID = customDevice;
            sys.localStorage.setItem(LocalStorageKey.LocalDeviceID, deviceID);
        } else {
            let localDeviceID = sys.localStorage.getItem(LocalStorageKey.LocalDeviceID);
            if (localDeviceID && localDeviceID != "") {
                deviceID = localDeviceID;
            } else {
                //随机生成字符串
                deviceID = generateRandomString(16);
                sys.localStorage.setItem(LocalStorageKey.LocalDeviceID, deviceID);
            }
        }

        this.login(LoginType.Guest, deviceID, "", "", "test", callBack)
    }

    /**
     * 手机号及验证码登录
     * @param phoneNumber 手机号码
     * @param verifyCode 验证码
     * @param callBack 
     */
    static async loginByPhoneNumber(phoneNumber: string, verifyCode: string, callBack: Function = null) {
        let deviceID = phoneNumber;
        if (sys.isNative) {
            //取得真正的deviceID
        } else {
            deviceID = sys.localStorage.getItem(LocalStorageKey.LocalDeviceID);
        }
        this.login(LoginType.Phone, deviceID, phoneNumber, verifyCode, "test", callBack)
    }

    /**
     * 账户密码登录
     * @param account 
     * @param password 
     * @param callBack 
     */
    static async loginByAccount(phoneNumber: string, password: string, callBack: Function = null) {
        let deviceID = phoneNumber;
        if (sys.isNative) {
            //取得真正的deviceID
        } else {
            deviceID = sys.localStorage.getItem(LocalStorageKey.LocalDeviceID);
        }
        this.login(LoginType.Account, deviceID, phoneNumber, password, "test", callBack)
    }

    /**
     * 登录请求
     * @param loginType 登录方式
     * @param account 账号/手机号/设备ID
     * @param passWord 密码/验证码
     * @param source 归因来源
     * @param callBack 
     */
    static async login(loginType: LoginType, deviceID: string, account: string, passWord: string, source: string, callBack: Function = null) {
        Logger.info(`======> 请求登录, loginType: ${loginType}, deviceID: ${deviceID}, account: ${account}, passWord: ${passWord}, source :${source}`);
        EventMgr.Instance.emit(GAME_EVENT.ON_LOADING_CIRCLE, true);
        
        let ret: any = await HttpMgr.Instance.httpRequestJson("/login", {
            method: "POST",
            data: {
                LoginType: loginType,
                LoginSource: source,
                DeviceCode: deviceID,
                PhoneAreaCode: PhoneAreaCode,
                PhoneNum: account,
                Password: passWord,
            }
        }).catch((reason) => {
            Logger.error("====> login 请求发生错误: ", reason);
        });

        if (callBack) {
            callBack(loginType, ret);
        }
    }

    /**
     * 请求验证码
     * @param phoneNum 手机号
     */
    static async sendVerifyCode(phoneNum: string, callBack: Function) {
        let ret: any = await HttpMgr.Instance.httpRequestJson("/phonecode", {
            method: "POST",
            data: {
                phoneNum: phoneNum,
                PhoneAreaCode: PhoneAreaCode
            }
        }).catch((reason) => {
            Logger.error("====> phonecode 请求发生错误: ", reason);
        });

        if (callBack) {
            callBack(ret);
        }
    }

    /**
    * 请求修改密码
    * @param phoneNum 
    * @param verifyCode 
    * @param newPassword 
    * @param callBack 
    */
    static async modifyPassword(phoneNum: string, verifyCode: string, newPassword: string, callBack: Function) {
        let ret: any = await HttpMgr.Instance.httpRequestJson("/setpassword", {
            method: "POST",
            data: {
                phoneAreaCode: PhoneAreaCode,
                phoneNum: phoneNum,
                phoneCode: verifyCode,
                password: newPassword,
            }
        }).catch((reason) => {
            Logger.error("====> phonecode 请求发生错误: ", reason);
        });

        if (callBack) {
            callBack(ret);
        }
    }
}
