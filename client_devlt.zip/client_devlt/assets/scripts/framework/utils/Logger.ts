import { StringUtils } from "./StringUtils";

/**
 * 日志等级枚举
 */
export enum LogLv {
    DEBUG = 0,
    INFO,
    WARN,
    ERROR
}

/**
 * 日志系统描述
 */
export interface LogInfo {
    level: LogLv,
    info: string,
}

export class Logger {
    /** 当前日志标志 */
    public static Cur_Level: LogLv = LogLv.DEBUG;
    /** 日志最大行数 */
    private static MAX_LEN: number = 5000;
    /** 达到最大行数清理的数量 */
    private static CLEAR_COUNT: number = 1000;
    /** 日志缓存 */
    private static logs: Array<LogInfo> = [];

    //
    static debug(message: any, ...args: any[]) {
        if (LogLv.DEBUG < Logger.Cur_Level) {
            return;
        }
        Logger.pushLogs(LogLv.DEBUG, `[DEBUG] ${message}`, ...args);
        console.log(`%c${this.getDateString()} [DEBUG] ${message}`, 'color: #3498db', ...args);
    }

    //
    static info(message: any, ...args: any[]) {
        if (LogLv.INFO < Logger.Cur_Level) {
            return;
        }
        Logger.pushLogs(LogLv.INFO, `[INFO] ${message}`, ...args);
        console.info(`%c${this.getDateString()} [INFO] ${message}`, 'color: #2ecc71', ...args);
    }

    //
    static warning(message: any, ...args: any[]) {
        if (LogLv.WARN < Logger.Cur_Level) {
            return;
        }
        Logger.pushLogs(LogLv.WARN, `[WARNING] ${message}`, ...args);
        console.warn(`%c${this.getDateString()} [WARNING] ${message}`, 'color: #f39c12', ...args);
    }

    //
    static error(message: any, ...args: any[]) {
        if (LogLv.ERROR < Logger.Cur_Level) {
            return;
        }
        Logger.pushLogs(LogLv.ERROR, `[ERROR] ${message}`, ...args);
        console.error(`%c${this.getDateString()} [ERROR] ${message}`, 'color: #e74c3c', ...args);
    }

    //
    static net(message: any, ...args: any[]) {
        if (LogLv.INFO < Logger.Cur_Level) {
            return;
        }
        Logger.pushLogs(LogLv.INFO, `[NETWORK] ${message}`, ...args);
        console.info(`%c${this.getDateString()} [NETWORK] ${message}`, 'color: #ee7700', ...args);
    }

    //
    private static getDateString() {
        let time = new Date().getTime();
        return `[${StringUtils.time_HMS(time)}:${StringUtils.formatNumberForZore(time % 1000, 3)}]`;
    }

    //
    private static pushLogs(lv: LogLv, message: string, ...args: any[]) {
        let info = `${this.getDateString()} ${message}`;
        for (let index = 0; index < args.length; index++) {
            try {
                info += (" " + JSON.stringify(args[index]));
            } catch (error) {
                info += (" " + args[index]);
            }
        }
        let logInfo: LogInfo = { level: lv, info: info };
        // 超过最大行数
        if (Logger.logs.length >= Logger.MAX_LEN) {
            Logger.logs.shift();
        }
        Logger.logs.push(logInfo);
    }
}

// if (DEBUG) {
Logger.Cur_Level = LogLv.DEBUG;
// }
// else {
//     Logger.Cur_Level = LogLv.WARN;
// }
