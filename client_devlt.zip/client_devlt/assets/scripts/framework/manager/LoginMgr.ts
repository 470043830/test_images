import * as cc from "cc";
import { ToastUIUtils } from "../../lobby/ToastUIUtils";
import AccountModel from "../../model/AccountModel";
import Singleton from "../base/Singleton";
import { HallReqManager } from "../net/HallReqManager";
import SocketMgr from "../net/SocketMgr";
import { HttpUtils } from "../utils/HttpUtils";
import { Logger } from "../utils/Logger";
import { LoginType } from "../../Const";
import { LocalStorageKey } from "../../LocalStorageKey";
import { EnumPrefab, EnumScene } from "../../config/BundleConfig";
import { GAME_EVENT, SYS_EVENT } from "../event/EventDefine";
import EventMgr from "../event/EventMgr";
import GlobalModel from "../../model/GlobalModel";
import { GameApp } from "../../lobby/GameApp";
import { UIMgr } from "./UIMgr";
import { buildType, AppConfig } from "../../config/Config";



/**
 * 登录管理
 */
export class LoginMgr extends Singleton {

    static get Instance() {
        return super.GetInstance<LoginMgr>();
    }


    /**
     * 尝试自动登录，用于app启动后
     */
    tryAutoLogin() {
        //上次是游客登录，则继续用游客登录
        let lastLoginType = this.getLoginType();
        if (lastLoginType == LoginType.Guest) {
            if (buildType != AppConfig.BuildType.RELEASE) {
                //开发模式
                UIMgr.Instance.showView(EnumPrefab.accountCreate, null, GameApp.Instance.getDialogLayer(), EnumPrefab.accountCreate, false);
                return;
            }
        }

        let logout = this.isLogoutByUser();
        if (logout) {
            //用户主动登出过，则跳转到手机号码登录场景
            EventMgr.Instance.emit(SYS_EVENT.CHANGE_SCENE, { name: EnumScene.login });
            return;
        }

        let loginRecord = this.getLoginRecord();
        if (loginRecord && loginRecord.account != "" && loginRecord.code != "") {
            //以上次的登录记录去登录
            this.login(lastLoginType, loginRecord.account, loginRecord.code);
        } else {
            if (lastLoginType == LoginType.Guest) {
                this.login(LoginType.Guest, null);
            } else {
                //登录信息不全，则跳转到手机号码登录场景
                EventMgr.Instance.emit(SYS_EVENT.CHANGE_SCENE, { name: EnumScene.login });
            }
        }
    }

    /**
     * 登录
     * @param account 
     * @param code 
     */
    login(loginType: LoginType, account: string, code: string = "") {
        let loginResult = (loginType, ret) => {
            if (ret && ret.code == 200) {
                //保存登录信息在本地，用于下次自动登录
                this.saveLoginType(loginType);
                if (loginType != LoginType.Guest) {
                    this.saveLoginInfo(account, code);
                }

                this.onLoginSucc(ret);
            } else {
                this.onLoginFailed(ret);
            }
        }

        if (loginType == LoginType.Guest) {
            //游客登录
            HttpUtils.loginByGuest(account, loginResult);
        } else if (loginType == LoginType.Account) {
            //账户密码登录
            HttpUtils.loginByAccount(account, code, loginResult);
        } else {
            //手机验证码登录
            HttpUtils.loginByPhoneNumber(account, code, loginResult);
        }
    }

    onLoginSucc(ret) {
        AccountModel.Instance.token = ret.token;
        Logger.info(`======> 登录成功`, JSON.stringify(ret));
        //{"code":"200","version":"1.0.0","host":"192.168.1.178:10000","token":"cd86adf9-c973-4809-891d-338db8bae7e410004","pid":"10004"}
        // AccountModel.Instance.userId = ret.uid;
        AccountModel.Instance.userId = ret.pid;
        AccountModel.Instance.token = ret.token;
        AccountModel.Instance.host = ret.host;
        GlobalModel.Instance.version = ret.version;
        // EventMgr.Instance.emit(SYS_EVENT.GAME_INIT_CONFIG);
        this.connectSocket();
    }

    onLoginFailed(ret) {
        Logger.info(`======> 登录失败`);
        ToastUIUtils.openLoginFailedUI();
    }

    /**
     * 整个登录流程完成（包括socket连接成功）
     */
    onLoginFinished() {
        cc.sys.localStorage.setItem(LocalStorageKey.KeyLogOutActive, "0");
        // EventMgr.Instance.emit(GAME_EVENT.ON_SHOW_LOADING);
        // EventMgr.Instance.emit(GAME_EVENT.ON_LOADING_CIRCLE, true);
        EventMgr.Instance.emit(SYS_EVENT.CHANGE_SCENE, { name: EnumScene.lobby });
    }

    /**
     * 尝试重新登录
     */
    tryRelogin() {
        // this.login(this._lastLoginDeviceID);
    }

    /**
     * 登出
     */
    logout() {
        cc.sys.localStorage.setItem(LocalStorageKey.KeyLogOutActive, "1");
        SocketMgr.Instance.setReconnectAble(false);
        SocketMgr.Instance.close();
    }

    /**
     * 初始化socket网络连接
     */
    private async connectSocket() {
        let wsHost = AccountModel.Instance.host;
        let isShow = await SocketMgr.Instance.connect(wsHost);
        Logger.info("网络状态")
        if (isShow == false) {
            this.connectSocket();
            return;
        }
        HallReqManager.sendLogin();
    }

    /**
     * 取得上次登录类型
     */
    getLoginType() {
        let loginType = cc.sys.localStorage.getItem(LocalStorageKey.KeyLoginType);
        if (loginType && loginType != "") {
            return Number(loginType);
        }
        return LoginType.Guest;
    }

    /**
     * 保存登录方式
     * @param loginType 
     */
    saveLoginType(loginType: LoginType) {
        cc.sys.localStorage.setItem(LocalStorageKey.KeyLoginType, loginType.toString());
    }

    /**
     * 保存登录信息
     * @param account 
     * @param code 
     */
    saveLoginInfo(account: string, code: string) {
        let data = {
            account: account,
            code: code,
        }
        cc.sys.localStorage.setItem(LocalStorageKey.KeyLoginInfo, JSON.stringify(data));
    }

    /**
     * 取得登录记录
     * @returns 
     */
    getLoginRecord(): { account: string, code: string } {
        let loginInfo = cc.sys.localStorage.getItem(LocalStorageKey.KeyLoginInfo);
        if (loginInfo && loginInfo != "") {
            return JSON.parse(loginInfo);
        }
        return null;
    }

    /**
     * 用户是否主动登出
     * @returns 
     */
    isLogoutByUser() {
        let logout = cc.sys.localStorage.getItem(LocalStorageKey.KeyLogOutActive);
        if (logout && logout == "1") {
            return true;
        }
        return false;
    }

}
