import { JSB, NATIVE } from 'cc/env';
import { BundleConfig, EnumBundle, EnumScene, IBundleAsset } from '../../config/BundleConfig';
import {
    __private,
    Asset,
    AssetManager,
    assetManager,
    AudioClip,
    Component,
    director,
    native,
    Prefab,
    Scene,
    SceneAsset,
    SpriteFrame
} from 'cc';
import { Logger } from '../utils/Logger';

/**
 * 资源加载类，场景预加载函数还没有移过来
 * { [eventName: string]: Function[] }
 */

export class ResMgr extends Component {
    /** */
    public static Instance: ResMgr = null;
    /** 子包字典 */
    private bundles: Map<string, AssetManager.Bundle> = new Map<string, AssetManager.Bundle>();
    /** 总子包数量 */
    private totalAb: number = 0;
    /** 总资源数量 */
    private total: number = 0;
    /** 当前加载子包数量*/
    private nowAb: number = 0;
    /** 当前加载资源数量 */
    private now: number = 0;
    /** 加载过程回调 */
    private progressFunc: Function | null = null;
    /** 加载完成回调 */
    private endFunc: Function | null = null;

    /** */
    onLoad() {
        if (ResMgr.Instance === null) {
            ResMgr.Instance = this;
        } else {
            this.destroy();
            return;
        }
    }

    /**
     * 加载文件夹资源
     */
    public loadDir<T extends Asset>(abName: string, type: __private.__types_globals__Constructor<T> | null, assetUrl_: string): Promise<T[]> {
        return new Promise<T[]>((resolve, reject) => {
            let bundle = this.bundles.get(abName);
            if (bundle) {
                bundle.loadDir<T>(assetUrl_, type, (now, total) => {
                }, (err, res) => {
                    if (err) {
                        reject(err);
                        return;
                    }
                    resolve(res);
                })
            } else {
                this.loadBundle(abName).then((bundle) => {
                    bundle.loadDir<T>(assetUrl_, type, (now, total) => {
                    }, (err, res) => {
                        if (err) {
                            reject(err);
                            return;
                        }
                        resolve(res);
                    })
                })
            }
        })
    }

    /**
     * 加载远程资源
     */
    public loadRemote<T extends Asset>(url: string, type?: new () => T): Promise<T> {
        return new Promise((resolve, reject) => {
            assetManager.loadRemote(url, { ext: type?.name?.toLowerCase() }, (err, asset) => {
                if (err) {
                    reject(err);
                    return;
                }
                resolve(asset as T);
            });
        });
    }

    /**
     * 加载场景
     */
    // public loadScene(abName: EnumBundle | string, sceneName: EnumScene | string): Promise<Scene> {
    //     return new Promise<Scene>((resolve, reject) => {
    //         let bundle = this.bundles.get(abName);
    //         if (null == bundle) {
    //             this.loadBundle(abName).then((res) => {
    //                 director.loadScene(sceneName, (err, sceneAsset: Scene) => {
    //                     if (err) {
    //                         reject(err);
    //                         return
    //                     }
    //                     resolve(sceneAsset);
    //                 })
    //             })
    //         } else {
    //             director.loadScene(sceneName, (err, sceneAsset: Scene) => {
    //                 if (err) {
    //                     reject(err);
    //                     return;
    //                 }
    //                 resolve(sceneAsset);
    //             })
    //         }
    //     })
    // }

    /**
     * 加载资源
     */
    public loadAsset<T extends Asset>(abName: string, type: __private.__types_globals__Constructor<T> | null, assetUrl_: string): Promise<T> {
        return new Promise<T>((resolve, reject) => {
            let bundle = this.bundles.get(abName);
            if (bundle) {
                let asset = this.getAsset<T>(abName, type, assetUrl_);
                if (asset) {
                    // Logger.info("获取已加载资源：", assetUrl_)
                    resolve(asset);
                } else {
                    bundle.load<T>(assetUrl_, type, (now, total) => {
                    }, (err, res) => {
                        if (err) {
                            reject(err);
                            return;
                        }
                        resolve(res);
                    })
                }
            } else {
                this.loadBundle(abName).then((bundle) => {
                    bundle.load<T>(assetUrl_, type, (now, total) => {
                    }, (err, res) => {
                        if (err) {
                            reject(err);
                            return;
                        }
                        resolve(res);
                    })
                })
            }
        })
    }

    /**
     *
     * @param prefab_
     * @returns
     */
    public async loadPrefab(prefab_: string): Promise<Prefab> {
        return new Promise<Prefab>((resolve, reject) => {
            let bundleAsset: IBundleAsset = BundleConfig.getBundleAsset(prefab_);
            let abName = bundleAsset.ABName;
            ResMgr.Instance.loadAsset<Prefab>(abName, Prefab, bundleAsset.path).then((res) => {
                resolve(res);
            }, (err) => {
                resolve(null);
            })
        })
    }

    /**
     * 获取已加载资源
     */
    public getAsset<T extends Asset>(abName: string, type: __private.__types_globals__Constructor<T> | null, resUrl: string): T {
        var bundle = this.bundles.get(abName);
        if (bundle === null) {
            Logger.info("[error]: " + abName + " AssetsBundle not loaded !!!");
            return null;
        }
        return bundle.get<T>(resUrl, type);
    }

    /**
     * 获取子包
     *
     */
    public getBundle(abName: string): AssetManager.Bundle {
        return this.bundles.get(abName);
    }

    /**
     * 卸载子包资源
     */
    releaseBundle(abName_: string): void {
        if (this.bundles.get(abName_)) {
            Logger.info("releaseBundle===>>>>")
            // 移除子包资源
            this.bundles.get(abName_).releaseAll();
            assetManager.removeBundle(this.bundles.get(abName_));
            this.bundles.delete(abName_);
            Logger.info("移除后剩余的子包===>>>", assetManager.bundles)
            assetManager.bundles.forEach(e => {
                Logger.info("剩余的子包===>>>", e)
            })
        }
    }

    /**
     * 预加载资源
     * {
     *      "lobby":
     *      {
     *          remote_url:null
     *          src:[
     *             {
     *              assetType:Prefab
     *              urls:[
     *
     *
     *                  ]
     *              }
     *          ]
     *      }
     * }
     */
    preLoadPkgRes(list: Array<EnumBundle>, progressFunc: Function | null, endFunc: Function): void {
        this.total = 0;
        this.now = 0;
        this.totalAb = 0;
        this.nowAb = 0;
        this.progressFunc = progressFunc;
        this.endFunc = endFunc;

        let lists = [];
        for (let i = 0; i < list.length; i++) {
            let str = list[i];
            let data = BundleConfig.bundlePrepkg.get(str);
            for (let k = 0; k < data.src.length; k++) {
                let date = data.src[k];
                if (date.isLoadAll == true) {
                    let dirs = ResMgr.Instance.getAssetDownNum(str, date.assetType, date.path);
                    lists.push({ assetType: date.assetType, paths: dirs, enumBundle: str });
                    this.total += dirs.length;
                } else {
                    lists.push({ assetType: date.assetType, paths: date.paths, enumBundle: str });
                    this.total += date.paths.length;
                }
            }
        }
        this.loadAssetsInBundle(lists);
    }

    /**
     * 加载资源包
     */
    public async onLoadBundleModules(abName): Promise<boolean> {
        return new Promise<boolean>(async (resolve, reject) => {
            try {
                let data = await this.loadBundle(abName);
                if (data == null) {
                    reject(false);
                    return;
                }
                resolve(true)
            } catch (error) {
                reject(false)
            }
        })
    }

    /**
     * 卸载多余资源
     */
    unPreLoadPkgRes(resPkg: any): void {
        for (var key in resPkg) {
            var src = resPkg[key].src;
            for (var i = 0; i < src.length; i++) {
                var urlSet = src[i].urls;
                var typeClass = src[i].assetType;
                for (var j = 0; j < src[i].urls.length; ++j) {
                    // 卸载资源
                    Logger.info("卸载资源:", urlSet[j])
                    this.bundles.get(key).release(urlSet[j], typeClass);
                }
            }
        }
    }

    /**
     * 加载图片方法
     */
    loadSpriteFrame(abName: string, resUrl: string) {
        this.loadAsset<SpriteFrame>(abName, SpriteFrame, resUrl);
    }

    /**
     * 加载声音方法
     */
    loadAudioClip(abName: string, resUrl: string) {
        this.loadAsset<AudioClip>(abName, AudioClip, resUrl);
    }

    /**
     * 根据资源配置加载资源
     * assetName
     */
    loadBundleConfigAsset<T extends Asset>(assetName: string, type: __private.__types_globals__Constructor<T> | null): Promise<T> {
        let prefabInfo = BundleConfig.bundleAssets.get(assetName);
        if (!prefabInfo) {
            return null;
        }
        //
        return new Promise<T>((resolve, reject) => {
            let bundle = this.bundles.get(assetName);
            if (bundle) {
                let asset = this.getAsset<T>(prefabInfo.ABName, type, prefabInfo.path);
                if (asset) {
                    resolve(asset);
                } else {
                    bundle.load<T>(prefabInfo.path, type, (now, total) => {
                    }, (err, res) => {
                        if (err) {
                            reject(err);
                            return;
                        }
                        resolve(res);
                    })
                }
            } else {
                this.loadBundle(prefabInfo.ABName).then((bundle) => {
                    bundle.load(prefabInfo.path, type, (now, total) => {
                    }, (err, res) => {
                        if (err) {
                            reject(err);
                            return;
                        }
                        resolve(res);
                    })
                })
            }
        })
    }

    /**
     * 获取资源对应的下载数量
     */
    public getAssetDownNum(abName: string, typeClasss: any, path: string = ""): Array<any> {
        let abBundle: AssetManager.Bundle = this.bundles.get(abName);
        let dirs;
        if (typeClasss == null) {
            dirs = abBundle.getDirWithPath(path);
        } else {
            dirs = abBundle.getDirWithPath(path, typeClasss);
        }
        return dirs;
    }

    /** 获取资源对应的下载数量 */
    public getAssetDownNumLength(abName: string, typeClasss: any): number {
        let abBundle: AssetManager.Bundle = this.bundles.get(abName);
        let dirs = abBundle.getDirWithPath("", typeClasss);
        let aaanum = 0;
        let bbbnum = 0;
        let dirsnum = dirs.length;
        for (let index = 0; index < dirs.length; index++) {
            const element = dirs[index];
            let aaa = assetManager.dependUtil.getDeps(element.uuid);
            let bbb = assetManager.dependUtil.getDepsRecursively(element.uuid);
            aaanum += aaa.length;
            bbbnum += bbb.length;
        }
        //
        let func = function () {

        }
        func();
        return dirsnum;
    }

    /**
     * 加载子包内容
     */
    public loadBundle(abName: string): Promise<AssetManager.Bundle> {
        let path = this.getBundlePath(abName);
        return new Promise<AssetManager.Bundle>((resolve, reject) => {
            assetManager.loadBundle(path, (err, bundle: AssetManager.Bundle) => {
                if (err) {
                    reject(null);
                    return;
                }
                this.bundles.set(abName, bundle);
                resolve(bundle);
            })
        })
    }

    /***
     * 在bundle里加载资源
     */
    private loadAssetsInBundle(lists: any): void {
        for (let i = 0; i < lists.length; i++) {
            var data = lists[i];
            var urlSet = data.paths;
            var typeClass = data.assetType;
            for (var j = 0; j < urlSet.length; ++j) {
                this.loadRes(this.bundles.get(data.enumBundle), urlSet[j], typeClass);
            }
        }
    }

    /**
     * 加载资源
     */
    private loadRes(abBundle: AssetManager.Bundle, url: any, typeClasss: any): void {
        abBundle.load(url, typeClasss, (error: any, asset: any) => {
            if (error) {
                Logger.info("load Res " + url + " error: " + error);
                this.loadRes(abBundle, url, typeClasss)
                return;
            }
            //
            this.now++;
            //
            if (this.progressFunc) {
                this.progressFunc(this.now, this.total);
            }
            //
            if (this.now >= this.total) {
                if (this.endFunc !== null) {
                    this.endFunc();
                }
            }
        });
    }

    /** */
    private getBundlePath(abName: string) {
        let bundleInfo = BundleConfig.bundles.get(abName);
        let remoteUrl = abName;
        if (!NATIVE || !JSB) {

        } else {
            if (bundleInfo && bundleInfo.is_sub_game) {
                remoteUrl = bundleInfo.remote_url || native.fileUtils.getWritablePath() + `game-remote-asset/${abName}/assets/${abName}`;
            }
        }
        // Logger.info("bundle url：", remoteUrl);
        return remoteUrl;
    }
}
