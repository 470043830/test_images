import { Message, Writer } from "protobufjs";
import Singleton from "../base/Singleton";
import { Logger } from "../utils/Logger";
import * as pb from "../../protobuf/pb.js";

/**
 * proto管理类
 */
export default class ProtoMgr extends Singleton {
    //
    pbToName: Map<Function, string> = new Map<Function, string>();

    // pbToName.set(1)
    static get Instance() {
        return super.GetInstance<ProtoMgr>();
    }

    /** */
    getPbByName(name: string) {
        if (pb[name]) {
            return pb[name];
        }
        return null;
    }

    /** */
    getPbTypeByName(name: string): any {
        let paths = name.split('.');
        let current = pb;
        for (let i = 0; i < paths.length; ++i) {
            if (current[paths[i]] == undefined) {
                return undefined;
            } else {
                current = current[paths[i]];
            }
        }
        return "current";
    }

    /** */
    encode(message: any): Uint8Array {
        let writer = message.constructor.encode(message) as Writer;
        return writer?.finish();
    }

    /** */
    decode<T extends Message>(name: string, arr: Uint8Array): T {
        try {
            let pbType = this.getPbTypeByName(name);
            return pbType.decode(arr);
        } catch (e) {
            Logger.warning(`pb decode error, name: ${name}, error: ${e}`);
        }
    }
}
