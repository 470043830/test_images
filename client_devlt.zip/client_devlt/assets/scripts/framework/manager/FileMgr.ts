/** 文件操作管理类 */
// import CryptoJS = require('./FileSaver');

import { sys } from "cc";
import { Logger } from "../utils/Logger";

/**
 *
 * 读取文件方式
 */
enum READ_FILE_TYPE {
    DATA_URL,// readAsDataURL, base64
    TEXT,// readAsText
    BINARY,// readAsBinaryString
    ARRAYBUFFER,// readAsArrayBuffer
}

/**
 * 文件管理器
 */
class FileMgr {
    //
    private static instance: FileMgr;
    //
    public static get Instance(): FileMgr {
        if (!FileMgr.instance) {
            FileMgr.instance = new FileMgr();
        }
        return FileMgr.instance;
    }

    // /**
    //  * 保存2
    //  * @param jsonDate 要保存的文件内容
    //  * @param fileName 要保存的文件名
    //  */
    // downloadFile(jsonDate: object, fileName: string) {
    //     var file = new File([JSON.stringify(jsonDate)], fileName, { type: "text/plain;" });  //type: "text/plain;charset=utf-8"
    //     CryptoJS.saveAs(file);
    // }
    /**
     * callback(data)  data读到的json文件
     * @param callback
     */
    readJsonFile(callback: Function) {
        // 打开文件选择器
        this.openLocalFile(".json", (file) => {
            // 读取数据
            this.readLocalFile(file, READ_FILE_TYPE.TEXT, (result) => {
                callback && callback(result);
            })
        });
    }

    /**
     * 打开文件选择器
     * @param accept
     * @param callback
     */
    openLocalFile(accept: string, callback: (file: File) => void) {
        let inputEl: HTMLInputElement = <HTMLInputElement>document.getElementById('file_input');
        if (!inputEl) {
            inputEl = document.createElement('input');
            inputEl.id = 'file_input';
            inputEl.setAttribute('id', 'file_input');
            inputEl.setAttribute('type', 'file');
            inputEl.setAttribute('class', 'fileToUpload');
            inputEl.style.opacity = '0';
            inputEl.style.position = 'absolute';
            inputEl.setAttribute('left', '-999px');
            document.body.appendChild(inputEl);
        }
        //
        accept = accept || ".*";
        inputEl.setAttribute('accept', accept);
        inputEl.onchange = (event) => {
            let files = inputEl.files
            if (files && files.length > 0) {
                var file = files[0];
                if (callback) callback(file);
            }
        }
        inputEl.click();
    }

    /**
     * 读取本地文件数据
     *
     * @param {File} file
     * @param {READ_FILE_TYPE} readType
     * @param {((result: string | ArrayBuffer) => void)} callback
     * @memberof FileMgr
     */
    readLocalFile(file: File, readType: READ_FILE_TYPE, callback: (result: string | ArrayBuffer) => void) {
        var reader = new FileReader();
        reader.onload = function (event) {
            if (callback) {
                if (reader.readyState == FileReader.DONE) {
                    callback(reader.result);
                } else {
                    callback(null);
                }
            }
        };
        switch (readType) {
            case READ_FILE_TYPE.DATA_URL:
                reader.readAsDataURL(file);
                break;
            case READ_FILE_TYPE.TEXT:
                reader.readAsText(file);   //作为字符串读出
                //reader.readAsText(file,'gb2312');   //默认是用utf-8格式输出的，想指定输出格式就再添加一个参数，像txt的ANSI格式只能用国标才能显示出来
                break;
            case READ_FILE_TYPE.BINARY:
                reader.readAsBinaryString(file);
                break;
            case READ_FILE_TYPE.ARRAYBUFFER:
                reader.readAsArrayBuffer(file);
                break;
        }
    }

    /**
     * 保存文件
     */
    saveFile(content, fileName) {
        Logger.info(`文件开始提交 isBrowser = ${sys.isBrowser} `);
        if (sys.isBrowser) {
            this.saveForBrowser(content, fileName);
        } else {
            Logger.warning("保存失败");
        }
    }

    /**
     * 保存数据到本地
     * 只有浏览器有效
     * @param {*} jsonDate 要保存的文件内容
     * @param {*} fileName 要保存的文件名
     * @memberof FileMgr
     */
    saveForBrowser(textToWrite, fileNameToSaveAs) {
        if (sys.isBrowser) {
            let textFileAsBlob = new Blob([textToWrite], { type: 'application/json' });
            let downloadLink = document.createElement("a");
            downloadLink.download = fileNameToSaveAs;
            downloadLink.innerHTML = "Download File";
            if (window.webkitURL != null) {
                // Chrome allows the link to be clicked
                // without actually adding it to the DOM.
                downloadLink.href = window.webkitURL.createObjectURL(textFileAsBlob);
            } else {
                // Firefox requires the link to be added to the DOM
                // before it can be clicked.
                downloadLink.href = window.URL.createObjectURL(textFileAsBlob);
                // downloadLink.onclick = destroyClickedElement;
                downloadLink.style.display = "none";
                document.body.appendChild(downloadLink);
            }
            downloadLink.click();
        }
    }
}

export default FileMgr;
