import { _decorator, Component, Node, v3 } from 'cc';
import { UIMgr } from './UIMgr';
import { EnumPrefab } from '../../config/BundleConfig';
import { ToastView } from '../../common/ToastView';

const { ccclass, property } = _decorator;

@ccclass('ToastMgr')
export class ToastMgr extends Component {
    //
    public static Instance: ToastMgr = null;
    // 每个消息项高度
    private itemHeight: number = 105;
    // 当前活跃的Toast项
    private activeToasts: Node[] = [];
    // 最大显示数量
    private maxItems: number = 3;
    //
    private ToastMgrUI: Node = null;

    /** */
    public async onRecvToast<T>(param_: T) {
        this.ToastMgrUI.active = true;
        if (this.activeToasts.length >= this.maxItems) this.onPop();
        var tview = await UIMgr.Instance.addPrefabNode(EnumPrefab.toast, { data: param_ }, this.ToastMgrUI);
        tview.addComponent(ToastView);
        this.activeToasts.unshift(tview);
        this.resultCoord();
    }

    /**
     * 删除最早的队列
     */
    public onPop() {
        let tview = this.activeToasts.pop();
        tview.getComponent(ToastView).onPut();
        if (this.activeToasts.length == 0) {
            this.ToastMgrUI.active = false;
        }
    }

    /**
     * 
    */
    protected async onLoad(): Promise<void> {
        if (ToastMgr.Instance === null) {
            ToastMgr.Instance = this;
        } else {
            this.destroy();
            return;
        }
        //
        this.ToastMgrUI = await UIMgr.Instance.addPrefabNode(EnumPrefab.ToastMgrUI, null, this.node);
        this.ToastMgrUI.setPosition(v3(0, 360))
        this.ToastMgrUI.active = false;
    }

    /**
     * 
    */
    private resultCoord() {
        for (let i = 0; i < this.activeToasts.length; i++) {
            let node = this.activeToasts[i];
            if (!node)
                continue;
            // node.getComponent(ToastView).updateOpacity(i);
            node.setPosition(v3(i * 3, this.itemHeight * i));
        }
    }
}

