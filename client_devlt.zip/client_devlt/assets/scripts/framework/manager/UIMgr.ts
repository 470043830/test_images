import { Component, instantiate, Node, Prefab, tween, v3, Vec3, view } from "cc";
import { BundleConfig, IBundleAsset } from "../../config/BundleConfig";
import { ResMgr } from "./ResMgr";
import { UIDefaultCtrl } from "../base/UIDefaultCtrl";
import { Logger } from "../utils/Logger";
import { GameApp } from "../../lobby/GameApp";

/**
 * 界面控制类
 */

export class UIMgr extends Component {
    //
    public static Instance: UIMgr = null;
    //
    private uiMap: Map<string, Node> = new Map<string, Node>();

    /**
     * 
    */
    static closeWindow(node: Node) {
        UIMgr.Instance.removeView(node);
    }

    /** 
     * 添加预制体到阶段 
     */
    public async addPrefabNode<T>(prefab_: string, param_?: T, parent_: Node = GameApp.Instance.getDialogLayer(), name_?: string) {
        return new Promise<Node>((resolve, reject) => {
            let bundleAsset: IBundleAsset = BundleConfig.getBundleAsset(prefab_);
            let name = name_ || bundleAsset.name;

            ResMgr.Instance.loadAsset<Prefab>(bundleAsset.ABName, Prefab, bundleAsset.path).then((res) => {
                let item = instantiate(res);
                parent_.addChild(item);
                item.addComponent(UIDefaultCtrl);
                item["viewParam"] = param_;
                item.name = name || prefab_;
                resolve(item);
            })
        })
    }

    /**
     * 显示视图
    */
    public async showView<T>(prefab_: string, param_?: T, parent_: Node = GameApp.Instance.getDialogLayer(), name_?: string, isAnim_: boolean = true) {
        return new Promise<Node>((resolve, reject) => {
            let bundleAsset: IBundleAsset = BundleConfig.getBundleAsset(prefab_);
            let name = name_ || bundleAsset.name;
            ResMgr.Instance.loadAsset<Prefab>(bundleAsset.ABName, Prefab, bundleAsset.path).then((res) => {
                let item = instantiate(res);
                parent_.addChild(item);
                if (isAnim_) {
                    this.fadeIn(item);
                }
                let uiCtrl = item.addComponent(UIDefaultCtrl);
                uiCtrl.viewParam = param_;
                item["viewParam"] = param_;
                item["isAnim"] = isAnim_;
                // 存在先移除之前的
                if (this.uiMap.has(name)) {
                    this.removeView(this.uiMap.get(name));
                }
                //
                this.uiMap.set(name, item);
                Logger.info("showView===>>>", prefab_, this.uiMap)
                item.name = name || prefab_;
                resolve(item);
            })
        })
    }

    /**
     * 移除视图
    */
    removeNameView(name: string) {
        if (this.uiMap.has(name)) {
            this.removeView(this.uiMap.get(name));
        }
    }

    /**
     * 移除视图
    */
    removeView(node_: Node) {
        let name = node_.name;
        if (this.uiMap.has(name)) {
            let tnode = this.uiMap.get(name);
            let isAnim = tnode["isAnim"];
            this.uiMap.delete(name);
            Logger.info("showView===>>>", this.uiMap)
            if (isAnim) {
                this.fadeOut(tnode, () => {
                    tnode.destroy();
                })
            } else {
                tnode.destroy();
            }
        }
    }

    /** 
     * 移入效果
    */
    public moveIn(node: Node) {
        let width: number = view.getDesignResolutionSize().x;
        node.setPosition(v3(width, 0, 0));
        tween(node.position).to(0.2, new Vec3(0, 0, 0), {
            easing: "quadOut",
            onUpdate: (target: Vec3, ratio: number) => {
                node.position = target;
            }
        }).start();
    }

    /**
     * 移出效果
     */
    public moveOut(node: Node, flag_: boolean = true) {
        let width: number = view.getDesignResolutionSize().x;
        tween(node.position).to(0.2, new Vec3(width, 0, 0), {
            easing: "quadOut",
            onUpdate: (target: Vec3, ratio: number) => {
                node.position = target;
            }
        }).call(() => {
            if (flag_)
                node.destroy();
        }).start();
    }

    /** 
     * 淡入效果
    */
    public fadeIn(node: Node, callback_: Function = null) {
        node.active = true;
        let contentNode = node.getChildByName("content") || node;
        contentNode.scale = v3(0.5, 0.5, 1);
        tween(contentNode)
            .to(0.1, { scale: v3(1, 1, 1) })
            .call(() => {
                if (callback_) {
                    callback_();
                }
            })
            .start();
    }

    /**
     * 淡出效果
     */
    public fadeOut(node: Node, callback_: Function = null) {
        let contentNode = node.getChildByName("content") || node;
        tween(contentNode)
            .to(0.1, { scale: v3(0.1, 0.1, 1) })
            .call(() => {
                if (callback_) {
                    callback_();
                }
            }).start();
    }

    /**
     * 加载操作
     * @returns 
     */
    protected onLoad(): void {
        if (UIMgr.Instance === null) {
            UIMgr.Instance = this;
        } else {
            this.destroy();
            return;
        }
        this.uiMap.clear();
    }

    /**
     * 显示弹窗
     */
    async showDialog(dialogNode: Node) {
        // dialogNode.active = true;
        // const dialogScale = dialogNode.scale;
        // dialogNode.scale = Vec3.ZERO;
        // const t = new tween(dialogNode);
        // t.to(0.3, { scale: dialogScale }, { easing: 'backOut' });
        // await t.start().wait();
    }

    /** 
     * 隐藏弹窗
     */
    async hideDialog(dialogNode: Node) {
        // const tween = new Tween(dialogNode);
        // tween.to(0.3, { scale: Vec3.ZERO }, { easing: 'backIn' });
        // await tween.start().wait();
        // dialogNode.active = false;
    }
}

