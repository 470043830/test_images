import { assetManager, ImageAsset, SpriteFrame, Texture2D } from 'cc';
import Singleton from '../base/Singleton';
import { GIF } from '../../3rd/GIF';

/** */
class GifData {
    type: string;
    url: string;
    gif?: GIF;
    img?: { img: SpriteFrame, texture: Texture2D };
}

//
export class GifMgr extends Singleton {
    //
    GifMap: Map<string, GifData> = new Map<string, GifData>();

    //
    static get Instance() {
        return super.GetInstance<GifMgr>();
    }

    //
    async load(url: string = '') {
        if (url == "") return null;
        let data = this.GifMap.get(url);
        if (data == null) {
            data = new GifData()
            let type = await this.loadImage(url);
            if (type == "unknown") return null;
            data.type = type;
            if (type == 'gif') {
                let gif = await this.loadGif(url);
                if (gif == null) {
                    data.type = 'png';
                    data.img = await this.setLoadRemote(url);

                } else {
                    data.gif = gif;
                }
            } else {
                data.img = await this.setLoadRemote(url);
            }
            //
            this.GifMap.set(url, data);
        }

        return data;
    }

    /**
     *  加载并检测图片类型（PNG/GIF/JPEG）
     *  @param url 图片地址
     *  @returns Promise<{ data: Uint8Array, type: 'png' | 'gif' | 'jpg' | 'unknown' }>
     */
    async loadImage(url: string): Promise<'png' | 'gif' | 'jpg' | 'unknown'> {
        return new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            xhr.responseType = 'arraybuffer';
            xhr.onreadystatechange = () => {
                if (xhr.readyState === 4) {
                    if (xhr.status >= 200 && xhr.status < 400) {
                        const buffer = new Uint8Array(xhr.response);
                        const type = this.detectImageType(buffer);
                        resolve(type);
                    } else {
                        reject(new Error(`加载失败: ${xhr.status}`));
                    }
                }
            };
            xhr.open('GET', url, true);
            xhr.setRequestHeader('Range', 'bytes=0-15'); // 只请求前16字节
            xhr.send();
        });
    }

    /** 加载远程图片 */
    protected async setLoadRemote(path: string): Promise<{ img: SpriteFrame, texture: Texture2D }> {
        return new Promise((resolve, reject) => {
            assetManager.loadRemote<ImageAsset>(path, { ext: '.png' }, function (err, imageAsset) {
                if (err) {
                    resolve(null);
                    return;
                }
                //
                try {
                    const spriteFrame = new SpriteFrame();
                    const texture = new Texture2D();
                    texture.image = imageAsset;

                    spriteFrame.texture = texture;
                    resolve({ img: spriteFrame, texture: texture });
                } catch (e) {
                    resolve(null);
                }
            });
        });
    }

    /** 加载gif */
    private loadGif<T>(url: string = ''): Promise<GIF> {
        return new Promise((resolve, reject) => {
            let xhr = new XMLHttpRequest();
            xhr.responseType = "arraybuffer";
            xhr.onreadystatechange = async () => {
                if (xhr.readyState == 4 && (xhr.status >= 200 && xhr.status < 400)) {
                    let result = new Uint8Array(xhr.response);
                    let gif = new GIF()
                    let isShow = await gif.handle(result);
                    if (isShow == true) {
                        resolve(gif);
                    } else {
                        resolve(null);
                    }
                }
            }
            //
            xhr.open("GET", url, true);
            xhr.setRequestHeader('Cache-Control', 'max-age=3600'); // 缓存1小时
            xhr.setRequestHeader('If-None-Match', ''); // 触发304校验
            xhr.send();
        });
    }

    /**
     * 检测图片类型（通过文件头）
     */
    private detectImageType(buffer: Uint8Array): 'png' | 'gif' | 'jpg' | 'unknown' {
        if (buffer.length < 4) {
            return 'unknown';
        }
        // PNG: 前8字节固定签名
        const pngSignature = [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A];
        if (buffer.length >= 8 && pngSignature.every((byte, i) => buffer[i] === byte)) {
            return 'png';
        }
        // GIF: 前3字节是 'GIF'
        if (buffer[0] === 0x47 && buffer[1] === 0x49 && buffer[2] === 0x46) {
            return 'gif';
        }
        // JPEG/JPG: 前2字节是 0xFF 0xD8，后2字节是 0xFF 0xD9
        if (buffer[0] === 0xFF && buffer[1] === 0xD8) {
            // 可选：检查结尾是否为 0xFF 0xD9（确保完整JPEG）
            if (buffer.length >= 4 && buffer[buffer.length - 2] === 0xFF && buffer[buffer.length - 1] === 0xD9) {
                return 'jpg';
            }
            return 'jpg'; // 即使不检查结尾也认为是JPEG
        }
        //
        return 'unknown';
    }
}

