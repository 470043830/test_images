import { SpriteFrame } from "cc";
import Singleton from "../base/Singleton";

/**
 * 远程资源管理
 */

export interface ResRmoteInfo {
    remoteUrl: string;          //远程资源url
    cleanTime: number;          //存续时间
    res: SpriteFrame;           
}

export class RemoteResMgr extends Singleton {

    static get Instance() {
        return super.GetInstance<RemoteResMgr>();
    }



}