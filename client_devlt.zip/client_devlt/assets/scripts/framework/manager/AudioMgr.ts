import { AudioClip, AudioSource, Component } from 'cc';
import { ResMgr } from './ResMgr';
import { EnumBundle } from '../../config/BundleConfig';
import { Logger } from '../utils/Logger';

/** */
export enum Sounds {
    // BGM = 0,
    // CLICKBTN = 1,
    CFMUSIC = 0,
}

/** */
export let SoundName: any[] = [
    // "bgm",
    // "clickBtn",
    // "cf_music",
]

/**
 * 声音管理类
 */
export class AudioClipMode {
    soudName: string = "undefind"  //声音名字
    soundPath: string = "undefind" //子游戏 声音路劲
}

/** */
export class AudioMgr extends Component {
    //
    public static Instance: AudioMgr = null as unknown as AudioMgr;
    // 最大音效的数目
    private static MAX_SOUNDS: number = 6;
    //
    private nowIndex: number = 0;
    //
    private sounds: Array<AudioSource> = [];
    //
    private bgMusic: AudioSource = null as unknown as AudioSource;
    //
    private isMusicVolume: number = 0;
    //
    private isSoundVolume: number = 0;
    //
    private soundMap: AudioClip[] = [];
    /** 存放各个子包的音效 */
    private soundsMap: Map<string, { [key: string]: AudioClip }> = new Map<string, { [key: string]: AudioClip }>;
    //
    private subGamesoundMap: Map<string, AudioClip> = new Map<string, AudioClip>();
    //
    private soundInfoList: AudioClipMode[] = []
    //
    private _isMusicMute: boolean = false;

    //
    public get isMusicMute(): boolean {
        return this._isMusicMute;
    }

    //
    public set isMusicMute(isMusicMute: boolean) {
        this._isMusicMute = isMusicMute;
    }

    private _isSoundMute: boolean = false;

    //
    public get isSoundMute(): boolean {
        return this._isSoundMute;
    }

    //
    public set isSoundMute(isSoundMute: boolean) {
        this._isSoundMute = isSoundMute;
    }

    private _isVibrate: boolean = false;

    //
    public get isVibrate(): boolean {
        return this._isVibrate;
    }

    //
    public set isVibrate(isVibrate: boolean) {
        this._isVibrate = isVibrate;
    }

    //
    onLoad(): void {
        if (AudioMgr.Instance === null) {
            AudioMgr.Instance = this;
        } else {
            this.destroy();
            return;
        }
        //
        for (let i = 0; i < AudioMgr.MAX_SOUNDS; i++) {
            var as = this.node.addComponent(AudioSource);
            this.sounds.push(as);
        }
        //
        this.bgMusic = this.node.addComponent(AudioSource) as AudioSource;
        // 从本地存储里面把设置读出来, 0, 1
        var value = localStorage.getItem("GAME_MUSIC_MUTE");
        if (value) {
            let v = parseInt(value);
            this.isMusicMute = (v === 1) ? true : false;
        }

        value = localStorage.getItem("GAME_SOUND_MUTE");
        if (value) {
            let v = parseInt(value);
            this.isSoundMute = (v === 1) ? true : false;
        }
        value = localStorage.getItem("GAME_VIBRATE_MUTE");
        if (value) {
            let v = parseInt(value);
            this.isVibrate = (v === 1) ? true : false;
        }
    }

    /** */
    public getSoundClip(index: Sounds) {
        return this.soundMap[index];
    }

    /** */
    public async loadSoundClips(bundle?: string): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            bundle = bundle || EnumBundle.resources;
            ResMgr.Instance.loadDir<AudioClip>(bundle, AudioClip, "sounds").then((res) => {
                Logger.info("加载音效==>>>", res);
                let sounds: { [key: string]: AudioClip } = {};
                res.forEach(e => {
                    sounds[e.name] = e;
                })

                this.soundsMap.set(bundle, sounds);
                resolve(true);
            }).catch(() => {
                Logger.info("音效加载失败==>>>");
                reject(false);
            })
        })
    }

    /** */
    public releaseSoundClip(bundle: string, name: string) {
        let sounds = this.soundsMap.get(bundle);
        Logger.info(" sounds == ", sounds);
        let soundClip = sounds[name];
        if (soundClip) {
            Logger.info("release sound clip=", name);
            ResMgr.Instance.getBundle(bundle).release(`sounds/${name}`, AudioClip);
            delete sounds[name];
            Logger.info("delete sounds", sounds);
        }
    }

    /** */
    public releaseBundleSoundClips(bundle: string) {
        let sounds = this.soundsMap.get(bundle);
        if (sounds) {
            for (var key in sounds) {
                this.releaseSoundClip(bundle, key);
            }
        }
        this.soundsMap.delete(bundle);
    }

    /** */
    public playBgMusic(bundle: string, audioName: string): void {
        let clip = this.soundsMap.get(bundle)[audioName];
        this.bgMusic.clip = clip;
        this.bgMusic.loop = true;
        this.bgMusic.volume = (this.isMusicMute) ? 0 : 1.0;
        this.bgMusic.play();
    }

    /** */
    public stopBgMusic(): void {
        this.bgMusic.stop();
    }

    /** */
    public recoverBgMusic(): void {
        this.bgMusic.pause()
        this.bgMusic.play();
    }

    /** 播放应音效 */
    public playSound(bundle: string, audioName: string, isLoop: boolean = false) {
        if (!bundle || this.isSoundMute === true) {
            return;
        }
        var as = this.sounds[this.nowIndex];
        this.nowIndex = this.nowIndex == AudioMgr.MAX_SOUNDS - 1 ? 0 : this.nowIndex + 1;
        let clip = this.soundsMap.get(bundle)[audioName];
        as.clip = clip;
        as.loop = isLoop;
        as.play();
    }

    /**
     * 停止播放所有的sound
     */
    public stopAllSound() {
        for (let i = 0; i < this.sounds.length; i++) {
            this.sounds[i].stop()
            this.sounds[i].clip = null
        }
        this.nowIndex = 0
    }

    /**
     * 播放一次性音效
     */
    public playSoundOneShot(bundle: string, audioName: string): void {
        var as = this.sounds[this.nowIndex];
        this.nowIndex++;
        if (this.nowIndex >= AudioMgr.MAX_SOUNDS) {
            this.nowIndex = 0;
        }
        let clip = this.soundsMap.get(bundle)[audioName];
        as.clip = clip;
        as.loop = false;
        as.playOneShot(clip);
    }

    /** */
    public setMusicMute(isMute: boolean): void {
        this.isMusicMute = isMute;
        this.bgMusic.volume = (this.isMusicMute) ? 0 : 1.0;

        // localStorage
        let value = (isMute) ? 1 : 0;
        localStorage.setItem("GAME_MUSIC_MUTE", value.toString());
        // end
    }

    /** */
    public setMusicVolume(volume: number): void {
        this.isMusicVolume = volume;
        this.setMusicMute(volume == 0 ? false : true)
        this.bgMusic.volume = volume;
    }

    /** */
    public setSoundsMute(isMute: boolean): void {
        if (isMute == this.isSoundMute) {
            return
        }
        this.isSoundMute = isMute;
        for (let i = 0; i < this.sounds.length; i++) {
            this.sounds[i].volume = isMute ? this.sounds[i].volume : 0
        }
        // localStorage
        let value = (isMute) ? 1 : 0;
        localStorage.setItem("GAME_SOUND_MUTE", value.toString());
    }

    /** */
    public setSoundsVolume(volume: number): void {
        this.isSoundVolume = volume;
        this.setSoundsMute(volume == 0 ? false : true)
        for (let i = 0; i < this.sounds.length; i++) {
            this.sounds[i].volume = volume;
        }
    }
}
