import * as cc from 'cc';
const { ccclass, property } = cc._decorator;

@ccclass('SceneManager')
export class SceneManager {
    lastSceneName = '';
    curSceneName = '';
    private static _instance: SceneManager;
    public static get instance(): SceneManager {
        if (this._instance == null) {
            this._instance = new SceneManager();
            this._instance.init();
        }
        return this._instance;
    }

    init() {

    }

    loadScene(name: string, cb?) {
          
    }

    enterScene(name: string, cb?) {
        if (this.curSceneName == name) return;

        console.log("场景名字", name);
        this.lastSceneName = this.curSceneName;
        this.curSceneName = name;
        cc.director.loadScene(name, function () {
            cb && cb();
        });
    }

    isScene(sceneName: string) {
        return cc.director.getScene().name == sceneName;
    }

    getCurSceneName() {
        let sceneName = this.curSceneName != '' ? this.curSceneName : cc.director.getScene().name;
        return sceneName;
    }

    getLastSceneName() {
        return this.lastSceneName;
    }
}

SceneManager.instance;
