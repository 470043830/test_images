import { Component } from "cc";

type scheduleCallback = (data: any) => void;

class TimerNode {
    public callback: scheduleCallback = null;
    public duration: number = 0;
    public delay: number = 0;
    public repeat: number = 0;
    public passedTime: number = 0;
    public param: any = null;
    public isRemove: boolean = null;
    public timerId: number = 0;
}

/**
 * 类中的Schedule函数首字母是大写，不是小写，和系统自带的schedule函数进行区分
 * 不受节点销毁而影响定时器
 */
export class TimerMgr extends Component {
    //
    public static Instance: TimerMgr = null as unknown as TimerMgr;
    //
    private autoIncId: number = 1;
    //
    private timers: any = {};
    //
    private removeTimers: TimerNode[] = [];
    //
    private newAddTimers: TimerNode[] = [];
    /** 计时器管理 */
    private _timeoutIdTab: Map<number, number[]> = new Map();

    //
    public Schedule(func: scheduleCallback, duration: number = 0, param: any = null, repeat: number = 0, delay: number = 0): number {
        const timer: TimerNode = new TimerNode();
        timer.callback = func;
        timer.param = param;
        timer.repeat = repeat;
        timer.duration = duration;
        timer.delay = delay;
        timer.passedTime = duration;
        timer.isRemove = false;
        timer.timerId = this.autoIncId;
        this.autoIncId++;
        this.newAddTimers.push(timer);
        return timer.timerId;
    }

    /** */
    public ScheduleOnce(func: scheduleCallback, delay: number = 0, param: any = null): number {
        const repeat: number = 1;
        const duration: number = 1;
        return this.Schedule(func, duration, param, repeat, delay);
    }

    /** */
    public ScheduleWithoutParameter(func: scheduleCallback, duration: number, repeat: number, delay: number): number {
        const _func: scheduleCallback = func;
        const param: any = null;
        const _repeat: number = repeat;
        const _duration: number = duration;
        const _delay: number = delay;
        return this.Schedule(_func, _duration, param, _repeat, _delay);
    }

    /** */
    public ScheduleOnceWithoutParameter(func: scheduleCallback, delay: number): number {
        const _func: scheduleCallback = func;
        const repeat: number = 1;
        const duration: number = 0;
        const _delay: number = delay;
        return this.ScheduleWithoutParameter(_func, duration, repeat, _delay);
    }

    /** */
    public Unschedule(timerId: number): void {
        if (!this.timers[timerId]) {
            return;
        }
        const timer: TimerNode = this.timers[timerId];
        timer.isRemove = true;
    }

    /**
     * 延迟执行
     * */
    public async delayTime(time: number = 0, cmptID = 0) {
        if (!this._timeoutIdTab.has(cmptID)) {
            this._timeoutIdTab.set(cmptID, []);
        }
        let idArr = this._timeoutIdTab.get(cmptID);
        let timeoutId;
        await new Promise(r => {
            timeoutId = setTimeout(r, time * 1000);
            idArr.push(timeoutId);
        })
        // 清除计时器
        let idx = idArr.indexOf(timeoutId)
        ~idx && idArr.splice(idx, 1)
    }

    /** 加载回调 */
    protected onLoad(): void {
        if (TimerMgr.Instance === null) {
            TimerMgr.Instance = this;
        } else {
            this.destroy();
            return;
        }
    }

    /** 更新回调 */
    protected update(dt: number): void {
        for (const obj of this.newAddTimers) {
            this.timers[obj.timerId] = obj;
        }
        //
        this.newAddTimers.length = 0;
        //
        for (const key in this.timers) {
            if (this.timers[key]) {
                // 遍历表用for in 的时候一定要加这个
                const timer: any = this.timers[key];
                if (timer.isRemove) {
                    this.removeTimers.push(timer);
                    continue;
                }
                timer.passedTime += dt;
                if (timer.passedTime >= (timer.delay + timer.duration)) {
                    timer.callback(timer.param);
                    timer.repeat--;
                    timer.passedTime -= (timer.delay + timer.duration);
                    timer.delay = 0;

                    if (timer.repeat === 0) {
                        timer.isRemove = true;
                        this.removeTimers.push(timer);
                    }
                }
            }
        }
        //
        for (const obj of this.removeTimers) {
            delete this.timers[obj.timerId];
        }
        //
        this.removeTimers.length = 0;
    }
}
