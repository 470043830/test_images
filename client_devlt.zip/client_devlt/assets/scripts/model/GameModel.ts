import Singleton from "../framework/base/Singleton";
import { Utils } from "../framework/utils/Utils";
import { LobbyProto } from "../protobuf/pb";
import { Logger } from "../framework/utils/Logger";



/**
 * 游戏图标样式
 */
export enum GameIconStyle {
    LARGE = 1,
    MIDDLE,
    SMALL,
}

//游戏图标点击后的行为
export enum GameIconBehavor {
    NONE,
    ENTER_RECOMMEND_PAGE,                                       //进入二级推荐页面
    ENTER_GAME,                                                 //进入游戏
}

//游戏标签
export enum GameTag {
    NONE,
    HOT,
    NEW,
}

/**
 * 游戏图标属性
 */
export class GameIconProperty {
    supplierID: number;                                         //游戏/厂商ID
    gameFilter: number;                                         //筛选类型
    spriteUrl: string;                                          //图标url
    style: GameIconStyle;                                       //图标样式
    clickBehavor: GameIconBehavor;                              //点击事件类型
    sort: number;                                               //排序
    jumpValue: string;                                          //跳转值-分类ID/游戏ID
    tag: GameTag;                                               //游戏标签 0-无 1-HOT 2-NEW
    supplierName: string;                                       //厂商名称
    isRecommend: number;                                        //是否推荐 1-推荐 
}

/**
 * 游戏分类
 */
export interface GameStyles {
    filter: number;                                             //筛选类型
    sort: number;                                               //排序
    valid: number;                                              //是否有效
    spriteUrlN: string;                                         //正常状态的图片url
    spriteUrlS: string;                                         //选中状态的图片url
    name: string;                                               //名字
    isRecommend: number;                                        //是否推荐
    showRow: number;                                            //显示行数
}


/**
 * 二级/三级页面图标展示样式
 */
export interface GameSubPagetyles {
    name: string;                                               //厂商名称
    rowCount: number;                                           //二级页面显示行数
    maxCount: number;                                           //二级页面最多显示图标的数量
    gameIcons: GameIconProperty[];                              //游戏图标列表
}



/**
 * 游戏数据
 */
export default class GameModel extends Singleton {
    static get Instance() {
        return super.GetInstance<GameModel>();
    }

    //一级页面游戏大类型
    private _homeGameStyles: GameStyles[] = [];

    //二级页面大类型
    private _recommendGameStyles: GameStyles[] = [];

    //一级页面数据<类型，游戏图标属性>
    private _homePageGames: Map<number, GameIconProperty[]> = new Map();

    //二级页面数据<厂商，推荐游戏>
    private _recommendGames: Map<number, GameIconProperty[]> = new Map();

    //三级页面数据，指定厂商的所有数据
    private _allGames: GameIconProperty[] = [];

    parseGameTypes(v: LobbyProto.HallGameTypeInfo[]) {
        let ret: GameStyles[] = [];
        v.forEach((e, idx) => {
            //测试缺少
            // if (e.sName == `GAMES`) {
            //     return;
            // }
            ret.push({
                filter: Utils.longToNumber(e.lId),
                sort: e.iSort,
                valid: 1,
                spriteUrlN: e.sImgUrl,
                spriteUrlS: e.sChoseImgUrl,
                name: e.sName,
                isRecommend: e.iIsRecommend,
                showRow: e.iShowLine,
            });
        })

        ret.sort((a, b) => {
            return b.sort - a.sort;
        });

        return ret;
    }

    parseHomeGameStyles(v: LobbyProto.HallGameTypeInfo[]) {
        this._homeGameStyles = this.parseGameTypes(v);
    }

    parseRecommendGameStyles(v: LobbyProto.HallGameTypeInfo[]) {
        this._recommendGameStyles = this.parseGameTypes(v);
    }

    get homeGameStyles(): GameStyles[] {
        return this._homeGameStyles;
    }

    get recommendGameStyles(): GameStyles[] {
        return this._recommendGameStyles;
    }

    /**
     * 解析大厅一级游戏数据
     * @param v 
     */
    parseHomePageGames(v: LobbyProto.HallGameOneInfo[]) {
        this._homePageGames.clear();

        //根据this._gameStyles已经排好的顺序，遍历取得其对应的游戏
        this._homeGameStyles.forEach((style) => {
            v.forEach(e => {
                if (e.lParentId == style.filter) {
                    if (!this._homePageGames.has(style.filter)) {
                        this._homePageGames.set(style.filter, []);
                    }
                    let arr = this._homePageGames.get(style.filter);
                    arr.push({
                        supplierID: Utils.longToNumber(e.lId),
                        gameFilter: Utils.longToNumber(e.lParentId),
                        spriteUrl: e.sIconUrl,
                        style: e.iShowLine,
                        clickBehavor: e.iJumpCategory,
                        sort: e.iSort,
                        jumpValue: e.sJumpValue,
                        tag: e.iContentStyle,
                        supplierName: e.sName,
                        isRecommend: e.iIsRecommend,
                    });
                }
            });
        })

        //内部排序
        this._homePageGames.forEach((arr, k) => {
            arr.sort((a, b) => {
                return b.sort - a.sort;
            })
        })

        //再确定大类是否存在相应的游戏
        // this._homeGameStyles.forEach(e => {
        //     e.valid = this._homePageGames.get(e.filter) ? 1 : 0;
        // })

        Logger.debug(`一级游戏数据(排序后)`, this._homePageGames);
    }

    /**
     * 解析二级各个厂商推荐的数据
     * @param v 
     */
    parseRecommendGames(v: LobbyProto.HallGameTwoInfo[]) {
        this._recommendGames.clear();
        v.forEach(e => {
            let gameFilter = Utils.longToNumber(e.lParentId);
            if (!this._recommendGames.has(gameFilter)) {
                this._recommendGames.set(gameFilter, []);
            }
            let arr = this._recommendGames.get(gameFilter);
            arr.push({
                supplierID: Utils.longToNumber(e.lId),
                gameFilter: gameFilter,
                spriteUrl: e.sIconUrl,
                style: GameIconStyle.SMALL,
                clickBehavor: GameIconBehavor.ENTER_GAME,
                sort: e.iSort,
                jumpValue: e.sGameId,
                tag: e.iContentStyle,
                supplierName: e.sName,
                isRecommend: e.RecommendType,
            });
        })

        //内部排序
        this._recommendGames.forEach((arr, k) => {
            arr.sort((a, b) => {
                return b.sort - a.sort;
            })
        })
    }

    /**
     * 解析三级指定厂商的所有数据
     * @param v 
     */
    parseSupplierAllGames(v: LobbyProto.HallGameThreeInfo[]) {
        this._allGames = [];
        v.forEach(e => {
            this._allGames.push({
                supplierID: Utils.longToNumber(e.lId),
                gameFilter: Utils.longToNumber(e.lParentId),
                spriteUrl: e.sIconUrl,
                style: GameIconStyle.SMALL,
                clickBehavor: GameIconBehavor.ENTER_GAME,
                sort: e.iSort,
                jumpValue: e.sGameId,
                tag: e.iContentStyle,
                supplierName: e.sName,
                isRecommend: 0,
            });
        })

        //排序
        this._allGames.sort((a, b) => {
            return b.sort - a.sort;
        })
    }

    get homePageGames() {
        return this._homePageGames;
    }

    get recommendGames() {
        return this._recommendGames;
    }

    get allGames() {
        return this._allGames;
    }

    /**
     * 取得二级页面所有厂商
     */
    getRecommendSuppliers(): number[] {
        let ret = [];
        this._recommendGameStyles.forEach((e, k) => {
            ret.push(e.filter);
        });
        return ret;
    }

    /**
     * 取得二级显示页面显示行数
     */
    getRecommendGameShowRow(gameFilter: number) {
        let ret = this._recommendGameStyles.find(e => e.filter == gameFilter);
        if (ret) {
            return ret.showRow || 1;
        }

        return 1;
    }

}