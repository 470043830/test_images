import Singleton from "../framework/base/Singleton";
// address: "0x1520eddbfba437c66b892e883d86015b37f67124"  createTime: "20250702155136"  enable: 1  hasPayPwd: 1  hasThreeCert: 1  huifuStatus: "ENABLE"  id: 393286  imgUrl: "https://oss.cdnyu.cn/prod/icon/default_head.png"  inviteCode: "48xhibh"  inviteUserCode: "23qupbt"  inviteUserId: 393284  inviteUserName: "9055_393284"  name: "M-BOX6393"  reviewer: false  sex: "boy"  thirdWallet: true  userPhone: "15680615712"  vipLevel: 0  yiBaoMerStatus: "ENABLE"  ￼yiBaoStatus: "ENABLE"
// 游戏状态 NORMAL-正常 MATCH-匹配中 FIGHT-战斗中 SETTLE-结算中
export enum GameStatus {
    /** 正常 */
    NORMAL = "NORMAL",
    /** 暂停 */
    PAUSE = "PAUSE",
    /** 匹配中 */
    MATCH = "MATCH",
    /** 战斗中 */
    FIGHT = "FIGHT",
    /** 结算中 */
    SETTLE = "SETTLE"
}

export default class AccountModel extends Singleton {
    /** */
    balance: number = 0;
    symbol: string = "$";

    private _host: string = "";

    private _customDeviceID: string = "";

    /** 用户id */
    private _userId: string;

    /** 用户token */
    private _token: string = "1C3A8A2F3DC943C0BC812843EE71A879";

    //用户名称 
    private _username: string = "M-BOX6393";

    //头像
    private _avatar: string = "";

    //头像ID
    private _avatarId: number = 0;

    //性别
    private _gender: number = 0;

    //vip等级
    private _vipLevel: number = 0;

    //vip经验
    private _vipExp: number = 0;

    //vip流水
    private _vipWager: number = 0;

    //现金
    private _cash: number = 0;

    //彩金
    private _bonus: number = 0;

    //钻石
    private _diamond: number = 0;

    //绑定的手机号码
    private _bindPhoneNum: string = "";

    //登录密码
    private _passWord: string = "";

    //分享码
    private _shareCode: string = "QQQQQQQQ";

    //邀请码
    private _inviteCode: string = "";

    static get Instance() {
        return super.GetInstance<AccountModel>();
    }

    set host(v: string) {
        this._host = v;
    }

    get host(): string {
        return this._host;
    }

    set userId(v: string) {
        this._userId = v;
    }

    get userId(): string {
        return this._userId;
    }

    set token(v: string) {
        this._token = v;
    }

    get token(): string {
        return this._token;
    }

    set userName(v: string) {
        this._username = v;
    }

    get userName() {
        return this._username;
    }

    set avater(v: string) {
        this._avatar = v;
    }

    get avater() {
        return this._avatar;
    }

    set avatarId(v: number) {
        this._avatarId = v;
    }

    get avatarId(): number {
        return this._avatarId;
    }

    set gender(v: number) {
        this._gender = v;
    }

    get gender(): number {
        return this._gender;
    }

    set vipLevel(v: number) {
        this._vipLevel = v;
    }

    get vipLevel(): number {
        return this._vipLevel;
    }

    set vipExp(v: number) {
        this._vipExp = v;
    }

    get vipExp(): number {
        return this._vipExp;
    }

    set cash(v: number) {
        this._cash = v;
    }

    get cash(): number {
        return this._cash;
    }

    set bonus(v: number) {
        this._bonus = v;
    }

    get bonus(): number {
        return this._bonus;
    }

    set diamond(v: number) {
        this._diamond = v;
    }

    get diamond(): number {
        return this._diamond;
    }

    set bindPhoneNum(v: string) {
        this._bindPhoneNum = v;
    }

    get bindPhoneNum(): string {
        return this._bindPhoneNum;
    }

    set passWord(v: string) {
        this._passWord = v;
    }

    get passWord(): string {
        return this._passWord;
    }

    set shareCode(v: string) {
        this._shareCode = v;
    }

    get shareCode(): string {
        return this._shareCode;
    }

    set inviteCode(v: string) {
        this._inviteCode = v;
    }

    get inviteCode(): string {
        return this._inviteCode;
    }

    set vipWager(v: number) {
        this._vipWager = v;
    }

    get vipWager(): number {
        return this._vipWager;
    }

    set customDeviceID(v: string) {
        this._customDeviceID = v;
    }

    get customDeviceID(): string {
        return this._customDeviceID;
    }

}

