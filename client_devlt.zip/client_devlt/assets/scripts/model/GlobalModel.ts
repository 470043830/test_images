import { EnumBundle, ISceneParam } from "../config/BundleConfig";
import Singleton from "../framework/base/Singleton";

/**
 * 游戏模式
 */
export enum GNET_MODEL {
    /** 单机 */
    STANDALONE,
    /** 联网 */
    NETWORKING
}

/**
 * 游戏全局信息
 */
export default class GlobalModel extends Singleton {
    /** 当前子游戏数据 */
    curScene: ISceneParam;
    //
    bundle: EnumBundle = EnumBundle.ridCrush;

    //服务器时间戳(毫秒)
    serverTimeStamp: number = Date.now();

    //版本
    version: string = "1.0.0";

    //是否为点击出发的滚动
    homeGamesScrollByClick: boolean = false;

    //是否已经打开了子游戏
    isSubGameOpened: boolean = false;

    static get Instance() {
        return super.GetInstance<GlobalModel>();
    }
}
