import * as cc from "cc";
import Singleton from "../framework/base/Singleton";
import { LobbyProto } from "../protobuf/pb";
import { isSameDay } from "../framework/lib/GlobalFunc";
import GlobalModel from "./GlobalModel";


/**
 * 各等级配置基本信息
 */
export interface ClubConfigInfo {
    level: number;              //等级
    maxMember: number;          //最大成员数量
    maxBet: number;             //最大下注数量
    betRebate: number;          //下注返利比率
    depositRebate: number;      //充值返利比率
    inviteRewards: number;      //邀请奖励
}

/**
 * 代理层级配置
 */
export class ClubTeamConfig {
    name: string;               //名称
    showName: string;           //名称
}

/**
 * 俱乐部成员属性
 */
export class MemberInfo {
    uid: string;                //用户ID
    avatorID: string;           //头像ID
    name: string;               //用户名称
    phoneNum: string;           //用户绑定手机号
    deposit: number;            //用户充值数量
    commission: number;         //佣金数量
    joinTime: number;           //加入时间
    isNew: boolean;             //是否为新成员
}

//我的俱乐部信息
export class MyClubBaseInfo {
    level: number;              //等级
    memberCount: number;        //成员数量
    bets: number;               //下注总数

    withdrawable: number;       //可提现数量
    rewardToday: number;        //今日奖励
    rewardTotal: number;        //总奖励
}

//我的俱乐部队伍信息
export class MyClubTeamInfo {
    level: number;              //等级
    joinToday: number;          //今日加入数量
    joinYesterday: number;      //昨日加入数量
    joinMonth: number;          //本月加入数量
    membersAmount: { [k: string]: number };    //成员数量
    members: MemberInfo[];      //成员列表     
}

//邀请数量配置
export interface InviteAmountInfo {
    needInvite: number;         //需要邀请数量
    rewards: number;            //达到该阶段时的奖励
}

//邀请数据
export class InviteInfo {
    inviteNewerRewards: number; //邀请一个新用户奖励
    inviteEachRewards: number;  //每次邀请奖励
    MaxNeedInvite: number;      //最多可邀请的人数
    MaxReward: number;          //达到最多可邀请的人数时的奖励
    curInviteAmount: number;    //当前邀请数量
    validInviteAmount: number;  //有效邀请数量
    curInviteRewards: number;   //当前邀请数量对应的奖励
    inviteLimitDaily: number;   //每日邀请上限
    inviteToday: number;        //今日邀请数量

    cfg: InviteAmountInfo[];
}

//俱乐部规则结构
export interface ClubRuleInfo {
    buttonDesc: string;         //按钮描述
    buttonEvent: number;        //按钮点击事件
    imgUrl: string;             //图片地址
    richText: string;           //富文本
}

export interface SharePageInfo {
    pageUrl: string;            //轮播页url
    state: number;              //状态
}

//分享数据
export class SharedInfo {
    reawrd: number;             //分享可得奖励
    pages: SharePageInfo[];
}

export enum ClubHistoryType {
    REWARD_RECORD = 0,          //奖励记录
    WITHDRAW_RECORD = 1,        //提现记录
}

//记录过滤类型
export enum RecordFilterType {
    ALL = 0,
    Bets = 1,
    Deposit = 2,
    Invite = 3,
    InviteTask = 4,
}

//奖励历史记录
export class RewardHistoryInfo {
    recordFilerType: RecordFilterType;      //类型
    time: number;                           //时间
    commission: number;                     //佣金数量
    status: number;                         //状态 0:成功 1:待处理 2:超时
}


/**
 * 俱乐部数据模块
 */
export default class ClubModel extends Singleton {
    static get Instance() {
        return super.GetInstance<ClubModel>();
    }

    //俱乐部配置
    private _clubConfig: ClubConfigInfo[] = [];

    //代理层级配置
    private _clubTeamConfig: ClubTeamConfig[] = [];

    //我的俱乐部基本信息
    private _myClubBaseInfo: MyClubBaseInfo = null;

    //我的俱乐部团队信息
    private _myClubTeamInfo: MyClubTeamInfo = null;

    //邀请数据
    private _inviteInfo: InviteInfo = null;

    //历史记录
    private _historyRecords: Map<ClubHistoryType, RewardHistoryInfo[]> = new Map();

    //分享数据
    private _shareInfo: SharedInfo = null;

    test() {
        this._clubConfig = [];
        for (let index = 0; index < 4; index++) {
            this._clubConfig.push({
                level: index,
                maxMember: index + 1000,
                maxBet: index + 20000,
                betRebate: index + 10,
                depositRebate: index + 20,
                inviteRewards: index + 30,
            })
        }

        //我的俱乐部基本信息
        this._myClubBaseInfo = new MyClubBaseInfo();
        this._myClubBaseInfo.level = 1;
        this._myClubBaseInfo.bets = 111;
        this._myClubBaseInfo.memberCount = 30;

        this._myClubBaseInfo.withdrawable = 555;
        this._myClubBaseInfo.rewardToday = 12;
        this._myClubBaseInfo.rewardTotal = 666;

        //代理层级信息
        this._clubTeamConfig = [];
        for (let index = 0; index < 6; index++) {
            let item = new ClubTeamConfig();
            item.name = `id${index}`;
            item.showName = `Team${index}`;

            this._clubTeamConfig.push(item);
        }

        //我的俱乐部团队信息
        this._myClubTeamInfo = new MyClubTeamInfo();
        this._myClubTeamInfo.level = 2
        this._myClubTeamInfo.joinToday = 3;
        this._myClubTeamInfo.joinYesterday = 4;
        this._myClubTeamInfo.joinMonth = 5;
        this._myClubTeamInfo.membersAmount = {};
        for (let index = 0; index < this._clubTeamConfig.length; index++) {
            this._myClubTeamInfo.members = [];
            let n = cc.randomRangeInt(2, 30);
            for (let j = 0; j < n; j++) {
                let member = new MemberInfo();
                member.uid = `1223${index * n + j}`;
                member.avatorID = "";
                member.name = `UsrName${index * n + j}`
                member.phoneNum = `189000${index * n + j}`
                member.deposit = cc.randomRangeInt(0, 1000);
                member.commission = cc.randomRangeInt(0, 10000);
                member.joinTime = Date.now() - index * 3000000000 - j * 50000000;
                member.isNew = cc.randomRangeInt(0, 2) ? true : false;

                this._myClubTeamInfo.members.push(member);
                this._myClubTeamInfo.membersAmount[index] = this._myClubTeamInfo.members.length;
            }
        }

        //邀请数据
        this._inviteInfo = new InviteInfo();
        this._inviteInfo.MaxNeedInvite = 266;
        this._inviteInfo.MaxReward = 5555;
        this._inviteInfo.curInviteAmount = 200;
        this._inviteInfo.validInviteAmount = 11;
        this._inviteInfo.curInviteRewards = 300;
        this._inviteInfo.inviteEachRewards = 66;
        this._inviteInfo.inviteNewerRewards = 88;
        this._inviteInfo.inviteLimitDaily = 12;
        this._inviteInfo.inviteToday = 2;

        this._inviteInfo.cfg = [];
        for (let index = 0; index < 5; index++) {
            this._inviteInfo.cfg.push({
                needInvite: index * 10,
                rewards: index * 200,
            });
        }

        //历史记录
        this._historyRecords.clear();
        let rewardRecords: RewardHistoryInfo[] = [];
        for (let index = 0; index < 10; index++) {
            let record = new RewardHistoryInfo();
            // record.type = ClubHistoryType.REWARD_RECORD;
            record.time = Date.now() - index * 500000000;
            record.commission = cc.randomRangeInt(0, 1000);
            record.status = cc.randomRangeInt(0, 3);
            record.recordFilerType = cc.randomRangeInt(0, 5);
            rewardRecords.push(record);
        }

        this._historyRecords.set(ClubHistoryType.REWARD_RECORD, rewardRecords);

        let withdrawRecords: RewardHistoryInfo[] = [];
        for (let index = 0; index < 20; index++) {
            let record = new RewardHistoryInfo();
            // record.type = ClubHistoryType.WITHDRAW_RECORD;
            record.time = Date.now() - index * 600000000;
            record.commission = cc.randomRangeInt(1500, 2000);
            record.status = cc.randomRangeInt(0, 3);
            record.recordFilerType = 0;
            withdrawRecords.push(record);
        }
        this._historyRecords.set(ClubHistoryType.WITHDRAW_RECORD, withdrawRecords);

        //分享数据
        this._shareInfo = new SharedInfo();
        this._shareInfo.reawrd = 26;
        this._shareInfo.pages = [];
        for (let index = 0; index < 3; index++) {
            this._shareInfo.pages.push({
                pageUrl: "share_page1.jpg",
                state: 1
            })
        }
    }

    //基本配置
    parseBaseConfig(v: LobbyProto.ConfClubLevelData[]) {
        this._clubConfig = [];
        v.forEach(e => {
            this._clubConfig.push({
                level: e.id,
                maxMember: e.memberCond,
                maxBet: e.betCond,
                betRebate: 0,
                depositRebate: 0,
                inviteRewards: 0,
            })
        })
    }

    /**
     * 代理层级配置
     * @param v 
     */
    parseTeamConfig(v: LobbyProto.ConfClubBindLevelData[]) {
        this._clubTeamConfig = [];
        v.forEach(e => {
            this._clubTeamConfig.push({
                name: e.name,
                showName: e.showName
            })
        })
    }

    /**
     * 返利配置
     * @param v 
     */
    parseRebateInfo(v: LobbyProto.ConfClubRebateData[]) {
        v.forEach(e => {
            for (let index = 0; index < this._clubConfig.length; index++) {
                let element = this._clubConfig[index];
                if (element.level == e.clubLevel) {
                    element.betRebate = e.betRebate;
                    element.depositRebate = e.depositRebate;
                    element.inviteRewards = 0;
                    break;
                }
            }
        })
    }

    /**
     * 我的俱乐部基本信息
     * @param v 
     */
    parseMyClubInfo(v: LobbyProto.GetMyClubInfoRsp) {
        this._myClubBaseInfo = new MyClubBaseInfo();
        this._myClubBaseInfo.level = v.level;
        this._myClubBaseInfo.bets = v.bet;
        this._myClubBaseInfo.memberCount = v.member;
        this._myClubBaseInfo.rewardToday = 0;
        this._myClubBaseInfo.rewardTotal = 0;
        this._myClubBaseInfo.withdrawable = 0;
    }

    /**
     * 我的俱乐部团队信息
     * @param v 
     */
    parseMyClubTeamInfo(v: LobbyProto.GetCLubMemberRsp) {
        this._myClubTeamInfo = new MyClubTeamInfo();
        this._myClubTeamInfo.level = v.level;
        this._myClubTeamInfo.joinToday = v.todayAddMember;
        this._myClubTeamInfo.joinYesterday = v.yesterdayAddMember;
        this._myClubTeamInfo.joinMonth = v.monthAddMember;
        this._myClubTeamInfo.membersAmount = v.levelMemberNum;
        this._myClubTeamInfo.members = [];

        for (let index = 0; index < v.list.length; index++) {
            let itemData = v.list[index];

            let member = new MemberInfo();
            member.uid = itemData.pid;
            member.avatorID = itemData.avatar;
            member.name = itemData.nickname;
            member.phoneNum = itemData.phone;
            member.deposit = itemData.deposit;
            member.commission = itemData.commission;
            member.joinTime = Number(itemData.createTime);
            member.isNew = isSameDay(GlobalModel.Instance.serverTimeStamp, member.joinTime);

            this._myClubTeamInfo.members.push(member);
        }
    }

    paserInvitePageInfo() {

    }

    parseSharedInfo(v: LobbyProto.GetClubSharePosterConfRsp) {
        this._shareInfo = null;
        this._shareInfo = new SharedInfo();
        this._shareInfo.reawrd = 0;
        this._shareInfo.pages = [];
        v.list.forEach(e => {
            this._shareInfo.pages.push({
                pageUrl: e.imgURL,
                state: 1
            })
        });
    }

    parseRule() {

    }

    getClubConfig() {
        return this._clubConfig;
    }

    getTeamConfig() {
        return this._clubTeamConfig;
    }

    getClubInfoByLevel(lvl: number) {
        return this._clubConfig.find(e => e.level == lvl);
    }

    getMyClubBaseInfo(): MyClubBaseInfo {
        return this._myClubBaseInfo;
    }

    getTeamInfo(): MyClubTeamInfo {
        return this._myClubTeamInfo;
    }

    /**
     * 对成员以加入时间排序
     */
    memberSortByJoinTime(members: MemberInfo[], desc: boolean) {
        if (desc) {
            members.sort((a, b) => {
                return b.joinTime - a.joinTime;
            });
        } else {
            members.sort((a, b) => {
                return a.joinTime - b.joinTime;
            });

        }

        return members;
    }

    /**
     * 对成员以佣金进行排序
     * @param members 
     * @returns 
     */
    memberSortByCommission(members: MemberInfo[], desc: boolean) {
        if (desc) {
            members.sort((a, b) => {
                return b.commission - a.commission;
            });
        } else {
            members.sort((a, b) => {
                return a.commission - b.commission;
            });
        }

        return members;
    }

    filterMembersByJoinTime(members: MemberInfo[], startTime: number) {
        return members.filter(e => {
            return e.joinTime >= startTime;
        });
    }

    getInviteInfo(): InviteInfo {
        return this._inviteInfo;
    }

    /**
     * 取得历史记录
     * @param type 
     * @returns 
     */
    getHistoryRecords(type: ClubHistoryType): RewardHistoryInfo[] {
        return this._historyRecords.get(type) || [];
    }

    /**
     * 以时间过滤历史记录
     * @param type 
     * @param startTime 
     * @returns 
     */
    filterHistoryRecordsByTime(type: ClubHistoryType, startTime: number): RewardHistoryInfo[] {
        let records = this.getHistoryRecords(type);
        return records.filter(e => {
            return e.time >= startTime;
        });
    }

    /**
     * 以类型过滤历史记录
     * @param type 
     * @param filterType 
     * @returns 
     */
    filterHistoryRecordsByType(type: ClubHistoryType, filterType: RecordFilterType, startTime: number): RewardHistoryInfo[] {
        let records = this.getHistoryRecords(type);
        if (filterType == RecordFilterType.ALL) {
            return records.filter(e => {
                return e.time >= startTime;
            });
        } else {
            return records.filter(e => {
                return e.recordFilerType == filterType && e.time >= startTime;
            });
        }
    }

    /**
     * 分享数据
     * @returns 
     */
    getSharedInfo(): SharedInfo {
        return this._shareInfo;
    }
}

ClubModel.Instance.test();