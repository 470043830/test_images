import * as cc from "cc";
import Singleton from "../framework/base/Singleton";
import { LobbyProto } from "../protobuf/pb";

//规则页面ID
export namespace RulePageID {
    export const RULE_PAGE_CLUB = "clubRule";           //俱乐部规则
    export const inviteNew = "inviteNew";               //邀请新用户
    export const inviteMax = "inviteMax";               //邀请满员
}

//俱乐部规则结构
export interface ClubRuleInfo {
    showButton: number;         //是否显示按钮 0不显示 1显示
    buttonDesc: string;         //按钮描述
    buttonEvent: number;        //按钮点击事件
    buttonParam: string;        //按钮点击事件参数
    imgUrl: string;             //图片地址
    richText: string;           //富文本
    sortIndex: number;         //排序索引
    // ruleID?: number;            //规则ID
}

/**
 * 通用规则数据模块
 */
export default class RuleModel extends Singleton {
    static get Instance() {
        return super.GetInstance<RuleModel>();
    }


    //规则
    private _clubRule: Map<string, ClubRuleInfo[]> = new Map();

    test() {
        //规则
        this._clubRule.clear();
        this._clubRule.set(RulePageID.RULE_PAGE_CLUB, []);

        let ruleList: ClubRuleInfo[] = this._clubRule.get(RulePageID.RULE_PAGE_CLUB);
        ruleList.push({
            buttonDesc: "Invite Now",
            buttonEvent: 0,
            imgUrl: "http://192.168.1.40:8080/remotefiles/rule1.png",
            richText: "<color=#E7BBBB>Invite rewards\nup to </color><color=#DDC234>jasdpo oasdlasdl; aspdsad.lklasdasd poasdasdlfasafsaf</color>",
            buttonParam: "0",
            showButton: 0,
            sortIndex: 0,
        });
        ruleList.push({
            buttonDesc: "",
            buttonEvent: 0,
            imgUrl: "http://192.168.1.40:8080/remotefiles/rule2.png",
            richText: "<color=#E7BBBB>Invite rewards\nup to </color><color=#DDC234>jasdpo oasdlasdl; aspdsad.lklasdasd poasdasdlfasafsaf</color>",
            showButton: 0,
            buttonParam: "",
            sortIndex: 0
        });

        ruleList.push({
            buttonDesc: "Button Desc",
            buttonEvent: 0,
            imgUrl: "http://192.168.1.40:8080/remotefiles/rule1.png",
            richText: "<color=#E7BBBB>Invite rewards\nup to </color><color=#DDC234>jasdpo oasdlasdl; aspdsad.lklasdasd poasdasdlfasafsaf</color>",
            showButton: 1,
            buttonParam: "",
            sortIndex: 0
        });

        ruleList.push({
            buttonDesc: "",
            buttonEvent: 0,
            imgUrl: "http://192.168.1.40:8080/remotefiles/rule2.png",
            richText: "<color=#E7BBBB>Invite rewards\nup to </color><color=#DDC234>jasdpo oasdlasdl; aspdsad.lklasdasd poasdasdlfasafsaf</color>",
            showButton: 0,
            buttonParam: "",
            sortIndex: 0
        });


    }

    //所有规则页面配置
    parseBaseConfig(v: LobbyProto.ConfClubRuleData[]) {
        this._clubRule.clear();
        v.forEach(e => {
            let pageID = e.page;
            let ruleList: ClubRuleInfo[] = [];
            ruleList.push({
                showButton: e.showButton,
                buttonDesc: e.buttonName,
                buttonEvent: e.buttonEventType,
                buttonParam: e.buttonEventParam,
                imgUrl: e.imgUrl,
                richText: e.context,
                sortIndex: e.sortNum,
                // ruleID: e.id
            });

            ruleList.sort((a, b) => {
                return a.sortIndex - b.sortIndex;
            });

            this._clubRule.set(pageID, ruleList);
        });
    }

    getRules(pageID: string): ClubRuleInfo[] {
        return this._clubRule.get(pageID);
    }

}

RuleModel.Instance.test();