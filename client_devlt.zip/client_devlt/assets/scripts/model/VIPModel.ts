import Singleton from "../framework/base/Singleton";
import { LobbyProto } from "../protobuf/pb";
import AccountModel from "./AccountModel";
import * as cc from "cc";

//vip升级条件
export enum VipUpCategory {
    DEPOSITE = 1,       //充值
    WAGER,              //流水
    ALL,                //充值+流水
}

//VIP等级属性
export interface IVipProp {
    level: number;                      // 等级
    category: VipUpCategory;            // 积分类型 1充值 2有效流水 3充值+有效流水
    upDeposit: number;                  // 升级所需充值金额
    upWager: number;                    // 升级所需充值有效流水
    iconUrl: string;                    // vip等级图标
    avatar: string;                     // vip头像框
    color: string;                      // vip昵称颜色
    dailyWithdrawalLimit: number;       // 每日可提现总额度
    dailyWithdrawalFreeCnt: number;     // 每日免费提现次数
    withdrawalBaseFee: number;          // 提现基础手续费
    withdrawalPercentFee: number;       // 提现手续费百分比 10000=100%
    depositRewardPercent: number;       // 充值赠送百分比 10000=100%
    depositRewardCnt: number;           // 充值赠送次数 用户每日/周期可享受充值赠送次数
    state: number;                      // 状态 1正常 2关闭
}

//VIP权益属性
export interface IVipPrivilProp {
    vipLevel: number;                   // vip等级
    category: number;                   // 特权类型 1每周奖励 2升级奖励 3每日提现限额 4提现手续费 5每日免费提现次数
    icon: string;                       // 特权图标
    title: string;                      // 标题
    titleParam: string;                 // 标题参数
    sort: number;                       // 排序值 越大越前
    state: number;                      // 状态 1正常 2停用
}

//VIP 历史bonus属性
export interface VipBonusHistoryProp {
    icon: string;                       // 特权图标
    title: string;                      // 标题
    titleParam: number;                 // 标题参数
    date: number;                       // 时间
}

//VIP 返利属性
export interface VipRebateProp {
    gameType: string;                   // 游戏类型
    rate: number;                       // 返利比例
}

/**
 * VIP 数据模型
 */
export default class VIPModel extends Singleton {
    static get Instance() {
        return super.GetInstance<VIPModel>();
    }

    //vip列表
    private _vipList: IVipProp[] = [];

    //vip各等级权益配置列表
    private _vipPrivilList: IVipPrivilProp[] = [];

    //返利数据
    private _rebateRate: VipRebateProp[] = [];

    //BONUS 历史数据
    private _bonusHistory: VipBonusHistoryProp[] = [];

    test() {
        this._bonusHistory = [];
        for (let index = 0; index < cc.randomRangeInt(0, 10); index++) {
            this._bonusHistory.push({
                icon: "",
                title: `Description ${index}`,
                titleParam: cc.randomRangeInt(10, 100),
                date: Date.now() - index * 1000000
            })
        }

        this._rebateRate = [];
        this._rebateRate.push({ gameType: "Slots", rate: cc.randomRangeInt(0, 100) });
        this._rebateRate.push({ gameType: "Casino", rate: cc.randomRangeInt(0, 100) });
        this._rebateRate.push({ gameType: "Lottery", rate: cc.randomRangeInt(0, 100) });
        this._rebateRate.push({ gameType: "PVC", rate: cc.randomRangeInt(0, 100) });
    }

    parseVipList(v: LobbyProto.VipInfo[]) {
        this._vipList = [];
        v.forEach(e => {
            this._vipList.push({
                level: e.id,
                category: e.category,
                upDeposit: e.upDeposit,
                upWager: e.upWager,
                iconUrl: e.icon,
                avatar: e.avatar,
                color: e.color,
                dailyWithdrawalLimit: e.dailyWithdrawalLimit,
                dailyWithdrawalFreeCnt: e.dailyWithdrawalFreeCnt,
                withdrawalBaseFee: e.withdrawalBaseFee,
                withdrawalPercentFee: e.withdrawalPercentFee,
                depositRewardPercent: e.depositRewardPercent,
                depositRewardCnt: e.depositRewardCnt,
                state: e.state
            })
        })

        this._vipList.sort((a, b) => {
            return a.level - b.level;
        })
    }

    get vipList(): IVipProp[] {
        return this._vipList;
    }

    /**
     * 取得指定vip等级的属性
     * @param vipLvl 
     * @returns 
     */
    getVipInfo(vipLvl: number) {
        return this._vipList.find((e) => e.level == vipLvl);
    }

    /**
     * 取得当前VIP等级信息
     * @returns 
     */
    getCurVipLvlInfo() {
        return this.getVipInfo(AccountModel.Instance.vipLevel);
    }

    parseVipPrivilList(v: LobbyProto.VipPrivileges[]) {
        this._vipPrivilList = [];
        v.forEach(e => {
            this._vipPrivilList.push({
                vipLevel: e.vipLevel,
                category: e.category,
                icon: e.icon,
                title: e.title,
                titleParam: e.titleParam,
                sort: e.sort,
                state: e.state
            })
        })
    }

    get vipPrivilList(): IVipPrivilProp[] {
        return this._vipPrivilList;
    }

    /**
     * 取得指定vip等级的权益
     * @param vipLvl 
     * @returns 
     */
    getVipPrivInfo(vipLvl: number): IVipPrivilProp[] {
        let ret = [];
        this._vipPrivilList.forEach(e => {
            if (e.vipLevel == vipLvl) {
                ret.push(e);
            }
        })
        return ret;
    }

    /**
     * 取得当前VIP等级的权益
     * @returns 
     */
    getCurVipLvlPrivilInfo() {
        return this.getVipPrivInfo(AccountModel.Instance.vipLevel);
    }

    /**
     * 返利数据
     */
    get rebateRate() {
        return this._rebateRate;
    }

    parseRebateRate() {

    }

    parseBonusHistory(v) {

    }

    /**
     * 取得bonus历史数据
     * @returns 
     */
    getBonusHistory(): VipBonusHistoryProp[] {
        return this._bonusHistory;
    }
}
