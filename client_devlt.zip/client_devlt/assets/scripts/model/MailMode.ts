import Singleton from "../framework/base/Singleton";
import { LobbyProto } from "../protobuf/pb";
import AccountModel from "./AccountModel";
import * as cc from "cc";


//   string body = 1; // 邮件内容
//   string pictureUrl = 2; // 图片路径
//   int32 hasRewards = 3 ;// 是否有奖励
//   string taskIds = 4; // 任务id，靠英文“,” 分割
//   int32 taskExpireType = 5;// 任务过期类型
//   int32 taskExpireTime = 6; // 任务过期时间
//   int32 jumpType = 7 ;// 跳转类型
//   string jumpDst = 8; // 跳转目的地
export interface IUserMailInfo {
    body: string;
    pictureUrl: string;
    hasRewards: number;
    taskIds: string;
    taskExpireType: number;
    taskExpireTime: number;
    jumpType: number;
    jumpDst: string;
}

export interface IUserEmailDigest {
    eid: number; // 邮件id
    type: number; // 邮件类型，1~1000 平台邮件 > 1000 站长邮件
    status: number; // 邮件状态,已读,已读，已读未领奖等
    head: string; // 邮件头
    digest: string; // 摘要
    timestamp: number; // 时间戳
}

/**
 * VIP 数据模型
 */
export default class MailMode extends Singleton {
    static get Instance() {
        return super.GetInstance<MailMode>();
    }

    private _mailList: IUserEmailDigest[] = [];

    test() {

    }

    parseMailList(v: LobbyProto.UserEmailDigest[]) {
        this._mailList = [];
        v.forEach(e => {
            this._mailList.push({
                eid: e.eid,
                type: e.type,
                status: e.status,
                head: e.head,
                digest: e.digest,
                timestamp: e.timestamp
            })
        });

        console.log('this._mailList: ', this._mailList);
    }

    get mailList() {
        return this._mailList;
    }

}
