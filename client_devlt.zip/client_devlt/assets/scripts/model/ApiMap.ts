import { _decorator } from 'cc';

const { ccclass, property } = _decorator;

/** 登录接口数据映射 */
export enum EnumLoginReq {
    sitemid = 'a',                               // sitemid平台ID,游客：设备号，FB: FB登录平台ID
    device = 'd',                                // 设备号
    userName = 'n',
    userSex = 'f',
    utype = 't',                                 // 用户类型，1-游客，2-FB,3-手机，99-机器人
    api = 'c',                                   // 渠道包，由php提供，示例：’1001’
    version = 'v',                               // 版本号 1.0.0.0， <大版本号>.<整包版本号>.<热更版本号>.<资源版本号>
    gameType = 's',
    deviceInfo = 'z',
    network = 'w',
    screenWidth = 'x',                           // screenWidth屏幕宽度
    screenHeight = 'y',                          // screenHeight屏幕高度
    mobileBrand = 'b',                           // mobileBrand手机品牌
    osVersion = 'o',                             // osVersion手机系统
    code = 'c',
    share_code = 'c2',
    accessToken = 'a1',
    tokenForBusiness = 'a2',
    email = 'a3'
}

/**
 * 登录接口数据映射
 */
export enum EnumLoginResp {
    k = 'token',                                    // token
    n = 'isNew',                                    // 是否是注册用户，1-注册，0-非注册
    u = 'uid',                                      // 用户ID
    mn = 'mnick',                                   // 用户昵称
    r = 'head_url',                                 // 用户头像
}

/**
 * API字典
 */
export class ApiMap {
    static transformMap(table, data) {
        let ret: any = {};
        for (var key in data) {
            ret[table[key]] = data[key];
        }
        return ret;
    }
}

