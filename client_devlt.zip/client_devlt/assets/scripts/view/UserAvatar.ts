import * as cc from 'cc';
import AccountModel from '../model/AccountModel';
import VIPModel from '../model/VIPModel';
import EventMgr from '../framework/event/EventMgr';
import { LOBBY_EVENT } from '../framework/event/EventDefine';

const { ccclass, property } = cc._decorator;


/**
 * 头像
 */
@ccclass('UserAvatar')
export class UserAvatar extends cc.Component {
    // @property({ type: cc.Sprite, tooltip: "头像框" })
    // spFrame: cc.Sprite = null;

    @property({ type: cc.Sprite, tooltip: "头像" })
    spAvatar: cc.Sprite = null;

    protected onLoad(): void {
        EventMgr.Instance.on(LOBBY_EVENT.ACCOUNT_UPDATE_MY_INFO, this.updataAvatar, this);

    }

    protected onDestroy(): void {
        EventMgr.Instance.offTarget(this);

    }

    protected start(): void {
        this.updataAvatar();
    }

    /**
     * 更新头像显示
     */
    updataAvatar() {
        //头像
        let vipLvl = AccountModel.Instance.vipLevel;
        let vipInfo = VIPModel.Instance.getVipInfo(vipLvl);
        if (vipInfo) {
            let self = this;
            cc.assetManager.loadRemote(vipInfo.avatar, null, (err, data: cc.Texture2D) => {
                if (!err) {
                    if (data) {
                        let frame = cc.SpriteFrame.createWithImage(data as any);
                        self.spAvatar.spriteFrame = frame;
                    }
                } else {
                    console.log("头像下载失败", vipInfo.avatar)
                }
            })
        }
    }

}