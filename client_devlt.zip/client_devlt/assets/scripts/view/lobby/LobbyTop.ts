import * as cc from 'cc';
import { Logger } from '../../framework/utils/Logger';
import { UIMgr } from '../../framework/manager/UIMgr';
import { EnumPrefab } from '../../config/BundleConfig';
import { GameApp } from '../../lobby/GameApp';
const { ccclass, property } = cc._decorator;

/**
 * 
 * LobbyTop
 * LobbyTop
 * chonger8888
 * Sun Sep 28 2025 11:37:34 GMT+0800 (中国标准时间)
 * LobbyTop.ts
 * LobbyTop
 * <%URL%>
 * https://docs.cocos.com/creator/3.8/manual/zh/
 *
 */

@ccclass('LobbyTop')
export class LobbyTop extends cc.Component {
    @property({ type: cc.Button, tooltip: "客服按钮" })
    btnService: cc.Button = null;

    @property({ type: cc.Button, tooltip: "轮盘按钮" })
    btnWheel: cc.Button = null;

    @property({ type: cc.Button, tooltip: "邮件按钮" })
    btnMail: cc.Button = null;

    onLoad() {
        this.btnService.node.on(cc.Button.EventType.CLICK, this.onClickService, this);
        this.btnWheel.node.on(cc.Button.EventType.CLICK, this.onClickWheel, this);
        this.btnMail.node.on(cc.Button.EventType.CLICK, this.onClickEmail, this);
    }

    onClickService() {
        Logger.debug(`点击了客服按钮`);
        UIMgr.Instance.showView(EnumPrefab.taskPopup, null, GameApp.Instance.getDialogLayer(), EnumPrefab.taskPopup, false);
    }

    onClickWheel() {
        Logger.debug(`点击了轮盘`);
    }

    onClickEmail() {
        Logger.debug(`点击率邮件`);
    }
}