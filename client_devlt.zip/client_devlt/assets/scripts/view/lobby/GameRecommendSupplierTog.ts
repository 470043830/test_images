import * as cc from 'cc';
import { loadRemoteImg } from '../../framework/lib/GlobalFunc';
import { AppConfig, gameConfig } from '../../config/Config';

const { ccclass, property } = cc._decorator;


/**
 * 游戏图标列表item
 */
@ccclass('GameRecommendSupplierTog')
export class GameRecommendSupplierTog extends cc.Component {
    @property({ type: cc.Sprite, tooltip: "正常状态" })
    spIconN: cc.Sprite = null;

    @property({ type: cc.Sprite, tooltip: "选中状态" })
    spIconS: cc.Sprite = null;



    setIcons(urlN: string, urlS: string) {
        loadRemoteImg(this.spIconN, gameConfig.remote_url + "gameIcons/" + urlN);
        loadRemoteImg(this.spIconS, gameConfig.remote_url + "gameIcons/" + urlS);
    }

    setSelceted(v: boolean) {
        this.spIconN.node.active = !v;
        this.spIconS.node.parent.active = v;
    }




}