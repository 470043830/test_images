import * as cc from 'cc';
import { EnumPrefab } from '../../config/BundleConfig';
import { UIMgr } from '../../framework/manager/UIMgr';
import { GameApp } from '../../lobby/GameApp';
const { ccclass, property } = cc._decorator;

/**
 * 
 * LobbyPromo
 * LobbyPromo
 * chonger8888
 * Sun Sep 28 2025 11:56:28 GMT+0800 (中国标准时间)
 * LobbyPromo.ts
 * LobbyPromo
 * <%URL%>
 * https://docs.cocos.com/creator/3.8/manual/zh/
 *
 */

@ccclass('LobbyPromo')
export class LobbyPromo extends cc.Component {
    @property({ type: cc.ScrollView, tooltip: "" })
    scrollView: cc.ScrollView = null;

    onLoad() {
        this.scrollView.content.children.forEach(e => {
            e.on(cc.Button.EventType.CLICK, () => {
                UIMgr.Instance.showView(EnumPrefab.shareToApp, null, GameApp.Instance.getDialogLayer(), EnumPrefab.shareToApp, false);
            })
        })
    }

}