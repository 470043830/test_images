import * as cc from 'cc';
import { BaseScene } from '../../framework/base/BaseScene';
import { UIMgr } from '../../framework/manager/UIMgr';
import { EnumPrefab } from '../../config/BundleConfig';
import EventMgr from '../../framework/event/EventMgr';
import { GAME_EVENT } from '../../framework/event/EventDefine';

const { ccclass, property } = cc._decorator;

/**
 *  大厅场景
 */

@ccclass('SceneLobby')
export class SceneLobby extends BaseScene {

    @property({ type: cc.Prefab, tooltip: "LayerLobby预制体" })
    LayerLobby: cc.Prefab = null;

    private _layerLobby: cc.Node = null;

    protected initView(): void {
        this._layerLobby = cc.instantiate(this.LayerLobby);
        this.getGameLayer().addChild(this._layerLobby);

        UIMgr.Instance.removeNameView(EnumPrefab.signIn);
    }

    onDestroy(): void {
        super.onDestroy();
        if (this._layerLobby) {
            this._layerLobby.destroy();
            this._layerLobby = null;
        }
    }

}

