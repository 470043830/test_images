import * as cc from 'cc';
import { Logger } from '../../framework/utils/Logger';
import EventMgr from '../../framework/event/EventMgr';
import { LOBBY_EVENT } from '../../framework/event/EventDefine';
import { LobbyPageType } from '../../Const';
const { ccclass, property } = cc._decorator;

/**
 * 
 * LobbyBottom
 * LobbyBottom
 * chonger8888
 * Sun Sep 28 2025 11:37:04 GMT+0800 (中国标准时间)
 * LobbyBottom.ts
 * LobbyBottom
 * <%URL%>
 * https://docs.cocos.com/creator/3.8/manual/zh/
 *
 */

@ccclass('LobbyBottom')
export class LobbyBottom extends cc.Component {
    @property({ type: cc.Button, tooltip: "底部get按钮" })
    btnGet: cc.Button = null;

    @property({ type: cc.ToggleContainer, tooltip: "底部togger组" })
    togBottom: cc.ToggleContainer = null;

    @property({ type: cc.Color, tooltip: "底部单选按钮文字颜色" })
    togLabColor: cc.Color[] = [];

    private _curTogger: number = 0;     //当前选中的底部单选按钮
    onLoad() {
        this.btnGet.node.on(cc.Button.EventType.CLICK, this.onClickGet, this);
        this.initBottomToggers();
    }

    onClickGet() {
        EventMgr.Instance.emit(LOBBY_EVENT.SWICH_LOBBY_VIEW, LobbyPageType.GETMONEY);
    }


    /**
     * 初始化底部单选按钮
     */
    initBottomToggers() {
        this.togBottom.toggleItems.forEach((e, idx) => {
            e.node.on(cc.Toggle.EventType.CLICK, () => {
                this._curTogger = idx;
                this.onClickBottomTogger();
            });
        });

        this.updateBottomToggers();
    }

    /**
    * 更新底部单选按钮的点击状态
    */
    updateBottomToggers() {
        this.togBottom.toggleItems.forEach((e, idx) => {
            e.node.getComponentInChildren(cc.Label).color = this._curTogger == idx ? this.togLabColor[1] : this.togLabColor[0];
        });
    }


    /**
     * 底部单选按钮点击事件回调
     */
    onClickBottomTogger() {
        this.updateBottomToggers();
        EventMgr.Instance.emit(LOBBY_EVENT.SWICH_LOBBY_VIEW, this._curTogger);
    }



}