import * as cc from 'cc';
import { BaseUI } from '../../framework/base/BaseUI';
import { GameRecommendSupplierTog } from './GameRecommendSupplierTog';
import { SupplierRecommondGames } from './SupplierRecommondGames';
import GameModel, { GameIconProperty } from '../../model/GameModel';
import EventMgr from '../../framework/event/EventMgr';
import { LOBBY_EVENT } from '../../framework/event/EventDefine';
import { Logger } from '../../framework/utils/Logger';
import { UIDefaultCtrl } from '../../framework/base/UIDefaultCtrl';
import GlobalModel from '../../model/GlobalModel';

const { ccclass, property } = cc._decorator;


/**
 * 游戏图标列表
 */
@ccclass('GameRecommendPage')
export class GameRecommendPage extends BaseUI {
    @property({ type: cc.Button, tooltip: "返回按钮" })
    btnBack: cc.Button = null;

    @property({ type: cc.Label, tooltip: "厂商名称" })
    labSupplierName: cc.Label = null;

    @property({ type: cc.ScrollView, tooltip: "游戏厂商滚动列表" })
    supplierScrollView: cc.ScrollView = null;

    @property({ type: cc.Prefab, tooltip: "游戏厂商滚动列表item" })
    pfFilterItem: cc.Prefab = null;

    @property({ type: cc.ScrollView, tooltip: "各厂商的热门游戏列表" })
    gamesScrollView: cc.ScrollView = null;

    @property({ type: cc.Prefab, tooltip: "各厂商的热门游戏列表item" })
    pfGameItem: cc.Prefab = null;

    private _cellHeight: number[] = [];         //各个游戏厂商的显示高度
    private _lastScrollPosY: number = 0;
    private _curMoveIndex: number = -1;
    private _isScrollByClick: boolean = false;

    protected initView(): void {
        this.btnBack.node.on(cc.Button.EventType.CLICK, this.onClickBack, this);
        this.labSupplierName.string = this.getComponent(UIDefaultCtrl).viewParam.supplierName;

        this.gamesScrollView.node.on(cc.ScrollView.EventType.SCROLLING, this.onScrolling, this);
        this.gamesScrollView.node.on(cc.ScrollView.EventType.SCROLL_BEGAN, this.onScrollingBegan, this);
        this.gamesScrollView.node.on(cc.ScrollView.EventType.SCROLL_ENDED, this.onScrollingEnded, this);
    }

    protected bindEventListener(): void {
        EventMgr.Instance.on(LOBBY_EVENT.HALL_REMCOMMEND_TYPE_INFO, this.onRecvRecommendSuppliers, this);
        EventMgr.Instance.on(LOBBY_EVENT.HALL_RECOMMEND_GAMES_INFO, this.onRecvRecommendGames, this);
    }

    protected onDestroy(): void {
        super.onDestroy();
    }

    initSupplierList() {
        //取得所有厂商ID
        let gameStyles = GameModel.Instance.recommendGameStyles;

        let spaceY = this.gamesScrollView.content.getComponent(cc.Layout).spacingY;
        gameStyles.forEach((e, idx) => {
            let newItem = cc.instantiate(this.pfFilterItem);
            this.supplierScrollView.content.addChild(newItem);

            let src = newItem.getComponent(GameRecommendSupplierTog);
            src.setIcons(e.spriteUrlN, e.spriteUrlS);
            src.setSelceted(idx == 0);
            src.node.on(cc.Button.EventType.CLICK, () => {
                this.setToggleChecked(idx);
                //切换到某类
                let offsetY = 0;
                for (let index = 0; index < idx; index++) {
                    const element = this._cellHeight[index];
                    if (element && element != 0) {
                        offsetY += element;
                    }
                }

                offsetY += (spaceY * idx);
                this._isScrollByClick = true;
                this.gamesScrollView.scrollToOffset(cc.v2(0, offsetY), 0.1, false);
            })
        })
    }

    /**
     * 展示所有游戏厂商的热门游戏
     */
    initSupplierGames() {
        let recommendGames = GameModel.Instance.recommendGames;
        recommendGames.forEach((games, supllierID) => {
            let height = this.showSupplierGamesList(supllierID, games);
            this._cellHeight.push(height);
        })
    }

    /**
     * 展示指定厂商的热门游戏列表
     * @param v 
     */
    showSupplierGamesList(supllierID: number, gameIcons: GameIconProperty[]) {
        let newItem = cc.instantiate(this.pfGameItem);
        this.gamesScrollView.content.addChild(newItem);

        let showRow = GameModel.Instance.getRecommendGameShowRow(supllierID);

        let src: SupplierRecommondGames = newItem.getComponent(SupplierRecommondGames);
        src.initGameList(gameIcons, supllierID, showRow);

        return newItem.getComponent(cc.UITransform).height;
    }

    onClickBack() {
        this.onClose();
    }

    /**
     * 从服务器取得要显示的厂商
     */
    onRecvRecommendSuppliers() {
        this.initSupplierList();
    }

    onRecvRecommendGames() {
        this.initSupplierGames();
    }


    onScrolling() {
        let items = this.gamesScrollView.content.children;
        let viewSize = this.gamesScrollView.getComponent(cc.UITransform).contentSize;
        let scrollOffsetY = this.gamesScrollView.getScrollOffset().y;

        let isMoveUp = this.gamesScrollView.content.getPosition().y > this._lastScrollPosY;

        if (isMoveUp) {
            //向上滑
            for (let index = items.length - 1; index >= 0; index--) {
                let itemsHeight = this.getItemsHeight(index);
                if (scrollOffsetY >= itemsHeight) {
                    if (this._curMoveIndex != index + 1) {
                        this._curMoveIndex = index + 1;
                        if (!this._isScrollByClick) {
                            // Logger.info(`向上滑到: idx = `, index + 1);
                            this.setToggleChecked(index + 1);
                        }
                    }
                    break;
                }
            }

        } else {
            //向下滑
            for (let index = 0; index < items.length; index++) {
                let itemsHeight = this.getItemsHeight(index);
                if (scrollOffsetY <= itemsHeight) {
                    if (this._curMoveIndex != index) {
                        this._curMoveIndex = index;
                        if (!this._isScrollByClick) {
                            // Logger.info(`---向下滑到: idx = `, index);
                            this.setToggleChecked(index);
                        }
                    }
                    break;
                }
            }
        }


        // if (idx < moveIndex) {
        //     //移到顶部之外的隐藏
        //     e.children[0].active = false;
        // } else if (idx > moveIndex + maxShowItem) {
        //     //移到底部之外的隐藏
        //     e.children[0].active = false;
        // } else {
        //     e.children[0].active = true;
        // }
        this._lastScrollPosY = this.gamesScrollView.content.getPosition().y
    }

    onScrollingBegan() {
    }

    onScrollingEnded() {
        this._isScrollByClick = false;
    }

    getItemsHeight(itemCount: number) {
        let sum = 0;
        for (let index = 0; index < this._cellHeight.length; index++) {
            const h = this._cellHeight[index];
            sum += h;
            if (index >= itemCount) {
                break;
            }
        }

        return sum;
    }

    setToggleChecked(index) {
        let togs = this.supplierScrollView.content.children;
        togs.forEach((tog, idx) => {
            tog.getComponent(GameRecommendSupplierTog).setSelceted(idx == index);
        });

        let offsetX = togs[0].getComponent(cc.UITransform).width * index;
        this.supplierScrollView.scrollToOffset(cc.v2(offsetX, 0), 0.1, false);
    }


}