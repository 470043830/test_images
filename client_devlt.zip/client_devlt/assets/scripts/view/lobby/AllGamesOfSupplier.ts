import * as cc from 'cc';
import { BaseUI } from '../../framework/base/BaseUI';
import { GameIcon } from './GameIcon';
import GameModel, { GameIconBehavor } from '../../model/GameModel';
import EventMgr from '../../framework/event/EventMgr';
import { LOBBY_EVENT } from '../../framework/event/EventDefine';
import { UIDefaultCtrl } from '../../framework/base/UIDefaultCtrl';
import { HallReqManager } from '../../framework/net/HallReqManager';

const { ccclass, property } = cc._decorator;


/**
 * 游戏图标列表
 */
@ccclass('AllGamesOfSupplier')
export class AllGamesOfSupplier extends BaseUI {
    @property({ type: cc.Button, tooltip: "返回按钮" })
    btnBack: cc.Button = null;

    @property({ type: cc.Label, tooltip: "厂商名称" })
    labSupplierName: cc.Label = null;

    @property({ type: cc.ScrollView, tooltip: "游戏列表" })
    scrollView: cc.ScrollView = null;

    @property({ type: cc.Prefab, tooltip: "游戏列表item" })
    pfGameItem: cc.Prefab = null;

    protected initView(): void {
        this.btnBack.node.on(cc.Button.EventType.CLICK, this.onClickBack, this);

        let comp = this.getComponent(UIDefaultCtrl);
        this.labSupplierName.string = comp.viewParam.supplierName;

        this.requestAllGames();
    }

    requestAllGames() {
        let comp = this.getComponent(UIDefaultCtrl);
        HallReqManager.sendSupplierAllGames(comp.viewParam.supplierID);
    }

    protected bindEventListener(): void {
        EventMgr.Instance.on(LOBBY_EVENT.HALL_SUPPLIER_ALL_GAMES, this.onRecvSuppliersAllGames, this);

    }

    protected onDestroy(): void {
        super.onDestroy();
    }

    /**
     * 展示游戏厂商的所有游戏
     */
    onRecvSuppliersAllGames() {
        let allGames = GameModel.Instance.allGames;

        allGames.forEach((e, idx) => {
            let newItem = cc.instantiate(this.pfGameItem);
            this.scrollView.content.addChild(newItem);

            let src = newItem.getComponent(GameIcon);
            src.showIcon(e, GameIconBehavor.ENTER_GAME);
        })
    }

    onClickBack() {
        this.onClose();
    }

}