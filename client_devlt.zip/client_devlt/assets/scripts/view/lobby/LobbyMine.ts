import * as cc from 'cc';
import { EnumPrefab, EnumScene } from '../../config/BundleConfig';
import { LOBBY_EVENT, SYS_EVENT } from '../../framework/event/EventDefine';
import { UIMgr } from '../../framework/manager/UIMgr';
import { GameApp } from '../../lobby/GameApp';
import AccountModel from '../../model/AccountModel';
import EventMgr from '../../framework/event/EventMgr';
import { LoginMgr } from '../../framework/manager/LoginMgr';
import { INR } from '../../Const';
const { ccclass, property } = cc._decorator;

/**
 * 
 * 个人信息
 *
 */

@ccclass('LobbyMine')
export class LobbyMine extends cc.Component {
    @property({ type: cc.Button, tooltip: "" })
    btnLogout: cc.Button = null;

    @property({ type: cc.Label, tooltip: "玩家名字" })
    labName: cc.Label = null;

    @property({ type: cc.Label, tooltip: "玩家金钱" })
    labMoney: cc.Label = null;

    @property({ type: cc.Label, tooltip: "VIP等级" })
    labVipLvl: cc.Label = null;

    @property({ type: cc.Button, tooltip: "我的信息" })
    btnMyInfo: cc.Button = null;

    @property({ type: cc.Button, tooltip: "vip按钮" })
    btnVip: cc.Button = null;

    @property({ type: cc.Button, tooltip: "关于我们按钮" })
    btnAboutUs: cc.Button = null;

    @property({ type: cc.Button, tooltip: "礼包码按钮" })
    btnGiftCode: cc.Button = null;

    @property({ type: cc.Button, tooltip: "余额详情按钮" })
    btnBalanceDetail: cc.Button = null;

    @property({ type: cc.Button, tooltip: "通知按钮" })
    btnNotification: cc.Button = null;

    @property({ type: cc.Button, tooltip: "ticket按钮" })
    btnTicket: cc.Button = null;

    @property({ type: cc.Button, tooltip: "liver support按钮" })
    btnLiveSupport: cc.Button = null;

    onLoad() {
        this.btnLogout.node.on(cc.Button.EventType.CLICK, this.onClickLogout, this);
        this.btnMyInfo.node.on(cc.Button.EventType.CLICK, this.onClickMyInfo, this);
        this.btnVip.node.on(cc.Button.EventType.CLICK, this.onClicVip, this);
        this.btnAboutUs.node.on(cc.Button.EventType.CLICK, this.onClicAboutUs, this);
        this.btnGiftCode.node.on(cc.Button.EventType.CLICK, this.onClicGiftCode, this);
        this.btnBalanceDetail.node.on(cc.Button.EventType.CLICK, this.onClicBalanceDetail, this);
        this.btnNotification.node.on(cc.Button.EventType.CLICK, this.onClicNotifications, this);
        this.btnTicket.node.on(cc.Button.EventType.CLICK, this.onClicTicket, this);
        this.btnLiveSupport.node.on(cc.Button.EventType.CLICK, this.onClicLiveSupport, this);
        this.bindEvent();
        this.updateUserInfo();
    }

    updateUserInfo() {
        this.labName.string = AccountModel.Instance.userName;
        this.labMoney.string = INR + AccountModel.Instance.cash;
        this.labVipLvl.string = "VIP" + AccountModel.Instance.vipLevel;
    }

    bindEvent() {
        EventMgr.Instance.on(LOBBY_EVENT.ACCOUNT_UPDATE_MY_INFO, this.updateUserInfo, this);
    }

    protected onDestroy(): void {
        EventMgr.Instance.offTarget(this);

    }

    onClickLogout() {
        UIMgr.Instance.showView(EnumPrefab.logoutWarn, null, GameApp.Instance.getDialogLayer(), EnumPrefab.logoutWarn, false);
    }

    onClickMyInfo() {
        UIMgr.Instance.showView(EnumPrefab.myInfo, null, GameApp.Instance.getDialogLayer(), EnumPrefab.myInfo, false);
    }

    onClicVip() {
        UIMgr.Instance.showView(EnumPrefab.vipMain, null, GameApp.Instance.getDialogLayer(), EnumPrefab.vipMain, false);
    }

    onClicAboutUs() {
        UIMgr.Instance.showView(EnumPrefab.aboutUs, null, GameApp.Instance.getDialogLayer(), EnumPrefab.aboutUs, false);
    }

    onClicGiftCode() {
        UIMgr.Instance.showView(EnumPrefab.giftCode, null, GameApp.Instance.getDialogLayer(), EnumPrefab.giftCode, false);
    }

    onClicBalanceDetail() {
        UIMgr.Instance.showView(EnumPrefab.balanceDetail, null, GameApp.Instance.getDialogLayer(), EnumPrefab.balanceDetail, false);
    }

    onClicNotifications() {
        UIMgr.Instance.showView(EnumPrefab.notifications, null, GameApp.Instance.getDialogLayer(), EnumPrefab.notifications, false);
    }

    onClicTicket() {
        UIMgr.Instance.showView(EnumPrefab.ticket, null, GameApp.Instance.getDialogLayer(), EnumPrefab.ticket, false);
    }

    onClicLiveSupport() {
        UIMgr.Instance.showView(EnumPrefab.liveSupport, null, GameApp.Instance.getDialogLayer(), EnumPrefab.liveSupport, false);
    }


}