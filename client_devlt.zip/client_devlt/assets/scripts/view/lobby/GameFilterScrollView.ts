import * as cc from 'cc';
import { GameFilterItem } from './GameFilterItem';
import EventMgr from '../../framework/event/EventMgr';
import { LOBBY_EVENT } from '../../framework/event/EventDefine';
import { HallReqManager } from '../../framework/net/HallReqManager';
import GameModel from '../../model/GameModel';

const { ccclass, property } = cc._decorator;

/**
 * 大厅游戏类型选择
 */
@ccclass('GameFilterScrollView')
export class GameFilterScrollView extends cc.Component {
    @property({ type: cc.Prefab, tooltip: "游戏筛选类型" })
    pfItem: cc.Prefab = null;

    @property({ type: cc.ScrollView, tooltip: "滚动节点" })
    srollView: cc.ScrollView = null;

    private _items: GameFilterItem[] = [];
    private _clickFunc: Function = null;

    protected onLoad(): void {
        this.bindEvent();
        this.requestGameInfo();
    }


    bindEvent() {
        EventMgr.Instance.on(LOBBY_EVENT.HALL_GAME_TYPE_INFO, this.onRecvGameTypeInfo, this);
    }

    protected onDestroy(): void {
        EventMgr.Instance.offTarget(this);
    }

    requestGameInfo() {
        HallReqManager.sendHallGameType(0);
    }

    setSelected(v: number) {
        this._items.forEach((e, i) => {
            e.setSelected(e.getFilterType() == v);
        });
    }

    setClickFunc(v: Function) {
        this._clickFunc = v;
    }

    onClickItem(v: number) {
        this.setSelected(v);

        if (this._clickFunc) {
            this._clickFunc(v);
        }
    }

    onRecvGameTypeInfo() {
        let arr = GameModel.Instance.homeGameStyles;
        arr.forEach((e, idx) => {
            let node = cc.instantiate(this.pfItem);
            this.srollView.content.addChild(node);
            node.active = e.valid == 1;

            let item = node.getComponent(GameFilterItem);
            item.setSelected(idx === 0);
            item.setFilterType(e.filter);
            item.setClickCallback(this.onClickItem.bind(this));
            item.setInfo(e.spriteUrlN, e.spriteUrlS);
            this._items.push(item);
        })
    }



}