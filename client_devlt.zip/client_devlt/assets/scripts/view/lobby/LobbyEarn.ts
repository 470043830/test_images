import * as cc from 'cc';
import { HallReqManager } from '../../framework/net/HallReqManager';
const { ccclass, property } = cc._decorator;


enum PageType {
    REREWARD_PAGE,
    INVITE_PAGE,
    RULES_PAGE,
    NONE,
}

@ccclass('LobbyEarn')
export class LobbyEarn extends cc.Component {
    @property({ type: cc.ToggleContainer, tooltip: "" })
    togContainer: cc.ToggleContainer = null;

    @property({ type: cc.Node, tooltip: "" })
    nodeContent: cc.Node = null;

    @property({ type: cc.Prefab, tooltip: "" })
    pfMyReward: cc.Prefab = null;

    @property({ type: cc.Prefab, tooltip: "" })
    pfInviteReward: cc.Prefab = null;

    @property({ type: cc.Prefab, tooltip: "" })
    pfRules: cc.Prefab = null;

    private _pageType: PageType = PageType.NONE;

    protected onLoad(): void {
        this.togContainer.toggleItems.forEach((tog, idx) => {
            tog.node.on(cc.Toggle.EventType.TOGGLE, () => {
                if (tog.isChecked) {
                    if (idx == PageType.REREWARD_PAGE) {
                        this.showMyRewardPage();
                    } else if (idx == PageType.INVITE_PAGE) {
                        this.showInviteRewardPage();
                    } else if (idx == PageType.RULES_PAGE) {
                        this.showRulesdPage();
                    }
                }
            })
        })

        this.showMyRewardPage();
    }

    protected onEnable(): void {
        this.togContainer.toggleItems[0].isChecked = true;
    }

    protected onDisable(): void {
        this._pageType = PageType.NONE;

        this.nodeContent.destroyAllChildren();
    }

    showMyRewardPage() {
        if (this._pageType == PageType.REREWARD_PAGE) {
            return;
        }
        this._pageType = PageType.REREWARD_PAGE;

        this.nodeContent.destroyAllChildren();
        let newNode = cc.instantiate(this.pfMyReward);
        this.nodeContent.addChild(newNode);
    }

    showInviteRewardPage() {
        if (this._pageType == PageType.INVITE_PAGE) {
            return;
        }

        this._pageType = PageType.INVITE_PAGE;

        this.nodeContent.destroyAllChildren();
        let newNode = cc.instantiate(this.pfInviteReward);
        this.nodeContent.addChild(newNode);
    }

    showRulesdPage() {
        if (this._pageType == PageType.RULES_PAGE) {
            return;
        }

        this._pageType = PageType.RULES_PAGE;

        this.nodeContent.destroyAllChildren();
        let newNode = cc.instantiate(this.pfRules);
        this.nodeContent.addChild(newNode);
    }
}