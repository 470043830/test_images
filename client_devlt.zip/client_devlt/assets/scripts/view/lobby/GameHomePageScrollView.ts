import * as cc from 'cc';
import { LOBBY_EVENT } from '../../framework/event/EventDefine';
import EventMgr from '../../framework/event/EventMgr';
import { Logger } from '../../framework/utils/Logger';
import GameModel, { GameIconProperty, GameIconStyle } from '../../model/GameModel';
import { GameHomePageItem } from './GameHomePageItem';
import GlobalModel from '../../model/GlobalModel';

const { ccclass, property } = cc._decorator;


/**
 * 游戏图标列表
 */
@ccclass('GameHomePageScrollView')
export class GameHomePageScrollView extends cc.Component {
    @property({ type: cc.ScrollView, tooltip: "滚动列表" })
    scrollView: cc.ScrollView = null;

    @property({ type: cc.Prefab, tooltip: "游戏大图标预制体" })
    pfItemL: cc.Prefab = null;

    @property({ type: cc.Prefab, tooltip: "游戏中图标预制体" })
    pfItemM: cc.Prefab = null;

    @property({ type: cc.Prefab, tooltip: "游戏小图标预制体" })
    pfItemS: cc.Prefab = null;

    private _curMoveIndex: number = 0;
    private _rowHeight: number = 230;               //行高

    protected onLoad(): void {
        this.bindEvent();
        this.requestGameInfo();
    }

    bindEvent() {
        EventMgr.Instance.on(LOBBY_EVENT.HALL_HOME_GAMES_INFO, this.onRecvHomeGamesInfo, this);
    }


    protected onDestroy(): void {
        EventMgr.Instance.offTarget(this);
    }

    requestGameInfo() {
    }

    protected start(): void {
        this.scheduleOnce(this.onScrolling);
    }

    initScrollView(data: Map<number, GameIconProperty[]>) {
        let lastItem = null;
        let lastStyle = -1;
        data.forEach((arr, k) => {
            //当前大类的所有子游戏，按顺序以大中小的形状展示
            for (let index = 0; index < arr.length; index++) {
                let e = arr[index];
                let pf = null;
                if (e.style == GameIconStyle.LARGE) {
                    pf = this.pfItemL;
                } else if (e.style == GameIconStyle.MIDDLE) {
                    pf = this.pfItemM;
                } else if (e.style == GameIconStyle.SMALL) {
                    pf = this.pfItemS;
                } else {
                    Logger.error(`game icon style can not find: ${e.style}`)
                    pf = this.pfItemL;
                }

                let newItem = null;
                if (!lastItem || lastStyle != e.style) {
                    newItem = cc.instantiate(pf);
                    this.scrollView.content.addChild(newItem);

                    lastItem = newItem;
                    lastStyle = e.style;
                } else {
                    newItem = lastItem;
                }

                let src: GameHomePageItem = newItem.getComponent(GameHomePageItem);
                src.addIcon(e);
                if (src.isFull()) {
                    //已满，则下次需要新建item
                    lastItem = null;
                }
            }
        })

        this.scrollView.node.on(cc.ScrollView.EventType.SCROLLING, this.onScrolling, this);
        this.scrollView.node.on(cc.ScrollView.EventType.SCROLL_ENDED, this.onScrollingEnded, this);
        // this.schedule(this.onScrolling, 0.2);
    }

    scrollToGameFilterOffset(v: number) {
        //遍历找到第一个与游戏筛选类型相等的的数据，计算Y轴所需偏移量
        let items = this.scrollView.content.children;
        let retIndex = -1;
        for (let index = 0; index < items.length; index++) {
            let src: GameHomePageItem = items[index].getComponent(GameHomePageItem);
            if (src.getGameFilterType() == v) {
                retIndex = index;
                break;
            }
        }

        if (retIndex < 0) {
            //没有找到相关类型的游戏
            Logger.debug(`没有找到相关类型的游戏: ${v}`)
            return;
        }

        let offset = this._rowHeight * retIndex;
        this.scrollView.scrollToOffset(cc.v2(0, offset), 0.1, false);
    }

    onClickGameIcon(v) {
        //跳转到游戏场景
        Logger.debug(`将跳转到游戏场景:`, JSON.stringify(v));
    }

    onScrolling() {
        let items = this.scrollView.content.children;
        let viewSize = this.scrollView.getComponent(cc.UITransform).contentSize;
        let itemHeight = this._rowHeight;
        let scrollOffsetY = this.scrollView.getScrollOffset().y;
        let maxShowItem = Math.ceil(viewSize.height / itemHeight);
        let moveIndex = Math.floor(scrollOffsetY / itemHeight);
        items.forEach((e, idx) => {
            if (idx == moveIndex && this._curMoveIndex != moveIndex) {
                if (!GlobalModel.Instance.homeGamesScrollByClick) {
                    EventMgr.Instance.emit(LOBBY_EVENT.SCROLL_TO_GAME_FILTER, e.getComponent(GameHomePageItem).getGameFilterType());
                }
                this._curMoveIndex = moveIndex;
            }

            if (idx < moveIndex) {
                //移到顶部之外的隐藏
                e.children[0].active = false;
            } else if (idx > moveIndex + maxShowItem) {
                //移到底部之外的隐藏
                e.children[0].active = false;
            } else {
                e.children[0].active = true;
            }
        })
    }

    onScrollingEnded() {
        GlobalModel.Instance.homeGamesScrollByClick = false;
    }

    onRecvHomeGamesInfo() {
        this.initScrollView(GameModel.Instance.homePageGames);
    }
}