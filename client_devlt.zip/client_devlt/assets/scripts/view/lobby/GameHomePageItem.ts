import * as cc from 'cc';
import { Logger } from '../../framework/utils/Logger';
import { GameIconProperty } from '../../model/GameModel';
import { GameIcon } from './GameIcon';

const { ccclass, property } = cc._decorator;



/**
 * 游戏一级页面列表item
 */
@ccclass('GameHomePageItem')
export class GameHomePageItem extends cc.Component {
    @property({ type: cc.Prefab, tooltip: "游戏一级图标" })
    pfGameIcon: cc.Prefab = null;

    @property({ type: cc.Node, tooltip: "图标父节点" })
    ndParent: cc.Node = null;

    @property({ type: Number, tooltip: "最大数量" })
    maxCount: number = 0;

    private _gameFilerType: number = -1;
    private _gameIcons: GameIcon[] = [];
    /**
     * 根据图标属性展示游戏图标
     */
    addIcon(v: GameIconProperty): boolean {
        if (this.isFull()) {
            return false;
        }

        if (this._gameFilerType != -1 && this._gameFilerType != v.gameFilter) {
            Logger.warning(`游戏类型不一样`)
            return false;
        }

        let newNode = cc.instantiate(this.pfGameIcon);
        this.ndParent.addChild(newNode);

        let src = newNode.getComponent(GameIcon);
        src.showIcon(v, v.clickBehavor);

        this._gameFilerType = v.gameFilter;
        this._gameIcons.push(src);

        return true;
    }

    clear() {
        this._gameIcons.forEach(e => {
            e.node.destroy();
        });

        this._gameIcons = [];
    }

    isFull(): boolean {
        return this._gameIcons.length >= this.maxCount;
    }

    isSameFilter(v: number) {
        if (this._gameFilerType != -1 && this._gameFilerType != v) {
            return false;
        }
        return true;
    }

    getGameFilterType(): number {
        return this._gameFilerType;
    }

    getMaxCount(): number {
        return this.maxCount;
    }
}