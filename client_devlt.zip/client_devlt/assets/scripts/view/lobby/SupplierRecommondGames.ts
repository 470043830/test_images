import * as cc from 'cc';
import { BaseUI } from '../../framework/base/BaseUI';
import { GameIcon } from './GameIcon';
import { EnumPrefab } from '../../config/BundleConfig';
import { UIMgr } from '../../framework/manager/UIMgr';
import { GameApp } from '../../lobby/GameApp';
import GameModel, { GameIconBehavor, GameIconProperty } from '../../model/GameModel';
import { LOBBY_EVENT } from '../../framework/event/EventDefine';
import EventMgr from '../../framework/event/EventMgr';
import GlobalModel from '../../model/GlobalModel';
import { GameHomePageItem } from './GameHomePageItem';
import { Logger } from '../../framework/utils/Logger';

const { ccclass, property } = cc._decorator;


/**
 * 二级页面的厂商推荐游戏
 */
@ccclass('SupplierRecommondGames')
export class SupplierRecommondGames extends BaseUI {
    @property({ type: cc.Button, tooltip: "更多游戏" })
    btnMore: cc.Button = null;

    @property({ type: cc.Node, tooltip: "标题根节点" })
    ndTitle: cc.Node = null;

    @property({ type: cc.Label, tooltip: "厂商名称" })
    labSupplierName: cc.Label = null;

    @property({ type: cc.ScrollView, tooltip: "游戏列表" })
    scrollView: cc.ScrollView = null;

    @property({ type: cc.Prefab, tooltip: "游戏列表-小图标" })
    pfIconS: cc.Prefab = null;

    @property({ type: cc.Prefab, tooltip: "游戏列表-中图标" })
    pfIconM: cc.Prefab = null;

    @property({ type: cc.Prefab, tooltip: "游戏列表-更多游戏图标" })
    pfMore: cc.Prefab = null;

    private _supplierID: number = 0;
    private _supplierName: string = "";

    protected initView(): void {
        this.btnMore.node.on(cc.Button.EventType.CLICK, this.onClickMore, this);


    }

    setSupplierInfo(id: number, name: string) {
        this._supplierID = id;
        this._supplierName = name;
        this.labSupplierName.string = name;
    }

    /**
     * 设置更多游戏的数量
     * @param amount 
     */
    setAllGames(amount: number) {
        this.btnMore.getComponentInChildren(cc.Label).string = `ALL ${amount}`;
    }

    initGameList(data: GameIconProperty[], supplierID: number, row: number, allGameCount: number = 10) {
        this.setAllGames(allGameCount);

        let supplierName = data[0] ? data[0].supplierName : "";
        this.setSupplierInfo(supplierID, supplierName);

        let cpData = data.slice();
        cpData.push(null);

        let pfHeight = 0;
        cpData.forEach((e, idx) => {
            let pf = this.pfIconS;
            if (!e) {
                pf = this.pfMore;
            }

            pfHeight = pf.data.getComponent(cc.UITransform).height;
            let newItem = cc.instantiate(pf);
            this.scrollView.content.addChild(newItem);

            let src = newItem.getComponent(GameIcon);
            src.showIcon(e, GameIconBehavor.ENTER_GAME, supplierID, supplierName);
        })

        //修正滚动列表的高度
        this.scrollView.content.getComponent(cc.Layout).constraintNum = row;
        let spcaceY = this.scrollView.content.getComponent(cc.Layout).spacingY
        let scrollSize = this.scrollView.getComponent(cc.UITransform).contentSize;
        let newHeight = pfHeight * row + (row - 1) * spcaceY;
        this.scrollView.getComponent(cc.UITransform).contentSize = cc.size(scrollSize.width, newHeight);

        //整个节点的大小
        let viewSize = this.node.getComponent(cc.UITransform).contentSize;
        this.node.getComponent(cc.UITransform).contentSize = cc.size(viewSize.width, newHeight + this.ndTitle.getComponent(cc.UITransform).height);
    }

    onClickMore() {
        //打开三级页面
        UIMgr.Instance.showView(EnumPrefab.allGamesOfSupplier, { supplierID: this._supplierID, supplierName: this._supplierName }, GameApp.Instance.getDialogLayer(), EnumPrefab.allGamesOfSupplier, false);
    }


}