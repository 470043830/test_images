import * as cc from 'cc';
import { BaseUI } from '../../framework/base/BaseUI';
import { Logger } from '../../framework/utils/Logger';
import { UIDefaultCtrl } from '../../framework/base/UIDefaultCtrl';
import AccountModel from '../../model/AccountModel';
import { Base64 } from '../../3rd/Base64';
import { ToastUIUtils } from '../../lobby/ToastUIUtils';
import GlobalModel from '../../model/GlobalModel';

const { ccclass, property } = cc._decorator;




/**
 * 进入游戏
 */
@ccclass('EnterGame')
export class EnterGame extends BaseUI {
    @property({ type: cc.Button, tooltip: "返回按钮" })
    btnBack: cc.Button = null;

    @property({ type: cc.Button, tooltip: "充值按钮" })
    btnDeposit: cc.Button = null;

    @property({ type: cc.WebView, tooltip: "游戏webview" })
    webView: cc.WebView = null;

    @property({ type: cc.Node, tooltip: "loading" })
    ndLoading: cc.Node = null;

    protected initView(): void {
        this.btnBack.node.on(cc.Button.EventType.CLICK, this.onClickBack, this);
        this.btnDeposit.node.on(cc.Button.EventType.CLICK, this.onClickDeposit, this);

        this.playLoadingAnim();

        this.webView.node.on(cc.WebView.EventType.LOADED, this.onLoadEnd, this);
        this.webView.node.on(cc.WebView.EventType.ERROR, this.onLoadError, this);

        let gameParam = this.getComponent(UIDefaultCtrl).viewParam;
        if (gameParam) {
            let args = `pid=${AccountModel.Instance.userId}&token=${AccountModel.Instance.token}&supplierID=${gameParam.supplierID}`;
            let base64Code = Base64.encode(args);

            // http://game.91wan.club/game/x001/index.html
            this.webView.url = `${gameParam.gameID}?data=${base64Code}`;
            Logger.info(`game url: `, this.webView.url);
            Logger.info(`game args: `, args);
        } else {

            this.onLoadError();
        }
    }

    protected onDestroy(): void {
        super.onDestroy();

        GlobalModel.Instance.isSubGameOpened = false;
    }

    playLoadingAnim() {
        this.ndLoading.active = true;
        cc.tween(this.ndLoading)
            .repeatForever(
                cc.tween(this.ndLoading)
                    .to(0.5, { scale: cc.v3(0, 1, 1) }, { easing: cc.easing.sineOut })
                    .delay(0.2)
                    .to(0.5, { scale: cc.v3(1, 1, 1) }, { easing: cc.easing.sineOut })
            )
            .start()
    }

    stopLoadingAnim() {
        cc.Tween.stopAllByTarget(this.ndLoading)
        this.ndLoading.active = false;
    }

    onClickBack() {
        this.onClose();
    }

    onClickDeposit() {
        Logger.info(`打开充值页面`)
    }

    onLoadEnd() {
        this.stopLoadingAnim();
    }

    onLoadError() {
        this.stopLoadingAnim();
        this.webView.url = ``;
        this.webView.destroy();

        ToastUIUtils.openEnterGameFailedUI(() => {
            this.onClose();
        })
    }

}