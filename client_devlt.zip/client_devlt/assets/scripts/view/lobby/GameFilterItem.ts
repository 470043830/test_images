import * as cc from 'cc';
import { LOBBY_EVENT } from '../../framework/event/EventDefine';
import EventMgr from '../../framework/event/EventMgr';
import { loadRemoteImg } from '../../framework/lib/GlobalFunc';
import GlobalModel from '../../model/GlobalModel';
import { AppConfig, gameConfig } from '../../config/Config';

const { ccclass, property } = cc._decorator;

@ccclass('GameFilterItem')
export class GameFilterItem extends cc.Component {
    @property({ type: cc.Sprite, tooltip: "未选中" })
    spriteNor: cc.Sprite = null;

    @property({ type: cc.Sprite, tooltip: "选中" })
    spriteSel: cc.Sprite = null;

    private _filterType: number = -1;
    private _clickCallback: Function = null;
    private _sortId: number = 0;

    protected onLoad(): void {
        this.node.on(cc.Button.EventType.CLICK, this.onClick, this);
        this.node.getComponent(cc.Button).zoomScale = 1.05;
        EventMgr.Instance.on(LOBBY_EVENT.SCROLL_TO_GAME_FILTER, this.onScrollTo, this);
    }

    protected onDestroy(): void {
        EventMgr.Instance.offTarget(this);
    }

    setInfo(urlN: string, urlS: string) {
        let host = gameConfig.remote_url + "gameIcons/";
        loadRemoteImg(this.spriteNor, host + urlS);
        loadRemoteImg(this.spriteSel, host + urlN);
    }


    /**
     * 
     * @param selected 是否选中
     */
    setSelected(selected: boolean) {
        this.spriteNor.node.active = !selected;
        this.spriteSel.node.active = selected;
    }

    setFilterType(v: number) {
        this._filterType = v;
    }

    getFilterType(): number {
        return this._filterType;
    }

    setClickCallback(callback: Function) {
        this._clickCallback = callback;
    }

    onClick() {
        GlobalModel.Instance.homeGamesScrollByClick = true;
        if (this._clickCallback) {
            this._clickCallback(this._filterType);
        }
    }

    onScrollTo(gameFilter: number) {
        // Logger.debug(`选中:${data.gameFilter}`);
        this.setSelected(this._filterType == gameFilter);
    }

    setSortID(v: number) {
        this._sortId = v;
    }

    getSortID(): number {
        return this._sortId;
    }
}