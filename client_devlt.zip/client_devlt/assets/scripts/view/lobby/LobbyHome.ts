import * as cc from 'cc';
import { Logger } from '../../framework/utils/Logger';
import { GameFilterScrollView } from './GameFilterScrollView';
import { GameHomePageScrollView } from './GameHomePageScrollView';
import AccountModel from '../../model/AccountModel';
import EventMgr from '../../framework/event/EventMgr';
import { LOBBY_EVENT } from '../../framework/event/EventDefine';
import { INR } from '../../Const';
const { ccclass, property } = cc._decorator;

/**
 * 
 * HOME页签
 */

@ccclass('LobbyHome')
export class LobbyHome extends cc.Component {
    @property({ type: cc.Label, tooltip: "用户名称" })
    labUserName: cc.Label = null;

    @property({ type: cc.Label, tooltip: "用户VIP等级" })
    labVipLvl: cc.Label = null;

    @property({ type: cc.Label, tooltip: "用户金钱" })
    labCash: cc.Label = null;

    @property({ type: cc.Sprite, tooltip: "用户头像" })
    spAvatar: cc.Sprite = null;

    @property({ type: cc.Button, tooltip: "充值按钮" })
    btnRecharge: cc.Button = null;

    @property({ type: cc.Button, tooltip: "withdraw按钮" })
    btnWithDraw: cc.Button = null;

    @property({ type: cc.PageView, tooltip: "轮播页面" })
    pageView: cc.PageView = null;

    @property({ type: GameFilterScrollView, tooltip: "游戏筛选组件" })
    filterScrollView: GameFilterScrollView = null;

    @property({ type: GameHomePageScrollView, tooltip: "游戏图标组件" })
    GameHomePageScrollView: GameHomePageScrollView = null;

    protected onLoad(): void {
        this.btnRecharge.node.on(cc.Button.EventType.CLICK, this.onClickRecharge, this);
        this.btnWithDraw.node.on(cc.Button.EventType.CLICK, this.onClickWithDraw, this);

        this.bindEvent();
        this.initPageView();
        this.initGameLayer();
        this.updateUserInfo();
    }

    bindEvent() {
        EventMgr.Instance.on(LOBBY_EVENT.ACCOUNT_UPDATE_MY_INFO, this.updateUserInfo, this);
    }

    protected onDestroy(): void {
        EventMgr.Instance.offTarget(this);
    }

    /**
     * 初始化轮播页面
     */
    initPageView() {
        let pages = this.pageView.content.children;
        let index = this.pageView.curPageIdx;
        cc.tween(this.pageView)
            .repeatForever(
                cc.tween()
                    .delay(1)
                    .call(() => {
                        index++;
                        index %= pages.length;
                        this.pageView.scrollToPage(index);
                    })
            )
            .start();
    }

    onClickRecharge() {
        Logger.debug(`点击了recharge`);
    }

    onClickWithDraw() {
        Logger.debug(`点击了withdraw`);
    }


    /**
     * 初始化游戏选择页面
     */
    initGameLayer() {
        this.filterScrollView.setClickFunc(this.onClickGameFilterButton.bind(this));
    }


    /**
     * 点击了游戏类型筛选按钮，游戏图标滚动层滚动到指定的位置
     */
    onClickGameFilterButton(v: number) {
        this.GameHomePageScrollView.scrollToGameFilterOffset(v);
    }

    /**
     * 更新用户数据
     */
    updateUserInfo() {
        this.labUserName.string = AccountModel.Instance.userName;
        this.labVipLvl.string = "VIP" + AccountModel.Instance.vipLevel.toString();
        this.labCash.string = INR + AccountModel.Instance.cash.toString();

        let self = this;
        let avatarUrl = "https://q3.itc.cn/q_70/images03/20250110/1e71eecf56b34344bcae6a5b85c0bec2.jpeg";
        cc.assetManager.loadRemote(avatarUrl, null, (err, data: cc.Texture2D) => {
            if (!err) {
                if (data) {
                    let frame = cc.SpriteFrame.createWithImage(data as any);
                    self.spAvatar.spriteFrame = frame;
                }
            } else {
                console.log("头像下载失败", avatarUrl)
            }
        })
    }


}