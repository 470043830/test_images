import * as cc from 'cc';
import { LobbyPageType } from '../../Const';
import EventMgr from '../../framework/event/EventMgr';
import { LOBBY_EVENT } from '../../framework/event/EventDefine';
import { LobbyHome } from './LobbyHome';
import { LobbyEarn } from './LobbyEarn';
import { LobbyMine } from './LobbyMine';
import { LobbyGetMoney } from './LobbyGetMoney';
import { LobbyPromo } from './LobbyPromo';
import { EnumPrefab } from '../../config/BundleConfig';
import { UIMgr } from '../../framework/manager/UIMgr';
import { GameApp } from '../../lobby/GameApp';
import { HallReqManager } from '../../framework/net/HallReqManager';

const { ccclass, property } = cc._decorator;

/**
 * 大厅主页面
 */
@ccclass('LobbyMain')
export class LobbyMain extends cc.Component {
    @property({ type: cc.Prefab, tooltip: "LobbyHome" })
    pfLobbyHome: cc.Prefab = null;

    @property({ type: cc.Prefab, tooltip: "pfLobbyPromo" })
    pfLobbyPromo: cc.Prefab = null;

    @property({ type: cc.Prefab, tooltip: "pfLobbyEarn" })
    pfLobbyEarn: cc.Prefab = null;

    @property({ type: cc.Prefab, tooltip: "pfLobbyGetMoney" })
    pfLobbyGetMoney: cc.Prefab = null;

    @property({ type: cc.Prefab, tooltip: "pfLobbyMine" })
    pfLobbyMine: cc.Prefab = null;

    @property({ type: cc.Node, tooltip: "home页面父节点" })
    viewHome: cc.Node = null;

    @property({ type: cc.Node, tooltip: "promo页面父节点" })
    viewPromo: cc.Node = null;

    @property({ type: cc.Node, tooltip: "getMoney页面父节点" })
    viewGetMoney: cc.Node = null;

    @property({ type: cc.Node, tooltip: "match页面父节点" })
    viewMatch: cc.Node = null;

    @property({ type: cc.Node, tooltip: "mine页面父节点" })
    viewMine: cc.Node = null;

    @property({ type: cc.Button, tooltip: "mail btn" })
    mailBtn: cc.Button = null;

    private _homeView: LobbyHome = null;
    private _promoView: LobbyPromo = null;
    private _matchView: LobbyEarn = null;
    private _mineView: LobbyMine = null;
    private _getMoneyView: LobbyGetMoney = null;


    protected onLoad(): void {
        EventMgr.Instance.on(LOBBY_EVENT.SWICH_LOBBY_VIEW, this.onSwithToPage, this);
        this.mailBtn.node.on(cc.Button.EventType.CLICK, this.onClickMailBtn, this);
        this.showHomeView(true);
    }

    protected onDestroy(): void {
        EventMgr.Instance.offTarget(this);
    }

    onSwithToPage(v: LobbyPageType) {
        [
            this.showHomeView.bind(this),
            this.showPromoView.bind(this),
            this.showMathView.bind(this),
            this.showMineView.bind(this),
            this.showGetMoneyView.bind(this),
        ].forEach((callFunc, idx) => {
            callFunc(idx == v);
        })
    }

    showHomeView(v: boolean) {
        if (!this._homeView) {
            let node = cc.instantiate(this.pfLobbyHome);
            this.viewHome.addChild(node);
            this._homeView = node.getComponent(LobbyHome);
        }

        this._homeView.node.active = v;
    }

    showPromoView(v: boolean) {
        if (!this._promoView) {
            let node = cc.instantiate(this.pfLobbyPromo);
            this.viewPromo.addChild(node);
            this._promoView = node.getComponent(LobbyPromo);
        }

        this._promoView.node.active = v;
    }

    showMathView(v: boolean) {
        if (!this._matchView) {
            let node = cc.instantiate(this.pfLobbyEarn);
            this.viewMatch.addChild(node);
            this._matchView = node.getComponent(LobbyEarn);
        }

        this._matchView.node.active = v;
    }

    showMineView(v: boolean) {
        if (!this._mineView) {
            let node = cc.instantiate(this.pfLobbyMine);
            this.viewMine.addChild(node);
            this._mineView = node.getComponent(LobbyMine);
        }

        this._mineView.node.active = v;
    }

    showGetMoneyView(v: boolean) {
        if (!this._getMoneyView) {
            let node = cc.instantiate(this.pfLobbyGetMoney);
            this.viewGetMoney.addChild(node);
            this._getMoneyView = node.getComponent(LobbyGetMoney);
        }

        this._getMoneyView.node.active = v;
    }

    onClickMailBtn() {
        UIMgr.Instance.showView(EnumPrefab.mailMain, null, GameApp.Instance.getDialogLayer(), EnumPrefab.mailMain, false);
    }
}