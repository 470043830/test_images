import * as cc from 'cc';
import { GameIconBehavor, GameIconProperty } from '../../model/GameModel';
import { Logger } from '../../framework/utils/Logger';
import { EnumPrefab } from '../../config/BundleConfig';
import { UIMgr } from '../../framework/manager/UIMgr';
import { GameApp } from '../../lobby/GameApp';
import { loadRemoteImg } from '../../framework/lib/GlobalFunc';
import { HallReqManager } from '../../framework/net/HallReqManager';
import { AppConfig, gameConfig } from '../../config/Config';
import GlobalModel from '../../model/GlobalModel';

const { ccclass, property } = cc._decorator;

/**
 * 游戏图标
 */
@ccclass('GameIcon')
export class GameIcon extends cc.Component {
    @property({ type: cc.Sprite, tooltip: "游戏图标" })
    spGameIcon: cc.Sprite = null;

    @property({ type: cc.Sprite, tooltip: "游戏标签" })
    spGameTag: cc.Sprite = null;

    @property({ type: cc.SpriteFrame, tooltip: "游戏标签" })
    tagFrames: cc.SpriteFrame[] = [];

    @property({ type: cc.Label, tooltip: "游戏名称/厂商名称" })
    labGameName: cc.Label = null;

    @property({ type: cc.Label, tooltip: "分类名称" })
    labGameType: cc.Label = null;

    @property({ type: cc.CCBoolean, tooltip: "点击是否打开更多游戏" })
    isMore: boolean = false;

    private _iconProp: GameIconProperty = null;
    private _clikBehavor: GameIconBehavor = GameIconBehavor.ENTER_RECOMMEND_PAGE
    private _supplierID: number = -1;       //厂商ID
    private _supplierName: string = "";       //厂商名称

    protected onLoad(): void {
        this.node.on(cc.Button.EventType.CLICK, this.onClickIcon, this);
    }

    onClickIcon() {
        if (GlobalModel.Instance.isSubGameOpened) {
            return;
        }

        if (this.isMore) {
            //打开三级页面
            UIMgr.Instance.showView(EnumPrefab.allGamesOfSupplier, { supplierID: this._supplierID, supplierName: this._supplierName }, GameApp.Instance.getDialogLayer(), EnumPrefab.allGamesOfSupplier, false);
            return;
        }

        if (!this._iconProp) {
            return;
        }

        //点击事件：跳转到二级或者三级游戏厂商页面，或者直接加载游戏
        if (this._clikBehavor == GameIconBehavor.ENTER_RECOMMEND_PAGE) {
            //打开二级游戏列表页面
            UIMgr.Instance.showView(EnumPrefab.gameRecommendPage, { supplierName: this._iconProp.supplierName }, GameApp.Instance.getDialogLayer(), EnumPrefab.gameRecommendPage, false);

            //请求数据指定分类
            HallReqManager.sendHallGameType(Number(this._iconProp.jumpValue));
        } else if (this._clikBehavor == GameIconBehavor.ENTER_GAME) {
            //加载游戏
            Logger.debug(`======> 加载游戏: ${this._iconProp.jumpValue}`);
            GlobalModel.Instance.isSubGameOpened = true;
            UIMgr.Instance.showView(EnumPrefab.enterGame, { gameID: this._iconProp.jumpValue, supplierID: this._iconProp.supplierID }, GameApp.Instance.getDialogLayer(), EnumPrefab.enterGame, false);
        }
    }

    /**
     * 根据图标属性展示游戏图标
     */
    showIcon(v: GameIconProperty, behavor: GameIconBehavor, supplierID: number = -1, supplierName: string = "") {
        this._clikBehavor = behavor;
        this._supplierID = supplierID;
        this._supplierName = supplierName;

        if (!v) return;

        this._iconProp = v;

        //加载远程图标
        loadRemoteImg(this.spGameIcon, gameConfig.remote_url + "gameIcons/" + v.spriteUrl, () => {
            let logo = this.spGameIcon.getComponentInChildren(cc.Sprite);
            if (logo) {
                logo.node.active = false;
            }
        });
        // loadRemoteImg(this.spGameIcon, v.spriteUrl);

        //标签
        if (this.spGameTag) {
            let frame = this.tagFrames[v.tag - 1];
            if (frame) {
                this.spGameTag.spriteFrame = frame;
                this.spGameTag.node.active = true;
            } else {
                this.spGameTag.node.active = false;
            }
        }

        //游戏名称或者厂商名称，不存在则隐藏，降低dc
        if (this.labGameName) {
            this.labGameName.string = v.supplierName;
            this.labGameName.node.active = (v.supplierName != "");
        }

        if (this.labGameType) {
            this.labGameType.string = `${v.gameFilter}`;
        }
    }

    getItemData(): GameIconProperty {
        // Logger.debug(`icon filter: `, this._iconProp.gameFilter);
        return this._iconProp;
    }

}