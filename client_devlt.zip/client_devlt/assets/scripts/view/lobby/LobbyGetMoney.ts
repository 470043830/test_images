import * as cc from 'cc';
const { ccclass, property } = cc._decorator;

/**
 * 
 * LobbyGetMoney
 * LobbyGetMoney
 * chonger8888
 * Sun Sep 28 2025 11:56:57 GMT+0800 (中国标准时间)
 * LobbyGetMoney.ts
 * LobbyGetMoney
 * <%URL%>
 * https://docs.cocos.com/creator/3.8/manual/zh/
 *
 */

@ccclass('LobbyGetMoney')
export class LobbyGetMoney extends cc.Component {
    @property({ type: cc.Node, tooltip: "" })
    node: cc.Node = null;

    onLoad(){

    }

    start() {

    }

    update(deltaTime: number) {
        
    }
}