/**
 * 新消息红点组件
 */
import * as cc from 'cc';
import EventMgr from '../framework/event/EventMgr';
import { LOBBY_EVENT } from '../framework/event/EventDefine';
import AccountModel from '../model/AccountModel';

const { ccclass, property } = cc._decorator;

enum RedPontID {
    None,
    BindPhoneEnable,                //是否可以绑定手机号码
    LoginPWSetingEnable,            //是否可以设置登录密码
    BindInviteCodeEnable,           //是否可以绑定邀请码
    Max
}

@ccclass('RedpointComponent')
export class RedpointComponent extends cc.Component {
    @property({ type: cc.Enum(RedPontID) })
    ID: RedPontID = RedPontID.None;

    events: Map<number, []> = new Map<number, []>();

    onLoad() {
        this.registEvent();

        this.onUpdateBindPhone();
        this.onUpdateLoginPassword();
    }

    onDestroy() {
        EventMgr.Instance.offTarget(this);
    }

    initEvent() {
        this.events[RedPontID.BindPhoneEnable] = [
            { e: LOBBY_EVENT.ACCOUNT_BINDPHONE_RET, cb: this.onUpdateBindPhone },                       //绑定手机成功
        ];

        this.events[RedPontID.LoginPWSetingEnable] = [
            { e: LOBBY_EVENT.ACCOUNT_BINDPHONE_RET, cb: this.onUpdateLoginPassword },                   //绑定手机成功
            { e: LOBBY_EVENT.ACCOUNT_MODIFY_PW, cb: this.onUpdateLoginPassword },                       //设置/修改登录密码成功
        ];

        this.events[RedPontID.BindInviteCodeEnable] = [
            { e: LOBBY_EVENT.ACCOUNT_BIND_INVITE_CODE, cb: this.onUpdateBindInviteCode },               //绑定邀请码成功
        ];
    }

    registEvent() {
        this.initEvent();
        let events = this.events[this.ID];
        if (events && events.length > 0) {
            events.forEach((e: any) => {
                EventMgr.Instance.on(e.e, e.cb, this);
            })
        }
    }

    /**
     * 是否可以绑定手机
     * @param eventID 
     * @param pData 
     * @returns 
     */
    onUpdateBindPhone(eventID = -1, pData = null) {
        if (this.ID != RedPontID.BindPhoneEnable) {
            return;
        }

        this.node.active = AccountModel.Instance.bindPhoneNum == "";
    }

    /**
     * 是否可以修改/设置登录密码
     */
    onUpdateLoginPassword(eventID = -1, pData = null) {
        if (this.ID != RedPontID.LoginPWSetingEnable) {
            return;
        }
        this.node.active = (AccountModel.Instance.bindPhoneNum != "" && AccountModel.Instance.passWord == "");
    }

    /**
     * 是否可以绑定邀请码
     * @param eventID 
     * @param pData 
     */
    onUpdateBindInviteCode(eventID = -1, pData = null) {
        if (this.ID != RedPontID.BindInviteCodeEnable) {
            return;
        }
        this.node.active = (AccountModel.Instance.inviteCode == "");
    }

}