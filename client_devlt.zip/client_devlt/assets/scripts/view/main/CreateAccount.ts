import * as cc from 'cc';
import { BaseUI } from '../../framework/base/BaseUI';
import AccountModel from '../../model/AccountModel';
import { Logger } from '../../framework/utils/Logger';
import { LoginMgr } from '../../framework/manager/LoginMgr';
import { LoginType } from '../../Const';

const { ccclass, property } = cc._decorator;


const account_key = `Acc`;

/**
 * 创建账号（仅限web版本）
 */
@ccclass('CreateAccount')
export class CreateAccount extends BaseUI {
    @property({ type: cc.Button, tooltip: "关闭按钮" })
    btnClose: cc.Button = null;

    @property({ type: cc.Button, tooltip: "创建按钮" })
    btnCreate: cc.Button = null;

    @property({ type: cc.ScrollView, tooltip: "账户列表" })
    scrollView: cc.ScrollView = null;

    @property({ type: cc.Node, tooltip: "列表item" })
    accountItem: cc.Node = null;

    @property({ type: cc.EditBox, tooltip: "设备号输入" })
    editDeviceID: cc.EditBox = null;


    initView(): void {
        this.btnClose.node.on(cc.Button.EventType.CLICK, this.onClikClosed, this);
        this.btnCreate.node.on(cc.Button.EventType.CLICK, this.onClickCreate, this);

        this.initAccountList();
    }

    initAccountList() {
        //读取本地
        this.scrollView.content.destroyAllChildren();
        let localAcc = cc.sys.localStorage.getItem(account_key);
        if (localAcc && localAcc != "") {
            let accList = JSON.parse(localAcc);
            accList.forEach(e => {
                let newItem = cc.instantiate(this.accountItem);
                this.scrollView.content.addChild(newItem);
                newItem.active = true;

                console.log(`账户:`, e);
                newItem.getComponentInChildren(cc.Label).string = e;
                newItem.on(cc.Button.EventType.CLICK, () => {
                    //以当前账户登录
                    AccountModel.Instance.customDeviceID = e;
                    this.login();
                })
            })
        }

        this.accountItem.active = false;
    }

    onClikClosed() {
        this.onClose();
    }

    onClickCreate() {
        let newAcc = this.editDeviceID.string;
        if (newAcc != "") {
            AccountModel.Instance.customDeviceID = newAcc;

            let accList = [];
            let localAcc = cc.sys.localStorage.getItem(account_key);
            if (localAcc && localAcc != "") {
                accList = JSON.parse(localAcc);
            }
            if (accList.indexOf(newAcc) < 0) {
                accList.push(newAcc);
                cc.sys.localStorage.setItem(account_key, JSON.stringify(accList));
                this.initAccountList();
            }


            //登录
            this.login();

        }
    }

    login() {
        Logger.info(`自定义设备号: ${AccountModel.Instance.customDeviceID}`);
        LoginMgr.Instance.login(LoginType.Guest, AccountModel.Instance.customDeviceID)
        this.onClose();
    }
}