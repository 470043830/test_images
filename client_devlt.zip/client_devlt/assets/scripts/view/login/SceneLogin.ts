import * as cc from 'cc';
import { BaseScene } from '../../framework/base/BaseScene';
import { EnumPrefab } from '../../config/BundleConfig';
import { UIMgr } from '../../framework/manager/UIMgr';

const { ccclass, property } = cc._decorator;

/**
 *  登录场景
 */

@ccclass('SceneLogin')
export class SceneLogin extends BaseScene {
    protected initView(): void {
        UIMgr.Instance.showView(EnumPrefab.signIn, null, this.getGameLayer(), EnumPrefab.signIn, false);
    }



}

