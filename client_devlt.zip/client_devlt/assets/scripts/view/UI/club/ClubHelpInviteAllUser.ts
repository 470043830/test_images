import * as cc from 'cc';
import { BaseUI } from '../../../framework/base/BaseUI';
import { CommRulesView } from '../../../framework/lib/CommRulesView';
import { RulePageID } from '../../../model/RuleModel';

const { ccclass, property } = cc._decorator;


/**
 * 邀请满员规则
 */
@ccclass('ClubHelpInviteAllUser')
export class ClubHelpInviteAllUser extends BaseUI {
    @property({ type: cc.Button, tooltip: "返回按钮" })
    btnBack: cc.Button = null;

    @property({ type: cc.Node, tooltip: "内容父节点" })
    ndContent: cc.Node = null;

    @property({ type: cc.Prefab, tooltip: "通用规则预制体" })
    pfCommRule: cc.Prefab = null;


    onLoad(): void {
        let ruleView = cc.instantiate(this.pfCommRule);
        this.ndContent.addChild(ruleView);
        let commRuleComp = ruleView.getComponent(CommRulesView);
        commRuleComp.initView(RulePageID.RULE_PAGE_CLUB);

        this.btnBack.node.on(cc.Button.EventType.CLICK, this.onClose, this);
    }
}