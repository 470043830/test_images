import * as cc from 'cc';
import ClubModel, { } from '../../../model/ClubModel';
import { INR } from '../../../Const';

const { ccclass, property } = cc._decorator;


/**
 * 邀请进度
 */
@ccclass('ClubInviteTaskView')
export class ClubInviteTaskView extends cc.Component {
    @property({ type: cc.Layout, tooltip: "奖励进度Layout" })
    LayoutTask: cc.Layout = null;

    @property({ type: cc.Node, tooltip: "奖励进度item" })
    inviteProgressItem: cc.Node = null;

    @property({ type: cc.ProgressBar, tooltip: "邀请进度" })
    barInvite: cc.ProgressBar = null;

    @property({ type: cc.SpriteFrame, tooltip: "任务图标集合" })
    framesTaskIcon: cc.SpriteFrame[] = [];

    initView() {
        this.barInvite.node.active = false;
        this.inviteProgressItem.active = false;

        let info = ClubModel.Instance.getInviteInfo();
        if (!info) {
            return;
        }

        info.cfg.forEach((e, idx) => {
            let item = cc.instantiate(this.inviteProgressItem);
            this.LayoutTask.node.addChild(item);
            item.active = true;

            item.getComponentInChildren(cc.Sprite).spriteFrame = this.framesTaskIcon[idx % this.framesTaskIcon.length];
            item.getChildByName(`LabelReward`).getComponent(cc.Label).string = INR + e.rewards;
            item.getComponentInChildren(cc.Label).string = INR + e.rewards;
            item.getComponentInChildren(cc.RichText).string = `<color=#ffffff>${info.curInviteAmount}</color><color=#AC5555>/${e.needInvite}</color>`
        })

        this.barInvite.node.active = info.cfg.length > 1;
        this.barInvite.progress = info.curInviteAmount / info.MaxNeedInvite;
        let itemWidth = this.inviteProgressItem.getComponent(cc.UITransform).width;
        let barSize = this.barInvite.getComponent(cc.UITransform).contentSize;
        let barWidth = info.cfg.length * itemWidth - itemWidth;
        this.barInvite.getComponent(cc.UITransform).contentSize = cc.size(barWidth, barSize.height);
        this.barInvite.totalLength = barWidth;

        this.LayoutTask.updateLayout(true);

        let viewSize = this.node.getComponent(cc.UITransform).contentSize;
        this.node.getComponent(cc.UITransform).contentSize = cc.size(this.LayoutTask.getComponent(cc.UITransform).contentSize.width, viewSize.height)
    }

}