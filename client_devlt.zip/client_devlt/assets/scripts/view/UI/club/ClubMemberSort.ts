import * as cc from 'cc';
import { MemberSortType } from '../../../Const';

const { ccclass, property } = cc._decorator;


/**
 * 成员排序按钮
 */
@ccclass('ClubMemberSort')
export class ClubMemberSort extends cc.Component {
    @property({ type: cc.Label, tooltip: "过滤描述" })
    labDesc: cc.Label = null;

    @property({ type: cc.Color, tooltip: "过滤描述颜色" })
    labColor: cc.Color[] = [];

    @property({ type: cc.Node, tooltip: "未过滤状态" })
    stFilterN: cc.Node = null;

    @property({ type: cc.Node, tooltip: "升序过滤状态" })
    stFilterUp: cc.Node = null;

    @property({ type: cc.Node, tooltip: "降序过滤状态" })
    stFilterDown: cc.Node = null;

    @property({ type: cc.Enum(MemberSortType), tooltip: "过滤类型" })
    sortType: MemberSortType = MemberSortType.NONE;

    private _clickFunc = null;
    private _isDesc: boolean = true;           //是否降序

    onLoad(): void {
        this.node.on(cc.Button.EventType.CLICK, this.onClick, this);
    }

    resetState() {
        this.labDesc.color = this.labColor[0];
        this.stFilterN.active = true;
        this.stFilterUp.active = false;
        this.stFilterDown.active = false;
        this._isDesc = false;
    }

    getSortType() {
        return this.sortType;
    }

    /**
     * 设置是否降序排序
     * @param desc 
     */
    setDescState(desc: boolean) {
        this.labDesc.color = this.labColor[1];
        this.stFilterN.active = false;
        this.stFilterUp.active = !desc;
        this.stFilterDown.active = desc;
        this._isDesc = desc;
    }

    isSortByDesc(): boolean {
        return this._isDesc;
    }

    setClickFunc(v) {
        this._clickFunc = v;
    }

    onClick() {
        this._isDesc = !this._isDesc;
        this.setDescState(this._isDesc);
        this._clickFunc && this._clickFunc(this._isDesc);
    }

}