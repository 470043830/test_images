import * as cc from 'cc';
import { CommRulesView } from '../../../framework/lib/CommRulesView';
import { RulePageID } from '../../../model/RuleModel';

const { ccclass, property } = cc._decorator;


/**
 * 俱乐部规则
 */
@ccclass('ClubRule')
export class ClubRule extends cc.Component {
    @property({ type: cc.Prefab, tooltip: "通用规则预制体" })
    pfCommRule: cc.Prefab = null;


    onLoad(): void {
        let ruleView = cc.instantiate(this.pfCommRule);
        this.node.addChild(ruleView);
        let commRuleComp = ruleView.getComponent(CommRulesView);
        commRuleComp.initView(RulePageID.RULE_PAGE_CLUB);
    }

}