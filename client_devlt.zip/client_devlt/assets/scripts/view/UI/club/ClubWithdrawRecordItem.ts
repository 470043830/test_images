import * as cc from 'cc';
import { IComListItem } from '../../../framework/lib/ComListView';
import { StringUtils } from '../../../framework/utils/StringUtils';
import { RewardHistoryInfo } from '../../../model/ClubModel';
import { INR } from '../../../Const';

const { ccclass, property } = cc._decorator;


/**
 * 提现历史记录条目
 */
@ccclass('ClubWithdrawRecordItem')
export class ClubWithdrawRecordItem extends cc.Component implements IComListItem {
    @property({ type: cc.Label, tooltip: "时间" })
    labTime: cc.Label = null;

    @property({ type: cc.Label, tooltip: "佣金数量" })
    labCommission: cc.Label = null;

    @property({ type: cc.Node, tooltip: "Succ" })
    ndSucc: cc.Node = null;

    @property({ type: cc.Node, tooltip: "Pending" })
    ndPending: cc.Node = null;

    @property({ type: cc.Node, tooltip: "TimeOut" })
    ndTimeout: cc.Node = null;


    updateItem(idx: number, data: RewardHistoryInfo, dataExt: any) {
        this.labTime.string = StringUtils.dateFormat("yyyy-MM-dd HH:mm:ss", new Date(data.time));
        this.labCommission.string = `TotalCommission:` + INR + data.commission;
        this.ndSucc.active = data.status == 0;
        this.ndPending.active = data.status == 1;
        this.ndTimeout.active = data.status == 2;
    }

}