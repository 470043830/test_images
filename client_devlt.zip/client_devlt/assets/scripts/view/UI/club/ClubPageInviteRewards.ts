import * as cc from 'cc';
import EventMgr from '../../../framework/event/EventMgr';
import ClubModel, { ClubHistoryType } from '../../../model/ClubModel';
import { INR } from '../../../Const';
import { EnumPrefab } from '../../../config/BundleConfig';
import { UIMgr } from '../../../framework/manager/UIMgr';
import { GameApp } from '../../../lobby/GameApp';
import { HallReqManager } from '../../../framework/net/HallReqManager';
import { LOBBY_EVENT } from '../../../framework/event/EventDefine';
import { ClubInviteTaskView } from './ClubInviteTaskView';

const { ccclass, property } = cc._decorator;


/**
 * 邀请奖励信息
 */
@ccclass('ClubPageInviteRewards')
export class ClubPageInviteRewards extends cc.Component {
    @property({ type: cc.Label, tooltip: "总奖励" })
    labTotalReward: cc.Label = null;

    @property({ type: cc.Label, tooltip: "总邀请数量" })
    labTotalInvite: cc.Label = null;

    @property({ type: cc.Label, tooltip: "邀请新用户奖励" })
    labNewerReward: cc.Label = null;

    @property({ type: cc.Label, tooltip: "每次邀请奖励" })
    labEachReward: cc.Label = null;

    @property({ type: cc.Label, tooltip: "需要邀请的数量" })
    labNeedInvite: cc.Label = null;

    @property({ type: cc.Label, tooltip: "邀请300个奖励" })
    lab300Reward: cc.Label = null;

    @property({ type: cc.Label, tooltip: "每日邀请上限" })
    labDailyLimit: cc.Label = null;

    @property({ type: cc.Label, tooltip: "总共邀请tips" })
    labTotalHelpTips: cc.Label = null;

    @property({ type: cc.Button, tooltip: "邀请按钮" })
    btnInvite: cc.Button = null;

    @property({ type: cc.Button, tooltip: "奖励历史记录" })
    btnRewardHistory: cc.Button = null;

    @property({ type: cc.Button, tooltip: "俱乐部详情" })
    btnClubDetail: cc.Button = null;

    @property({ type: cc.Button, tooltip: "总邀请帮助按钮" })
    btnHelpTotalInvite: cc.Button = null;

    @property({ type: cc.Button, tooltip: "邀请新人帮助按钮" })
    btnHelpNewerInvite: cc.Button = null;

    @property({ type: cc.Button, tooltip: "邀请300帮助按钮" })
    btnHelp300Invite: cc.Button = null;


    @property({ type: cc.Node, tooltip: "总邀请帮助节点" })
    ndTipsTotalInvite: cc.Node = null;

    @property({ type: cc.ScrollView, tooltip: "奖励进度scrollview" })
    scrollviewTask: cc.ScrollView = null;

    @property({ type: cc.Prefab, tooltip: "奖励任务预制体" })
    inviteTaskItem: cc.Prefab = null;

    onLoad(): void {
        this.btnInvite.node.on(cc.Button.EventType.CLICK, this.onClickInvite, this);
        this.btnRewardHistory.node.on(cc.Button.EventType.CLICK, this.onClickRewardRecord, this);
        this.btnClubDetail.node.on(cc.Button.EventType.CLICK, this.onClickClubDetail, this);
        this.btnHelpTotalInvite.node.on(cc.Button.EventType.CLICK, this.onClickHelpTotalInvite, this);
        this.btnHelpNewerInvite.node.on(cc.Button.EventType.CLICK, this.onClickHelpNewerInvite, this);
        this.btnHelp300Invite.node.on(cc.Button.EventType.CLICK, this.onClickHelp300Invite, this);

        this.bindEventListener();
        //请求我的俱乐部团队信息

        this.initView();
    }

    protected onDestroy(): void {
        EventMgr.Instance.offTarget(this);
    }

    protected bindEventListener(): void {
        // EventMgr.Instance.on(LOBBY_EVENT.CLUB_GET_MYCUB_TEAM_INFO, this.initView, this);
    }


    initView() {
        let info = ClubModel.Instance.getInviteInfo();
        if (!info) {
            return;
        }
        this.labTotalReward.string = INR + info.curInviteRewards;
        this.labTotalInvite.string = info.curInviteAmount.toString();
        this.labNewerReward.string = INR + info.inviteNewerRewards;
        this.labEachReward.string = INR + info.inviteEachRewards;
        this.labDailyLimit.string = `Daily new user invite limit:${info.inviteToday}/${info.inviteLimitDaily}`
        this.labNeedInvite.string = `Invited ${info.MaxNeedInvite} friends get:`
        this.lab300Reward.string = INR + info.MaxReward;
        this.labTotalHelpTips.string = `You have invited a total of ${info.curInviteAmount} friends, of which ${info.validInviteAmount} are valid users.`;

        this.initInviteTaskListView();
    }

    initInviteTaskListView() {
        let item = cc.instantiate(this.inviteTaskItem);
        this.scrollviewTask.content.addChild(item);

        item.getComponent(ClubInviteTaskView).initView();

        this.scrollviewTask.content.getComponent(cc.Layout).updateLayout(true);
        this.scrollviewTask.scrollToLeft(0.1);
    }

    onClickInvite() {
        UIMgr.Instance.showView(EnumPrefab.shareToApp, null, GameApp.Instance.getDialogLayer(), EnumPrefab.shareToApp, false);
    }

    onClickRewardRecord() {
        UIMgr.Instance.showView(EnumPrefab.ClubHistory, { type: ClubHistoryType.REWARD_RECORD }, GameApp.Instance.getDialogLayer(), EnumPrefab.ClubHistory, false);
    }

    onClickClubDetail() {
        UIMgr.Instance.showView(EnumPrefab.ClubDetail, null, GameApp.Instance.getDialogLayer(), EnumPrefab.ClubDetail, false);
    }

    onClickHelpTotalInvite() {
        this.ndTipsTotalInvite.active = true;
    }

    onClickHelpNewerInvite() {
        UIMgr.Instance.showView(EnumPrefab.ClubHelpInviteNewUser, null, GameApp.Instance.getDialogLayer(), EnumPrefab.ClubHelpInviteNewUser, false);
    }

    onClickHelp300Invite() {
        UIMgr.Instance.showView(EnumPrefab.ClubHelpInviteAllUser, null, GameApp.Instance.getDialogLayer(), EnumPrefab.ClubHelpInviteAllUser, false);
    }

}