import * as cc from 'cc';
import { EnumPrefab } from '../../../config/BundleConfig';
import EventMgr from '../../../framework/event/EventMgr';
import { UIMgr } from '../../../framework/manager/UIMgr';
import { GameApp } from '../../../lobby/GameApp';
import ClubModel, { ClubConfigInfo } from '../../../model/ClubModel';
import { INR } from '../../../Const';

const { ccclass, property } = cc._decorator;


/**
 * 各等级俱乐部信息
 */
@ccclass('ClubTeam')
export class ClubTeam extends cc.Component {
    @property({ type: cc.Label, tooltip: "俱乐部标题" })
    labTitle: cc.Label = null;

    @property({ type: cc.Label, tooltip: "俱乐部等级" })
    labClubLvl: cc.Label = null;

    @property({ type: cc.ProgressBar, tooltip: "成员进度" })
    barMembers: cc.ProgressBar = null;

    @property({ type: cc.ProgressBar, tooltip: "下注进度" })
    barBets: cc.ProgressBar = null;

    @property({ type: cc.Label, tooltip: "成员进度" })
    labMembers: cc.Label = null;

    @property({ type: cc.Label, tooltip: "下注进度" })
    labBets: cc.Label = null;

    @property({ type: cc.RichText, tooltip: "下注返利" })
    betRebate: cc.RichText = null;

    @property({ type: cc.RichText, tooltip: "充值返利" })
    depositRebate: cc.RichText = null;

    @property({ type: cc.RichText, tooltip: "邀请奖励" })
    rewardInvite: cc.RichText = null;

    @property({ type: cc.Button, tooltip: "详情按钮" })
    btnDetail: cc.Button = null;

    @property({ type: cc.Button, tooltip: "帮助按钮" })
    btnHelp: cc.Button = null;

    @property({ type: cc.Node, tooltip: "帮助节点" })
    ndHelp: cc.Node = null;


    onLoad(): void {
        this.btnDetail.node.on(cc.Button.EventType.CLICK, this.onClickDetail, this);
        this.btnHelp.node.on(cc.Button.EventType.CLICK, this.onClickHelp, this);

        this.bindEventListener();
    }

    protected bindEventListener(): void {

    }

    protected onDestroy(): void {
        EventMgr.Instance.offTarget(this);
    }

    initClubInfo(v: ClubConfigInfo, myLvl: number, maxLvl: number) {
        if (v.level == myLvl) {
            this.labTitle.string = `My team Club`;
        } else if (v.level < myLvl) {
            this.labTitle.string = `Previous team Club`;
        } else if (v.level == maxLvl) {
            this.labTitle.string = `Highest star`;
        } else {
            this.labTitle.string = `Next team Club`;
        }
        this.labClubLvl.string = `LV.` + v.level;
        let myClubInfo = ClubModel.Instance.getMyClubBaseInfo();
        this.labMembers.string = `(${myClubInfo.memberCount}/${v.maxMember})`;
        this.labBets.string = `(${myClubInfo.bets}/${v.maxBet})`;

        this.barMembers.progress = myClubInfo.memberCount / v.maxMember;
        this.barBets.progress = myClubInfo.bets / v.maxBet;

        this.betRebate.string = `<color=#E7BBBB>Bet Rebate\nup to </color><color=#DDC234>${v.betRebate}%</color>`;
        this.depositRebate.string = `<color=#E7BBBB>First deposit\nrebate </color><color=#DDC234>${v.depositRebate}%</color>`;
        this.rewardInvite.string = `<color=#E7BBBB>Invite rewards\nup to </color><color=#DDC234>${INR}${v.inviteRewards}</color>`;
    }

    hideHelpTip() {
        this.ndHelp.active = false;
    }


    onClickDetail() {
        UIMgr.Instance.showView(EnumPrefab.ClubDetail, null, GameApp.Instance.getDialogLayer(), EnumPrefab.ClubDetail, false);
    }

    onClickHelp() {
        this.ndHelp.active = true;
    }


}