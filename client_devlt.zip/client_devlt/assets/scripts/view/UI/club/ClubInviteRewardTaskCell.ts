import * as cc from 'cc';
import ClubModel, { } from '../../../model/ClubModel';
import { INR } from '../../../Const';

const { ccclass, property } = cc._decorator;


/**
 * 邀请奖励进度格子
 */
@ccclass('ClubInviteRewardTaskCell')
export class ClubInviteRewardTaskCell extends cc.Component {
    @property({ type: cc.Sprite, tooltip: "图标" })
    spIcon: cc.Sprite = null;

    @property({ type: cc.SpriteFrame, tooltip: "图标" })
    framesIcon: cc.SpriteFrame[] = [];

    @property({ type: cc.Label, tooltip: "奖励" })
    labReward: cc.Label = null;

    @property({ type: cc.RichText, tooltip: "需要邀请人数" })
    richInviteAmount: cc.RichText = null;

    @property({ type: cc.Button, tooltip: "领取" })
    btnClaim: cc.Button = null;

    @property({ type: cc.ProgressBar, tooltip: "进度条" })
    bar: cc.ProgressBar = null;

    /**
     * 
     * @param idx 格子索引
     * @param gridCount 格子总数
     * @param curAmount 当前邀请数量
     * @param needAmount 本格子需要邀请的数量
     * @param lastNeedAmount 上一个格子需要邀请的数量
     * @param reward 奖励
     * @param receState 领取状态
     */
    initView(idx: number, gridCount: number, curAmount: number, needAmount: number, lastNeedAmount: number, reward: number, receState: number) {
        this.labReward.string = INR + reward;
        this.richInviteAmount.string = `<color=#ffffff>${curAmount}</color><color=#AC5555>/${needAmount}</color>`;
        this.btnClaim.node.active = receState == 1;
        this.spIcon.spriteFrame = this.framesIcon[idx % this.framesIcon.length];

        if (idx < gridCount - 1) {
            this.bar.node.active = true;
            //从第3个开始，接下来每隔6个格子展示向下的进度条
            //从第6个开始，接下来每隔6个格子展示向下的进度条
            if (idx == 2 ||  idx % 6 == 5) {
                this.bar.node.angle = -90;
            }
        } else {
            this.bar.node.active = false;
        }
    }

}