import * as cc from 'cc';

const { ccclass, property } = cc._decorator;

@ccclass('PageViewDragHandler')
export class PageViewDragHandler extends cc.Component {

    private _startPos: cc.Vec2 = cc.v2(0, 0);
    private _gragEnddCallback: Function = null;

    protected onLoad(): void {
        this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.node.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchEnd, this);
    }

    setGragEnddCallback(arg0: (dis: any) => void) {
        this._gragEnddCallback = arg0;
    }

    onTouchStart(event: cc.EventTouch) {
        this._startPos = event.getLocation();
    }

    onTouchMove(event: cc.EventTouch) {
    }

    onTouchEnd(event: cc.EventTouch) {
        let curPos = event.getLocation();
        let delta = curPos.subtract(this._startPos);
        // Logger.info("PageViewDragHandler", "onTouchEnd", "delta=", delta);

        this._gragEnddCallback && this._gragEnddCallback(delta.y);
    }
}