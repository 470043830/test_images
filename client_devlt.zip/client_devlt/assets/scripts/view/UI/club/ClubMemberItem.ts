import * as cc from 'cc';
import { IComListItem } from '../../../framework/lib/ComListView';
import { MemberInfo } from '../../../model/ClubModel';
import { StringUtils } from '../../../framework/utils/StringUtils';

const { ccclass, property } = cc._decorator;


/**
 * 成员
 */
@ccclass('ClubMemberItem')
export class ClubMemberItem extends cc.Component implements IComListItem {

    @property({ type: cc.Label, tooltip: "用户名称" })
    labName: cc.Label = null;

    @property({ type: cc.Label, tooltip: "用户充值数" })
    labDeposit: cc.Label = null;

    @property({ type: cc.Label, tooltip: "用户佣金" })
    labCommission: cc.Label = null;

    @property({ type: cc.Label, tooltip: "所在俱乐部名称" })
    labClubName: cc.Label = null;

    @property({ type: cc.Label, tooltip: "加入时间" })
    labJoinTime: cc.Label = null;

    @property({ type: cc.Node, tooltip: "新用户标志" })
    ndNewTag: cc.Node = null;

    @property({ type: cc.Node, tooltip: "头像" })
    nodeAvatar: cc.Node = null;

    updateItem(idx: number, data: any, dataExt: any) {
        let itemData = data as MemberInfo;
        this.labName.string = itemData.name;
        this.labDeposit.string = itemData.deposit.toString();
        this.labCommission.string = itemData.commission.toString();
        this.labClubName.string = "";
        this.labJoinTime.string = StringUtils.dateFormat("yyyy-MM-dd hh:mm:ss", new Date(itemData.joinTime));
        this.ndNewTag.active = itemData.isNew;
    }
}