import * as cc from 'cc';
import { BaseUI } from '../../../framework/base/BaseUI';
import { LOBBY_EVENT } from '../../../framework/event/EventDefine';
import EventMgr from '../../../framework/event/EventMgr';
import { ClubRewardRecord } from './ClubRewardRecord';
import { ClubWithdrawRecord } from './ClubWithdrawRecord';
import ClubModel, { ClubHistoryType, RecordFilterType } from '../../../model/ClubModel';
import { UIDefaultCtrl } from '../../../framework/base/UIDefaultCtrl';

const { ccclass, property } = cc._decorator;


/**
 * 俱乐部历史记录
 */
@ccclass('ClubHistory')
export class ClubHistory extends BaseUI {
    @property({ type: cc.Button, tooltip: "返回按钮" })
    btnBack: cc.Button = null;

    @property({ type: cc.ToggleContainer, tooltip: "单选按钮组" })
    toggContaniner: cc.ToggleContainer = null;

    @property({ type: cc.Node, tooltip: "内容父节点" })
    ndContent: cc.Node = null;

    @property({ type: cc.Prefab, tooltip: "奖励详情" })
    pfRewardDetail: cc.Prefab = null;

    @property({ type: cc.Prefab, tooltip: "withdraw历史记录" })
    pfWithdrawReward: cc.Prefab = null;

    initView(): void {
        this.btnBack.node.on(cc.Button.EventType.CLICK, this.onClose, this);
        this.toggContaniner.toggleItems.forEach((toggle, idx) => {
            toggle.node.on(cc.Toggle.EventType.TOGGLE, () => {
                if (toggle.isChecked) {
                    this.switchView(idx);
                }
            });
        });

        let viewType = this.node.getComponent(UIDefaultCtrl).viewParam.type as ClubHistoryType;
        this.switchView(viewType);
    }

    protected bindEventListener(): void {
        super.bindEventListener();
        EventMgr.Instance.on(LOBBY_EVENT.CLUB_REWARD_RECORD, this.onGetRewardRecord, this);
        EventMgr.Instance.on(LOBBY_EVENT.CLUB_WITHDRAW_RECORD, this.onGetWithdrawRecord, this);
    }

    switchView(type: ClubHistoryType) {
        if (type == ClubHistoryType.REWARD_RECORD) {
            this.switchToRewardRecord();
        } else if (type == ClubHistoryType.WITHDRAW_RECORD) {
            this.switchToWithdrawRecord();
        }
    }

    switchToRewardRecord() {
        this.ndContent.removeAllChildren();
        let rewardRecord = cc.instantiate(this.pfRewardDetail);
        this.ndContent.addChild(rewardRecord);

        rewardRecord.getComponent(ClubRewardRecord).resetView(RecordFilterType.ALL);
    }

    switchToWithdrawRecord() {
        this.ndContent.removeAllChildren();
        let withdrawRecord = cc.instantiate(this.pfWithdrawReward);
        this.ndContent.addChild(withdrawRecord);

        withdrawRecord.getComponent(ClubWithdrawRecord).resetView();
    }

    onGetRewardRecord() {
        this.switchToRewardRecord();
    }

    onGetWithdrawRecord() {
        this.switchToWithdrawRecord();
    }
}