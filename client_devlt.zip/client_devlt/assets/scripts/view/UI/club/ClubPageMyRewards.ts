import * as cc from 'cc';
import EventMgr from '../../../framework/event/EventMgr';
import ClubModel, { ClubHistoryType } from '../../../model/ClubModel';
import { ClubTeam } from './ClubTeam';
import { INR } from '../../../Const';
import { EnumPrefab } from '../../../config/BundleConfig';
import { UIMgr } from '../../../framework/manager/UIMgr';
import { GameApp } from '../../../lobby/GameApp';
import { LOBBY_EVENT } from '../../../framework/event/EventDefine';
import { HallReqManager } from '../../../framework/net/HallReqManager';

const { ccclass, property } = cc._decorator;


/**
 * 俱乐部基本信息
 */
@ccclass('ClubPageMyRewards')
export class ClubPageMyRewards extends cc.Component {
    @property({ type: cc.PageView, tooltip: "各等级俱乐部pageview" })
    pageView: cc.PageView = null;

    @property({ type: cc.Prefab, tooltip: "俱乐部模版" })
    pfClubTeam: cc.Prefab = null;

    @property({ type: cc.Label, tooltip: "可提现" })
    labWithdrawable: cc.Label = null;

    @property({ type: cc.Label, tooltip: "总奖励" })
    rewardTotal: cc.Label = null;

    @property({ type: cc.Label, tooltip: "今日奖励" })
    rewardToday: cc.Label = null;

    @property({ type: cc.Button, tooltip: "邀请按钮" })
    btnInvite: cc.Button = null;

    @property({ type: cc.Button, tooltip: "上一页按钮" })
    btnPre: cc.Button = null;

    @property({ type: cc.Button, tooltip: "下一页按钮" })
    btnNext: cc.Button = null;

    @property({ type: cc.Button, tooltip: "提取按钮" })
    btnClaim: cc.Button = null;

    @property({ type: cc.Button, tooltip: "详情按钮" })
    btnDetail: cc.Button = null;

    @property({ type: cc.SpriteFrame, tooltip: "按钮状态图片" })
    btnFrames: cc.SpriteFrame[] = [];

    @property({ type: cc.Button, tooltip: "分享到PG" })
    btnSharePg: cc.Button = null;

    @property({ type: cc.Button, tooltip: "分享到WA" })
    btnShareWA: cc.Button = null;

    @property({ type: cc.Button, tooltip: "分享到IG" })
    btnShareIG: cc.Button = null;


    onLoad(): void {
        this.btnInvite.node.on(cc.Button.EventType.CLICK, this.onClickInvite, this);
        this.btnPre.node.on(cc.Button.EventType.CLICK, this.onClickPrePage, this);
        this.btnNext.node.on(cc.Button.EventType.CLICK, this.onClickNextPage, this);
        this.btnClaim.node.on(cc.Button.EventType.CLICK, this.onClickClaim, this);
        this.btnDetail.node.on(cc.Button.EventType.CLICK, this.onClickDetail, this);
        this.btnSharePg.node.on(cc.Button.EventType.CLICK, this.onClickShare2Telegram, this);
        this.btnShareWA.node.on(cc.Button.EventType.CLICK, this.onClickShare2Whatsapp, this);
        this.btnShareIG.node.on(cc.Button.EventType.CLICK, this.onClickShare2Instagram, this);

        this.bindEventListener();

        //请求代理系统配置
        HallReqManager.sendClubConfig();
    }

    protected bindEventListener(): void {
        EventMgr.Instance.on(LOBBY_EVENT.CLUB_GET_CLUB_BASE_CONFIG, this.initView, this);
    }

    protected onDestroy(): void {
        EventMgr.Instance.offTarget(this);
    }

    initView() {
        this.initMyClubInfo();
        this.initClubTeams();
    }

    initMyClubInfo() {
        this.labWithdrawable.string = INR + ClubModel.Instance.getMyClubBaseInfo().withdrawable;

        let claimAble = ClubModel.Instance.getMyClubBaseInfo().withdrawable > 0;
        this.btnClaim.enabled = claimAble;
        this.btnClaim.getComponent(cc.Sprite).spriteFrame = claimAble ? this.btnFrames[0] : this.btnFrames[1];
        this.btnClaim.getComponentInChildren(cc.Label).color = claimAble ? cc.color(`#FFFFFF`) : cc.color(`#2A0B0B`);
        this.rewardToday.string = INR + ClubModel.Instance.getMyClubBaseInfo().rewardToday;
        this.rewardTotal.string = INR + ClubModel.Instance.getMyClubBaseInfo().rewardTotal;
    }

    initClubTeams() {
        this.pageView.removeAllPages();

        let clubCfg = ClubModel.Instance.getClubConfig();
        let myClub = ClubModel.Instance.getMyClubBaseInfo();

        clubCfg.forEach(e => {
            let clubItem = cc.instantiate(this.pfClubTeam);
            this.pageView.addPage(clubItem);

            let src = clubItem.getComponent(ClubTeam);
            src.initClubInfo(e, myClub.level, clubCfg.length - 1);
        });
    }


    onClickInvite() {
        UIMgr.Instance.showView(EnumPrefab.shareToApp, null, GameApp.Instance.getDialogLayer(), EnumPrefab.shareToApp, false);
    }

    onClickPrePage() {
        let curPage = this.pageView.getCurrentPageIndex();
        if (--curPage < 0) {
            return;
        }
        this.pageView.scrollToPage(curPage);
    }

    onClickNextPage() {
        let curPage = this.pageView.getCurrentPageIndex();
        if (++curPage >= this.pageView.getPages().length) {
            return;
        }
        this.pageView.scrollToPage(curPage);
    }

    onClickClaim() {
        if (ClubModel.Instance.getMyClubBaseInfo().withdrawable > 0) {
            //请求提取
        }
    }

    onClickDetail() {
        UIMgr.Instance.showView(EnumPrefab.ClubHistory, { type: ClubHistoryType.REWARD_RECORD }, GameApp.Instance.getDialogLayer(), EnumPrefab.ClubHistory, false);
    }

    onClickShare2Telegram() {
        UIMgr.Instance.showView(EnumPrefab.shareToApp, null, GameApp.Instance.getDialogLayer(), EnumPrefab.shareToApp, false);

    }

    onClickShare2Whatsapp() {
        UIMgr.Instance.showView(EnumPrefab.shareToApp, null, GameApp.Instance.getDialogLayer(), EnumPrefab.shareToApp, false);

    }

    onClickShare2Instagram() {
        UIMgr.Instance.showView(EnumPrefab.shareToApp, null, GameApp.Instance.getDialogLayer(), EnumPrefab.shareToApp, false);
    }


}