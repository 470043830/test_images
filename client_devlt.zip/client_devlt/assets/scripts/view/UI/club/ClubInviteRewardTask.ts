import * as cc from 'cc';
import ClubModel, { } from '../../../model/ClubModel';
import { INR } from '../../../Const';
import { ClubInviteRewardTaskCell } from './ClubInviteRewardTaskCell';

const { ccclass, property } = cc._decorator;


/**
 * 邀请奖励进度
 */
@ccclass('ClubInviteRewardTask')
export class ClubInviteRewardTask extends cc.Component {
    @property({ type: cc.Label, tooltip: "总奖励" })
    labTotalReward: cc.Label = null;

    @property({ type: cc.Node, tooltip: "任务排列节点" })
    taskViewNode: cc.Node = null;

    @property({ type: cc.Prefab, tooltip: "任务节点模版" })
    pfTaskGrid: cc.Prefab = null;

    @property({ type: cc.ProgressBar, tooltip: "进度条模版" })
    barTemp: cc.ProgressBar = null;

    protected onLoad(): void {
        this.initView();
    }

    initView() {
        // this.labTotalReward.string = INR + 0;
        // let testArr = [
        //     {}, {}, {},
        //     {}, {}, {},
        //     {}, {}, {},
        //     {}, {}, {},
        //     {}, {}, {},
        //     {}, {}, {},
        // ];

        // let rowCount = Math.ceil(testArr.length / 3);
        // let gridData = {};
        // let index = 0;
        // for (let row = 0; row < rowCount; row++) {
        //     if (row % 2 == 0) {
        //         for (let col = 0; col < 3; col++) {
        //             index = row * 3 + col;
        //             gridData = testArr[index];
        //             let grid = cc.instantiate(this.pfTaskGrid);
        //             this.taskViewNode.addChild(grid);

        //             let src = grid.getComponent(ClubInviteRewardTaskCell);
        //             src.initView(index, 26, 5, 5 * index, 5, 123, 0);
        //         }
        //     } else {
        //         for (let col = 3 - 1; col >= 0; col++) {
        //             index = row * 3 + col;
        //             gridData = testArr[index];
        //             let grid = cc.instantiate(this.pfTaskGrid);
        //             this.taskViewNode.addChild(grid);

        //             let src = grid.getComponent(ClubInviteRewardTaskCell);
        //             src.initView(index, 26, 5, 5 * index, 5, 123, 0);
        //         }
        //     }
        // }
    }
}