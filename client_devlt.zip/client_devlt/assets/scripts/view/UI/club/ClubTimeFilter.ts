import * as cc from 'cc';
import GlobalModel from '../../../model/GlobalModel';
import { getDaysInMonth } from '../../../framework/lib/GlobalFunc';
// import { Logger } from '../../../framework/utils/Logger';
import { PageViewDragHandler } from './PageViewDragHandler';

const { ccclass, property } = cc._decorator;

export interface TimerFilterInfo {
    dayEnable: boolean;
    yearStart: number;
    chooseYear: number;
    chooseMonth: number;
    chooseDay: number;
}

/**
 * 时间筛选器
 */
@ccclass('ClubTimeFilter')
export class ClubTimeFilter extends cc.Component {
    @property({ type: cc.PageView, tooltip: "年" })
    pageViewYear: cc.PageView = null;

    @property({ type: cc.PageView, tooltip: "月" })
    pageViewMonth: cc.PageView = null;

    @property({ type: cc.PageView, tooltip: "日" })
    pageViewDay: cc.PageView = null;

    @property({ type: cc.Button, tooltip: "取消" })
    btnCancel: cc.Button = null;

    @property({ type: cc.Button, tooltip: "确定" })
    btnConfirm: cc.Button = null;

    @property({ type: cc.Layout, tooltip: "" })
    layout: cc.Layout = null;

    @property({ type: cc.Node, tooltip: "数字模版" })
    ndNumberTemp: cc.Node = null;

    private _confirmFunc = null;
    private _year: number = 0;
    private _montth: number = 0;
    private _day: number = 0;

    onLoad(): void {
        this.btnCancel.node.on(cc.Button.EventType.CLICK, this.onClickCancel, this);
        this.btnConfirm.node.on(cc.Button.EventType.CLICK, this.onClickConfirm, this);

        this.pageViewYear.node.on(cc.PageView.EventType.PAGE_TURNING, () => {
            let idx = this.pageViewYear.getCurrentPageIndex();
            let page = this.pageViewYear.getPages()[idx];
            this._year = parseInt(page.getComponentInChildren(cc.Label).string)
            // Logger.info("ClubTimeFilter", "onLoad", "year=", this._year);
            this.refreshDayView();
        }, this);

        this.pageViewMonth.node.on(cc.PageView.EventType.PAGE_TURNING, () => {
            this._montth = this.pageViewMonth.getCurrentPageIndex() + 1;
            // Logger.info("ClubTimeFilter", "onLoad", "month=", this._montth);
            this.refreshDayView();
        }, this);

        this.pageViewDay.node.on(cc.PageView.EventType.PAGE_TURNING, () => {
            this._day = this.pageViewDay.getCurrentPageIndex() + 1;
            // Logger.info("ClubTimeFilter", "onLoad", "day=", this._day);
        }, this);

        this.onPageViewByDrag(this.pageViewYear);
        this.onPageViewByDrag(this.pageViewMonth);
        this.onPageViewByDrag(this.pageViewDay);
    }

    onPageViewByDrag(pageview: cc.PageView) {
        let viewSize = pageview.view.getComponent(cc.UITransform).contentSize;
        pageview.getComponent(PageViewDragHandler).setGragEnddCallback((dis) => {
            // Logger.info("ClubTimeFilter", "onLoad", "year touch end dis=", dis);
            let curIdx = pageview.getCurrentPageIndex();
            if (Math.abs(dis) > viewSize.height) {
                pageview.scrollToPage(curIdx + Math.floor(dis / viewSize.height), 0.5);
            }
        });
    }

    setDateShowView(v: TimerFilterInfo) {
        // Logger.info("ClubTimeFilter", "setDateShowView", v);
        this.pageViewDay.node.parent.active = v.dayEnable;
        this.layout.spacingX = v.dayEnable ? 0 : 100;

        this._year = v.yearStart;
        this._montth = v.chooseMonth > 0 ? v.chooseMonth : 1;
        this._day = v.chooseDay > 0 ? v.chooseDay : 1;

        this.pageViewYear.removeAllPages();
        this.pageViewMonth.removeAllPages();
        this.pageViewDay.removeAllPages();

        //今年
        let thisYear = new Date(GlobalModel.Instance.serverTimeStamp).getFullYear();
        for (let year = v.yearStart; year <= thisYear; year++) {
            this.addItem(this.pageViewYear, year);
        }

        for (let month = 1; month <= 12; month++) {
            this.addItem(this.pageViewMonth, month);
        }

        if (v.dayEnable) {
            let days = getDaysInMonth(v.chooseYear, v.chooseMonth);
            days = Math.min(days, 31);
            for (let day = 1; day <= days; day++) {
                this.addItem(this.pageViewDay, day);
            }
        }

        this.ndNumberTemp.active = false;

        this.pageViewYear.scrollToPage(v.chooseYear - v.yearStart, 0.05);
        this.pageViewMonth.scrollToPage(v.chooseMonth - 1, 0.05);
        this.pageViewDay.scrollToPage(v.chooseDay - 1, 0.05);

        this.refreshDayView();
    }

    addItem(pageView: cc.PageView, text: number) {
        let newNum = cc.instantiate(this.ndNumberTemp);
        newNum.active = true;
        pageView.addPage(newNum);

        newNum.getComponentInChildren(cc.Label).string = text.toString();

        return newNum;
    }

    refreshDayView() {
        if (!this.pageViewDay.node.active) {
            return;
        }
        let days = getDaysInMonth(this._year, this._montth);
        // Logger.info("ClubTimeFilter", "refreshDayView", "days=", days, this._year, this._montth);
        let pageCount = this.pageViewDay.getPages().length;
        if (days < pageCount) {
            //从最后开始删除多余的
            for (let i = 0; i < pageCount - days; i++) {
                this.pageViewDay.removePageAtIndex(this.pageViewDay.getPages().length - 1);
            }
        } else if (days > pageCount) {
            //补充不足的
            for (let i = pageCount; i < days; i++) {
                this.addItem(this.pageViewDay, i + 1);
            }
        }

        this._day = this.pageViewDay.getCurrentPageIndex() + 1;
    }

    setConfirmFunc(func) {
        this._confirmFunc = func;
    }

    onClickCancel() {
        this.node.active = false;
    }

    onClickConfirm() {
        // Logger.info("ClubTimeFilter", "onClickConfirm", this._year, this._montth, this._day);
        this._confirmFunc && this._confirmFunc(this._year, this._montth, this._day);
        this.node.active = false;
    }


}