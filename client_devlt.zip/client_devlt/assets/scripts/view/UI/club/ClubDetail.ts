import * as cc from 'cc';
import { BaseUI } from '../../../framework/base/BaseUI';
import { ClubMemberSort } from './ClubMemberSort';
import ClubModel, { MemberInfo } from '../../../model/ClubModel';
import { LOBBY_EVENT } from '../../../framework/event/EventDefine';
import EventMgr from '../../../framework/event/EventMgr';
import { HallReqManager } from '../../../framework/net/HallReqManager';
import { StringUtils } from '../../../framework/utils/StringUtils';
import { ClubMemberItem } from './ClubMemberItem';
import { ComListView } from '../../../framework/lib/ComListView';
import { MemberSortType } from '../../../Const';
import { ClubTimeFilter } from './ClubTimeFilter';
import { Logger } from '../../../framework/utils/Logger';

const { ccclass, property } = cc._decorator;


/**
 * 俱乐部详情
 */
@ccclass('ClubDetail')
export class ClubDetail extends BaseUI {
    @property({ type: cc.Button, tooltip: "返回按钮" })
    btnBack: cc.Button = null;

    @property({ type: cc.Label, tooltip: "俱乐部等级" })
    labClubLvl: cc.Label = null;

    @property({ type: cc.Label, tooltip: "俱乐部成员数量" })
    labMemberAmount: cc.Label = null;

    @property({ type: cc.Label, tooltip: "今日新增数量" })
    labJoinToday: cc.Label = null;

    @property({ type: cc.Label, tooltip: "昨日新增数量" })
    labJoinYestoday: cc.Label = null;

    @property({ type: cc.Label, tooltip: "本月新增数量" })
    labJoinMonth: cc.Label = null;

    @property({ type: cc.Button, tooltip: "帮助按钮" })
    btnHelp: cc.Button = null;

    @property({ type: cc.Button, tooltip: "搜索按钮" })
    btnSearch: cc.Button = null;

    @property({ type: cc.EditBox, tooltip: "搜索输入框" })
    editSearch: cc.EditBox = null;

    @property({ type: cc.ScrollView, tooltip: "俱乐部层级滚动列表" })
    scrollViewClubs: cc.ScrollView = null;

    @property({ type: cc.Node, tooltip: "俱乐部模版" })
    clubItem: cc.Node = null;

    @property({ type: cc.ScrollView, tooltip: "俱乐部程成员滚动列表" })
    scrollViewMembers: cc.ScrollView = null;

    @property({ type: cc.Prefab, tooltip: "成员item" })
    pfMember: cc.Prefab = null;

    @property({ type: ClubMemberSort, tooltip: "排序按钮-加入时间" })
    sortByJoinTime: ClubMemberSort = null;

    @property({ type: ClubMemberSort, tooltip: "排序按钮-佣金" })
    sortByCommission: ClubMemberSort = null;

    @property({ type: cc.Button, tooltip: "过滤按钮-时间" })
    filterByTime: cc.Button = null;

    @property({ type: ClubTimeFilter, tooltip: "时间过滤器" })
    timeFilterComp: ClubTimeFilter = null;

    private _teamIdx: number = 0;
    private _sortType: MemberSortType = MemberSortType.NONE;
    private _desc: boolean = true;
    private _filterDate: number = Date.now();
    private _filterMembers: MemberInfo[] = [];

    initView(): void {
        this.btnBack.node.on(cc.Button.EventType.CLICK, this.onClikClosed, this);
        this.btnHelp.node.on(cc.Button.EventType.CLICK, this.onClikHelp, this);
        this.btnSearch.node.on(cc.Button.EventType.CLICK, this.onClikSearch, this);
        this.filterByTime.node.on(cc.Button.EventType.CLICK, this.onClikFilterByTime, this);

        this.setFilterTime(Date.now());

        this.sortByJoinTime.setClickFunc((desc: boolean) => {
            this._desc = desc;
            this.sortByCommission.resetState();
            this._sortType = this.sortByJoinTime.getSortType();

            //以加入时间进行排序
            this.showMembersByJoinTime();
        });
        this.sortByCommission.setClickFunc((desc: boolean) => {
            this._desc = desc;
            this.sortByJoinTime.resetState();
            this._sortType = this.sortByCommission.getSortType();

            //以佣金数量进行排序
            this.showMembersByCommission();
        });

        HallReqManager.sendMyClubTeamInfo(this._teamIdx);
    }

    protected bindEventListener(): void {
        super.bindEventListener();
        EventMgr.Instance.on(LOBBY_EVENT.CLUB_GET_MYCUB_TEAM_INFO, this.onGetTeamInfo, this);
    }

    protected onDestroy(): void {
        super.onDestroy();
    }

    initClubInfo() {
        let clubInfo = ClubModel.Instance.getMyClubBaseInfo();
        this.labClubLvl.string = clubInfo.level.toString();
        this.labMemberAmount.string = clubInfo.memberCount.toString();

        let teamInfo = ClubModel.Instance.getTeamInfo();
        this.labJoinToday.string = teamInfo.joinToday.toString();
        this.labJoinYestoday.string = teamInfo.joinYesterday.toString();
        this.labJoinMonth.string = teamInfo.joinMonth.toString();
    }

    initClubTeams() {
        let teamInfo = ClubModel.Instance.getTeamInfo();
        let teamConfig = ClubModel.Instance.getTeamConfig();
        teamConfig.forEach((e, idx) => {
            let item = cc.instantiate(this.clubItem);
            this.scrollViewClubs.content.addChild(item);
            item.active = true;

            let teamName = item.getComponentsInChildren(cc.Label)[0];
            let teamMembers = item.getComponentsInChildren(cc.Label)[1];

            teamName.string = e.showName;
            if (teamInfo.membersAmount[idx]) {
                teamMembers.string = teamInfo.membersAmount[idx].toString();
            }

            item.on(cc.Button.EventType.CLICK, () => {
                this._teamIdx = idx;
                HallReqManager.sendMyClubTeamInfo(this._teamIdx);
            })
        })

        this.clubItem.active = false;

        if (this._sortType <= MemberSortType.JOINTIME) {
            this.sortByJoinTime.setDescState(this._desc);
            this.sortByCommission.resetState();
        } else {
            this.sortByCommission.setDescState(this._desc);
            this.sortByJoinTime.resetState();
        }
    }

    refreshMembers(members: MemberInfo[]) {
        let viewData = {
            scrollView: this.scrollViewMembers,
            content: this.scrollViewMembers.content,
            itemPrefab: this.pfMember,
            itemClass: ClubMemberItem,
            dataList: members,
            dataEx: null,
            space: 15,
            createInterval: 0.05,
        }

        let comListView = this.scrollViewMembers.getComponent(ComListView);
        (comListView == null) && (comListView = this.scrollViewMembers.addComponent(ComListView))
        comListView.initParams(viewData)
        comListView.initScrollView(true);
    }

    setFilterTime(date: number) {
        this.filterByTime.getComponentInChildren(cc.Label).string = StringUtils.dateFormat("yyyy-MM-dd", new Date(date))
    }

    onClikClosed() {
        this.onClose();
    }

    onClikHelp() {

    }

    onClikSearch() {

    }

    onClikFilterByTime() {
        this.timeFilterComp.node.active = true;
        this.timeFilterComp.setDateShowView({
            dayEnable: true,
            yearStart: 2020,
            chooseYear: this._filterDate > 0 ? new Date(this._filterDate).getFullYear() : 2020,
            chooseMonth: this._filterDate > 0 ? new Date(this._filterDate).getMonth() + 1 : 1,
            chooseDay: this._filterDate > 0 ? new Date(this._filterDate).getDate() : 1
        })

        this.timeFilterComp.setConfirmFunc((year: number, month: number, day: number) => {
            this._filterDate = new Date(year, month - 1, day, 0, 0, 0, 0).getTime();
            this.setFilterTime(this._filterDate);

            let newDate = new Date(this._filterDate);
            Logger.info("ClubDetail", "onClikFilterByTime", "filter date=", newDate.getFullYear(), newDate.getMonth() + 1, newDate.getDate());

            //过滤该时间段加入的成员
            let members = ClubModel.Instance.getTeamInfo().members.slice();
            this.filterMembersByJoinTime(members, this._filterDate);
        });
    }

    onGetTeamInfo(lvl: number) {
        this.initClubInfo();
        this.initClubTeams();

        //按当前时间过滤
        let members = ClubModel.Instance.getTeamInfo().members.slice();
        this.filterMembersByJoinTime(members, this._filterDate);
        this.showMembersByJoinTime();
    }

    showMembersByJoinTime() {
        ClubModel.Instance.memberSortByJoinTime(this._filterMembers, this._desc);
        this.refreshMembers(this._filterMembers);
    }

    showMembersByCommission() {
        ClubModel.Instance.memberSortByCommission(this._filterMembers, this._desc);
        this.refreshMembers(this._filterMembers);
    }

    filterMembersByJoinTime(members: MemberInfo[], startTime: number) {
        this._filterMembers = ClubModel.Instance.filterMembersByJoinTime(members, startTime);
        this.refreshMembers(this._filterMembers);
    }


}