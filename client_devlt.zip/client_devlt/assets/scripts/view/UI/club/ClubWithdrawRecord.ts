import * as cc from 'cc';
import ClubModel, { ClubHistoryType, RewardHistoryInfo } from '../../../model/ClubModel';
import { ComListView } from '../../../framework/lib/ComListView';
import { ClubWithdrawRecordItem } from './ClubWithdrawRecordItem';

const { ccclass, property } = cc._decorator;



/**
 * withdraw历史记录
 */
@ccclass('ClubWithdrawRecord')
export class ClubWithdrawRecord extends cc.Component {
    @property({ type: cc.Enum(ClubHistoryType), tooltip: "记录类型" })
    historyType: ClubHistoryType = ClubHistoryType.WITHDRAW_RECORD;

    @property({ type: cc.ScrollView, tooltip: "" })
    scrollView: cc.ScrollView = null;

    @property({ type: cc.Prefab, tooltip: "" })
    pfItem: cc.Prefab = null;

    @property({ type: cc.Node, tooltip: "列表为空" })
    ndEmpty: cc.Node = null;

    protected onLoad(): void {


    }

    resetView() {
        let listData = ClubModel.Instance.getHistoryRecords(this.historyType);
        this.refrshListView(listData);
    }

    refrshListView(listData: RewardHistoryInfo[]) {
        let viewData = {
            scrollView: this.scrollView,
            content: this.scrollView.content,
            itemPrefab: this.pfItem,
            itemClass: ClubWithdrawRecordItem,
            dataList: listData,
            dataEx: null,
            space: 15,
            createInterval: 0.05,
        }

        let comListView = this.scrollView.getComponent(ComListView);
        (comListView == null) && (comListView = this.scrollView.addComponent(ComListView))
        comListView.initParams(viewData)
        comListView.initScrollView(true);

        this.ndEmpty.active = listData.length <= 0;

        //计算总佣金
        let totalCommission = 0;
        for (let i = 0; i < listData.length; i++) {
            totalCommission += listData[i].commission;
        }
    }


}