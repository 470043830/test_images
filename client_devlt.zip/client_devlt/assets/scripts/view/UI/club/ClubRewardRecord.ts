import * as cc from 'cc';
import { EnumPrefab } from '../../../config/BundleConfig';
import EventMgr from '../../../framework/event/EventMgr';
import { UIMgr } from '../../../framework/manager/UIMgr';
import { GameApp } from '../../../lobby/GameApp';
import ClubModel, { ClubConfigInfo, ClubHistoryType, RecordFilterType, RewardHistoryInfo } from '../../../model/ClubModel';
import { INR } from '../../../Const';
import { ClubTimeFilter } from './ClubTimeFilter';
import { ComListView } from '../../../framework/lib/ComListView';
import { ClubRewardRecordItem } from './ClubRewardRecordItem';
import { Logger } from '../../../framework/utils/Logger';
import { StringUtils } from '../../../framework/utils/StringUtils';

const { ccclass, property } = cc._decorator;



/**
 * 奖励历史记录
 */
@ccclass('ClubRewardRecord')
export class ClubRewardRecord extends cc.Component {
    @property({ type: cc.Enum(ClubHistoryType), tooltip: "记录类型" })
    historyType: ClubHistoryType = ClubHistoryType.REWARD_RECORD;

    @property({ type: cc.ToggleContainer, tooltip: "选项组" })
    toggContainer: cc.ToggleContainer = null;

    @property({ type: cc.Button, tooltip: "过滤按钮-时间" })
    filterByTime: cc.Button = null;

    @property({ type: ClubTimeFilter, tooltip: "时间过滤器" })
    timeFilterComp: ClubTimeFilter = null;

    @property({ type: cc.Label, tooltip: "总佣金数" })
    labTotalCommission: cc.Label = null;

    @property({ type: cc.ScrollView, tooltip: "" })
    scrollView: cc.ScrollView = null;

    @property({ type: cc.Prefab, tooltip: "" })
    pfItem: cc.Prefab = null;

    @property({ type: cc.Node, tooltip: "列表为空" })
    ndEmpty: cc.Node = null;

    private _filterDate: number = 0;
    private _filterType: RecordFilterType = RecordFilterType.ALL;

    protected onLoad(): void {
        this.filterByTime.node.on(cc.Button.EventType.CLICK, this.onClickFilterByTime, this);
        this.toggContainer.toggleItems.forEach((toggle, idx) => {
            toggle.node.on(cc.Toggle.EventType.TOGGLE, () => {
                if (toggle.isChecked) {
                    this._filterType = idx;
                    Logger.info("ClubRewardRecord", "onLoad", "filter type=", this._filterType);
                    this.resetView(this._filterType);
                }
            });
        });


        let dateNow = Date.now();
        let year = new Date(dateNow).getFullYear();
        let month = new Date(dateNow).getMonth() + 1;
        this._filterDate = new Date(year, month - 1, 1, 0, 0, 0, 0).getTime();
        this.setFilterTime(this._filterDate);
    }

    setFilterTime(date: number) {
        this.filterByTime.getComponentInChildren(cc.Label).string = StringUtils.dateFormat("yyyy-MM", new Date(date))
    }

    resetView(type: RecordFilterType) {
        //过滤该时间段的奖励记录
        let listData = ClubModel.Instance.filterHistoryRecordsByType(this.historyType, type, this._filterDate);
        this.refrshListView(listData);
    }

    refrshListView(listData: RewardHistoryInfo[]) {
        let viewData = {
            scrollView: this.scrollView,
            content: this.scrollView.content,
            itemPrefab: this.pfItem,
            itemClass: ClubRewardRecordItem,
            dataList: listData,
            dataEx: null,
            space: 15,
            createInterval: 0.05,
        }

        let comListView = this.scrollView.getComponent(ComListView);
        (comListView == null) && (comListView = this.scrollView.addComponent(ComListView))
        comListView.initParams(viewData)
        comListView.initScrollView(true);

        this.ndEmpty.active = listData.length <= 0;

        //计算总佣金
        let totalCommission = 0;
        for (let i = 0; i < listData.length; i++) {
            totalCommission += listData[i].commission;
        }
        this.labTotalCommission.string = `TotalCommission:` + INR + totalCommission;
    }

    onClickFilterByTime() {
        this.timeFilterComp.node.active = true;
        this.timeFilterComp.setDateShowView({
            dayEnable: false,
            yearStart: 2020,
            chooseYear: this._filterDate > 0 ? new Date(this._filterDate).getFullYear() : 2020,
            chooseMonth: this._filterDate > 0 ? new Date(this._filterDate).getMonth() + 1 : 1,
            chooseDay: this._filterDate > 0 ? new Date(this._filterDate).getDate() : 1
        })

        this.timeFilterComp.setConfirmFunc((year: number, month: number, day: number) => {
            // 使用 month-1 是因为 JS Date 的月份从 0 开始计数
            this._filterDate = new Date(year, month - 1, 1, 0, 0, 0, 0).getTime();
            this.setFilterTime(this._filterDate);

            let newDate = new Date(this._filterDate);
            Logger.info("ClubRewardRecord", "onClickFilterByTime", "filter date=", newDate.getFullYear(), newDate.getMonth() + 1, newDate.getDate());

            this.resetView(this._filterType);
        });
    }

}