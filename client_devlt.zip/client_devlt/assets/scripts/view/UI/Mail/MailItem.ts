import { _decorator, Component, Node, Label, Sprite, SpriteFrame } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('MailItem')
export class MailItem extends Component {

    @property({ type: Label })
    public titleLabel: Label | null = null;

    @property({ type: Label })
    public dateTimeLabel: Label | null = null;

    @property({ type: Label })
    public contentLabel: Label | null = null;

    @property({ type: Node })
    public notReadBg: Node | null = null;

    @property({ type: Node })
    public readBg: Node | null = null;

    @property({ type: Sprite })
    public stateIcon: Sprite | null = null;

    @property({ type: Node })
    public liwuIconNode: Node | null = null;

    @property(SpriteFrame)
    public frames: SpriteFrame[] = [];

    private _eid: number;

    get eid(): number {
        return this._eid;
    }

    set eid(value: number) {
        this._eid = value;
    }

    start() {
        // this.contentLabel.maxLines = 2; // 最多显示2行
        // console.log('frames: ', this.frames);
    }

    setReadState(str: string) {
        let isRead = str != '1';
        this.notReadBg.active = false;
        this.readBg.active = false;
        isRead ? this.readBg.active = true : this.notReadBg.active = true;
        this.stateIcon.spriteFrame = isRead ? this.frames[1] : this.frames[0];
    }

    setAwardState(isAward: string, isAwardGetted: string, isExpired: string) {
        if (isAward == '1') return;

        isAwardGetted == '1' ? this.notReadBg.active = true : this.readBg.active = true;
        this.liwuIconNode.active = isAwardGetted == '1' ? true : false;
        this.stateIcon.spriteFrame = isAwardGetted == '1' ? this.frames[2] : this.frames[3];
        if (isExpired == '2') {
            this.stateIcon.spriteFrame = this.frames[4];
            this.liwuIconNode.active = false;
            this.setDateTimeText('Expire');
        }

    }

    setTitleText(str: string) {
        if (this.titleLabel) {
            this.titleLabel.string = str;
        }
    }

    setDateTimeText(str: string) {
        if (this.dateTimeLabel) {
            this.dateTimeLabel.string = str;
        }
    }

    setContentText(str: string) {
        this.contentLabel.string = str;
    }

    onClick() {
        console.log(`---${this.titleLabel.string} clicke...`);
    }


}


