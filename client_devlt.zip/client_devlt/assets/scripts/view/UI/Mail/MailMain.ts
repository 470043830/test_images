import { _decorator, CCInteger, Component, instantiate, Label, math, Node, Prefab, Vec3, Sprite, Color, ScrollView } from 'cc';
const { ccclass, property } = _decorator;
import { MailItem } from './MailItem';
import { MailDetails } from './MailDetails';
import { Utils } from './Utils';
import { TestData } from './TestData';
import { HallReqManager } from '../../../framework/net/HallReqManager';
import { UIMgr } from '../../../framework/manager/UIMgr';
import { EnumPrefab } from '../../../config/BundleConfig';
import EventMgr from '../../../framework/event/EventMgr';
import { LOBBY_EVENT } from '../../../framework/event/EventDefine';
import MailModel, { IUserEmailDigest } from "../../../model/MailMode";
import { Logger } from '../../../framework/utils/Logger';

@ccclass('MailMain')
export class MailMgr extends Component {

    @property({ type: Prefab })
    public mailItemPrefab: Prefab | null = null;

    @property({ type: Node })
    public mailListNode: Node | null = null;

    @property({ type: Node })
    public mailDetailsNode: Node | null = null;

    @property({ type: Label })
    public bottomTipLabel: Label | null = null;

    @property({ type: Node })
    public mailTabsNode: Node | null = null;

    @property({ type: Label })
    public platformLabel: Label | null = null;
    @property({ type: Node })
    public plHighlight: Node | null = null;
    @property({ type: Node })
    public peHighlight: Node | null = null;

    @property({ type: Label })
    public personalLabel: Label | null = null;

    @property({ type: ScrollView })
    public mailListScrollView: ScrollView | null = null;

    @property({ type: Node })
    public bottomPanelForList: Node | null = null;

    @property({ type: Node })
    public bottomPanelForDDetail: Node | null = null;

    @property({ type: Label })
    public plNumLabel: Label | null = null;
    @property({ type: Label })
    public peNumLabel: Label | null = null;

    // private _mailItemList: MailItem[] = [];
    private _mailList: IUserEmailDigest[] = [];
    private _plList: IUserEmailDigest[] = []; // 平台邮件
    private _peList: IUserEmailDigest[] = []; // 站长邮件
    private _currListType = 'pl';
    private _isGetMore = false;

    //...
    onLoad() {
        this.bindEvent();
    }

    //...
    onDestroy() {
        EventMgr.Instance.offTarget(this);
        // this.mailListScrollView.node.off('scroll-to-bottom', this.onScrollViewBottom, this);
    }

    //...
    start() {
        this.showMailDetails(false);
        this.showPlatformMails();
    }

    bindEvent() {
        EventMgr.Instance.on(LOBBY_EVENT.USER_MAIL_LIST_INFO, this.onRecvMailList, this);
        EventMgr.Instance.on(LOBBY_EVENT.USER_ALTER_EMAIL_STATUS, this.onRecvMailAlterStatus, this);
        EventMgr.Instance.on(LOBBY_EVENT.USER_REMOVE_EMAIL, this.onRecvMailRemove, this);
        EventMgr.Instance.on(LOBBY_EVENT.USER_REMOVE_READ_EMAIL, this.onRecvRemoveReadMail, this);
        EventMgr.Instance.on(LOBBY_EVENT.USER_MARK_ALL_READ_EMAIL, this.onRecvMarkAllReadMail, this);
        this.mailListScrollView.node.on('scroll-to-bottom', this.onScrollViewBottom, this);
    }

    getMailListData(isGetMore = false) {
        console.log('---mail--- getMailListData, isGetMore:', isGetMore);
        this._isGetMore = isGetMore;
        if (!isGetMore) {
            this._plList = [];
            this._peList = [];
        }
        let offset = isGetMore ? this._mailList.length : 0;
        let limit = 200; //now get 200 items by once
        HallReqManager.sendMailList(offset, limit);
    }

    onReceiveBtn() {
        // this.getMailListData();
        HallReqManager.sendMarkAllReadEmailReq();
    }

    // 接收到网络邮件列表数据
    onRecvMailList() {
        this._mailList = MailModel.Instance.mailList;

        console.log('---mail--- onRecvMailList, mailList: ', this._mailList);
        for (let index = 0; index < this._mailList.length; index++) {
            const element = this._mailList[index];
            if (element.type > 1000) {
                this._peList.push(element);
            } else {
                this._plList.push(element);
            }
        }
        //...
        if (this._currListType == 'pl') {
            this.initMailList(this._plList, TestData.getTestData().details);
            // if (this._plList.length < 5) {
            //     this.getMailListData(true);
            // }
        } else if (this._currListType == 'pe') {
            this.initMailList(this._peList, TestData.getTestData().details);
            // if (this._peList.length < 5) {
            //     this.getMailListData(true);
            // }
        }
        this.updateNotReadLabel();
    }

    // 邮件状态改变
    onRecvMailAlterStatus(para) {
        console.log('onRecvMailAlterStatus: ', para)
        this.updateMailItemStatus(para.eid, 3);
        this.updateNotReadLabel();
    }

    // 删除邮件
    onRecvMailRemove(para) {
        console.log('onRecvMailRemove: ', para)
        this.removeMailItem(para.eid);
        if (this.mailDetailsNode?.active) {
            this.showMailDetails(false);
        }
    }

    // 删除已读邮件
    onRecvRemoveReadMail(para) {
        console.log('onRecvRemoveReadMail: ', para.plEids, para.peEids);
        const plEids = para.plEids || [];
        const peEids = para.peEids || [];
        for (let index = 0; index < plEids.length; index++) {
            const eid = Utils.longToNumber(plEids[index]);
            this.removeMailItem(eid);
        }
        for (let index = 0; index < peEids.length; index++) {
            const eid = Utils.longToNumber(peEids[index]);
            this.removeMailItem(eid);
        }
    }

    // 标记为已读邮件
    onRecvMarkAllReadMail(para) {
        console.log('onRecvMarkAllReadMail: ', para.plEids, para.peEids);
        const plEids = para.plEids || [];
        const peEids = para.peEids || [];
        for (let index = 0; index < plEids.length; index++) {
            const eid = Utils.longToNumber(plEids[index]);
            this.updateMailItemStatus(eid, 3);
        }
        for (let index = 0; index < peEids.length; index++) {
            const eid = Utils.longToNumber(peEids[index]);
            this.updateMailItemStatus(eid, 3);
        }
        // ...
        this.updateNotReadLabel();
    }

    onBackBtn() {
        if (this.mailDetailsNode.active) {
            this.showMailDetails(false);
        } else {
            UIMgr.Instance.removeNameView(EnumPrefab.mailMain);
        }
    }

    onDeleteReadBtn() {
        console.log('---mail--- onDeleteReadBtn...')
        HallReqManager.sendUserRemoveAllEmailReq();
        // this.deleteReadMails(this._plList);
        // this.deleteReadMails(this._peList);
    }


    showPlatformMails() {
        console.log('---mail--- showPlatformMails...')
        this.platformLabel.color = new Color().fromHEX("#E2CB26");
        this.personalLabel.color = new Color().fromHEX("#FFFFFF");
        this.plHighlight.active = true;
        this.peHighlight.active = false;

        //...
        this._currListType = 'pl';
        this.getMailListData();
    }

    showPersonalMails() {
        console.log('---mail--- showPersonalMails...')
        this.personalLabel.color = new Color().fromHEX("#E2CB26");
        this.platformLabel.color = new Color().fromHEX("#FFFFFF");
        this.plHighlight.active = false;
        this.peHighlight.active = true;

        //...
        this._currListType = 'pe';
        this.getMailListData();
    }

    showMailDetails(isShow: boolean) {
        this.mailListScrollView.node.active = !isShow;
        this.mailTabsNode.active = !isShow;
        this.bottomTipLabel.node.active = !isShow;
        this.mailDetailsNode.active = isShow;
        this.bottomPanelForList.active = !isShow;
        this.bottomPanelForDDetail.active = isShow;
    }


    initMailList(list, details) {
        !this._isGetMore && this.mailListNode.removeAllChildren();

        for (let i = 0; i < list.length; i++) {
            let item: Node | null = this.spawnMailItem();
            if (item) {
                let mailItem = item.getComponent("MailItem") as MailItem;

                mailItem.eid = list[i].eid;
                this.setMailItemByData(mailItem, list[i]);
                item.on(Node.EventType.TOUCH_END, () => this.onMailItemClicked(list[i]));
                this.mailListNode.addChild(item);
                // this._mailItemList.push(mailItem);
            }
        }

        //...
        !this._isGetMore && this.scheduleOnce(() => this.mailListScrollView.scrollToTop());
    }

    setMailItemByData(mailItem, data) {
        mailItem.setTitleText(data.head); //(list[i].title);
        // mailItem.setDateTimeText(Utils.formatDate(new Date(), "yyyy-MM-dd hh:mm"));
        mailItem.setDateTimeText(Utils.formatDate(new Date(Utils.longToNumber(data.timestamp)), "MM-dd hh:mm"));
        mailItem.setContentText(data.digest);

        mailItem.setReadState(data.status + '');//(list[i].isRead);
        // mailItem.setAwardState(list[i].isAward, list[i].isAwardGetted, list[i].isExpired);
        // mailItem.setAwardState(list[i].hasRewards + '', list[i].isAwardGetted, list[i].isExpired);
    }

    updateMailItemStatus(eid, status) {
        console.log('updateMailItemStatus, this.mailListNode: ', this.mailListNode)
        let itemList = this.mailListNode?.getComponentsInChildren("MailItem") as MailItem[] || [];

        console.log('updateMailItemStatus itemList: ', itemList, eid, status);
        for (let index = 0; index < itemList.length; index++) {
            let element = itemList[index];
            element.eid == eid && element.setReadState(status + '');
        }
        if (this._currListType == 'pl') {
            for (let index = 0; index < this._plList.length; index++) {
                let element = this._plList[index];
                element.eid == eid && (element.status = 3);
            }
        } else if (this._currListType == 'pe') {
            for (let index = 0; index < this._peList.length; index++) {
                let element = this._peList[index];
                element.eid == eid && (element.status = 3);
            }
        }
    }

    removeMailItem(eid) {
        console.log('RemoveMailItem, eid: ', eid)
        let itemList = this.mailListNode?.getComponentsInChildren("MailItem") as MailItem[] || [];

        for (let index = 0; index < itemList.length; index++) {
            let element = itemList[index];
            element.eid == eid && element.node.removeFromParent();
        }
    }

    updateNotReadLabel() {
        if (!this.plNumLabel || !this.peNumLabel) return;
        this.plNumLabel.string = this.getNotReadMailCount(this._plList); //this._plList.length + '';
        this.peNumLabel.string = this.getNotReadMailCount(this._peList); //this._peList.length + '';
    }

    getNotReadMailCount(list) {
        let count = 0;
        for (let index = 0; list && index < list.length; index++) {
            let element = list[index];
            element.status == 1 && count++;
        }
        return count + '';
    }

    deleteReadMails(list) {
        for (let index = 0; index < list.length; index++) {
            const element = list[index];
            element.status == 3 && HallReqManager.sendUserRemoveEmailReq(element.eid, element.type);
        }
    }

    onMailItemClicked(item) {
        console.log(`Item ${item.eid} clicked at ${new Date().toLocaleTimeString()}`, item);
        let data = Utils.formatDate(new Date(Utils.longToNumber(item.timestamp)), "yyyy-MM-dd hh:mm:ss");
        console.log(`timestamp at ${data}`);
        //...
        this.showMailDetails(true);
        this.mailDetailsNode.getComponent(MailDetails)?.getEmailInfoData(item);
    }

    spawnMailItem() {
        if (!this.mailItemPrefab) {
            return null;
        }

        let block: Node | null = null;
        block = instantiate(this.mailItemPrefab);
        return block;
    }


    onScrollViewBottom(scrollView: ScrollView) {
        // 回调的参数是 ScrollView 组件，注意这种方式注册的事件，无法传递 customEventData
        console.log('---mail--- onScrollViewBottom...')
        // this.getMailListData(true);
    }

}


