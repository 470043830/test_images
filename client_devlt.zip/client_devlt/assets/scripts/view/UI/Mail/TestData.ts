

export class TestData {

    //...
    static imgUrls = [
        'https://raw.githubusercontent.com/470043830/test_images/main/icon_teshuliwu.png',
        'https://cdn.jsdelivr.net/gh/470043830/test_images@main/motetu.png',
        'https://raw.githubusercontent.com/470043830/test_images/main/motetu.png',
        'https://raw.githubusercontent.com/470043830/test_images/main/icon_weidu.png',
        'https://xcimg.szwego.com/imgHD/cd16e6b8/20251014/o_1j7gmtrmfbt91ksn1ccfgku19sh0.png',
        'https://cdn.jsdelivr.net/gh/470043830/test_images@main/icon_jinbi1.png',
    ]

    //...
    static getTestData() {
        const testRich1 = `<img src='icon_huangguan' width=25 height=25 align=center offset=-6,-1 /><size=30>rummy tournament is offcially launched, Free</size><br/>`
            + `<img src='icon_teshuliwu' width=25 height=25 align=center offset=-6,-1 /><size=30>registration,luxurious prize sare waiting for you!</size><img src='icon_huangguan' width=25 height=25 align=center offset=-6,-1 /><br/>`
            + `<size=30>No threshold to participate,everyone has the opportunity to win the prize</size><br/>`
            + `<img src='icon_lihua' width=25 height=25 align=center offset=-6,-1 /><size=30>Each player can enjoy[3 free participation opportunities]</size><br/>`;
        const testRich2 = `<img src='icon_huangguan' width=30 height=30 align=center offset=-6,-1 /><size=30>LowerThreshold,BiggerRewards!</size><br/>` +
            `<br/><img src='icon_lihua' width=30 height=30 align=center offset=-6,-1 /><size=20>We'vemade it easier to earn-now your invitees only need to recharge 100 or more to qualify！</size>`;
        const mail = {
            list1: [
                {
                    title: 'Day Rank Rankings settlement',
                    content: 'Wevemade it easier to earnnow your invitees only need to recharge R100 or more to qualify！',
                    datetime: '10-01 10:00',
                    isRead: '1',
                    isAward: '1',
                    isAwardGetted: '1',
                    isExpired: '1',
                    expireTime: '11-11 11:00',
                },
                {
                    title: 'Day Rank Rankings settlement 2',
                    content: 'Wevemade it easier to earnnow your invitees only need to recharge R100 or more to qualify！',
                    datetime: '10-02 10:00',
                    isRead: '1',
                    isAward: '1',
                    isAwardGetted: '1',
                    isExpired: '1',
                    expireTime: '11-11 11:00',
                },
                {
                    title: 'Rummy Tournament Wins Big Prizes 333',
                    content: 'Wevemade it easier to earnnow your invitees only need to recharge R100 or more to qualify！',
                    datetime: '10-03 10:00',
                    isRead: '2',
                    isAward: '1',
                    isAwardGetted: '1',
                    isExpired: '1',
                    expireTime: '11-11 11:00',
                },
                {
                    title: 'Rummy Tournament Wins Big Prizes 111',
                    content: 'Wevemade it easier to earnnow your invitees only need to recharge R100 or more to qualify！',
                    datetime: '10-04 10:00',
                    isRead: '1',
                    isAward: '2',
                    isAwardGetted: '1',
                    isExpired: '1',
                    expireTime: '11-11 11:00',
                },
                {
                    title: 'Rummy Tournament Wins Big Prizes 111',
                    content: 'Wevemade it easier to earnnow your invitees only need to recharge R100 or more to qualify！',
                    datetime: '10-05 10:00',
                    isRead: '1',
                    isAward: '2',
                    isAwardGetted: '2',
                    isExpired: '1',
                    expireTime: '11-11 11:00',
                },
                {
                    title: 'Rummy Tournament Wins Big Prizes 111',
                    content: 'Wevemade it easier to earnnow your invitees only need to recharge R100 or more to qualify！',
                    datetime: '10-06 10:00',
                    isRead: '1',
                    isAward: '2',
                    isAwardGetted: '2',
                    isExpired: '2',
                    expireTime: '11-11 11:00',
                }
            ],
            list2: [
                {
                    title: 'Tournament Wins Big Prizes 111',
                    content: 'Wevemade it easier to earnnow your invitees only need to recharge R100 or more to qualify！',
                    datetime: '10-01 10:00',
                    isRead: '1',
                    isAward: '1',
                    isAwardGetted: '1',
                    isExpired: '1',
                    expireTime: '11-11 11:00',
                },
                {
                    title: 'Tournament Wins Big Prizes 222',
                    content: 'Wevemade it easier to earnnow your invitees only need to recharge R100 or more to qualify！',
                    datetime: '10-02 10:00',
                    isRead: '1',
                    isAward: '1',
                    isAwardGetted: '1',
                    isExpired: '1',
                    expireTime: '11-11 11:00',
                },
                {
                    title: 'Tournament Wins Big Prizes 3',
                    content: 'Wevemade it easier to earnnow your invitees only need to recharge R100 or more to qualify！',
                    datetime: '10-03 10:00',
                    isRead: '2',
                    isAward: '1',
                    isAwardGetted: '1',
                    isExpired: '1',
                    expireTime: '11-11 11:00',
                },
                {
                    title: 'Rummy Tournament Wins Big Prizes 111',
                    content: 'Wevemade it easier to earnnow your invitees only need to recharge R100 or more to qualify！',
                    datetime: '10-04 10:00',
                    isRead: '1',
                    isAward: '2',
                    isAwardGetted: '1',
                    isExpired: '1',
                    expireTime: '11-11 11:00',
                },
                {
                    title: 'Rummy Tournament Wins Big Prizes 111',
                    content: 'Wevemade it easier to earnnow your invitees only need to recharge R100 or more to qualify！',
                    datetime: '10-05 10:00',
                    isRead: '1',
                    isAward: '2',
                    isAwardGetted: '2',
                    isExpired: '1',
                    expireTime: '11-11 11:00',
                },
                {
                    title: 'Rummy Tournament Wins Big Prizes 111',
                    content: 'Wevemade it easier to earnnow your invitees only need to recharge R100 or more to qualify！',
                    datetime: '10-06 10:00',
                    isRead: '1',
                    isAward: '2',
                    isAwardGetted: '2',
                    isExpired: '2',
                    expireTime: '11-11 11:00',
                }
            ],
            details: [
                {
                    title: 'Day Rank Rankings settlement',
                    datetime: '2025-10-01 10:00',
                    image: TestData.imgUrls[2],
                    isAward: '1',
                    richtext: `<img src='icon_huangguan' width=30 height=30 align=center offset=-6,-1 /><size=30>Lower Threshold,BiggerRewards!</size><br/>` +
                        `<br/><img src='icon_huangguan' width=30 height=30 align=center offset=-6,-1 /><size=20>We'vemade it easier to earn-now your invitees only need to recharge 100 or more to qualify！</size>`
                },
                {
                    title: 'Rummy Tournament Wins Big Prizes',
                    datetime: '2025-10-02 10:00',
                    image: 'https://xcimg.szwego.com/imgHD/cd16e6b8/20251014/o_1j7gmtrmfbt91ksn1ccfgku19sh0.png',
                    isAward: '2',
                    richtext: `<img src='icon_huangguan' width=25 height=25 align=center offset=-6,-1 /><size=30>rummy tournament is offcially launched, Free</size><br/>`
                        + `<img src='icon_teshuliwu' width=25 height=25 align=center offset=-6,-1 /><size=20>registration,luxurious prize sare waiting for you!</size><img src='icon_huangguan' width=25 height=25 align=center offset=10,-1 /><br/>`
                        + `<size=30>No threshold to participate,everyone has the opportunity to win the prize</size><br/>`
                        + `<img src='icon_lihua' width=25 height=25 align=center offset=-6,-1 /><size=20>Each player can enjoy[3 free participation opportunities]</size><br/>`,
                    ricktext2: `<img src='icon_huangguan' width=30 height=30 align=center offset=-6,-1 /><size=30>LowerThreshold,BiggerRewards!</size><br/>` +
                        `<br/><img src='icon_lihua' width=30 height=30 align=center offset=-6,-1 /><size=20>We'vemade it easier to earn-now your invitees only need to recharge 100 or more to qualify！</size>`,
                    attach: [
                        {
                            id: 1,
                            type: 'cash',
                            num: 777,
                            lock: '1',
                            locktip: 'VIP 2 Can Claim',
                        },
                        {
                            id: 2,
                            type: 'cash',
                            num: 10,
                            lock: '2',
                            locktip: 'VIP 2 Can Claim',
                        },
                        {
                            id: 3,
                            type: 'cash',
                            num: 10,
                            lock: '2',
                            locktip: 'VIP 2 Can Claim',
                        }
                    ]

                }
            ]
        }
        return mail;
    }
}


