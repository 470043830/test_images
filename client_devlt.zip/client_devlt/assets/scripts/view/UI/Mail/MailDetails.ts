import {
    _decorator, instantiate, Component, Node, RichText, assetManager, SpriteFrame, Sprite,
    Texture2D, ImageAsset, resources, SpriteAtlas, Label, ScrollView, sys,
} from 'cc';

import { Utils } from './Utils';
import { MailAttachItem } from "./MailAttachItem";
import EventMgr from '../../../framework/event/EventMgr';
import { LOBBY_EVENT } from '../../../framework/event/EventDefine';
import { HallReqManager } from '../../../framework/net/HallReqManager';
import { IUserEmailDigest, IUserMailInfo } from '../../../model/MailMode';

const { ccclass, property } = _decorator;


@ccclass('MailDetails')
export class MailDetails extends Component {

    @property({ type: Label })
    public textTitle: Label | null = null;

    @property({ type: RichText })
    public richText: RichText | null = null;

    @property({ type: Sprite })
    public mailImage: Sprite | null = null;

    @property({ type: Label })
    public dateTimeLabel: Label | null = null;

    @property({ type: Node })
    public attachList: Node | null = null;

    @property({ type: Node })
    public tipLabelsNode: Node | null = null;

    @property({ type: Node })
    public deleteBtnNode: Node | null = null;
    @property({ type: Node })
    public claimBtnNode: Node | null = null;
    @property({ type: Node })
    public receiveBtnNode: Node | null = null;

    @property({ type: Node })
    public attachListNode: Node | null = null;
    @property({ type: Node })
    public attachListContent: Node | null = null;
    @property({ type: Node })
    public attachItemNode: Node | null = null;

    private attachItemPreNode: Node | null = null;

    private richTextStr = '';

    private userMailDigest: IUserEmailDigest = null;
    private userMailInfo: IUserMailInfo = null;

    //...
    onLoad() {
        this.bindEvent();
    }

    //...
    onDestroy() {
        EventMgr.Instance.off(LOBBY_EVENT.USER_MAIL_DETAIL_INFO, this.onRecvMailInfoData, this);
    }

    //...
    start() {

    }

    bindEvent() {
        EventMgr.Instance.on(LOBBY_EVENT.USER_MAIL_DETAIL_INFO, this.onRecvMailInfoData, this);
    }


    //...
    onRecvMailInfoData(data) {
        this.userMailInfo = { ...data };
        console.log('onRecvMailInfoData: ', this.userMailInfo);
        this.showMailInfo();

        // ..Notify server email is read‌ed
        if (this.userMailDigest.status == 1) {
            HallReqManager.sendAlterUserEmailStatusReq(this.userMailDigest.eid, this.userMailDigest.type);
        }
    }

    getEmailInfoData(digest) {
        this.userMailDigest = { ...digest };
        console.log('getEmailInfoData: ', this.userMailDigest);
        HallReqManager.sendMailInfo(digest.eid, digest.type);
    }


    //...
    showMailInfo() {
        this.textTitle.string = this.userMailDigest.head;
        // this.dateTimeLabel.string = detailData.datetime;
        this.dateTimeLabel.string = Utils.formatDate(new Date(Utils.longToNumber(this.userMailDigest.timestamp)), "yyyy-MM-dd hh:mm:ss");
        this.richTextStr = this.userMailInfo.body;
        console.log('this.richTextStr: ', this.richTextStr);
        this.LoadMailImage(this.userMailInfo.pictureUrl);
        this.loadResImg();

        //...
        this.attachList.active = this.userMailInfo.hasRewards != 2 ? true : false;
        this.tipLabelsNode.active = this.attachList.active;
        this.claimBtnNode.active = this.attachList.active;
        this.receiveBtnNode.active = this.attachList.active;
        this.deleteBtnNode.active = !this.attachList.active;
        this.showAttachList();

        //...
        this.scheduleOnce(() => this.node.getComponentsInChildren(ScrollView)[0]?.scrollToTop());
    }

    setDetailData(detailData) {
        console.log('detailData: ', detailData)

        // this.richText.string = "<on click='onClicked' param='hello world'>Click Me!</on>"
        //     + "<br/>" + "<size=30>dasdasdasda<color=#00ff00>Rich</color><color=#0fffff>Text</color>bcvbcvbcbvc</size>"
        //     + "<br/>" + "cccccccc<color=#00ff00>Rich</color><color=#0fffff>Text</color>bcvbcvbcbvc";
        this.textTitle.string = detailData.title;
        this.dateTimeLabel.string = detailData.datetime;
        this.richTextStr = detailData.richtext;
        console.log('this.richTextStr: ', this.richTextStr)
        this.LoadMailImage(detailData.image);
        this.loadResImg();

        //...
        this.attachList.active = detailData.isAward != '2' ? true : false;
        this.tipLabelsNode.active = this.attachList.active;
        this.claimBtnNode.active = this.attachList.active;
        this.receiveBtnNode.active = this.attachList.active;
        this.deleteBtnNode.active = !this.attachList.active;
        this.showAttachList();

        //...
        this.scheduleOnce(() => this.node.getComponentsInChildren(ScrollView)[0]?.scrollToTop());
    }

    showAttachList() {
        if (!this.attachList.active) return;

        this.resetAttachItems();
        //for test
        for (let i = 0; i < 5; i++) {
            let item: Node | null = this.spawnAttachItem();
            if (item) {
                let attachItem = item.getComponent(MailAttachItem);

                attachItem.showLock(i != 0);
                // item.active = true;
                item.on(Node.EventType.TOUCH_END, () => this.onAttachItemClicked(attachItem));
                this.attachListContent.addChild(item);
            }
        }
        this.attachListNode.getComponent(ScrollView)?.scrollToLeft();
    }

    resetAttachItems() {
        !this.attachItemPreNode && (this.attachItemPreNode = instantiate(this.attachItemNode));
        this.attachListContent.removeAllChildren();
    }

    spawnAttachItem() {
        if (!this.attachItemPreNode) {
            return null;
        }

        let block: Node | null = null;
        block = instantiate(this.attachItemPreNode);
        return block;
    }

    onAttachItemClicked(attachItem) {
        console.log('onAttachItemClicked...')
    }

    LoadMailImage(url: string) {
        // 远程 url 带图片后缀名
        let remoteUrl = url;
        const mailImage = this.mailImage;
        assetManager.loadRemote<ImageAsset>(remoteUrl, function (err, imageAsset) {
            const spriteFrame = new SpriteFrame();
            const texture = new Texture2D();
            texture.image = imageAsset;
            spriteFrame.texture = texture;
            // ...
            console.log('spriteFrame: ', spriteFrame)
            mailImage.spriteFrame = spriteFrame;
        });
    }

    loadResImg() {
        if (!this.richText.imageAtlas) {
            this.richText.imageAtlas = new SpriteAtlas();
        }

        // 加载 SpriteFrame，image 是 ImageAsset，spriteFrame 是 image/spriteFrame，texture 是 image/texture

        // resources.load("imgs/111/spriteFrame", SpriteFrame, (err, spriteFrame) => {
        //     // this.mailImage.spriteFrame = spriteFrame;

        //     // console.log('spriteFrames: ', this.richText.imageAtlas)


        //     this.richText.imageAtlas.spriteFrames['dynamic_img'] = spriteFrame; // 动态添加图集
        //     this.richText.string += "<br/>" + "<img src='dynamic_img' click='onClicked' param='img'/>";
        // });


        resources.loadDir("textures/mailRichTextIcon", SpriteFrame, (err, assets: SpriteFrame[]) => {
            if (err) {
                console.error(err);
                return;
            }
            // console.log('assets: ', assets)
            assets.forEach(frame => {
                // const sprite = new Sprite(frame);
                // const node = new Node();
                // node.addComponent(SpriteComponent).spriteFrame = sprite;
                // this.node.addChild(node);
                this.richText.imageAtlas.spriteFrames[frame.name] = frame;
                // this.richText.string += `<size=30>${frame.name}: </size><img src='${frame.name}' width=30 height=30 align=top click='onClicked' param='img'/>`;
            });

            //...
            // console.log('this.richText.imageAtlas.spriteFrames: ', this.richText.imageAtlas.spriteFrames)
            // console.log('this.richTextStr: ', this.richTextStr)
            this.richTextStr && (this.richText.string = this.richTextStr);
        });



        // 加载图集资源并赋值
        // resources.load('imgs/auto-atlas', SpriteAtlas, (err, atlas) => {
        //     if (atlas) {
        //         this.richText.imageAtlas = atlas;
        //         console.log('imageAtlas: ', atlas)
        //         // this.richText.string += "文本<img src='111'/>";
        //     }
        // });

    }

    onClaimBtn() {
        // 替换废弃的 cc.systemEvent.openURL(url)
        console.log('onClaimBtn: ', sys.now())
        sys.openURL("https://www.baidu.com");

    }

    onReceiveBtn() {
        //领取所有奖励
        console.log('onReceiveBtn...')

    }

    onDeleteBtn() {
        console.log('onDeleteBtn...')
        HallReqManager.sendUserRemoveEmailReq(this.userMailDigest.eid, this.userMailDigest.type);
    }


}


