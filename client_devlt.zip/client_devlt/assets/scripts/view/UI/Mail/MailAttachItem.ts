import { _decorator, Component, Node, Label } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('MailAttachItem')
export class MailAttachItem extends Component {

    @property({ type: Node })
    public lockNode: Node | null = null;

    @property({ type: Node })
    public jinbi1Node: Node | null = null;

    @property({ type: Node })
    public jinbi2Node: Node | null = null;

    @property({ type: Node })
    public qiandaiNode: Node | null = null;

    @property({ type: Label })
    public numLabel: Label | null = null;
    @property({ type: Label })
    public cashLabel: Label | null = null;

    @property({ type: Label })
    public lockTipLabel: Label | null = null;

    @property({ type: Node })
    public claimBtn: Node | null = null;

    start() {

    }

    showLock(isLock) {
        this.lockNode.active = isLock;
        this.jinbi2Node.active = isLock;
        this.lockTipLabel.node.active = isLock;

        this.qiandaiNode.active = !isLock;
        this.claimBtn.active = !isLock;
    }


    onClaimBtn() {

    }

}


