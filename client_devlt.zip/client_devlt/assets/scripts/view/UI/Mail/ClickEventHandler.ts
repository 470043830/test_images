import { _decorator, Component, EventTouch } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('ClickEventHandler')
export class ClickEventHandler extends Component {

    onClicked(eventTouch:EventTouch, param:string){
        console.log("onClicked", param);
        window.open("https://www.baidu.com");
    }
}