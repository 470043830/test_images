import * as cc from 'cc';
const { ccclass, property } = cc._decorator;

/**
 * 
 *
 */

@ccclass('VipRebateRate')
export class VipRebateRate extends cc.Component {
    @property({ type: cc.Sprite, tooltip: "连接竖线" })
    spColLine: cc.Sprite = null;

    @property({ type: cc.Label, tooltip: "游戏名称" })
    labGameName: cc.Label = null;

    @property({ type: cc.Label, tooltip: "返利比例" })
    labRate: cc.Label = null;

    setInfo(gameName: string, rate: number, isEnd: boolean) {
        this.labGameName.string = `${gameName} rebate rate`;
        this.labRate.string = `${(rate / 100).toFixed(2)}%`;

        this.spColLine.node.active = !isEnd;
    }

}