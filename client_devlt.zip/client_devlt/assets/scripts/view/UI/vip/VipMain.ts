import * as cc from 'cc';
import { BaseUI } from '../../../framework/base/BaseUI';
import { ComListView, IComlistData } from '../../../framework/lib/ComListView';
import { VipLevelItem } from './VipLevelItem';
import { VipPrivilItem } from './VipPrivilItem';
import { HallReqManager } from 'db://assets/scripts/framework/net/HallReqManager';
import AccountModel from 'db://assets/scripts/model/AccountModel';
import VIPModel, { IVipProp } from 'db://assets/scripts/model/VIPModel';
import { EnumPrefab } from '../../../config/BundleConfig';
import { UIMgr } from '../../../framework/manager/UIMgr';
import { GameApp } from '../../../lobby/GameApp';
import { Logger } from '../../../framework/utils/Logger';
import { VipRebateRate } from './VipRebateRate';
import { INR } from '../../../Const';

const { ccclass, property } = cc._decorator;


/**
 * VIP 主页
 */
@ccclass('VipMain')
export class VipMain extends BaseUI {
    @property({ type: cc.Button, tooltip: "关闭按钮" })
    btnClose: cc.Button = null;

    @property({ type: cc.Label, tooltip: "昵称" })
    labName: cc.Label = null;

    @property({ type: cc.Label, tooltip: "金钱" })
    labMoney: cc.Label = null;

    @property({ type: cc.Label, tooltip: "vip等级" })
    labVipLvl: cc.Label = null;

    @property({ type: cc.Button, tooltip: "升级按钮" })
    btnLevelUp: cc.Button = null;

    @property({ type: cc.PageView, tooltip: "VIP等级列表" })
    pageViewVipLvl: cc.PageView = null;

    @property({ type: cc.Prefab, tooltip: "VIP等级列表item" })
    pfVipLvlItem: cc.Prefab = null;

    @property({ type: cc.ScrollView, tooltip: "VIP权益列表" })
    scrollViewVipPrivil: cc.ScrollView = null;

    @property({ type: cc.Prefab, tooltip: "VIP权益列表item" })
    pfVipPrivilItem: cc.Prefab = null;

    @property({ type: cc.Label, tooltip: "当前权益" })
    labCurPriv: cc.Label = null;

    @property({ type: cc.Label, tooltip: "当前福利" })
    labCurBenefits: cc.Label = null;

    @property({ type: cc.Button, tooltip: "myBonus按钮" })
    btnMyBonus: cc.Button = null;

    @property({ type: cc.Button, tooltip: "更多权益按钮" })
    btnMorePriv: cc.Button = null;

    @property({ type: cc.Button, tooltip: "更多福利按钮" })
    btnMoreBenefit: cc.Button = null;

    @property({ type: cc.Prefab, tooltip: "返利比例" })
    pfRebate: cc.Prefab = null;

    @property({ type: cc.Layout, tooltip: "返利比例父节点" })
    parentRebate: cc.Layout = null;


    private _vipShowLvl: number = 1;        //默认从vip1级开始显示，vip0不显示

    initView(): void {
        this.btnClose.node.on(cc.Button.EventType.CLICK, this.onClikClosed, this);
        this.btnLevelUp.node.on(cc.Button.EventType.CLICK, this.onClickLevelUp, this);
        this.btnMyBonus.node.on(cc.Button.EventType.CLICK, this.onClickMyBonus, this);
        this.btnMorePriv.node.on(cc.Button.EventType.CLICK, this.onClickMorePriv, this);
        this.btnMoreBenefit.node.on(cc.Button.EventType.CLICK, this.onClickBenefit, this);

        this.labMoney.string = INR + AccountModel.Instance.cash.toString();
        this.labName.string = AccountModel.Instance.userName;
        this.labVipLvl.string = "VIP" + AccountModel.Instance.vipLevel;
        this.initVipLevelView(VIPModel.Instance.vipList.slice().splice(1));  //从VIP1开始
        this.updateView(this._vipShowLvl);
    }

    initVipLevelView(listData: IVipProp[]) {
        listData.forEach((e, idx) => {
            let vipItem = cc.instantiate(this.pfVipLvlItem);
            this.pageViewVipLvl.addPage(vipItem);

            let src = vipItem.getComponent(VipLevelItem);
            src.setInfo(idx, e);
        })

        this.pageViewVipLvl.node.on(cc.PageView.EventType.PAGE_TURNING, () => {
            this.onLevelListMoving(this.pageViewVipLvl.getCurrentPageIndex() + 1);
        })
    }

    initVipPrivilView(listData) {
        let viewData = {
            scrollView: this.scrollViewVipPrivil,
            content: this.scrollViewVipPrivil.content,
            itemPrefab: this.pfVipPrivilItem,
            itemClass: VipPrivilItem,
            dataList: listData,
            dataEx: {
                curVipLvl: AccountModel.Instance.vipLevel,
                maxCount: listData.length,
            },
            space: 50,
            createInterval: 0.01,
        }

        let comListView = this.scrollViewVipPrivil.getComponent(ComListView);
        (comListView == null) && (comListView = this.scrollViewVipPrivil.addComponent(ComListView))
        comListView.initParams(viewData)
        comListView.initScrollView(true);
    }

    protected bindEventListener(): void {
        super.bindEventListener();
        // EventMgr.Instance.on(LOBBY_EVENT.ACCOUNT_BINDPHONE_RET, this.onBindResult, this);
    }

    onDestroy() {
        super.onDestroy();
    }

    onClikClosed() {
        this.onClose();
    }

    onClickLevelUp() {
        HallReqManager.sendCreateOrder();
    }

    onClickMyBonus() {
        UIMgr.Instance.showView(EnumPrefab.vipBonusHistory, null, GameApp.Instance.getDialogLayer(), EnumPrefab.vipBonusHistory, false);
    }

    onClickMorePriv() {
        UIMgr.Instance.showView(EnumPrefab.vipLevelDiscrition, null, GameApp.Instance.getDialogLayer(), EnumPrefab.vipLevelDiscrition, false);
    }

    onClickBenefit() {
        UIMgr.Instance.showView(EnumPrefab.vipBonusHistory, null, GameApp.Instance.getDialogLayer(), EnumPrefab.vipBonusHistory, false);
    }

    onLevelListMoving(pageIdx: number) {
        if (this._vipShowLvl != pageIdx) {
            // Logger.debug(`移动的索引: ${pageIdx}`);
            this._vipShowLvl = pageIdx;
            this.updateView(this._vipShowLvl);
        }
    }

    updateView(vipLvl: number) {
        this.labCurPriv.string = `V${vipLvl} level privileges`;
        this.labCurBenefits.string = `V${vipLvl} level benefits`;

        VIPModel.Instance.test();
        let rebateArr = VIPModel.Instance.rebateRate;
        this.parentRebate.node.destroyAllChildren();
        rebateArr.forEach((e, idx) => {
            let newNode = cc.instantiate(this.pfRebate);
            this.parentRebate.node.addChild(newNode);

            let src = newNode.getComponent(VipRebateRate);
            src.setInfo(e.gameType, e.rate, idx == rebateArr.length - 1);
        })

        this.initVipPrivilView(VIPModel.Instance.getVipPrivInfo(vipLvl));
    }

}