import * as cc from 'cc';
import { BaseUI } from '../../../framework/base/BaseUI';
import { VipPrivilegeType } from '../../../Const';
import VIPModel, { IVipPrivilProp } from '../../../model/VIPModel';
import { VipLevelDiscritionItem } from './VipLevelDiscritionItem';

const { ccclass, property } = cc._decorator;

/**
 * VIP 各等级特权列表
 */
@ccclass('VipLevelDiscrition')
export class VipLevelDiscrition extends BaseUI {
    @property({ type: cc.Button, tooltip: "关闭按钮" })
    btnClose: cc.Button = null;

    @property({ type: cc.ScrollView, tooltip: "列表" })
    scrollView: cc.ScrollView = null;

    @property({ type: cc.Prefab, tooltip: "列表Item" })
    pfItem: cc.Prefab = null;


    protected initView(): void {
        this.btnClose.node.on(cc.Button.EventType.CLICK, this.onClickClose, this);
        this.showPrivilegeDetail();
    }

    onClickClose() {
        this.onClose();
    }

    showPrivilegeDetail() {
        for (let index = 0; index < Number.MAX_VALUE; index++) {
            let privileges = VIPModel.Instance.getVipPrivInfo(index);
            if (privileges.length <= 0) {
                break;
            }

            let item = cc.instantiate(this.pfItem);
            this.scrollView.content.addChild(item);

            let src = item.getComponent(VipLevelDiscritionItem);
            src.setVipLvl(privileges[0].vipLevel);

            privileges.forEach((e: IVipPrivilProp) => {
                src.setPrivInfo(e.category, e.titleParam);
            })
        }


    }

}