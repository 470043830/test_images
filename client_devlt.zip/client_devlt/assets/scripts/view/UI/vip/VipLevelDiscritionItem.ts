import * as cc from 'cc';
import { BaseUI } from '../../../framework/base/BaseUI';
import { VipPrivilegeType } from '../../../Const';

const { ccclass, property } = cc._decorator;

/**
 * VIP 各等级特权列表的条目
 */
@ccclass('VipLevelDiscritionItem')
export class VipLevelDiscritionItem extends BaseUI {
    @property({ type: cc.Label, tooltip: "vip等级" })
    labVipLvl: cc.Label = null;

    @property({ type: cc.Label, tooltip: "每周奖励" })
    labWeeklyBonus: cc.Label = null;

    @property({ type: cc.Label, tooltip: "升级奖励" })
    labUpBonus: cc.Label = null;

    @property({ type: cc.Label, tooltip: "每日提现限额" })
    labWithdrawLimit: cc.Label = null;

    @property({ type: cc.Label, tooltip: "提现手续费" })
    labWithDrawFee: cc.Label = null;

    @property({ type: cc.Label, tooltip: "每日免费提现次数" })
    labWithDrawTimes: cc.Label = null;

    setVipLvl(vipLvl: number) {
        this.labVipLvl.string = `V${vipLvl}`;
    }

    setPrivInfo(cate: VipPrivilegeType, param: string) {
        switch (cate) {
            case VipPrivilegeType.WEEKLY_BONUS:
                this.labWeeklyBonus.string = param;
                break;
            case VipPrivilegeType.UPGRADE_BONUS:
                this.labUpBonus.string = param;
                break;
            case VipPrivilegeType.WITHDRAW_DAILY_LIMIT:
                this.labWithdrawLimit.string = param;
                break;
            case VipPrivilegeType.WITHDRAW_FEE:
                this.labWithDrawFee.string = param;
                break;
            case VipPrivilegeType.WITHDRAW_DAILY_TIMES:
                this.labWithDrawTimes.string = param;
                break;

            default:
                break;
        }
    }

}