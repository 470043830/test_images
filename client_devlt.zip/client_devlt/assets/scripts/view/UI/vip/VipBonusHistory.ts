import * as cc from 'cc';
import { LobbyProto } from 'db://assets/scripts/protobuf/pb';
import { BaseUI } from '../../../framework/base/BaseUI';
import { ComListView } from '../../../framework/lib/ComListView';
import { VipBonusHistoryItem } from './VipBonusHistoryItem';
import VIPModel from '../../../model/VIPModel';
import AccountModel from '../../../model/AccountModel';
import { INR } from '../../../Const';

const { ccclass, property } = cc._decorator;

enum ListViewType {
    Month,
    All,
}

/**
 * VIP 历史bonus列表的元素
 */
@ccclass('VipBonusHistory')
export class VipBonusHistory extends BaseUI {
    @property({ type: cc.Button, tooltip: "关闭按钮" })
    btnClose: cc.Button = null;

    @property({ type: cc.ToggleContainer, tooltip: "单选按钮" })
    togContainer: cc.ToggleContainer = null;

    @property({ type: cc.ScrollView, tooltip: "列表" })
    scrollView: cc.ScrollView = null;

    @property({ type: cc.Prefab, tooltip: "列表Item" })
    pfItem: cc.Prefab = null;

    @property({ type: cc.Label, tooltip: "总数" })
    labTotal: cc.Label = null;

    @property({ type: cc.Node, tooltip: "历史为空" })
    ndEmpty: cc.Node = null;

    protected initView(): void {
        this.btnClose.node.on(cc.Button.EventType.CLICK, this.onClickClose, this);

        this.togContainer.toggleItems.forEach((tog, idx) => {
            tog.node.on(cc.Toggle.EventType.TOGGLE, () => {
                if (tog.isChecked) {
                    this.swithView(idx);
                }
            })
        })

        this.swithView(ListViewType.Month);
    }

    onClickClose() {
        this.onClose();
    }

    initListView(listData) {
        let viewData = {
            scrollView: this.scrollView,
            content: this.scrollView.content,
            itemPrefab: this.pfItem,
            itemClass: VipBonusHistoryItem,
            dataList: listData,
            dataEx: null,
            space: 10,
            createInterval: 0.05,
        }

        let comListView = this.scrollView.getComponent(ComListView);
        (comListView == null) && (comListView = this.scrollView.addComponent(ComListView))
        comListView.initParams(viewData)
        comListView.initScrollView(true);
    }

    swithView(v: ListViewType) {
        VIPModel.Instance.test();
        let data = VIPModel.Instance.getBonusHistory();
        if (v == ListViewType.Month) {

        } else {

        }

        this.initListView(data);

        let sum = 0;
        data.forEach(e => {
            sum += e.titleParam;
        })
        this.labTotal.string = INR + sum;

        this.ndEmpty.active = (data.length == 0);
    }
}