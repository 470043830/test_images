import * as cc from 'cc';
import { IComListItem } from '../../../framework/lib/ComListView';
import { LobbyProto } from 'db://assets/scripts/protobuf/pb';

const { ccclass, property } = cc._decorator;


/**
 * VIP 权益列表的元素
 */
@ccclass('VipPrivilItem')
export class VipPrivilItem extends cc.Component implements IComListItem {
    @property({ type: cc.Sprite, tooltip: "锁" })
    spLocked: cc.Sprite = null;

    @property({ type: cc.Sprite, tooltip: "权益图标" })
    spIcon: cc.Sprite = null;

    @property({ type: cc.Sprite, tooltip: "箭头" })
    spArrow: cc.Sprite = null;

    @property({ type: cc.Label, tooltip: "描述1" })
    labDesc1: cc.Label = null;

    @property({ type: cc.Label, tooltip: "描述2" })
    labDesc2: cc.Label = null;

    @property({ type: cc.SpriteFrame, tooltip: "ICON 图标集合" })
    framesIcon: cc.SpriteFrame[] = [];

    updateItem(idx: number, data: any, dataExt: any) {
        let itemData = data as LobbyProto.VipPrivileges;
        this.labDesc1.string = itemData.title;
        this.labDesc2.string = itemData.titleParam;

        this.spIcon.spriteFrame = this.framesIcon[idx % this.framesIcon.length];
        // this.spLocked.node.active = false;

        this.spArrow.node.active = idx < dataExt.maxCount - 1;
    }

}