import * as cc from 'cc';
import { IComListItem } from '../../../framework/lib/ComListView';
import { LobbyProto } from 'db://assets/scripts/protobuf/pb';
import { StringUtils } from '../../../framework/utils/StringUtils';
import { VipBonusHistoryProp } from '../../../model/VIPModel';
import { Logger } from '../../../framework/utils/Logger';

const { ccclass, property } = cc._decorator;


/**
 * VIP 历史bonus列表的元素
 */
@ccclass('VipBonusHistoryItem')
export class VipBonusHistoryItem extends cc.Component implements IComListItem {
    @property({ type: cc.Sprite, tooltip: "图标" })
    spIcon: cc.Sprite = null;

    @property({ type: cc.Button, tooltip: "帮助按钮" })
    btnHelp: cc.Button = null;

    @property({ type: cc.Label, tooltip: "权益内容" })
    labContent: cc.Label = null;

    @property({ type: cc.Label, tooltip: "日期" })
    labDate: cc.Label = null;

    @property({ type: cc.Label, tooltip: "数量" })
    labAmount: cc.Label = null;

    @property({ type: cc.SpriteFrame, tooltip: "ICON 图标集合" })
    framesIcon: cc.SpriteFrame[] = [];

    updateItem(idx: number, data: any, dataExt: any) {
        let itemData = data as VipBonusHistoryProp;
        this.labContent.string = itemData.title;
        this.labAmount.string = `${itemData.titleParam}`;
        this.labDate.string = StringUtils.dateFormat("yyyy-MM-dd hh:mm:ss", new Date(itemData.date));

        this.spIcon.spriteFrame = this.framesIcon[idx % this.framesIcon.length];

        this.btnHelp.node.off(cc.Button.EventType.CLICK, this.onClickHelp, this);
        this.btnHelp.node.on(cc.Button.EventType.CLICK, this.onClickHelp, this);
    }

    onClickHelp() {
        Logger.info(`点击了help`);
    }

}