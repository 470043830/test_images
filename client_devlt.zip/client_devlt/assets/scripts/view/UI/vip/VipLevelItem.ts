import * as cc from 'cc';
import { IComListItem } from '../../../framework/lib/ComListView';
import { IVipProp, VipUpCategory } from 'db://assets/scripts/model/VIPModel';
import AccountModel from 'db://assets/scripts/model/AccountModel';
import { Logger } from '../../../framework/utils/Logger';
import { gameConfig } from '../../../config/Config';
import { loadRemoteImg } from '../../../framework/lib/GlobalFunc';

const { ccclass, property } = cc._decorator;


/**
 * VIP 等级列表的元素
 */
@ccclass('VipLevelItem')
export class VipLevelItem extends cc.Component {
    @property({ type: cc.Sprite, tooltip: "VIP 等级图标" })
    vipIcon: cc.Sprite = null;

    @property({ type: cc.Sprite, tooltip: "VIP 等级数字" })
    vipLevel: cc.Sprite = null;

    @property({ type: cc.Label, tooltip: "当前等级" })
    vipCurLvl: cc.Label = null;

    @property({ type: cc.Label, tooltip: "下一等级" })
    vipNextLvl: cc.Label = null;

    @property({ type: cc.Label, tooltip: "deposit数量" })
    labDepos: cc.Label = null;

    @property({ type: cc.Label, tooltip: "wager数量" })
    labWager: cc.Label = null;

    @property({ type: cc.ProgressBar, tooltip: "deposit进度" })
    barDepos: cc.ProgressBar = null;

    @property({ type: cc.ProgressBar, tooltip: "wager进度" })
    barWager: cc.ProgressBar = null;

    @property({ type: cc.SpriteFrame, tooltip: "ICON 图标集合" })
    framesIcon: cc.SpriteFrame[] = [];

    @property({ type: cc.SpriteFrame, tooltip: "ICON 等级集合" })
    framesLvl: cc.SpriteFrame[] = [];


    protected onLoad(): void {
        this.schedule(this.refreshPos, 1 / 24);
    }

    setInfo(idx: number, data: any) {
        let itemData = data as IVipProp;
        let curVipLvl = AccountModel.Instance.vipLevel;
        // this.loadRemoteImg(itemData.icon, this.vipIcon, this.framesIcon[idx % this.framesIcon.length]);
        loadRemoteImg(this.vipIcon, gameConfig.remote_url + "vipIcons/" + itemData.iconUrl);

        this.vipLevel.spriteFrame = this.framesLvl[idx % this.framesLvl.length];
        this.vipCurLvl.string = `V${idx}`;
        this.vipNextLvl.string = `V${idx + 1}`;

        this.barDepos.node.active = false;
        this.barWager.node.active = false;

        let curDeposit = 0;
        let curWager = 0;
        if (idx + 1 == curVipLvl) {
            curDeposit = AccountModel.Instance.vipExp;
            curWager = AccountModel.Instance.vipWager;
        }

        if (itemData.category == VipUpCategory.DEPOSITE || itemData.category == VipUpCategory.ALL) {
            this.barDepos.node.active = true;
            this.barDepos.progress = curDeposit / itemData.upDeposit;
            this.labDepos.string = `${curDeposit}/${itemData.upDeposit}`
        }
        if (itemData.category == VipUpCategory.WAGER || itemData.category == VipUpCategory.ALL) {
            this.barWager.node.active = true;
            this.barWager.progress = curWager / itemData.upWager;
            this.labWager.string = `${curWager}/${itemData.upWager}`
        }
    }

    protected refreshPos(dt: number): void {
        //每个item的实际宽度为可见区域的宽度，为了能看见前一个/后一个的item部分界面，以可见区域的中轴线对每个item的子节点的x坐标进行偏移（前一个item向右偏移，后一个item向前偏移）
        let viewSize = cc.view.getVisibleSize();
        let pos = this.node.getComponent(cc.UITransform).convertToNodeSpaceAR(cc.v3(0, 0));
        let dis = pos.x + viewSize.width * 0.5;
        let rootNode = this.node.children[0];
        rootNode.position = cc.v3(dis * 0.25, rootNode.position.y)
    }
}