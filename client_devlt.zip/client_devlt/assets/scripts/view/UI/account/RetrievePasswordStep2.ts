import * as cc from 'cc';
import { BaseUI } from '../../../framework/base/BaseUI';
import { LOBBY_EVENT } from '../../../framework/event/EventDefine';
import EventMgr from '../../../framework/event/EventMgr';
const { ccclass, property } = cc._decorator;

/**
 * 
找回密码步骤2: 设置新密码
 *
 */

@ccclass('RetrievePasswordStep2')
export class RetrievePasswordStep2 extends BaseUI {
    @property({ type: cc.Button, tooltip: "关闭按钮" })
    btnClose: cc.Button = null;

    @property({ type: cc.Button, tooltip: "继续按钮" })
    btnContinue: cc.Button = null;

    @property({ type: cc.EditBox, tooltip: "密码输入框" })
    editPassword: cc.EditBox = null;

    @property({ type: cc.Button, tooltip: "密码输入框明文/密文" })
    pwCipher: cc.Button = null;

    @property({ type: cc.EditBox, tooltip: "密码确认输入框" })
    editPasswordAgain: cc.EditBox = null;

    @property({ type: cc.Button, tooltip: "密码确认输入框明文/密文" })
    pwAgainCipher: cc.Button = null;


    protected initView(): void {
        this.btnClose.node.on(cc.Button.EventType.CLICK, this.onClose, this);
        this.btnContinue.node.on(cc.Button.EventType.CLICK, this.onClickContinue, this);
    }

    bindEventListener() {
        super.bindEventListener();
        EventMgr.Instance.on(LOBBY_EVENT.ACCOUNT_RETRIEVE_NEW_PW_RET, this.onVerifyPhoneResult, this);

    }

    protected onDestroy(): void {
        super.onDestroy();
    }

    onClickContinue() {
        //TODO:请求服务器

        //测试
        EventMgr.Instance.emit(LOBBY_EVENT.ACCOUNT_RETRIEVE_NEW_PW_RET, { ret: cc.randomRangeInt(0, 2) == 1 ? true : false });
    }

    onVerifyPhoneResult(result) {
        if (result.ret) {
            this.onClose();
            return;
        }
        //TODO:提示密码修改失败
    }

}