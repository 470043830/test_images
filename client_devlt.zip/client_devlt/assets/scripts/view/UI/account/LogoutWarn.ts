import * as cc from 'cc';
import { EnumPrefab } from '../../../config/BundleConfig';
import { BaseUI } from '../../../framework/base/BaseUI';
import { UIMgr } from '../../../framework/manager/UIMgr';
import { GameApp } from '../../../lobby/GameApp';

const { ccclass, property } = cc._decorator;


/**
 * 登出警告
 */
@ccclass('LogoutWarn')
export class LogoutWarn extends BaseUI {
    @property({ type: cc.Button, tooltip: "关闭按钮" })
    btnClose: cc.Button = null;

    @property({ type: cc.Button, tooltip: "登出按钮" })
    btnLogout: cc.Button = null;

    @property({ type: cc.Button, tooltip: "去绑定按钮" })
    btnGoBind: cc.Button = null;

    initView(): void {
        this.btnClose.node.on(cc.Button.EventType.CLICK, this.onClikClosed, this);
        this.btnLogout.node.on(cc.Button.EventType.CLICK, this.onClicLogout, this);
        this.btnGoBind.node.on(cc.Button.EventType.CLICK, this.onClickGoBinding, this);
    }

    onClikClosed() {
        this.onClose();
    }

    /**
     * 登出
     */
    onClicLogout() {
        this.onClose();
        UIMgr.Instance.showView(EnumPrefab.logoutConfirm, null, GameApp.Instance.getDialogLayer(), EnumPrefab.logoutConfirm, false);
    }

    /**
     * 去绑定
     */
    onClickGoBinding() {
        this.onClose();
        UIMgr.Instance.showView(EnumPrefab.bindPhone, null, GameApp.Instance.getDialogLayer(), EnumPrefab.bindPhone, false);
    }

}