import * as cc from 'cc';
import AccountModel from '../../../model/AccountModel';
import { QRCodeComponent } from '../../../framework/lib/QRCodeComponent';

const { ccclass, property } = cc._decorator;


/**
 * 分享页面玩家的信息
 */
@ccclass('SharedUserInfo')
export class SharedUserInfo extends cc.Component {

    @property({ type: cc.Label, tooltip: "用户昵称" })
    labUserName: cc.Label = null;

    @property({ type: cc.Label, tooltip: "用户邀请码" })
    labInviteCode: cc.Label = null;

    @property(QRCodeComponent)
    QRComponent: QRCodeComponent = null;


    private _qrUrl: string = "";

    onLoad(): void {
        this.labUserName.string = AccountModel.Instance.userName;
        this.labInviteCode.string = AccountModel.Instance.inviteCode;

        this.initQrCode(`www.bilibili.com`);
    }

    //二维码
    initQrCode(qrUrl) {
        this._qrUrl = qrUrl;
        this.QRComponent.refreshQRCode(qrUrl);
    }

}