import * as cc from 'cc';
import { EnumScene } from '../../../config/BundleConfig';
import { SYS_EVENT } from '../../../framework/event/EventDefine';
import EventMgr from '../../../framework/event/EventMgr';
import { BaseUI } from '../../../framework/base/BaseUI';
import { LoginMgr } from '../../../framework/manager/LoginMgr';

const { ccclass, property } = cc._decorator;


/**
 * 登出确认
 */
@ccclass('LogoutConfirm')
export class LogoutConfirm extends BaseUI {
    @property({ type: cc.Button, tooltip: "关闭按钮" })
    btnClose: cc.Button = null;

    @property({ type: cc.Button, tooltip: "取消" })
    btnCancel: cc.Button = null;

    @property({ type: cc.Button, tooltip: "确认" })
    btnConfirm: cc.Button = null;

    initView(): void {
        this.btnClose.node.on(cc.Button.EventType.CLICK, this.onClikClosed, this);
        this.btnCancel.node.on(cc.Button.EventType.CLICK, this.onClickCancel, this);
        this.btnConfirm.node.on(cc.Button.EventType.CLICK, this.onClickConfirm, this);
    }

    onClikClosed() {
        this.onClose();
    }

    /**
     * 取消
     */
    onClickCancel() {
        this.onClose();
    }

    /**
     * 确认登出
     */
    onClickConfirm() {
        LoginMgr.Instance.logout();

        this.onClose();
        EventMgr.Instance.emit(SYS_EVENT.CHANGE_SCENE, { name: EnumScene.login });
    }

}