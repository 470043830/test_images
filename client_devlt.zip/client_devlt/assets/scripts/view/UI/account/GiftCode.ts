import * as cc from 'cc';
import { EnumPrefab } from '../../../config/BundleConfig';
import { LOBBY_EVENT } from '../../../framework/event/EventDefine';
import EventMgr from '../../../framework/event/EventMgr';
import { BaseUI } from '../../../framework/base/BaseUI';
import { UIMgr } from '../../../framework/manager/UIMgr';
import { GameApp } from '../../../lobby/GameApp';
import AccountModel from '../../../model/AccountModel';
import { Logger } from '../../../framework/utils/Logger';

const { ccclass, property } = cc._decorator;


/**
 * 礼包码
 */
@ccclass('GiftCode')
export class GiftCode extends BaseUI {
    @property({ type: cc.Button, tooltip: "关闭按钮" })
    btnClose: cc.Button = null;

    @property({ type: cc.Button, tooltip: "确认按钮" })
    btnConfirm: cc.Button = null;

    @property({ type: cc.EditBox, tooltip: "输入框" })
    editor: cc.EditBox = null;


    initView(): void {
        this.btnClose.node.on(cc.Button.EventType.CLICK, this.onClikClosed, this);
        this.btnConfirm.node.on(cc.Button.EventType.CLICK, this.onClikConfirm, this);
    }

    protected bindEventListener(): void {
        super.bindEventListener();
    }

    protected onDestroy(): void {
        super.onDestroy();
    }

    onClikClosed() {
        this.onClose();
    }

    onClikConfirm() {
        //TOOD: 请求服务器

    }


}