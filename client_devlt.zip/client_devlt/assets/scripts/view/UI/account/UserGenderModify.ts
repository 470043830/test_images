import * as cc from 'cc';
import { EnumPrefab } from '../../../config/BundleConfig';
import { LOBBY_EVENT } from '../../../framework/event/EventDefine';
import EventMgr from '../../../framework/event/EventMgr';
import { BaseUI } from '../../../framework/base/BaseUI';
import { UIMgr } from '../../../framework/manager/UIMgr';
import { GameApp } from '../../../lobby/GameApp';
import AccountModel from '../../../model/AccountModel';
import { Logger } from '../../../framework/utils/Logger';

const { ccclass, property } = cc._decorator;


/**
 * 性别修改页面
 */
@ccclass('UserGenderModify')
export class UserGenderModify extends BaseUI {
    @property({ type: cc.Button, tooltip: "关闭按钮" })
    btnClose: cc.Button = null;

    @property({ type: cc.Sprite, tooltip: "性别图标" })
    spGenders: cc.Sprite[] = [];


    initView(): void {
        this.btnClose.node.on(cc.Button.EventType.CLICK, this.onClikClosed, this);

        this.spGenders.forEach((e, idx) => {
            e.node.on(cc.Button.EventType.CLICK, () => {
                this.onClikGender(idx);
            });
        })

        this.onClikGender(AccountModel.Instance.gender);
    }

    protected bindEventListener(): void {
        super.bindEventListener();
    }

    protected onDestroy(): void {
        super.onDestroy();
    }

    onClikClosed() {
        this.onClose();
    }

    onClikGender(checkedId: number) {
        //TOOD: 请求服务器修改昵称
        AccountModel.Instance.gender = checkedId;
        this.spGenders.forEach((e, idx) => {
            e.getComponentInChildren(cc.Sprite).node.active = checkedId == idx;
        })

        EventMgr.Instance.emit(LOBBY_EVENT.ACCOUNT_UPDATE_MY_INFO);

    }


}