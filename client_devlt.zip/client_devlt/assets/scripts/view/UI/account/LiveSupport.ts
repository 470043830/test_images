import * as cc from 'cc';
import { BaseUI } from '../../../framework/base/BaseUI';

const { ccclass, property } = cc._decorator;


/**
 * 直播支持
 */
@ccclass('LiveSupport')
export class LiveSupport extends BaseUI {
    @property({ type: cc.Button, tooltip: "返回按钮" })
    btnBack: cc.Button = null;



    initView(): void {
        this.btnBack.node.on(cc.Button.EventType.CLICK, this.onClikClosed, this);
    }

    onClikClosed() {
        this.onClose();
    }




}