import * as cc from 'cc';
import { LOBBY_EVENT } from '../../../framework/event/EventDefine';
import EventMgr from '../../../framework/event/EventMgr';
import { BaseUI } from '../../../framework/base/BaseUI';
import AccountModel from '../../../model/AccountModel';
import { Logger } from '../../../framework/utils/Logger';
import { ToastMgr } from '../../../framework/manager/ToastMgr';
import { HallReqManager } from '../../../framework/net/HallReqManager';

const { ccclass, property } = cc._decorator;


/**
 * 绑定邀请码页面
 */
@ccclass('BindInvitationCode')
export class BindInvitationCode extends BaseUI {
    @property({ type: cc.Button, tooltip: "关闭按钮" })
    btnClose: cc.Button = null;

    @property({ type: cc.Button, tooltip: "确认按钮" })
    btnConfirm: cc.Button = null;

    @property({ type: cc.Button, tooltip: "取消按钮" })
    btnCancel: cc.Button = null;

    @property({ type: cc.EditBox, tooltip: "输入框" })
    editor: cc.EditBox = null;


    initView(): void {
        this.btnClose.node.on(cc.Button.EventType.CLICK, this.onClikClosed, this);
        this.btnCancel.node.on(cc.Button.EventType.CLICK, this.onClikClosed, this);
        this.btnConfirm.node.on(cc.Button.EventType.CLICK, this.onClikConfirm, this);
    }

    protected bindEventListener(): void {
        super.bindEventListener();
    }

    protected onDestroy(): void {
        super.onDestroy();
    }

    onClikClosed() {
        this.onClose();
    }

    onClikConfirm() {
        HallReqManager.sendBindInviteCode(this.editor.string);
        this.onClose();
    }


}