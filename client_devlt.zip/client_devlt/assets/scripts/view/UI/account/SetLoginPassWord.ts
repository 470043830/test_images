import * as cc from 'cc';
import { BaseUI } from '../../../framework/base/BaseUI';
import { EnumScene } from '../../../config/BundleConfig';
import { checkNumber, StartTimeCountDown } from '../../../framework/lib/GlobalFunc';
import { LOBBY_EVENT } from '../../../framework/event/EventDefine';
import EventMgr from '../../../framework/event/EventMgr';
import { HttpUtils } from '../../../framework/utils/HttpUtils';
import { ToastMgr } from '../../../framework/manager/ToastMgr';
import { Logger } from '../../../framework/utils/Logger';
import { HallReqManager } from '../../../framework/net/HallReqManager';
import AccountModel from '../../../model/AccountModel';
import GlobalModel from '../../../model/GlobalModel';
const { ccclass, property } = cc._decorator;

/**
 * 
 * 设置密码
 *
 */

@ccclass('SetLoginPassWord')
export class SetLoginPassWord extends BaseUI {
    @property({ type: cc.Button, tooltip: "关闭按钮" })
    btnClose: cc.Button = null;

    @property({ type: cc.Button, tooltip: "完成按钮" })
    btnComplete: cc.Button = null;

    @property({ type: cc.Button, tooltip: "发送按钮" })
    btnSend: cc.Button = null;

    @property({ type: cc.Label, tooltip: "发送冷却时间" })
    labSendCD: cc.Label = null;

    @property({ type: cc.EditBox, tooltip: "手机号码输入框" })
    editPhone: cc.EditBox = null;

    @property({ type: cc.EditBox, tooltip: "验证码输入框" })
    editVerify: cc.EditBox = null;

    @property({ type: cc.EditBox, tooltip: "输入密码" })
    editPW: cc.EditBox = null;

    @property({ type: cc.EditBox, tooltip: "再次输入密码" })
    editPWAgain: cc.EditBox = null;

    @property({ type: cc.Button, tooltip: "明文/密文" })
    btnEye: cc.Button = null;

    @property({ type: cc.Button, tooltip: "明文/密文" })
    btnEyeAgain: cc.Button = null;

    @property({ type: cc.SpriteFrame, tooltip: "明文图片" })
    frameEye: cc.SpriteFrame = null;

    @property({ type: cc.SpriteFrame, tooltip: "密文图片" })
    frameCipher: cc.SpriteFrame = null;

    private _isCD: boolean = false;

    private _pwCipher: boolean = false;
    private _pwCipherAgain: boolean = false;

    protected initView(): void {
        this.btnClose.node.on(cc.Button.EventType.CLICK, this.onClose, this);
        this.btnComplete.node.on(cc.Button.EventType.CLICK, this.onClickComplete, this);
        this.btnSend.node.on(cc.Button.EventType.CLICK, this.onClickSend, this);
        this.btnEye.node.on(cc.Button.EventType.CLICK, this.onClickEye, this);
        this.btnEyeAgain.node.on(cc.Button.EventType.CLICK, this.onClickEyeAgain, this);

        this.editPW.node.on(cc.EditBox.EventType.EDITING_RETURN, this.onCheckPW, this);
        this.editPW.node.on(cc.EditBox.EventType.EDITING_DID_ENDED, this.onCheckPW, this);

        this.editPWAgain.node.on(cc.EditBox.EventType.EDITING_RETURN, this.onCheckPWAgain, this);
        this.editPWAgain.node.on(cc.EditBox.EventType.EDITING_DID_ENDED, this.onCheckPWAgain, this);

        this.labSendCD.node.active = false;

        if (!GlobalModel.Instance.curScene || GlobalModel.Instance.curScene.name == EnumScene.login) {
            //在登录场景不处理
        } else {
            this.editPhone.string = AccountModel.Instance.bindPhoneNum;
            this.editPhone.enabled = false;
        }
    }

    bindEventListener() {
        super.bindEventListener();
        EventMgr.Instance.on(LOBBY_EVENT.ACCOUNT_MODIFY_PW, this.onSetPasswordResult, this);

    }

    protected onDestroy(): void {
        super.onDestroy();
    }

    onClickComplete() {
        if (!checkNumber(this.editPhone.string, 5, `请输入手机号码`, `手机号码长度不正确`)) {
            return;
        }

        if (!checkNumber(this.editVerify.string, 6, `请输入验证码`, `验证码长度不正确`, true)) {
            return;
        }

        if (!checkNumber(this.editPW.string, 8, `请输入密码`, `密码长度至少8位`)) {
            return;
        }

        if (this.editPW.string.length > 32) {
            ToastMgr.Instance.onRecvToast({ msg: "密码长度超过32位" })
            return;
        }

        if (this.editPW.string == "" || this.editPWAgain.string == "") {
            ToastMgr.Instance.onRecvToast({ msg: `请输入密码` });
            return;
        }

        if (this.editPW.string == this.editPWAgain.string) {
            if (!GlobalModel.Instance.curScene || GlobalModel.Instance.curScene.name == EnumScene.login) {
                HttpUtils.modifyPassword(this.editPhone.string, this.editVerify.string, this.editPW.string, (ret) => {
                    if (ret && ret.code == 200) {
                        this.onClose();
                        ToastMgr.Instance.onRecvToast({ msg: "找回密码成功" })
                    } else {
                        ToastMgr.Instance.onRecvToast({ msg: "找回密码失败" })
                    }
                })
            } else {
                //游戏内
                HallReqManager.sendSetPassword(this.editPW.string, this.editVerify.string);
            }
        } else {
            ToastMgr.Instance.onRecvToast({ msg: `两次输入的密码不一致` });
        }
    }

    onClickSend() {
        if (this._isCD) {
            return;
        }

        if (!checkNumber(this.editPhone.string, 5, `请输入手机号码`, `手机号码长度不正确`)) {
            return;
        }

        this._isCD = true;

        HttpUtils.sendVerifyCode(this.editPhone.string, (ret) => {
            if (ret && ret.code == 200) {
                this.startVerifyCD();
                ToastMgr.Instance.onRecvToast({ msg: "验证码已发送" })
            } else {
                Logger.error(`请求验证码失败:`, JSON.stringify(ret));
                ToastMgr.Instance.onRecvToast({ msg: "请求验证码失败" })
            }
        })

    }

    onClickEye() {
        this._pwCipher = !this._pwCipher;
        this.btnEye.getComponent(cc.Sprite).spriteFrame = this._pwCipher ? this.frameCipher : this.frameEye;

        this.editPW.inputFlag = this._pwCipher ? cc.EditBox.InputFlag.PASSWORD : cc.EditBox.InputFlag.DEFAULT;
    }

    onClickEyeAgain() {
        this._pwCipherAgain = !this._pwCipherAgain;
        this.btnEyeAgain.getComponent(cc.Sprite).spriteFrame = this._pwCipherAgain ? this.frameCipher : this.frameEye;

        this.editPWAgain.inputFlag = this._pwCipherAgain ? cc.EditBox.InputFlag.PASSWORD : cc.EditBox.InputFlag.DEFAULT;
    }

    onCheckPW() {
        if (this.editPW.string != "" && this.editPWAgain.string != "" && this.editPW.string != this.editPWAgain.string) {
            ToastMgr.Instance.onRecvToast({ msg: `两次输入的密码不一致` });
        }
    }

    onCheckPWAgain() {
        this.onCheckPW();
    }

    onSetPasswordResult(result) {
        this.onClose();
    }

    startVerifyCD() {
        cc.Tween.stopAllByTarget(this.labSendCD.node);
        this.btnSend.node.active = false;
        this.labSendCD.node.active = true;
        this._isCD = true;
        StartTimeCountDown(this.labSendCD, 10, () => {
            this.btnSend.node.active = true;
            this.labSendCD.node.active = false;
            this._isCD = false;
        }, null, "(%ss)", (t) => {
            // this.timeLeft = t;
        })
    }

    stopVerifyCD() {
        cc.Tween.stopAllByTarget(this.labSendCD.node);
        this._isCD = false;
        this.btnSend.node.active = true;
        this.labSendCD.node.active = false;
    }
}