import * as cc from 'cc';
import { BaseUI } from '../../../framework/base/BaseUI';

const { ccclass, property } = cc._decorator;


/**
 * 关于我们
 */
@ccclass('AboutUs')
export class AboutUs extends BaseUI {
    @property({ type: cc.Button, tooltip: "返回按钮" })
    btnBack: cc.Button = null;

    @property({ type: cc.Button, tooltip: "telegram按钮" })
    btnTelegram: cc.Button = null;

    @property({ type: cc.Button, tooltip: "whatsapp按钮" })
    btnWhatsapp: cc.Button = null;

    @property({ type: cc.Button, tooltip: "InstaGram按钮" })
    btnInstaGram: cc.Button = null;

    @property({ type: cc.Button, tooltip: "Moj按钮" })
    btnMoj: cc.Button = null;

    @property({ type: cc.Button, tooltip: "Youtube按钮" })
    btnYoutube: cc.Button = null;


    initView(): void {
        this.btnBack.node.on(cc.Button.EventType.CLICK, this.onClikClosed, this);
        this.btnTelegram.node.on(cc.Button.EventType.CLICK, this.onClicTelegram, this);
        this.btnWhatsapp.node.on(cc.Button.EventType.CLICK, this.onClickWhatsapp, this);
        this.btnInstaGram.node.on(cc.Button.EventType.CLICK, this.onClickInstaGram, this);
        this.btnMoj.node.on(cc.Button.EventType.CLICK, this.onClickMoj, this);
        this.btnYoutube.node.on(cc.Button.EventType.CLICK, this.onClickYoutube, this);
    }

    onClikClosed() {
        this.onClose();
    }



    onClicTelegram() {
        //TODO: 拉起telegram app
    }


    onClickWhatsapp() {

    }


    onClickInstaGram() {

    }

    onClickMoj() {

    }


    onClickYoutube() {

    }


}