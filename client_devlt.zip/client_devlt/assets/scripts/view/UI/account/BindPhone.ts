import * as cc from 'cc';
import { EnumScene } from '../../../config/BundleConfig';
import { GAME_EVENT, LOBBY_EVENT, SYS_EVENT } from '../../../framework/event/EventDefine';
import EventMgr from '../../../framework/event/EventMgr';
import { BaseUI } from '../../../framework/base/BaseUI';
import { checkNumber, StartTimeCountDown } from '../../../framework/lib/GlobalFunc';
import { HallReqManager } from '../../../framework/net/HallReqManager';
import { PhoneAreaCode } from '../../../Const';
import { ToastMgr } from '../../../framework/manager/ToastMgr';
import { HttpUtils } from '../../../framework/utils/HttpUtils';
import { Logger } from '../../../framework/utils/Logger';

const { ccclass, property } = cc._decorator;


/**
 * 绑定手机
 */
@ccclass('BindPhone')
export class BindPhone extends BaseUI {
    @property({ type: cc.Button, tooltip: "关闭按钮" })
    btnClose: cc.Button = null;

    @property({ type: cc.Button, tooltip: "请求验证码按钮" })
    btnVerify: cc.Button = null;

    @property({ type: cc.Button, tooltip: "确认按钮" })
    btnConfirm: cc.Button = null;

    @property({ type: cc.EditBox, tooltip: "手机号码" })
    editPhone: cc.EditBox = null;

    @property({ type: cc.EditBox, tooltip: "验证码" })
    editVerify: cc.EditBox = null;

    @property({ type: cc.Label, tooltip: "发送倒计时" })
    labSendCD: cc.Label = null;

    private _isCD: boolean = false;

    initView(): void {
        this.btnClose.node.on(cc.Button.EventType.CLICK, this.onClikClosed, this);
        this.btnVerify.node.on(cc.Button.EventType.CLICK, this.onClickSend, this);
        this.btnConfirm.node.on(cc.Button.EventType.CLICK, this.onClickConfirm, this);
        this.editPhone.node.on(cc.EditBox.EventType.EDITING_RETURN, this.onCheckPhone, this);
        this.editPhone.node.on(cc.EditBox.EventType.EDITING_DID_ENDED, this.onCheckPhone, this);

        this.labSendCD.node.active = false;
    }

    protected bindEventListener(): void {
        super.bindEventListener();
        EventMgr.Instance.on(LOBBY_EVENT.ACCOUNT_BINDPHONE_RET, this.onBindResult, this);
    }

    onDestroy() {
        super.onDestroy();
    }

    onClikClosed() {
        this.onClose();
    }

    /**
     * 请求验证码
     */
    onClickSend() {
        if (this._isCD) {
            return;
        }

        this._isCD = true;

        HttpUtils.sendVerifyCode(this.editPhone.string, (ret) => {
            if (ret && ret.code == 200) {
                this.startVerifyCD();
                ToastMgr.Instance.onRecvToast({ msg: "验证码已发送" })
            } else {
                Logger.error(`请求验证码失败:`, JSON.stringify(ret));
                ToastMgr.Instance.onRecvToast({ msg: "请求验证码失败" })
            }
        })

    }

    /**
     * 点击了确认
     */
    onClickConfirm() {
        if (!checkNumber(this.editPhone.string, 5, `请输入手机号码`, `手机号码长度不正确`)) {
            return;
        }

        if (!checkNumber(this.editVerify.string, 6, `请输入验证码`, `验证码长度不正确`, true)) {
            return;
        }

        HallReqManager.sendBindPhone(PhoneAreaCode, this.editPhone.string, this.editVerify.string);
    }

    /**
     * 登录/登出
     */
    onClickSign() {
        EventMgr.Instance.emit(GAME_EVENT.ON_LOADING_CIRCLE, true);
        EventMgr.Instance.emit(SYS_EVENT.CHANGE_SCENE, { name: EnumScene.lobby });
    }

    /**
     * 验证手机号码
     */
    onCheckPhone() {
        checkNumber(this.editPhone.string, 5, `请输入手机号码`, `手机号码长度不正确`);
    }

    onBindResult(result) {
        this.onClose();
    }

    startVerifyCD() {
        cc.Tween.stopAllByTarget(this.labSendCD.node);
        this.btnVerify.node.active = false;
        this.labSendCD.node.active = true;
        this._isCD = true;
        StartTimeCountDown(this.labSendCD, 10, () => {
            this.btnVerify.node.active = true;
            this.labSendCD.node.active = false;
            this._isCD = false;
        }, null, "(%ss)", (t) => {
            // this.timeLeft = t;
        })
    }

    stopVerifyCD() {
        cc.Tween.stopAllByTarget(this.labSendCD.node);
        this._isCD = false;
        this.btnVerify.node.active = true;
        this.labSendCD.node.active = false;
    }
}