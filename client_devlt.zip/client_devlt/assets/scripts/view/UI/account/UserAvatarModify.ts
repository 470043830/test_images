import * as cc from 'cc';
import { EnumPrefab } from '../../../config/BundleConfig';
import { LOBBY_EVENT } from '../../../framework/event/EventDefine';
import EventMgr from '../../../framework/event/EventMgr';
import { BaseUI } from '../../../framework/base/BaseUI';
import { UIMgr } from '../../../framework/manager/UIMgr';
import { GameApp } from '../../../lobby/GameApp';
import AccountModel from '../../../model/AccountModel';

const { ccclass, property } = cc._decorator;


/**
 * 头像修改页面
 */
@ccclass('UserAvatarModify')
export class UserAvatarModify extends BaseUI {
    @property({ type: cc.Button, tooltip: "返回按钮" })
    btnBack: cc.Button = null;

    @property({ type: cc.ScrollView, tooltip: "滚动列表" })
    scrollView: cc.ScrollView = null;

    @property({ type: cc.Sprite, tooltip: "头像模版" })
    spAvatarTemplete: cc.Sprite = null;

    @property({ type: cc.SpriteFrame, tooltip: "头像资源" })
    avatarFrames: cc.SpriteFrame[] = [];

    initView(): void {
        this.btnBack.node.on(cc.Button.EventType.CLICK, this.onClikClosed, this);

        this.initAvatarList();
    }

    protected bindEventListener(): void {
        super.bindEventListener();
    }

    protected onDestroy(): void {
        super.onDestroy();
    }

    initAvatarList() {
        this.avatarFrames.forEach((e, idx) => {
            let newAvatar = cc.instantiate(this.spAvatarTemplete.node);
            this.scrollView.content.addChild(newAvatar);

            newAvatar.on(cc.Button.EventType.CLICK, () => {
                this.setChecked(idx);

                //TODO：请求服务器修改头像
            })
        })
        this.spAvatarTemplete.node.destroy();
        this.setChecked(0);
    }

    refreshInfo() {

    }

    setChecked(checkedIdx: number) {
        let items = this.scrollView.content.children;
        items.forEach((e, idx) => {
            let spChecked = e.getComponentInChildren(cc.Sprite);
            spChecked.node.active = checkedIdx == idx;
        })
    }

    onClikClosed() {
        this.onClose();
    }


}