import * as cc from 'cc';
import { BaseUI } from '../../../framework/base/BaseUI';
import { EnumPrefab } from '../../../config/BundleConfig';
import { UIMgr } from '../../../framework/manager/UIMgr';
import { GameApp } from '../../../lobby/GameApp';
import { StartTimeCountDown } from '../../../framework/lib/GlobalFunc';
import { LOBBY_EVENT } from '../../../framework/event/EventDefine';
import EventMgr from '../../../framework/event/EventMgr';
import { ToastMgr } from '../../../framework/manager/ToastMgr';
import { HttpUtils } from '../../../framework/utils/HttpUtils';
import { Logger } from '../../../framework/utils/Logger';
const { ccclass, property } = cc._decorator;

/**
 * 
找回密码步骤1：验证手机号码
 *
 */

@ccclass('RetrievePasswordStep1')
export class RetrievePasswordStep1 extends BaseUI {
    @property({ type: cc.Button, tooltip: "关闭按钮" })
    btnClose: cc.Button = null;

    @property({ type: cc.Button, tooltip: "继续按钮" })
    btnContinue: cc.Button = null;

    @property({ type: cc.Button, tooltip: "发送按钮" })
    btnSend: cc.Button = null;

    @property({ type: cc.Label, tooltip: "发送冷却时间" })
    labSendCD: cc.Label = null;

    @property({ type: cc.EditBox, tooltip: "手机号码输入框" })
    editPhone: cc.EditBox = null;

    @property({ type: cc.EditBox, tooltip: "验证码输入框" })
    editVerify: cc.EditBox = null;

    private _isCD: boolean = false;
    protected initView(): void {
        this.btnClose.node.on(cc.Button.EventType.CLICK, this.onClose, this);
        this.btnContinue.node.on(cc.Button.EventType.CLICK, this.onClickContinue, this);
        this.btnSend.node.on(cc.Button.EventType.CLICK, this.onClickSend, this);

        this.labSendCD.node.active = false;
    }

    bindEventListener() {
        super.bindEventListener();
        EventMgr.Instance.on(LOBBY_EVENT.ACCOUNT_RETRIEVE_PHONE_RET, this.onVerifyPhoneResult, this);

    }

    protected onDestroy(): void {
        super.onDestroy();
    }

    onClickContinue() {
        if (this.editPhone.string == "") {
            ToastMgr.Instance.onRecvToast({ msg: `请输入手机号码` })
            return;
        }

        if (this.editVerify.string == "") {
            ToastMgr.Instance.onRecvToast({ msg: `请输入验证码` })
            return;
        }

        //测试
        // EventMgr.Instance.emit(LOBBY_EVENT.ACCOUNT_RETRIEVE_PHONE_RET, { ret: cc.randomRangeInt(0, 2) == 1 ? true : false });
    }

    onClickSend() {
        if (this._isCD) {
            return;
        }

        this._isCD = true;

        HttpUtils.sendVerifyCode(this.editPhone.string, (ret) => {
            if (ret && ret.code == 200) {
                this.startVerifyCD();
                ToastMgr.Instance.onRecvToast({ msg: "验证码已发送" })
            } else {
                Logger.error(`请求验证码失败:`, JSON.stringify(ret));
                ToastMgr.Instance.onRecvToast({ msg: "请求验证码失败" })
            }
        })

    }

    onVerifyPhoneResult(result) {
        if (result.ret) {
            this.onClose();
            UIMgr.Instance.showView(EnumPrefab.retrievePasswordStep2, null, GameApp.Instance.getDialogLayer(), EnumPrefab.retrievePasswordStep2, false);
            return;
        }

        //TODO: 提示验证失败
    }


    startVerifyCD() {
        cc.Tween.stopAllByTarget(this.labSendCD.node);
        this.btnSend.node.active = false;
        this.labSendCD.node.active = true;
        this._isCD = true;
        StartTimeCountDown(this.labSendCD, 10, () => {
            this.btnSend.node.active = true;
            this.labSendCD.node.active = false;
            this._isCD = false;
        }, null, "(%ss)", (t) => {
            // this.timeLeft = t;
        })
    }

    stopVerifyCD() {
        cc.Tween.stopAllByTarget(this.labSendCD.node);
        this._isCD = false;
        this.btnSend.node.active = true;
        this.labSendCD.node.active = false;
    }
}