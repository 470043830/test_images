import * as cc from 'cc';
import { EnumPrefab } from '../../../config/BundleConfig';
import { LOBBY_EVENT } from '../../../framework/event/EventDefine';
import EventMgr from '../../../framework/event/EventMgr';
import { BaseUI } from '../../../framework/base/BaseUI';
import { UIMgr } from '../../../framework/manager/UIMgr';
import { GameApp } from '../../../lobby/GameApp';
import AccountModel from '../../../model/AccountModel';
import { Logger } from '../../../framework/utils/Logger';

const { ccclass, property } = cc._decorator;


/**
 * 昵称修改页面
 */
@ccclass('UserNameModify')
export class UserNameModify extends BaseUI {
    @property({ type: cc.Button, tooltip: "关闭按钮" })
    btnClose: cc.Button = null;

    @property({ type: cc.Button, tooltip: "保存按钮" })
    btnSave: cc.Button = null;

    @property({ type: cc.EditBox, tooltip: "输入框" })
    editor: cc.EditBox = null;


    initView(): void {
        this.btnClose.node.on(cc.Button.EventType.CLICK, this.onClikClosed, this);
        this.btnSave.node.on(cc.Button.EventType.CLICK, this.onClikSave, this);
    }

    protected bindEventListener(): void {
        super.bindEventListener();
    }

    protected onDestroy(): void {
        super.onDestroy();
    }

    onClikClosed() {
        this.onClose();
    }

    onClikSave() {
        //TOOD: 请求服务器修改昵称
        Logger.info(`new name:`, this.editor.string);
        AccountModel.Instance.userName = this.editor.string;

        EventMgr.Instance.emit(LOBBY_EVENT.ACCOUNT_UPDATE_MY_INFO);

    }


}