import * as cc from 'cc';
import { EnumPrefab } from '../../../config/BundleConfig';
import { LOBBY_EVENT } from '../../../framework/event/EventDefine';
import EventMgr from '../../../framework/event/EventMgr';
import { BaseUI } from '../../../framework/base/BaseUI';
import { UIMgr } from '../../../framework/manager/UIMgr';
import { GameApp } from '../../../lobby/GameApp';
import AccountModel from '../../../model/AccountModel';

const { ccclass, property } = cc._decorator;


/**
 * 我的信息
 */
@ccclass('MyInfo')
export class MyInfo extends BaseUI {
    @property({ type: cc.Button, tooltip: "返回按钮" })
    btnBack: cc.Button = null;

    @property({ type: cc.Button, tooltip: "复制UID按钮" })
    btnCopyUID: cc.Button = null;

    @property({ type: cc.Button, tooltip: "复制邀请码按钮" })
    btnCopyCode: cc.Button = null;

    @property({ type: cc.Button, tooltip: "Other按钮" })
    btnOther: cc.Button = null;

    @property({ type: cc.Button, tooltip: "绑定手机号码按钮" })
    btnBindPhone: cc.Button = null;

    @property({ type: cc.Button, tooltip: "修改密码按钮" })
    btnPassword: cc.Button = null;

    @property({ type: cc.Button, tooltip: "绑定邀请码按钮" })
    btnInviteCode: cc.Button = null;

    @property({ type: cc.Label, tooltip: "UID" })
    labUserID: cc.Label = null;

    @property({ type: cc.Label, tooltip: "昵称" })
    labNickName: cc.Label = null;

    @property({ type: cc.Label, tooltip: "我的分享码" })
    labShareCode: cc.Label = null;

    @property({ type: cc.Label, tooltip: "绑定的手机号" })
    labPhone: cc.Label = null;

    @property({ type: cc.Label, tooltip: "登录密码" })
    labPassword: cc.Label = null;

    @property({ type: cc.Label, tooltip: "邀请码" })
    labInviteCode: cc.Label = null;

    @property({ type: cc.Sprite, tooltip: "头像" })
    spAvatar: cc.Sprite = null;

    initView(): void {
        this.btnBack.node.on(cc.Button.EventType.CLICK, this.onClikClosed, this);
        // this.btnAvatar.node.on(cc.Button.EventType.CLICK, this.onClicAvatar, this);
        // this.btnNickName.node.on(cc.Button.EventType.CLICK, this.onClickNickName, this);
        // this.btnGender.node.on(cc.Button.EventType.CLICK, this.onClickGender, this);
        this.btnCopyUID.node.on(cc.Button.EventType.CLICK, this.onClickCopyUserID, this);
        this.btnCopyCode.node.on(cc.Button.EventType.CLICK, this.onClickCopyCode, this);
        this.btnOther.node.on(cc.Button.EventType.CLICK, this.onClickOther, this);
        this.btnBindPhone.node.on(cc.Button.EventType.CLICK, this.onClickBindPhone, this);
        this.btnPassword.node.on(cc.Button.EventType.CLICK, this.onClickPassword, this);
        this.btnInviteCode.node.on(cc.Button.EventType.CLICK, this.onClickInviteCode, this);

        this.updateUserInfo();
    }

    protected bindEventListener(): void {
        super.bindEventListener();
        EventMgr.Instance.on(LOBBY_EVENT.ACCOUNT_UPDATE_MY_INFO, this.updateUserInfo, this);
        EventMgr.Instance.on(LOBBY_EVENT.ACCOUNT_BIND_INVITE_CODE, this.updateUserInfo, this);
        EventMgr.Instance.on(LOBBY_EVENT.ACCOUNT_BINDPHONE_RET, this.updateUserInfo, this);
        EventMgr.Instance.on(LOBBY_EVENT.ACCOUNT_MODIFY_PW, this.updateUserInfo, this);
    }

    protected onDestroy(): void {
        super.onDestroy();
    }


    updateUserInfo() {
        // this.spAvatar.spriteFrame = ;
        this.labUserID.string = AccountModel.Instance.userId;
        this.labNickName.string = AccountModel.Instance.userName;
        this.labShareCode.string = AccountModel.Instance.shareCode;
        this.labPhone.string = AccountModel.Instance.bindPhoneNum;
        this.labPassword.string = AccountModel.Instance.passWord;
        this.labInviteCode.string = AccountModel.Instance.inviteCode;

        this.udapteButtonState();
    }

    udapteButtonState() {
        let bindPhoneEnable = AccountModel.Instance.bindPhoneNum == "";
        let bindInviteCodeEnable = AccountModel.Instance.inviteCode == "";

        this.btnBindPhone.enabled = bindPhoneEnable;
        this.btnInviteCode.enabled = bindInviteCodeEnable;

        this.btnBindPhone.getComponentInChildren(cc.Sprite).node.active = bindPhoneEnable;
        this.btnInviteCode.getComponentInChildren(cc.Sprite).node.active = bindInviteCodeEnable;
    }

    onClikClosed() {
        this.onClose();
    }

    /**
     * 登出
     */
    onClicLogout() {
        this.onClose();
        UIMgr.Instance.showView(EnumPrefab.logoutConfirm, null, GameApp.Instance.getDialogLayer(), EnumPrefab.logoutConfirm, false);
    }

    /**
     * 去绑定
     */
    onClickGoBinding() {
        this.onClose();
        UIMgr.Instance.showView(EnumPrefab.bindPhone, null, GameApp.Instance.getDialogLayer(), EnumPrefab.bindPhone, false);
    }


    /**
     * 打开头像选择页面
     */
    onClicAvatar() {
        UIMgr.Instance.showView(EnumPrefab.userAvatarModify, null, GameApp.Instance.getDialogLayer(), EnumPrefab.userAvatarModify, false);
    }

    /**
     * 打开昵称修改页面
     */
    onClickNickName() {
        UIMgr.Instance.showView(EnumPrefab.userNameModify, null, GameApp.Instance.getDialogLayer(), EnumPrefab.userNameModify, false);
    }

    /**
     * 打开性别修改页面
     */
    onClickGender() {
        UIMgr.Instance.showView(EnumPrefab.userGenderModify, null, GameApp.Instance.getDialogLayer(), EnumPrefab.userGenderModify, false);
    }

    onClickCopyUserID() {
        platform.setClipText(this.labUserID.string);
    }

    onClickCopyCode() {
        platform.setClipText(this.labShareCode.string);
    }

    /**
     * 打开其他
     */
    onClickOther() {

    }

    /**
     * 打开绑定手机号码页面
     */
    onClickBindPhone() {
        UIMgr.Instance.showView(EnumPrefab.bindPhone, null, GameApp.Instance.getDialogLayer(), EnumPrefab.bindPhone, false);
    }

    /**
     * 打开密码修改页面
     */
    onClickPassword() {
        UIMgr.Instance.showView(EnumPrefab.setLoginPassWord, null, GameApp.Instance.getDialogLayer(), EnumPrefab.setLoginPassWord, false);

    }

    /**
     * 打开绑定邀请码页面
     */
    onClickInviteCode() {
        UIMgr.Instance.showView(EnumPrefab.bindInvitationCode, null, GameApp.Instance.getDialogLayer(), EnumPrefab.bindInvitationCode, false);
    }


}