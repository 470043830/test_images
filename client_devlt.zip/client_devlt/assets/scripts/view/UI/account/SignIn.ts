import * as cc from 'cc';
import { EnumPrefab, EnumScene } from '../../../config/BundleConfig';
import { GAME_EVENT, LOBBY_EVENT, SYS_EVENT } from '../../../framework/event/EventDefine';
import EventMgr from '../../../framework/event/EventMgr';
import { UIMgr } from '../../../framework/manager/UIMgr';
import { GameApp } from '../../../lobby/GameApp';
import { checkNumber, StartTimeCountDown } from '../../../framework/lib/GlobalFunc';
import { LoginMgr } from '../../../framework/manager/LoginMgr';
import { HttpUtils } from '../../../framework/utils/HttpUtils';
import { ToastMgr } from '../../../framework/manager/ToastMgr';
import { Logger } from '../../../framework/utils/Logger';
import { LoginType } from '../../../Const';

const { ccclass, property } = cc._decorator;


/**
 * 注册登录
 */
@ccclass('SignIn')
export class SignIn extends cc.Component {
    @property({ type: cc.Button, tooltip: "请求验证码按钮" })
    btnVerify: cc.Button = null;

    @property({ type: cc.Button, tooltip: "登录/登出按钮" })
    btnLogin: cc.Button = null;

    @property({ type: cc.Button, tooltip: "验证码登录方式按钮" })
    btnLoginTypeVerify: cc.Button = null;

    @property({ type: cc.Button, tooltip: "密码登录方式按钮" })
    bntLoginTypePW: cc.Button = null;

    @property({ type: cc.EditBox, tooltip: "手机号码" })
    editPhone: cc.EditBox = null;

    @property({ type: cc.EditBox, tooltip: "验证码" })
    editVerify: cc.EditBox = null;

    @property({ type: cc.EditBox, tooltip: "密码" })
    editPassword: cc.EditBox = null;

    @property({ type: cc.Label, tooltip: "请求验证码倒计时" })
    labVerifyCD: cc.Label = null;

    @property({ type: cc.Button, tooltip: "明文/暗纹按钮" })
    btnEye: cc.Button = null;

    @property({ type: cc.SpriteFrame, tooltip: "明文/暗纹图片 " })
    frameEyes: cc.SpriteFrame[] = [];

    @property({ type: cc.Node, tooltip: "验证码登录节点" })
    ndVerify: cc.Node = null;

    @property({ type: cc.Node, tooltip: "密码登录节点" })
    ndPassword: cc.Node = null;

    @property({ type: cc.Button, tooltip: "忘记密码" })
    btnForgot: cc.Button = null;

    @property({ type: cc.Button, tooltip: "设备号登录" })
    btnLoginByDevice: cc.Button = null;

    private _bCiphertext: boolean = false;      //密码是否为密文
    private _isByPassword: boolean = true;      //当前是否为密码登录方式
    private _isCD: boolean = false;

    protected onLoad(): void {
        this.btnVerify.node.on(cc.Button.EventType.CLICK, this.onClickSend, this);
        this.btnEye.node.on(cc.Button.EventType.CLICK, this.onClickEye, this);
        this.btnLogin.node.on(cc.Button.EventType.CLICK, this.onClickSign, this);
        this.btnForgot.node.on(cc.Button.EventType.CLICK, this.onClickForgot, this);
        this.btnLoginTypeVerify.node.on(cc.Button.EventType.CLICK, this.onLoginByVerify, this);
        this.bntLoginTypePW.node.on(cc.Button.EventType.CLICK, this.onLoginByPassword, this);
        this.btnLoginByDevice.node.on(cc.Button.EventType.CLICK, this.onLoginByDevice, this);
        this.editPhone.node.on(cc.EditBox.EventType.EDITING_RETURN, this.onCheckPhone, this);

        this.btnLoginByDevice.node.active = cc.sys.isBrowser;

        this.onLoginByVerify();
        this.initEventListener();
    }

    initEventListener() {

    }

    protected onDestroy(): void {
    }

    /**
     * 请求验证码
     */
    onClickSend() {
        if (this._isCD) {
            return;
        }

        if (!checkNumber(this.editPhone.string, 5, `请输入手机号码`, `手机号码长度不正确`)) {
            return;
        }


        this._isCD = true;

        HttpUtils.sendVerifyCode(this.editPhone.string, (ret) => {
            if (ret && ret.code == 200) {
                this.startVerifyCD();
                ToastMgr.Instance.onRecvToast({ msg: "验证码已发送" })
            } else {
                Logger.error(`请求验证码失败:`, JSON.stringify(ret));
                ToastMgr.Instance.onRecvToast({ msg: "请求验证码失败" })
            }
        })
    }

    /**
     * 点击了明文/密文
     */
    onClickEye() {
        this._bCiphertext = !this._bCiphertext;
        this.btnEye.getComponent(cc.Sprite).spriteFrame = this._bCiphertext ? this.frameEyes[1] : this.frameEyes[0];

        this.editPassword.inputFlag = this._bCiphertext ? cc.EditBox.InputFlag.PASSWORD : cc.EditBox.InputFlag.DEFAULT;
    }

    /**
     * 登录/注册
     */
    onClickSign() {
        if (!checkNumber(this.editPhone.string, 5, `请输入手机号码`, `手机号码长度不正确`)) {
            return;
        }


        if (this._isByPassword) {
            if (!checkNumber(this.editPassword.string, 1, `请输入密码`, ``,)) {
                return;
            }

            LoginMgr.Instance.login(LoginType.Account, this.editPhone.string, this.editPassword.string);
        } else {
            if (!checkNumber(this.editVerify.string, 6, `请输入验证码`, `验证码长度不正确`, true)) {
                return;
            }

            LoginMgr.Instance.login(LoginType.Phone, this.editPhone.string, this.editVerify.string);
        }
    }

    /**
     * 点击了忘记密码
     */
    onClickForgot() {
        UIMgr.Instance.showView(EnumPrefab.setLoginPassWord, null, GameApp.Instance.getDialogLayer(), EnumPrefab.setLoginPassWord, false);
    }

    /**
     * 切换成验证码登录方式
     */
    onLoginByVerify() {
        if (!this._isByPassword) {
            return;
        }
        this._isByPassword = false;
        this.ndPassword.active = false;
        this.ndVerify.active = true;
        this.editVerify.string = "";
        this.btnForgot.node.active = false;
    }

    /**
     * 切换成密码登录方式
     */
    onLoginByPassword() {
        if (this._isByPassword) {
            return;
        }
        this._isByPassword = true;
        this.ndPassword.active = true;
        this.ndVerify.active = false;
        this.editPassword.string = "";
        this.btnForgot.node.active = true;
    }

    /**
     * 打开设备号登录界面
     */
    onLoginByDevice() {
        this.showDeviceIDView();
    }

    showDeviceIDView() {
        if (!cc.sys.isBrowser) {
            return;
        }
        UIMgr.Instance.showView(EnumPrefab.accountCreate, null, GameApp.Instance.getDialogLayer(), EnumPrefab.accountCreate, false);
    }

    /**
     * 验证手机号码
     */
    onCheckPhone() {
        checkNumber(this.editPhone.string, 11, `请输入手机号码`, `手机号码长度不正确`);
    }

    startVerifyCD() {
        cc.Tween.stopAllByTarget(this.labVerifyCD.node);
        this.btnVerify.node.active = false;
        this.labVerifyCD.node.active = true;
        this._isCD = true;
        StartTimeCountDown(this.labVerifyCD, 10, () => {
            this.btnVerify.node.active = true;
            this.labVerifyCD.node.active = false;
            this._isCD = false;
        }, null, "(%ss)", (t) => {
            // this.timeLeft = t;
        })
    }

    stopVerifyCD() {
        cc.Tween.stopAllByTarget(this.labVerifyCD.node);
        this._isCD = false;
        this.btnVerify.node.active = true;
        this.labVerifyCD.node.active = false;
    }

}