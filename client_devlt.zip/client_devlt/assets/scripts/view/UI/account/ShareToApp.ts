import * as cc from 'cc';
import { BaseUI } from '../../../framework/base/BaseUI';
import { INR } from '../../../Const';
import { Screenshot2D } from '../../../framework/lib/Screenshot2D';
import ClubModel from '../../../model/ClubModel';
import { loadRemoteImg } from '../../../framework/lib/GlobalFunc';
import { gameConfig } from '../../../config/Config';
import { HallReqManager } from '../../../framework/net/HallReqManager';
import { LOBBY_EVENT, SYS_EVENT } from '../../../framework/event/EventDefine';
import EventMgr from '../../../framework/event/EventMgr';
import { Logger } from '../../../framework/utils/Logger';

const { ccclass, property } = cc._decorator;


/**
 * 分享到app
 */
@ccclass('ShareToApp')
export class ShareToApp extends BaseUI {
    @property({ type: cc.Button, tooltip: "返回按钮" })
    btnBack: cc.Button = null;

    @property({ type: cc.Button, tooltip: "分享到whatsapp" })
    btnToWhatsapp: cc.Button = null;

    @property({ type: cc.Button, tooltip: "分享到telegram" })
    btnToTelegram: cc.Button = null;

    @property({ type: cc.Button, tooltip: "分享到facebook" })
    btnToFB: cc.Button = null;

    @property({ type: cc.Button, tooltip: "分享到其他" })
    btnToOther: cc.Button = null;

    @property({ type: cc.Button, tooltip: "复制链接" })
    btnCopyLink: cc.Button = null;

    @property({ type: cc.PageView, tooltip: "" })
    pageview: cc.PageView = null;

    @property({ type: cc.Node, tooltip: "轮播页" })
    ndPageTemp: cc.Node = null;

    @property({ type: cc.Label, tooltip: "" })
    labTips: cc.Label = null;

    private _qrUrl: string = "";

    initView(): void {
        this.btnBack.node.on(cc.Button.EventType.CLICK, this.onClikClosed, this);
        this.btnToWhatsapp.node.on(cc.Button.EventType.CLICK, this.onClicShare2Whatsapp, this);
        this.btnToTelegram.node.on(cc.Button.EventType.CLICK, this.onClicShare2Telegram, this);
        this.btnToFB.node.on(cc.Button.EventType.CLICK, this.onClicShare2Facebook, this);
        this.btnToOther.node.on(cc.Button.EventType.CLICK, this.onClicShare2Other, this);
        this.btnCopyLink.node.on(cc.Button.EventType.CLICK, this.onClickCopyLink, this);

        //请求数据
        HallReqManager.sendClubShareConfig();
    }

    protected bindEventListener(): void {
        super.bindEventListener();
        EventMgr.Instance.on(LOBBY_EVENT.SHARED_CONFIG, this.udpateView, this);
    }

    udpateView() {
        let shareInfo = ClubModel.Instance.getSharedInfo();
        this.labTips.string = `Share to other apps to get ${INR}${shareInfo.reawrd}`;

        this.pageview.removeAllPages();
        shareInfo.pages.forEach((e, idx) => {
            let page = cc.instantiate(this.ndPageTemp);
            this.pageview.addPage(page);
            page.active = true;

            // loadRemoteImg(page.getComponentInChildren(cc.Sprite), gameConfig.remote_url + "share/" + e.pageUrl);
            loadRemoteImg(page.getComponentInChildren(cc.Sprite), gameConfig.remote_url + "share/" + "share_page1.jpg");
        })

        this.ndPageTemp.active = false;
    }

    ScreenShotNode() {
        let curPage = this.pageview.getPages()[this.pageview.getCurrentPageIndex()];
        if (curPage) {
            let sp = curPage.getComponentInChildren(cc.Sprite)
            this.node.getComponent(Screenshot2D).capture(sp, (filePath: string) => {
                Logger.debug(`图片保存路径`, filePath);
            });
        }
    }

    onClikClosed() {
        this.onClose();
    }

    onClicShare2Whatsapp() {
        this.ScreenShotNode();
    }

    onClicShare2Telegram() {
        this.ScreenShotNode();

    }

    onClicShare2Facebook() {
        this.ScreenShotNode();

    }

    onClicShare2Other() {
        this.ScreenShotNode();

    }

    onClickCopyLink() {
        platform.setClipText(`www.baidu.com`);
    }

}