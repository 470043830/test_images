// Event 由 cc 模块导入
import { Event } from 'cc';

export class PriorityEvent extends Event {
    constructor(name: string, bubbles?: boolean, detail?: any) {
        super(name, bubbles);
        this.detail = detail;
    }
    public detail: any = null;  // 自定义的属性
}

export interface TestDataObject {
    [key: string]: any;
}

export class TestData {

    //...


    //...
    static getTestData() {
        const count = 10;
        const test_condition = [3, 5, 10, 20, 50, 60, 70, 80, 90, 100];
        const test_prize = [30, 100, 120, 150, 450, 600, 700, 800, 900, 1000];
        const testData = Array(count).fill(0).map((_, i) => {
            return { index: i, num: 30 + i * 10, icon: 'icon_0' + (i % 5 + 1), prize: '₹' + test_prize[i], condition: test_condition[i] }
        });
        const superTaskData = {
            cardTip: 'Invite  valid users Pre-requisite 3',
            taskName: 'Super Quarterly Grand Prize', //'超级季度大奖',
            totalPrize: 1000,
            remainTime: '20:25:35',
            requirement: 'Effective betting ', //'邀请人数 ',
            currValue: 18,
            maxValue: 100,
            list: testData,
        }
        console.log('superTaskData: ', superTaskData);
        return superTaskData;
    }

    static getTestData2(para = 10, isCardTip = true) {
        const types = ['Time-limited task', 'Daily Tasks', 'Weekly Tasks'];
        return {
            taskType: 0,
            types,
            cardTip: isCardTip ? 'Effective betting pre-requisite 3000' : '',
            taskName: 'VIP monthly bonus',
            totalPrize: 777,
            remainTime: '20:25:35',
            requirement: 'Effective betting ', //'邀请人数 ',
            currValue: 10 + 5 * para,
            maxValue: 100,
        };
    }

    static getTaskTypes() {
        const types = ['ALL', 'Effective betting', 'Invite', 'Recharge'];
        return types;
    }

    static getSuperTasks() {
        const count = 10;
        const test_condition = [3, 5, 10, 20, 50, 60, 70, 80, 90, 100];
        const test_prize = [30, 100, 120, 150, 450, 600, 700, 800, 900, 1000];
        const testData = Array(count).fill(0).map((_, i) => {
            return { index: i, num: 30 + i * 10, icon: 'icon_0' + (i % 5 + 1), prize: '₹' + test_prize[i], condition: test_condition[i] }
        });
        return [
            {
                taskId: 11000,
                taskType: 10,
                state: 1,
                cardTip: 'Invite valid users Pre-requisite 3',
                taskName: 'Super Quarterly Grand Prize',
                totalPrize: 1000,
                remainTime: '20:25:35',
                requirement: 'Effective betting ',
                currValue: 18,
                maxValue: 100,
                list: testData,
            },
            {
                taskId: 11001,
                taskType: 10,
                state: 0,
                cardTip: 'Effective betting pre-requisite 3000',
                taskName: 'Quarterly Grand Prize',
                totalPrize: 2000,
                remainTime: '20:25:35',
                requirement: 'Invited ',
                currValue: 0,
                maxValue: 100,
                list: testData,
            }
        ];
    }

    static getOneTasks() {
        return [
            {
                taskId: 10000,
                taskType: 1,
                state: 1,
                cardTip: 'Effective betting pre-requisite 3000',
                taskName: 'VIP monthly bonus',
                totalPrize: 555,
                remainTime: '20:25:35',
                requirement: 'Effective betting ',
                currValue: 100,
                maxValue: 100,
            },
            {
                taskId: 10001,
                taskType: 2,
                state: 1,
                cardTip: 'Invite valid users Pre-requisite 3',
                taskName: 'VIP monthly bonus',
                totalPrize: 666,
                remainTime: '20:25:35',
                requirement: 'Invite ',
                currValue: 20,
                maxValue: 100,
            }
        ];
    }

    static getOneTasks2() {
        return [
            {
                taskId: 10002,
                taskType: 1,
                state: 0,
                cardTip: '',
                taskName: 'VIP monthly bonus',
                totalPrize: 777,
                remainTime: '20:25:35',
                requirement: 'Effective betting ',
                currValue: 15,
                maxValue: 100,
            },
            {
                taskId: 10003,
                taskType: 2,
                state: 0,
                cardTip: '',
                taskName: 'VIP monthly bonus',
                totalPrize: 888,
                remainTime: '20:25:35',
                requirement: 'Invite ',
                currValue: 25,
                maxValue: 100,
            },
            {
                taskId: 10004,
                taskType: 3,
                state: 0,
                cardTip: '',
                taskName: 'VIP monthly bonus',
                totalPrize: 999,
                remainTime: '20:25:35',
                requirement: 'Recharge ',
                currValue: 25,
                maxValue: 100,
            }
        ];
    }


    static getPopupTask1() {
        return [
            { name: 'Invited', prize: '₹10000', time: '1D 00:00:00', currValue: 70, maxValue: 100, require: 'Friends', go: 'go Invaited' },
            { name: 'First Deposit', prize: '₹20000', time: '1D 00:00:00', currValue: 80, maxValue: 100, require: 'Deposit', go: 'go First Deposit' },
            { name: 'Deposit', prize: '₹30000', time: '1D 00:00:00', currValue: 90, maxValue: 100, require: 'Deposit', go: 'go Deposit' },
        ]
    }

    static getPopupTask2() {
        return [
            { name: 'First Deposit', prize: '₹10000', require: 'Valid betting 1000', go: 'go First Deposit' },
            { name: 'Invited', prize: '₹20000', require: 'Friends 100', go: 'go Invited' },
            { name: 'Deposit', prize: '₹30000', require: 'Valid betting 3000', go: 'go Deposit' },
            { name: 'First Deposit', prize: '₹10000', require: 'Valid betting 1000', go: 'go First Deposit' },
            { name: 'Invited', prize: '₹20000', require: 'Friends 100', go: 'go Invited' },
            { name: 'Deposit', prize: '₹30000', require: 'Valid betting 3000', go: 'go Deposit' },
        ]
    }

    static getRequirements() {
        return [
            { phase: 'phase1', state: 'Claimed', prize: '₹10000', desc: 'Need to complete 3 times the effective turn over which is 3000' },
            { phase: 'phase2', state: 'In progress', prize: '₹20000', desc: 'Need to complete 3 times the effective turn over which is 3000' },
            { phase: 'phase3', state: 'In progress', prize: '₹30000', desc: 'Need to complete 3 times the effective turn over which is 3000' },
            { phase: 'phase4', state: 'In progress', prize: '₹40000', desc: 'Need to complete 3 times the effective turn over which is 3000' },
            { phase: 'phase5', state: 'In progress', prize: '₹50000', desc: 'Need to complete 3 times the effective turn over which is 3000' },
        ]
    }
}



