import { _decorator, Component, Node, ScrollView, UITransform, instantiate, SpriteFrame, resources, Vec2, misc, Label, Color, v2, Vec3, Prefab } from 'cc';
import { UIMgr } from '../../../framework/manager/UIMgr';
import { SuperTaskCard } from './SuperTaskCard';
import { OnestepTaskCard } from './OnestepTaskCard';
import { PriorityEvent, TestData, TestDataObject } from './TestData';
const { ccclass, property } = _decorator;

@ccclass('TaskMain')
export class TaskMain extends Component {

    @property({ type: Node })
    public contentNode: Node | null = null;

    @property({ type: Node })
    public superTaskCard: Node | null = null;

    @property({ type: Node })
    public onestepTaskCard: Node | null = null;

    @property({ type: Node })
    public waitingTabNode: Node | null = null;

    @property({ type: Node })
    public waitingTabItemNodes: [] | null = [];;

    @property({ type: ScrollView })
    public mainScrollView: ScrollView | null = null;

    @property({ type: Node })
    public testSpriteNode: Node | null = null;

    @property({ type: Prefab })
    public requirementsNodePrefab: Prefab | null = null;


    private _spriteFrames: [] | null = [];
    private _cardList = [];

    start() {
        this.loadResIcons();
    }


    loadResIcons() {
        resources.loadDir("textures/taskIcons", SpriteFrame, (err, assets: SpriteFrame[]) => {
            if (err) {
                console.error(err);
                return;
            }
            assets.forEach(frame => {
                this._spriteFrames[frame.name] = frame;
            });
            console.log('this._spriteFrames: ', this._spriteFrames);
            //...
            this.initAllTask();

            //for test
            this.scheduleOnce(() => {
                this.moveNodeAToB(this.testSpriteNode, this.waitingTabNode);
            });
            this.scheduleOnce(() => {
                this.testSpriteNode.active = false;
            }, 2);
        });

    }

    //...
    initAllTask() {
        this.initWaitingTabs();
        //...
        // this.superTaskCard.getComponent(SuperTaskCard).initSuperTask(TestData.getTestData(), this._spriteFrames);
        // this.onestepTaskCard.getComponent(OnestepTaskCard).initTask(TestData.getTestData2());

        // for test
        let testlist0 = TestData.getSuperTasks();
        for (let index = 0; index < testlist0.length; index++) {
            this.spawnSuperTaskCard(testlist0[index], index == 0);
        }
        // for (let index = 0; index < 1; index++) {
        //     this.spawnSuperTaskCard(TestData.getTestData(), false);
        // }
        let testlist1 = TestData.getOneTasks();
        let testlist2 = TestData.getOneTasks2();
        for (let index = 0; index < testlist1.length; index++) {
            this.spawnOnestepTaskCard(testlist1[index], true);
        }
        for (let index = 0; index < testlist2.length; index++) {
            this.spawnOnestepTaskCard(testlist2[index], false);
        }
        // for (let index = 0; index < 2; index++) {
        //     this.spawnOnestepTaskCard(TestData.getTestData2(index), true);
        // }
        // for (let index = 0; index < 3; index++) {
        //     this.spawnOnestepTaskCard(TestData.getTestData2(index, false), false);
        // }
    }

    /**
     * 生成单阶段任务卡
     * @param taskData 
     * @param isExe 是否在执行中
     * @returns 
     */
    spawnOnestepTaskCard(taskData, isExe = false) {
        if (!this.onestepTaskCard) {
            return null;
        }
        this.onestepTaskCard.active && (this.onestepTaskCard.active = false);
        let block: Node | null = null;
        block = instantiate(this.onestepTaskCard);
        let card = block.getComponent(OnestepTaskCard);
        card.initTask(taskData);
        this.contentNode.addChild(block);
        isExe && block.setSiblingIndex(this.waitingTabNode.getSiblingIndex());
        block.active = true;

        //...
        this._cardList.push({ node: block, taskData: taskData });
    }

    /**
     * 生成多阶段任务卡
     * @param taskData 
     * @param isExe 
     * @returns 
     */
    spawnSuperTaskCard(taskData, isExe = false) {
        if (!this.superTaskCard) {
            return null;
        }
        this.superTaskCard.active && (this.superTaskCard.active = false);

        let block: Node | null = null;
        block = instantiate(this.superTaskCard);
        let card = block.getComponent(SuperTaskCard);
        card.initSuperTask(taskData, this._spriteFrames);
        this.contentNode.addChild(block);
        isExe && block.setSiblingIndex(this.waitingTabNode.getSiblingIndex());
        block.active = true;

        //...
        this._cardList.push({ node: block, taskData: taskData });
    }

    initWaitingTabs() {
        const nodes = this.waitingTabItemNodes;
        for (let index = 0; index < nodes.length; index++) {
            let item: Node | null = nodes[index];
            item.on(Node.EventType.TOUCH_END, () => this.onTabItemClicked(index));
        }
        this.setTabHighlight(0);
    }

    onTabItemClicked(index) {
        console.log('onTabItemClicked ', index);
        this.setTabHighlight(index);
    }

    setTabHighlight(index = 0) {
        let nodes: Node[] = this.waitingTabItemNodes;

        for (let index = 0; index < nodes.length; index++) {
            let item: Node | null = nodes[index];
            item.getComponentInChildren(Label).color = new Color().fromHEX("#FFFFFF");
        }

        nodes[index].getComponentInChildren(Label).color = new Color().fromHEX("#E2CB26");

        //...
        this.filterWaitingList(index);
    }

    filterWaitingList(type) {
        for (let i = 0; i < this._cardList.length; i++) {
            const element = this._cardList[i];
            const { taskType, state, taskId } = element.taskData;
            if (state == 0) {
                element.node.active = (type == 0 || taskType == type);
            }
        }
    }

    onClosekBtn() {
        UIMgr.Instance.removeView(this.node);
    }


    onEnable() {
        this.node.on('priority_evt', this.handlePriorityEvent, this);
        this.node.on('requirements_evt', this.handleRequirementsEvent, this);
    }

    onDisable() {
        this.node.off('priority_evt', this.handlePriorityEvent, this);
        this.node.off('requirements_evt', this.handleRequirementsEvent, this);
    }

    handleRequirementsEvent(event: PriorityEvent) {
        console.log('handleRequirementsEvent:', event.detail);
        let taskId = event.detail;

        let block: Node | null = null;
        block = instantiate(this.requirementsNodePrefab);
        this.node.addChild(block);
    }

    handlePriorityEvent(event: PriorityEvent) {
        console.log('handlePriorityEvent:', event.detail);
        let fromTaskId = event.detail;
        let fromTask = null;
        let toTask = null;

        //find the same id task in list
        for (let index = 0; index < this._cardList.length; index++) {
            const element = this._cardList[index];
            if (element.taskData.taskId == fromTaskId) {
                console.log('from element:', element);
                fromTask = element;
                break;
            }
        }

        //find the same type task in executing list
        for (let index = 0; index < this._cardList.length; index++) {
            const element = this._cardList[index];
            const { taskType, state, taskId } = element.taskData || {};
            const { taskId: f_taskId, taskType: f_taskType } = fromTask.taskData || {};

            if (taskId != f_taskId && taskType == f_taskType && state > 0) {
                console.log('target element:', element);
                toTask = element;
                toTask.taskData.state = 0;
                this.setCardState(toTask, 0);
                break;
            }
        }
        if (fromTask && toTask) {
            fromTask.taskData.state = 1;
            this.setCardState(fromTask, 1);
            this.switchTaskPos(fromTask.node, toTask.node);
            this.mainScrollView.getScrollOffset().y > 1 && this.scrollToNode(toTask.node);
        }
    }

    setCardState(element, state) {
        if (element.taskData.list) { //super task
            element.node.getComponent(SuperTaskCard).updateCardState(state);
        } else { //onestep task
            element.node.getComponent(OnestepTaskCard).updateCardState(state);
        }
    }

    switchTaskPos(childA, childB) {
        // 获取当前索引
        let indexA = childA.getSiblingIndex();
        let indexB = childB.getSiblingIndex();

        // 交换索引位置
        childA.setSiblingIndex(indexB);
        childB.setSiblingIndex(indexA);
    }


    // 滚动到指定节点位置
    scrollToNode(targetNode: Node, duration: number = 0.2) {
        const y = Math.abs(targetNode.y) - (targetNode.getComponent(UITransform).height / 2);
        console.log('scrollToNode: ', y, this.mainScrollView.getScrollOffset());
        this.mainScrollView.scrollToOffset(new Vec2(0, y), duration);
    }


    // 将节点A移动到节点B的位置
    moveNodeAToB(aNode: Node, bNode: Node) {
        // 获取B节点的世界坐标
        const bUITransform = bNode.getComponent(UITransform);
        const bWorldPos = bUITransform.convertToWorldSpaceAR(new Vec3(0, 0));

        // 将世界坐标转换到A节点父节点的本地坐标系
        const aParentUITransform = aNode.parent.getComponent(UITransform);
        const targetPos = aParentUITransform.convertToNodeSpaceAR(bWorldPos);

        // 设置A节点位置
        aNode.position = targetPos;
    }

    // 获取节点在世界坐标系中的位置
    getWorldPosition(node: Node): Vec3 {
        const uiTransform = node.getComponent(UITransform);
        return uiTransform.convertToWorldSpaceAR(new Vec3(0, 0));
    }
}


