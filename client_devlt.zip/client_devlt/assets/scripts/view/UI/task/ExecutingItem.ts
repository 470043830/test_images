import { _decorator, Component, Label, Node, Sprite, UITransform } from 'cc';
import { TestDataObject } from './TestData';
const { ccclass, property } = _decorator;

@ccclass('ExecutingItem')
export class ExecutingItem extends Component {

    @property({ type: Sprite })
    public taskSprite: Sprite | null = null;
    @property({ type: Label })
    public nameLabel: Label | null = null;
    @property({ type: Label })
    public prizeLabel: Label | null = null;
    @property({ type: Label })
    public remainTimeLabel: Label | null = null;
    @property({ type: Label })
    public progressLabel: Label | null = null;
    @property({ type: Sprite })
    public progressFg: Sprite | null = null;
    @property({ type: Node })
    public goBtn: Node | null = null;
    @property({ type: Node })
    public claimBtn: Node | null = null;

    private _taskData: TestDataObject = {};

    start() {

    }

    initItem(itemData: TestDataObject = {}) {
        const { name, prize, time, currValue, maxValue, require = '' } = itemData;
        this._taskData = { ...itemData };

        this.nameLabel.string = name;
        this.prizeLabel.string = prize;
        this.remainTimeLabel.string = time;
        this.progressLabel.string = require + ' ' + currValue + '/' + maxValue;

        //
        this.setProgressBar(currValue, maxValue);
    }

    setProgressBar(currValue, maxValue) {
        let transform = this.progressFg.node.getComponent(UITransform);
        let transformBg = this.progressFg.node.parent.getComponent(UITransform);
        transform.width = transformBg.width * currValue / maxValue;
    }

    onGoBtn() {
        console.log('onGoBtn...', this._taskData.go)
    }

    onClaimBtn() {
        console.log('onClaimBtn...')
    }

}


