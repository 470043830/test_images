import { _decorator, Component, Label, Node, Sprite } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('SuperTaskItem')
export class SuperTaskItem extends Component {

    @property({ type: Sprite })
    public icon: Sprite | null = null;

    @property({ type: Label })
    public prizeLabel: Label | null = null;

    @property({ type: Label })
    public numLabel: Label | null = null;


    initItem(data, spriteFrames) {
        console.log('initItem: ', data);
        this.icon.spriteFrame = spriteFrames[data.icon];
        this.numLabel.string = data.condition + '';
        this.prizeLabel.string = data.prize + '';
    }

    start() {

    }

}


