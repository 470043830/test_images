import { _decorator, Component, instantiate, Label, Node, ScrollView, UITransform } from 'cc';
import { ExecutingItem } from './ExecutingItem';
import { WaitingItem } from './WaitingItem';
import { TestData } from './TestData';
import { UIMgr } from '../../../framework/manager/UIMgr';
import { EnumPrefab } from '../../../config/BundleConfig';
import { GameApp } from '../../../lobby/GameApp';
const { ccclass, property } = _decorator;

@ccclass('TaskPopup')
export class TaskPopup extends Component {

    @property({ type: ScrollView })
    public mainScrollView: ScrollView | null = null;

    @property({ type: Node })
    public executingItemNode: Node | null = null;

    @property({ type: Node })
    public waitingItemNode: Node | null = null;

    @property({ type: Node })
    public splitNode: Node | null = null;

    @property({ type: Label })
    public totalPrizeLabel: Label | null = null;

    @property({ type: Label })
    public tobePrizeLabel: Label | null = null;

    start() {
        this.initUI();
    }

    initUI() {
        this.executingItemNode.active = false;
        this.waitingItemNode.active = false;
        this.splitNode.getComponent(UITransform).height = 50;

        //for test
        const testlist1 = TestData.getPopupTask1();
        const testlist2 = TestData.getPopupTask2();

        for (let i = 0; i < testlist1.length; i++) {
            this.spawnExecutingItem(testlist1[i]);
        }
        for (let i = 0; i < testlist2.length; i++) {
            this.spawnWaitingItem(testlist2[i]);
        }
        this.totalPrizeLabel.string = '₹30000';
        this.tobePrizeLabel.string = '₹20000';
    }


    spawnExecutingItem(itemData = {}) {
        let block: Node | null = null;
        block = instantiate(this.executingItemNode);
        let item = block.getComponent(ExecutingItem);
        item.initItem(itemData);
        this.mainScrollView.content.addChild(block);
        block.setSiblingIndex(this.splitNode.getSiblingIndex());
        block.active = true;
    }

    spawnWaitingItem(itemData = {}) {
        let block: Node | null = null;
        block = instantiate(this.waitingItemNode);
        let item = block.getComponent(WaitingItem);
        item.initItem(itemData);
        this.mainScrollView.content.addChild(block);
        block.active = true;
    }

    onListBtn() {
        console.log('onListBtn...')
        UIMgr.Instance.showView(EnumPrefab.taskMain, null, GameApp.Instance.getDialogLayer(), EnumPrefab.taskMain, false);
    }

    onCloseBtn() {
        console.log('onCloseBtn...')
        UIMgr.Instance.removeView(this.node);

    }
}


