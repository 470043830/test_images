import { _decorator, Component, instantiate, Label, Node, ScrollView } from 'cc';
import { TestData } from './TestData';
import { RequirementsItem } from './RequirementsItem';
const { ccclass, property } = _decorator;

@ccclass('Requirements')
export class Requirements extends Component {

    @property({ type: ScrollView })
    public mainScrollView: ScrollView | null = null;

    @property({ type: Label })
    public titleLabel: Label | null = null;

    @property({ type: Node })
    public itemNode: Node | null = null;


    start() {
        this.initUI();
    }

    initUI() {
        // this.titleLabel.string = title;
        this.itemNode.active = false;
        //for test
        const testlist1 = TestData.getRequirements();


        for (let i = 0; i < testlist1.length; i++) {
            this.spawnPhaseItem(testlist1[i]);
        }
    }

    spawnPhaseItem(itemData = {}) {
        let block: Node | null = null;
        block = instantiate(this.itemNode);
        let item = block.getComponent(RequirementsItem);
        item.initItem(itemData);
        this.mainScrollView.content.addChild(block);
        block.active = true;
    }

    onCloseBtn() {
        console.log('onCloseBtn...')
        this.node.removeFromParent();
    }

}


