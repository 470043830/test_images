import { _decorator, Component, instantiate, Label, Node, resources, ScrollView, SpriteFrame, UITransform, Vec2 } from 'cc';
import { SuperTaskItem } from './SuperTaskItem';
import { PriorityEvent, TestDataObject } from './TestData';
const { ccclass, property } = _decorator;

@ccclass('SuperTaskCard')
export class SuperTaskCard extends Component {

    @property(ScrollView)
    stScrollView: ScrollView = null;

    @property({ type: Node })
    public iconItemPrefab: Node | null = null;

    @property({ type: Node })
    public stProgressBarBg: Node | null = null;

    @property({ type: Node })
    public stProgressBarFg: Node | null = null;

    @property({ type: Label })
    public cardTipLabel: Label | null = null;

    @property({ type: Label })
    public totalPrizeLabel: Label | null = null;

    @property({ type: Label })
    public nameLabel: Label | null = null;

    @property({ type: Label })
    public remainTimeLabel: Label | null = null;

    @property({ type: Label })
    public totalProgressLabel: Label | null = null;

    @property({ type: Node })
    public stateBtns: [] | null = [];

    @property({ type: Node })
    public blockNode: Node | null = null;

    @property({ type: Node })
    public clickNode: Node | null = null;

    private _taskData: TestDataObject = {};

    private _spriteFrames: [] | null = [];

    private _firstTaskOffset = 52;
    private _stepOffset = 137; // (182 - 53)

    start() {
        // this.blockNode.on(Node.EventType.TOUCH_END, () => this.onBlockClicked());
        this.clickNode.on(Node.EventType.TOUCH_END, () => this.onCardClicked());
    }

    initSuperTask(taskData, spriteFrames) {
        // const taskData = this.getTestData();
        const {
            taskId,
            state,
            cardTip,
            taskName,
            totalPrize,
            remainTime,
            requirement,
            currValue = 0,
            maxValue = 0,
            list = [],
        } = taskData;
        this._taskData = { ...taskData };

        this._spriteFrames = spriteFrames;
        const count = list.length;

        // labels
        this.totalPrizeLabel.string = '₹' + totalPrize + '';
        this.nameLabel.string = taskName + '';
        this.cardTipLabel.string = cardTip;
        this.remainTimeLabel.string = 'remaining time ' + remainTime;
        this.totalProgressLabel.string = requirement + currValue + '/' + maxValue;

        // ...
        const stepOffset = this._stepOffset;
        const content = this.stScrollView.content;
        const stProgressBarBgWidth = this._firstTaskOffset + stepOffset * (count - 1);
        content.getComponent(UITransform).width = stProgressBarBgWidth + 50;
        this.stProgressBarBg.getComponent(UITransform).width = stProgressBarBgWidth;
        this.stProgressBarFg.getComponent(UITransform).width = this.getSuperTaskFgWidth(currValue, taskData.list);
        //...
        let currIndex = this.getSuperTaskCurrAwardIndex(currValue, taskData.list);
        this.scheduleOnce(() => {
            this.initSuperTaskList(taskData.list, content);

            let offsetY = currIndex > 2 ? stepOffset * (currIndex - 2) : 0;
            // this.stScrollView.scrollTo(new Vec2(offsetY, 0), 0.5);
            this.stScrollView.scrollToOffset(new Vec2(offsetY, 0), 0.5);
        });

        //...
        this.updateCardState(state);
    }

    initSuperTaskList(data, content) {
        const pos0 = this._firstTaskOffset; //53;

        data.forEach((itemData, idx) => {
            const itemNode = this.spawnIconItem();
            const item = itemNode?.getComponent(SuperTaskItem);

            // item.getComponentInChildren(Label).string = text;
            itemNode.active = true;
            itemNode.x = pos0 + this._stepOffset * idx;
            // itemNode.setPosition(pos0 + (182 - 53) * idx, 48.391);
            item.initItem(itemData, this._spriteFrames);
            content.addChild(itemNode);
        });
    }

    getSuperTaskCurrAwardIndex(curr, tasks) {
        let awardIndex = 0;

        for (let index = 0; index < tasks.length; index++) {
            const element = tasks[index];
            if (curr >= element.condition) {  // 满足任务条件
                awardIndex = index;
            } else {
                break;
            }
        }
        console.log('awardIndex: ', awardIndex);
        return awardIndex;
    }

    getSuperTaskFgWidth(curr, tasks) {
        let last = 0;
        let width = 0;

        for (let index = 0; index < tasks.length; index++) {
            const element = tasks[index];
            if (curr >= element.condition) {  // 满足任务条件
                width += index == 0 ? this._firstTaskOffset : this._stepOffset;
                last = element.condition;
            } else {
                width += index == 0 ? (this._firstTaskOffset * curr / element.condition) : (this._stepOffset * (curr - last) / (element.condition - last));
                break;
            }
        }
        return width;
    }

    spawnIconItem() {
        if (!this.iconItemPrefab) {
            return null;
        }

        let block: Node | null = null;
        block = instantiate(this.iconItemPrefab);
        return block;
    }

    updateCardState(state) {
        const {
            currValue = 0,
            maxValue = 0,
            list = [],
        } = this._taskData;
        this._taskData.state = state;

        // 队列中的任务暂不显示这个tip
        (!this._taskData.cardTip || state == 0) && (this.cardTipLabel.node.active = false);
        (this._taskData.cardTip && state > 0) && (this.cardTipLabel.node.active = true);

        this.setStateBtn(state);

        //for test
        if (state == 1 && currValue >= list[0].condition) {
            this.setStateBtn(2);
        }
    }


    setStateBtn(state) {
        console.log('setStateBtn, state: ', state);
        for (let index = 0; index < this.stateBtns.length; index++) {
            let element: Node = this.stateBtns[index];
            element.active = state == index;
        }
    }

    onClaimBtn() {
        console.log('onClaimBtn...');
    }

    onPriorityBtn() {
        // 节点 c 的组件脚本中
        console.log('onPriorityBtn...1');
        this.node.dispatchEvent(new PriorityEvent('priority_evt', true, this._taskData.taskId));
    }


    onCardClicked() {
        console.log('onCardClicked...')
        this.node.dispatchEvent(new PriorityEvent('requirements_evt', true, this._taskData.taskId));
    }

    onBlockClicked() {
        this.blockNode.active = false;
    }
}


