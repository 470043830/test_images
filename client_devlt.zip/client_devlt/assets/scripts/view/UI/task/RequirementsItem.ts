import { _decorator, Color, Component, Label, Node } from 'cc';
import { TestDataObject } from './TestData';
const { ccclass, property } = _decorator;

@ccclass('RequirementsItem')
export class RequirementsItem extends Component {

    @property({ type: Label })
    public phaseLabel: Label | null = null;
    @property({ type: Label })
    public stateLabel: Label | null = null;
    @property({ type: Label })
    public prizeLabel: Label | null = null;
    @property({ type: Label })
    public descLabel: Label | null = null;

    start() {

    }
    initItem(itemData: TestDataObject = {}) {
        const { phase, state, prize, desc } = itemData;

        this.phaseLabel.string = phase;
        this.prizeLabel.string = prize;
        this.stateLabel.string = '(' + state + ')';
        this.descLabel.string = desc;

        this.stateLabel.color = state == 'Claimed' ? new Color().fromHEX("#24B924") : new Color().fromHEX("#F5B45B");
    }
}


