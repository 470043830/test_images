import { _decorator, Component, Label, Node, ScrollView, UITransform } from 'cc';
import { PriorityEvent, TestDataObject } from './TestData';
const { ccclass, property } = _decorator;

@ccclass('OnestepTaskCard')
export class OnestepTaskCard extends Component {

    @property({ type: Node })
    public stProgressBarBg: Node | null = null;

    @property({ type: Node })
    public stProgressBarFg: Node | null = null;

    @property({ type: Label })
    public cardTipLabel: Label | null = null;

    @property({ type: Label })
    public totalPrizeLabel: Label | null = null;

    @property({ type: Label })
    public nameLabel: Label | null = null;

    @property({ type: Label })
    public remainTimeLabel: Label | null = null;

    @property({ type: Label })
    public totalProgressLabel: Label | null = null;

    @property({ type: Node })
    public stateBtns: [] | null = [];

    @property({ type: Node })
    public clickNode: Node | null = null;

    private _taskData: TestDataObject = {};

    start() {
        this.clickNode.on(Node.EventType.TOUCH_END, () => this.onCardClicked());
    }


    initTask(taskData) {
        const {
            taskId,
            cardTip,
            state,
            taskName,
            totalPrize,
            remainTime,
            requirement,
            currValue = 0,
            maxValue = 0,
        } = taskData;
        this._taskData = { ...taskData };

        // labels
        this.totalPrizeLabel.string = '₹' + totalPrize + '';
        this.nameLabel.string = taskName + '';
        this.cardTipLabel.string = cardTip;
        this.remainTimeLabel.string = 'remaining time ' + remainTime;
        this.totalProgressLabel.string = requirement + currValue + '/' + maxValue;

        this.stProgressBarBg.getComponent(UITransform).width = 628;
        this.stProgressBarFg.getComponent(UITransform).width = 628 * currValue / maxValue;

        //...
        this.updateCardState(state);
    }

    updateCardState(state) {
        const {
            currValue = 0,
            maxValue = 0,
        } = this._taskData;
        this._taskData.state = state;

        // 队列中的任务暂不显示这个tip
        (!this._taskData.cardTip || state == 0) && (this.cardTipLabel.node.active = false);
        (this._taskData.cardTip && state > 0) && (this.cardTipLabel.node.active = true);

        this.setStateBtn(state);

        //for test
        if (state == 1 && currValue >= maxValue) {
            this.setStateBtn(2);
        }
    }

    setStateBtn(state) {
        for (let index = 0; index < this.stateBtns.length; index++) {
            let element: Node = this.stateBtns[index];
            element.active = state == index;
        }
    }

    onClaimBtn() {

    }

    onPriorityBtn() {
        // 节点 c 的组件脚本中
        console.log('onPriorityBtn...');
        this.node.dispatchEvent(new PriorityEvent('priority_evt', true, this._taskData.taskId));
    }

    onCardClicked() {
        console.log('onCardClicked...')
        this.node.dispatchEvent(new PriorityEvent('requirements_evt', true, this._taskData.taskId));
    }
}


