import { _decorator, Component, Label, Node, Sprite, UITransform } from 'cc';
import { TestDataObject } from './TestData';
const { ccclass, property } = _decorator;

@ccclass('WaitingItem')
export class WaitingItem extends Component {
    @property({ type: Sprite })
    public taskSprite: Sprite | null = null;
    @property({ type: Label })
    public nameLabel: Label | null = null;
    @property({ type: Label })
    public prizeLabel: Label | null = null;
    @property({ type: Label })
    public requireLabel: Label | null = null;

    @property({ type: Node })
    public viewBtn: Node | null = null;
    @property({ type: Node })
    public claimableBtn: Node | null = null;

    private _taskData: TestDataObject = {};

    start() {

    }


    initItem(itemData: TestDataObject = {}) {
        const { name, prize, require } = itemData;
        this._taskData = { ...itemData };

        this.nameLabel.string = name;
        this.prizeLabel.string = prize;
        this.requireLabel.string = require;
    }



    onViewBtn() {
        console.log('onViewBtn...', this._taskData.go)
    }

    onClaimableBtn() {
        console.log('onClaimableBtn...')
    }
}


