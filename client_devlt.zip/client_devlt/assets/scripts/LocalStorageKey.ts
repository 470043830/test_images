export namespace LocalStorageKey {
    //是否主动登出游客账号
    export const KeyLogOutActive = "KeyLogOutActive";

    //web端设备号
    export const LocalDeviceID = "LocalDeviceID";

    //登录方式
    export const KeyLoginType = "LoginType";

    //登录信息
    export const KeyLoginInfo = "LoginInfo";
}