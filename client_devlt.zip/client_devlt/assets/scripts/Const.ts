
/** 货币符号 */
export const INR = "₹" as const;
/** 货币倍率 */
export const DF_RATE = 100 as const;
/** 层级 */
export const APP_LOCAL_INDEX = 1000 as const;
/**英文月份（1 -> 12）月 */
export const MonthEn = [`Jan`, `Feb`, `Mar`, `Apr`, `May`, `Jun`, `Jul`, `Aug`, `Spt`, `Oct`, `Nov`, `Dec`] as const;
/** 呢称长度 */
export const NICKNAME_LEN_MAX = 6 as const;
/**任意键值类型 */
export type AnyKeyType = string | number | symbol;
/**任意Object */
export type AnyObjectType = { [key: AnyKeyType]: any }

export const PhoneAreaCode = "91"

/**
 * 标签
 */
export enum EnumGameTag {
    none = 0,
    hot,
    new,
    tuned     // 敬请期待
}

/**
 * 用户类型
 */
export enum EnumUserType {
    guest = 1,
    facebook,
    phone,
    account,
    robot = 99,
}


/**
 * 大厅页面类型
 */
export enum LobbyPageType {
    HOME,
    PROMO,
    MATCH,
    MINE,
    GETMONEY,
}

/**
 * VIP 特权类型
 */
export enum VipPrivilegeType {
    WEEKLY_BONUS = 1,       //每周奖励
    UPGRADE_BONUS,          //升级奖励
    WITHDRAW_DAILY_LIMIT,   //每日提现限额
    WITHDRAW_FEE,           //提现手续费
    WITHDRAW_DAILY_TIMES,   //每日提现次数
}

/**
 * 登录类型
 */
export enum LoginType {
    Guest = 0,              //游客登录
    Phone,                  //手机验证码登录
    Account,                //账户密码登录
    Default
}

/**
 * 成员过滤类型
 */
export enum MemberSortType {
    NONE,
    JOINTIME,                   //加入时间
    COMMISSION,                 //佣金
}