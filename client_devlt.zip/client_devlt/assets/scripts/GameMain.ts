import { _decorator, sys, director, screen, Node, Widget } from 'cc';
import { UIUtils } from './framework/utils/UIUtils';
import { APP_LOCAL_INDEX } from './Const';
import { ResMgr } from './framework/manager/ResMgr';
import { UIMgr } from './framework/manager/UIMgr';
import { EnumBundle } from './config/BundleConfig';
import { TimerMgr } from './framework/manager/TimeMgr';
import EventMgr from './framework/event/EventMgr';
import { GAME_EVENT } from './framework/event/EventDefine';
import { AudioMgr } from './framework/manager/AudioMgr';
import { ToastMgr } from './framework/manager/ToastMgr';
import { GameApp } from './lobby/GameApp';
import { SocketEventMgr } from './framework/net/SocketEventMgr';
import { H5Api } from './api/H5Api';
import { AdaptScreen } from './framework/base/AdaptScreen';
import { BaseScene } from './framework/base/BaseScene';

const { ccclass, property } = _decorator;

/**
 *  游戏入口文件
 */

@ccclass('GameMain')
export class GameMain extends BaseScene {
    /**
     * myapp常驻节点
     */
    protected myapp: Node = null;

    /**
     * 加载过程
     */
    onLoad() {
        // if (sys.isBrowser && sys.platform != sys.Platform.DESKTOP_BROWSER) {
        // if (sys.isBrowser) {
        //     screen.requestFullScreen();
        // }
        platform.hideNativeSplash();
        // 添加常驻节点
        this.myapp = UIUtils.createCanvas();
        let widget = this.myapp.addComponent(Widget);
        widget.top = 0;
        widget.bottom = 0;
        widget.left = 0;
        widget.right = 0;
        this.myapp.addComponent(AdaptScreen);

        director.addPersistRootNode(this.myapp);
        this.myapp.name = "myapp";
        this.myapp["viewParam"] = {};
        this.myapp!.setSiblingIndex(APP_LOCAL_INDEX);
        // end
        // 绑定框架逻辑 初始化游戏框架： 资源模块，网络模块，协议模块，日志模块。。。
        this.myapp.addComponent(ResMgr);
        this.myapp.addComponent(AudioMgr);
        this.myapp.addComponent(UIMgr);
        this.myapp.addComponent(TimerMgr);
        this.myapp.addComponent(SocketEventMgr);
        this.myapp.addComponent(ToastMgr);
        this.myapp.addComponent(GameApp);

        super.onLoad();
    }

    /**
     * 开始
     */
    start() {
        super.start();

        // //测试网络
        // let data = new pb.XGameComm.TMsgRespLoginHall();
        // data.iResultID = 1;
        // data.sPubKey = "TestKey123";

        // let encodeMsg = SocketEventMgr.Instance.sendMessages(EnumCodeID.LoginResp, data);
        // Logger.info("测试发送消息", encodeMsg);

        // SocketEventMgr.Instance.onRecvData({
        //     data: encodeMsg,
        // })
    }

    /** 初始化初步*/
    async initView() {
        //H5Api.getToken();
        H5Api.showLoad(52);
        //资源包加载
        try {
            let isShow = await ResMgr.Instance.onLoadBundleModules(EnumBundle.resources);
            H5Api.showLoad(54);
            isShow = await ResMgr.Instance.onLoadBundleModules(EnumBundle.lobby);
            H5Api.showLoad(56);
        } catch (error) {
            H5Api.loadingError();
            return;
        }
        //音乐加载
        try {
            // await AudioMgr.Instance.loadSoundClips(EnumBundle.ridCrush);
            H5Api.showLoad(60);
        } catch (error) {
            H5Api.loadingError();
            return;
        }
        //
        EventMgr.Instance.emit(GAME_EVENT.ON_CIRCLE_SHOW, false)
        EventMgr.Instance.emit(GAME_EVENT.ON_SHOW_LOADING, [EnumBundle.resources, EnumBundle.lobby]);
    }
}

