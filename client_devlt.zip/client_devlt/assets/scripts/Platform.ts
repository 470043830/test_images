/**平台方法*/

import { _decorator, native, sys } from "cc";
import { EncryptUtil } from "./framework/utils/EncryptUtil";
import { Logger } from "./framework/utils/Logger";
import { ToastMgr } from "./framework/manager/ToastMgr";

/**
 * int I
 * float F
 * boolean Z
 * String Ljava/lang/String;
 */

const { ccclass } = _decorator;

@ccclass('Platform')
export class Platform {
    /** 当前语言 */
    lan: string = "en";
    /** 平台名字 */
    name: string = "win32";

    /** 
     * 
    */
    constructor() {

    }

    /**
     * 平台类型
     */
    getPlatform() {
        return sys.os;
    }

    /**
     * 判断是不是原生的
     */
    isNative() {
        return sys.isNative;
    }

    /**
     * 获取设备id
     */
    getDeviceID() {
        let device = this.isNative() ? "h5_native" : "h5_web";
        if (this.isNative()) {
            switch (sys.os) {
                case sys.OS.ANDROID:
                    device = native.reflection.callStaticMethod("com/cocos/game/HelperUtils", "getDeviceID", "()Ljava/lang/String;");
                    break;
                case sys.OS.IOS:
                    break;
                case sys.OS.OPENHARMONY:
                    break;
            }
        } else {
            // 计算哈希值
            var hash = (str) => {
                var hash = 0;
                for (var i = 0; i < str.length; i++) {
                    var char = str.charCodeAt(i);
                    hash = ((hash << 5) - hash) + char;
                    hash = hash & hash;
                }
                return hash;
            }
            // 获取浏览器 User Agent 信息
            var userAgent = navigator.userAgent;
            // 获取浏览器 Accept Headers 信息
            var acceptHeaders = ""//navigator.acceptHeader;
            // 获取屏幕分辨率
            var screenWidth = screen.width;
            var screenHeight = screen.height;
            // 获取时区偏移量
            var timezoneOffset = new Date().getTimezoneOffset();
            // 创建一个 Canvas 元素
            var canvas = document.createElement('canvas');
            var ctx = canvas.getContext('2d');
            // 绘制一个图像，并获取图像数据的哈希值
            var text = 'fingerprint';
            ctx.textBaseline = "top";
            ctx.font = "14px 'Arial'";
            ctx.textBaseline = "alphabetic";
            ctx.fillStyle = "#f60";
            ctx.fillRect(125, 1, 62, 20);
            ctx.fillStyle = "#069";
            ctx.fillText(text, 2, 15);
            ctx.fillStyle = "rgba(102, 204, 0, 0.7)";
            ctx.fillText(text, 4, 17);
            var canvasData = canvas.toDataURL();
            var canvasHash = hash(canvasData);
            // 获取本地 IP 地址和端口号
            var rtcPeerConnection = window.RTCPeerConnection || window.RTCPeerConnection || window.RTCPeerConnection;
            if (rtcPeerConnection) {
                var pc = new rtcPeerConnection({
                    iceServers: []
                });
                pc.createDataChannel("");
                pc.createOffer(function (result) {
                    pc.setLocalDescription(result, function () {
                    }, function () {
                    });
                }, function () {

                });
                pc.onicecandidate = function (event) {
                    if (event && event.candidate && event.candidate.candidate) {
                        var address = event.candidate.candidate.split(' ')[4];
                        var port = event.candidate.candidate.split(' ')[5];
                        var ip = address.split(':')[0];
                    }
                };
            }
            // 整合上述信息生成浏览器指纹
            var fingerprint = userAgent + acceptHeaders + screenWidth + screenHeight + timezoneOffset + canvasHash;

            //测试 随机加账号
            device = EncryptUtil.md5(fingerprint).toString();
        }
        // device = this.deleteRandomChar(device)
        Logger.info("设备id", device)
        return device;
    }

    /**
     * 随机替换一个字符串 暂时用一下之后是删掉
     */
    deleteRandomChar(str) {
        var index = Math.floor(Math.random() * str.length); // 获取随机索引
        var num = Math.floor(Math.random() * 9); // 获取随机数
        return str.slice(0, index) + num + str.slice(index + 1); // 返回删除指定索引处字符后的新字符串
    }

    /**
     * 复制
     */
    setClipText(text: string) {
        if (this.isNative()) {
            switch (sys.os) {
                case sys.OS.ANDROID:
                    native.reflection.callStaticMethod("com/cocos/game/HelperUtils", "setClipText", "(Ljava/lang/String;)Z", text);
                    break;
                case sys.OS.IOS:
                    break;
                case sys.OS.OPENHARMONY:
                    break;
            }
        } else {
            // 创建一个临时的textarea元素，将文本放入其中
            const textarea = document.createElement('textarea');
            textarea.value = text;
            document.body.appendChild(textarea);
            // 选中文本
            textarea.select();
            textarea.setSelectionRange(0, textarea.value.length);
            try {
                // 尝试执行复制操作
                document.execCommand('copy');
                ToastMgr.Instance.onRecvToast({ msg: "复制成功" })
            } catch (err) {
                Logger.error('Unable to copy text to clipboard');
            }
            // 移除临时元素
            document.body.removeChild(textarea);
        }
    }

    /**
     * 获取剪切文本
     */
    getClipText(): string {
        let clipString = "";
        if (this.isNative()) {
            switch (sys.os) {
                case sys.OS.ANDROID:
                    clipString = native.reflection.callStaticMethod("com/cocos/game/HelperUtils", "getClipText", "()Ljava/lang/String;");
                    break;
                case sys.OS.IOS:
                    break;
                case sys.OS.OPENHARMONY:
                    break;
            }
        }
        //
        return clipString;
    }

    /**
     * 隐藏闪屏
     */
    hideNativeSplash(): void {
        if (this.isNative()) {
            switch (sys.os) {
                case sys.OS.ANDROID:
                    native.reflection.callStaticMethod("com/cocos/game/AppActivity", "hideSplash", "()V");
                    break;
                case sys.OS.IOS:
                    break;
                case sys.OS.OPENHARMONY:
                    break;
            }
        }
    }

    /**
     * 发送消息给平台
     */
    sendToNative(arg0: string, arg1?: string) {
        if (this.isNative()) {
            native.jsbBridgeWrapper.dispatchEventToNative(arg0, arg1);
        }
    }

    /**
     * 注册平台消息
     */
    onNative(event: string, listener: native.OnNativeEventListener) {
        if (this.isNative()) {
            native.jsbBridgeWrapper.addNativeEventListener(event, listener);
        }
    }

    /**
     * 打开原生分享
     */
    shareUrl(text: string) {
        if (this.isNative()) {
            switch (sys.os) {
                case sys.OS.ANDROID:
                    native.reflection.callStaticMethod("com/cocos/game/ShareUtils", "shareUrl", "(Ljava/lang/String;)V");
                    break;
                case sys.OS.IOS:
                    break;
                case sys.OS.OPENHARMONY:
                    break;
            }
        }
    }

    /**
     * 分享文本
     */
    shareText(title: string, text: string) {
        if (this.isNative()) {
            switch (sys.os) {
                case sys.OS.ANDROID:
                    native.reflection.callStaticMethod("com/cocos/game/ShareUtil", "shareText", "(Ljava/lang/String;Ljava/lang/String;)V", title, text);
                    break;
                case sys.OS.IOS:
                    break;
                case sys.OS.OPENHARMONY:
                    break;
            }
        }
    }

    /**
     * battery percent
     */
    getBatteryPercent(): number {
        if (this.isNative()) {
            switch (sys.os) {
                case sys.OS.ANDROID:
                    return native.reflection.callStaticMethod("com/cocos/game/HelperUtils", "getBatteryPercent", "()I");
                    break;
                case sys.OS.IOS:
                    break;
                case sys.OS.OPENHARMONY:
                    break;
            }
        }
    }

    /**
     * Bttery param
     */
    getBatteryParam(id: number = 4): number {
        if (this.isNative()) {
            switch (sys.os) {
                case sys.OS.ANDROID:
                    return native.reflection.callStaticMethod("com/cocos/game/HelperUtils", "getBatteryParam", "(I)I", id);
                    break;
                case sys.OS.IOS:
                    break;
                case sys.OS.OPENHARMONY:
                    break;
            }
        }
    }

    /**
     * 获取网络状态
     */
    getNetworkState(): number {
        if (this.isNative()) {
            switch (sys.os) {
                case sys.OS.ANDROID:
                    return native.reflection.callStaticMethod("com/cocos/game/HelperUtils", "getNetworkState", "()I");
                    break;
                case sys.OS.IOS:
                    break;
                case sys.OS.OPENHARMONY:
                    break;
            }
        }
    }

    /**
     * 获取网络信号
     */
    getNetworkSignal(): number {
        if (this.isNative()) {
            switch (sys.os) {
                case sys.OS.ANDROID:
                    return native.reflection.callStaticMethod("com/cocos/game/HelperUtils", "getNetworkSignal", "()I");
                    break;
                case sys.OS.IOS:
                    break;
                case sys.OS.OPENHARMONY:
                    break;
            }
        }
    }
}

window["platform"] = new Platform();

declare global {
    namespace globalThis {
        var platform: Platform;
    }
}
