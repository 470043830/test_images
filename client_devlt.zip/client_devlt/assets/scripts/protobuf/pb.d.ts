// DO NOT EDIT! This is a generated file. Edit the JSDoc in src/*.js instead and run 'npm run build:types'.

export = pb;

declare namespace pb {


    namespace ActivityProto {

        interface IGetRankActivityInfoReq {
            lUid?: (Long|null);
        }

        class GetRankActivityInfoReq implements IGetRankActivityInfoReq {
            constructor(p?: ActivityProto.IGetRankActivityInfoReq);
            public lUid: Long;
            public static create(properties?: ActivityProto.IGetRankActivityInfoReq): ActivityProto.GetRankActivityInfoReq;
            public static encode(m: ActivityProto.GetRankActivityInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityProto.GetRankActivityInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IRankActivityOwnerInfo {
            lUid?: (Long|null);
            sAvater?: (string|null);
            sNickname?: (string|null);
            lScore?: (Long|null);
            iRank?: (number|null);
        }

        class RankActivityOwnerInfo implements IRankActivityOwnerInfo {
            constructor(p?: ActivityProto.IRankActivityOwnerInfo);
            public lUid: Long;
            public sAvater: string;
            public sNickname: string;
            public lScore: Long;
            public iRank: number;
            public static create(properties?: ActivityProto.IRankActivityOwnerInfo): ActivityProto.RankActivityOwnerInfo;
            public static encode(m: ActivityProto.RankActivityOwnerInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityProto.RankActivityOwnerInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPrizeInfo {
            iRankBegin?: (number|null);
            iRankEnd?: (number|null);
            reward?: ({ [k: string]: number }|null);
        }

        class PrizeInfo implements IPrizeInfo {
            constructor(p?: ActivityProto.IPrizeInfo);
            public iRankBegin: number;
            public iRankEnd: number;
            public reward: { [k: string]: number };
            public static create(properties?: ActivityProto.IPrizeInfo): ActivityProto.PrizeInfo;
            public static encode(m: ActivityProto.PrizeInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityProto.PrizeInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetRankActivityInfoResp {
            iLevelLimit?: (number|null);
            iEndTime?: (number|null);
            rewards?: (ActivityProto.PrizeInfo[]|null);
            info?: (ActivityProto.RankActivityOwnerInfo|null);
            infos?: (ActivityProto.RankActivityOwnerInfo[]|null);
        }

        class GetRankActivityInfoResp implements IGetRankActivityInfoResp {
            constructor(p?: ActivityProto.IGetRankActivityInfoResp);
            public iLevelLimit: number;
            public iEndTime: number;
            public rewards: ActivityProto.PrizeInfo[];
            public info?: (ActivityProto.RankActivityOwnerInfo|null);
            public infos: ActivityProto.RankActivityOwnerInfo[];
            public static create(properties?: ActivityProto.IGetRankActivityInfoResp): ActivityProto.GetRankActivityInfoResp;
            public static encode(m: ActivityProto.GetRankActivityInfoResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityProto.GetRankActivityInfoResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetRankActivityRewardReq {
            lUid?: (Long|null);
        }

        class GetRankActivityRewardReq implements IGetRankActivityRewardReq {
            constructor(p?: ActivityProto.IGetRankActivityRewardReq);
            public lUid: Long;
            public static create(properties?: ActivityProto.IGetRankActivityRewardReq): ActivityProto.GetRankActivityRewardReq;
            public static encode(m: ActivityProto.GetRankActivityRewardReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityProto.GetRankActivityRewardReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IReward {
            type?: (number|null);
            amount?: (number|null);
        }

        class Reward implements IReward {
            constructor(p?: ActivityProto.IReward);
            public type: number;
            public amount: number;
            public static create(properties?: ActivityProto.IReward): ActivityProto.Reward;
            public static encode(m: ActivityProto.Reward, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityProto.Reward;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IRankActivityRewardInfo {
            iID?: (Long|null);
            iRank?: (number|null);
            iStartTime?: (number|null);
            iStatus?: (number|null);
            rewards?: (ActivityProto.Reward[]|null);
        }

        class RankActivityRewardInfo implements IRankActivityRewardInfo {
            constructor(p?: ActivityProto.IRankActivityRewardInfo);
            public iID: Long;
            public iRank: number;
            public iStartTime: number;
            public iStatus: number;
            public rewards: ActivityProto.Reward[];
            public static create(properties?: ActivityProto.IRankActivityRewardInfo): ActivityProto.RankActivityRewardInfo;
            public static encode(m: ActivityProto.RankActivityRewardInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityProto.RankActivityRewardInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetRankActivityRewardRsp {
            iResultCode?: (number|null);
            infos?: (ActivityProto.RankActivityRewardInfo[]|null);
        }

        class GetRankActivityRewardRsp implements IGetRankActivityRewardRsp {
            constructor(p?: ActivityProto.IGetRankActivityRewardRsp);
            public iResultCode: number;
            public infos: ActivityProto.RankActivityRewardInfo[];
            public static create(properties?: ActivityProto.IGetRankActivityRewardRsp): ActivityProto.GetRankActivityRewardRsp;
            public static encode(m: ActivityProto.GetRankActivityRewardRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityProto.GetRankActivityRewardRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ITakeRankActivityRewardReq {
            iID?: (Long|null);
        }

        class TakeRankActivityRewardReq implements ITakeRankActivityRewardReq {
            constructor(p?: ActivityProto.ITakeRankActivityRewardReq);
            public iID: Long;
            public static create(properties?: ActivityProto.ITakeRankActivityRewardReq): ActivityProto.TakeRankActivityRewardReq;
            public static encode(m: ActivityProto.TakeRankActivityRewardReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityProto.TakeRankActivityRewardReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ITakeRankActivityRewardRsp {
            iResultCode?: (number|null);
            iID?: (Long|null);
            rewards?: (ActivityProto.Reward[]|null);
        }

        class TakeRankActivityRewardRsp implements ITakeRankActivityRewardRsp {
            constructor(p?: ActivityProto.ITakeRankActivityRewardRsp);
            public iResultCode: number;
            public iID: Long;
            public rewards: ActivityProto.Reward[];
            public static create(properties?: ActivityProto.ITakeRankActivityRewardRsp): ActivityProto.TakeRankActivityRewardRsp;
            public static encode(m: ActivityProto.TakeRankActivityRewardRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityProto.TakeRankActivityRewardRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }

    namespace ActivityCashRainProto {

        interface IGetActCashRainMyInfoReq {
        }

        class GetActCashRainMyInfoReq implements IGetActCashRainMyInfoReq {
            constructor(p?: ActivityCashRainProto.IGetActCashRainMyInfoReq);
            public static create(properties?: ActivityCashRainProto.IGetActCashRainMyInfoReq): ActivityCashRainProto.GetActCashRainMyInfoReq;
            public static encode(m: ActivityCashRainProto.GetActCashRainMyInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityCashRainProto.GetActCashRainMyInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetActCashRainMyInfoRsp {
            resultCode?: (number|null);
            leftCnt?: (number|null);
            todayMaxCnt?: (number|null);
            redPackage?: (ActivityCashRainProto.RedPackage|null);
            lastBuyTime?: (Long|null);
            timeSeg?: (ActivityCashRainProto.TimeSeg[]|null);
            maxReward?: (string|null);
        }

        class GetActCashRainMyInfoRsp implements IGetActCashRainMyInfoRsp {
            constructor(p?: ActivityCashRainProto.IGetActCashRainMyInfoRsp);
            public resultCode: number;
            public leftCnt: number;
            public todayMaxCnt: number;
            public redPackage?: (ActivityCashRainProto.RedPackage|null);
            public lastBuyTime: Long;
            public timeSeg: ActivityCashRainProto.TimeSeg[];
            public maxReward: string;
            public static create(properties?: ActivityCashRainProto.IGetActCashRainMyInfoRsp): ActivityCashRainProto.GetActCashRainMyInfoRsp;
            public static encode(m: ActivityCashRainProto.GetActCashRainMyInfoRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityCashRainProto.GetActCashRainMyInfoRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IRedPackage {
            id?: (Long|null);
            expireTime?: (Long|null);
            reward?: (string|null);
        }

        class RedPackage implements IRedPackage {
            constructor(p?: ActivityCashRainProto.IRedPackage);
            public id: Long;
            public expireTime: Long;
            public reward: string;
            public static create(properties?: ActivityCashRainProto.IRedPackage): ActivityCashRainProto.RedPackage;
            public static encode(m: ActivityCashRainProto.RedPackage, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityCashRainProto.RedPackage;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ITimeSeg {
            startUnix?: (Long|null);
            endUnix?: (Long|null);
        }

        class TimeSeg implements ITimeSeg {
            constructor(p?: ActivityCashRainProto.ITimeSeg);
            public startUnix: Long;
            public endUnix: Long;
            public static create(properties?: ActivityCashRainProto.ITimeSeg): ActivityCashRainProto.TimeSeg;
            public static encode(m: ActivityCashRainProto.TimeSeg, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityCashRainProto.TimeSeg;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IOpenActCashRainReq {
            id?: (Long|null);
        }

        class OpenActCashRainReq implements IOpenActCashRainReq {
            constructor(p?: ActivityCashRainProto.IOpenActCashRainReq);
            public id: Long;
            public static create(properties?: ActivityCashRainProto.IOpenActCashRainReq): ActivityCashRainProto.OpenActCashRainReq;
            public static encode(m: ActivityCashRainProto.OpenActCashRainReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityCashRainProto.OpenActCashRainReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IOpenActCashRainRsp {
            resultCode?: (number|null);
            id?: (Long|null);
        }

        class OpenActCashRainRsp implements IOpenActCashRainRsp {
            constructor(p?: ActivityCashRainProto.IOpenActCashRainRsp);
            public resultCode: number;
            public id: Long;
            public static create(properties?: ActivityCashRainProto.IOpenActCashRainRsp): ActivityCashRainProto.OpenActCashRainRsp;
            public static encode(m: ActivityCashRainProto.OpenActCashRainRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityCashRainProto.OpenActCashRainRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }

    namespace ActivityDailyLotteryProto {

        interface IGetActDailyLotteryMyInfoReq {
        }

        class GetActDailyLotteryMyInfoReq implements IGetActDailyLotteryMyInfoReq {
            constructor(p?: ActivityDailyLotteryProto.IGetActDailyLotteryMyInfoReq);
            public static create(properties?: ActivityDailyLotteryProto.IGetActDailyLotteryMyInfoReq): ActivityDailyLotteryProto.GetActDailyLotteryMyInfoReq;
            public static encode(m: ActivityDailyLotteryProto.GetActDailyLotteryMyInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityDailyLotteryProto.GetActDailyLotteryMyInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetActDailyLotteryMyInfoRsp {
            resultCode?: (number|null);
            lotteryCnt?: (number|null);
            dailyLotteryRewards?: (string|null);
            myChars?: (string|null);
            taskList?: (ActivityDailyLotteryProto.ActDailyLotteryTaskItem[]|null);
        }

        class GetActDailyLotteryMyInfoRsp implements IGetActDailyLotteryMyInfoRsp {
            constructor(p?: ActivityDailyLotteryProto.IGetActDailyLotteryMyInfoRsp);
            public resultCode: number;
            public lotteryCnt: number;
            public dailyLotteryRewards: string;
            public myChars: string;
            public taskList: ActivityDailyLotteryProto.ActDailyLotteryTaskItem[];
            public static create(properties?: ActivityDailyLotteryProto.IGetActDailyLotteryMyInfoRsp): ActivityDailyLotteryProto.GetActDailyLotteryMyInfoRsp;
            public static encode(m: ActivityDailyLotteryProto.GetActDailyLotteryMyInfoRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityDailyLotteryProto.GetActDailyLotteryMyInfoRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IActDailyLotteryTaskItem {
            id?: (number|null);
            itemId?: (number|null);
            name?: (string|null);
            taskType?: (number|null);
            taskName?: (Long|null);
            taskContent?: (Long|null);
            roomGameId?: (Long|null);
            okNum?: (number|null);
            rewardCnt?: (number|null);
            curNum?: (number|null);
            received?: (boolean|null);
            ticketPrice?: (number|null);
        }

        class ActDailyLotteryTaskItem implements IActDailyLotteryTaskItem {
            constructor(p?: ActivityDailyLotteryProto.IActDailyLotteryTaskItem);
            public id: number;
            public itemId: number;
            public name: string;
            public taskType: number;
            public taskName: Long;
            public taskContent: Long;
            public roomGameId: Long;
            public okNum: number;
            public rewardCnt: number;
            public curNum: number;
            public received: boolean;
            public ticketPrice: number;
            public static create(properties?: ActivityDailyLotteryProto.IActDailyLotteryTaskItem): ActivityDailyLotteryProto.ActDailyLotteryTaskItem;
            public static encode(m: ActivityDailyLotteryProto.ActDailyLotteryTaskItem, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityDailyLotteryProto.ActDailyLotteryTaskItem;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IReceiveTaskRewardReq {
            id?: (Long|null);
        }

        class ReceiveTaskRewardReq implements IReceiveTaskRewardReq {
            constructor(p?: ActivityDailyLotteryProto.IReceiveTaskRewardReq);
            public id: Long;
            public static create(properties?: ActivityDailyLotteryProto.IReceiveTaskRewardReq): ActivityDailyLotteryProto.ReceiveTaskRewardReq;
            public static encode(m: ActivityDailyLotteryProto.ReceiveTaskRewardReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityDailyLotteryProto.ReceiveTaskRewardReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IReceiveTaskRewardRsp {
            resultCode?: (number|null);
            id?: (Long|null);
            lotteryCnt?: (number|null);
        }

        class ReceiveTaskRewardRsp implements IReceiveTaskRewardRsp {
            constructor(p?: ActivityDailyLotteryProto.IReceiveTaskRewardRsp);
            public resultCode: number;
            public id: Long;
            public lotteryCnt: number;
            public static create(properties?: ActivityDailyLotteryProto.IReceiveTaskRewardRsp): ActivityDailyLotteryProto.ReceiveTaskRewardRsp;
            public static encode(m: ActivityDailyLotteryProto.ReceiveTaskRewardRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityDailyLotteryProto.ReceiveTaskRewardRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ILotteryDrawReq {
        }

        class LotteryDrawReq implements ILotteryDrawReq {
            constructor(p?: ActivityDailyLotteryProto.ILotteryDrawReq);
            public static create(properties?: ActivityDailyLotteryProto.ILotteryDrawReq): ActivityDailyLotteryProto.LotteryDrawReq;
            public static encode(m: ActivityDailyLotteryProto.LotteryDrawReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityDailyLotteryProto.LotteryDrawReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ILotteryDrawRsp {
            resultCode?: (number|null);
            receivedReward?: (string|null);
            lotteryCnt?: (number|null);
            myChars?: (string|null);
        }

        class LotteryDrawRsp implements ILotteryDrawRsp {
            constructor(p?: ActivityDailyLotteryProto.ILotteryDrawRsp);
            public resultCode: number;
            public receivedReward: string;
            public lotteryCnt: number;
            public myChars: string;
            public static create(properties?: ActivityDailyLotteryProto.ILotteryDrawRsp): ActivityDailyLotteryProto.LotteryDrawRsp;
            public static encode(m: ActivityDailyLotteryProto.LotteryDrawRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityDailyLotteryProto.LotteryDrawRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IReceiveWinnerRewardReq {
        }

        class ReceiveWinnerRewardReq implements IReceiveWinnerRewardReq {
            constructor(p?: ActivityDailyLotteryProto.IReceiveWinnerRewardReq);
            public static create(properties?: ActivityDailyLotteryProto.IReceiveWinnerRewardReq): ActivityDailyLotteryProto.ReceiveWinnerRewardReq;
            public static encode(m: ActivityDailyLotteryProto.ReceiveWinnerRewardReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityDailyLotteryProto.ReceiveWinnerRewardReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IReceiveWinnerRewardRsp {
            resultCode?: (number|null);
            myChars?: (string|null);
            receivedReward?: (string|null);
        }

        class ReceiveWinnerRewardRsp implements IReceiveWinnerRewardRsp {
            constructor(p?: ActivityDailyLotteryProto.IReceiveWinnerRewardRsp);
            public resultCode: number;
            public myChars: string;
            public receivedReward: string;
            public static create(properties?: ActivityDailyLotteryProto.IReceiveWinnerRewardRsp): ActivityDailyLotteryProto.ReceiveWinnerRewardRsp;
            public static encode(m: ActivityDailyLotteryProto.ReceiveWinnerRewardRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityDailyLotteryProto.ReceiveWinnerRewardRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }

    namespace ActivityFriendProto {

        interface IActivityFriendRewardConfig {
            lId?: (Long|null);
            lFriendCount?: (Long|null);
            sReward?: (string|null);
        }

        class ActivityFriendRewardConfig implements IActivityFriendRewardConfig {
            constructor(p?: ActivityFriendProto.IActivityFriendRewardConfig);
            public lId: Long;
            public lFriendCount: Long;
            public sReward: string;
            public static create(properties?: ActivityFriendProto.IActivityFriendRewardConfig): ActivityFriendProto.ActivityFriendRewardConfig;
            public static encode(m: ActivityFriendProto.ActivityFriendRewardConfig, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityFriendProto.ActivityFriendRewardConfig;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IActivityFriendRewardConfigReq {
        }

        class ActivityFriendRewardConfigReq implements IActivityFriendRewardConfigReq {
            constructor(p?: ActivityFriendProto.IActivityFriendRewardConfigReq);
            public static create(properties?: ActivityFriendProto.IActivityFriendRewardConfigReq): ActivityFriendProto.ActivityFriendRewardConfigReq;
            public static encode(m: ActivityFriendProto.ActivityFriendRewardConfigReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityFriendProto.ActivityFriendRewardConfigReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IActivityFriendRewardConfigRsp {
            iResultCode?: (number|null);
            infos?: (ActivityFriendProto.ActivityFriendRewardConfig[]|null);
        }

        class ActivityFriendRewardConfigRsp implements IActivityFriendRewardConfigRsp {
            constructor(p?: ActivityFriendProto.IActivityFriendRewardConfigRsp);
            public iResultCode: number;
            public infos: ActivityFriendProto.ActivityFriendRewardConfig[];
            public static create(properties?: ActivityFriendProto.IActivityFriendRewardConfigRsp): ActivityFriendProto.ActivityFriendRewardConfigRsp;
            public static encode(m: ActivityFriendProto.ActivityFriendRewardConfigRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityFriendProto.ActivityFriendRewardConfigRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IActivityFriendInfo {
            lPid?: (Long|null);
            lUid?: (Long|null);
            sNickname?: (string|null);
            iDeposit?: (number|null);
            iMatchCount?: (number|null);
            iMaxCount?: (number|null);
        }

        class ActivityFriendInfo implements IActivityFriendInfo {
            constructor(p?: ActivityFriendProto.IActivityFriendInfo);
            public lPid: Long;
            public lUid: Long;
            public sNickname: string;
            public iDeposit: number;
            public iMatchCount: number;
            public iMaxCount: number;
            public static create(properties?: ActivityFriendProto.IActivityFriendInfo): ActivityFriendProto.ActivityFriendInfo;
            public static encode(m: ActivityFriendProto.ActivityFriendInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityFriendProto.ActivityFriendInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IActivityFriendInfoListReq {
            lID?: (Long|null);
            lRound?: (Long|null);
        }

        class ActivityFriendInfoListReq implements IActivityFriendInfoListReq {
            constructor(p?: ActivityFriendProto.IActivityFriendInfoListReq);
            public lID: Long;
            public lRound: Long;
            public static create(properties?: ActivityFriendProto.IActivityFriendInfoListReq): ActivityFriendProto.ActivityFriendInfoListReq;
            public static encode(m: ActivityFriendProto.ActivityFriendInfoListReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityFriendProto.ActivityFriendInfoListReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IActivityFriendInfoListRsp {
            iResultCode?: (number|null);
            iFinishCount?: (number|null);
            infos?: (ActivityFriendProto.ActivityFriendInfo[]|null);
        }

        class ActivityFriendInfoListRsp implements IActivityFriendInfoListRsp {
            constructor(p?: ActivityFriendProto.IActivityFriendInfoListRsp);
            public iResultCode: number;
            public iFinishCount: number;
            public infos: ActivityFriendProto.ActivityFriendInfo[];
            public static create(properties?: ActivityFriendProto.IActivityFriendInfoListRsp): ActivityFriendProto.ActivityFriendInfoListRsp;
            public static encode(m: ActivityFriendProto.ActivityFriendInfoListRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityFriendProto.ActivityFriendInfoListRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IActivityFriendTakeRewardReq {
            iID?: (Long|null);
        }

        class ActivityFriendTakeRewardReq implements IActivityFriendTakeRewardReq {
            constructor(p?: ActivityFriendProto.IActivityFriendTakeRewardReq);
            public iID: Long;
            public static create(properties?: ActivityFriendProto.IActivityFriendTakeRewardReq): ActivityFriendProto.ActivityFriendTakeRewardReq;
            public static encode(m: ActivityFriendProto.ActivityFriendTakeRewardReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityFriendProto.ActivityFriendTakeRewardReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IActivityFriendTakeRewardRsp {
            iResultCode?: (number|null);
            iID?: (Long|null);
            sReward?: (string|null);
        }

        class ActivityFriendTakeRewardRsp implements IActivityFriendTakeRewardRsp {
            constructor(p?: ActivityFriendProto.IActivityFriendTakeRewardRsp);
            public iResultCode: number;
            public iID: Long;
            public sReward: string;
            public static create(properties?: ActivityFriendProto.IActivityFriendTakeRewardRsp): ActivityFriendProto.ActivityFriendTakeRewardRsp;
            public static encode(m: ActivityFriendProto.ActivityFriendTakeRewardRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityFriendProto.ActivityFriendTakeRewardRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IActivityFriendTakeListReq {
            lID?: (Long|null);
            lRound?: (Long|null);
        }

        class ActivityFriendTakeListReq implements IActivityFriendTakeListReq {
            constructor(p?: ActivityFriendProto.IActivityFriendTakeListReq);
            public lID: Long;
            public lRound: Long;
            public static create(properties?: ActivityFriendProto.IActivityFriendTakeListReq): ActivityFriendProto.ActivityFriendTakeListReq;
            public static encode(m: ActivityFriendProto.ActivityFriendTakeListReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityFriendProto.ActivityFriendTakeListReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IActivityFriendTakeListRsp {
            iResultCode?: (number|null);
            iID?: (Long|null);
            vIds?: (number[]|null);
        }

        class ActivityFriendTakeListRsp implements IActivityFriendTakeListRsp {
            constructor(p?: ActivityFriendProto.IActivityFriendTakeListRsp);
            public iResultCode: number;
            public iID: Long;
            public vIds: number[];
            public static create(properties?: ActivityFriendProto.IActivityFriendTakeListRsp): ActivityFriendProto.ActivityFriendTakeListRsp;
            public static encode(m: ActivityFriendProto.ActivityFriendTakeListRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityFriendProto.ActivityFriendTakeListRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }

    namespace ActivityFriendSupportProto {

        interface IGetActFriendSupportCfgReq {
        }

        class GetActFriendSupportCfgReq implements IGetActFriendSupportCfgReq {
            constructor(p?: ActivityFriendSupportProto.IGetActFriendSupportCfgReq);
            public static create(properties?: ActivityFriendSupportProto.IGetActFriendSupportCfgReq): ActivityFriendSupportProto.GetActFriendSupportCfgReq;
            public static encode(m: ActivityFriendSupportProto.GetActFriendSupportCfgReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityFriendSupportProto.GetActFriendSupportCfgReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetActFriendSupportCfgRsp {
            resultCode?: (number|null);
            conf?: (ActivityFriendSupportProto.ActFriendSupportCfgItem[]|null);
        }

        class GetActFriendSupportCfgRsp implements IGetActFriendSupportCfgRsp {
            constructor(p?: ActivityFriendSupportProto.IGetActFriendSupportCfgRsp);
            public resultCode: number;
            public conf: ActivityFriendSupportProto.ActFriendSupportCfgItem[];
            public static create(properties?: ActivityFriendSupportProto.IGetActFriendSupportCfgRsp): ActivityFriendSupportProto.GetActFriendSupportCfgRsp;
            public static encode(m: ActivityFriendSupportProto.GetActFriendSupportCfgRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityFriendSupportProto.GetActFriendSupportCfgRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IActFriendSupportCfgItem {
            id?: (number|null);
            name?: (string|null);
            taskType?: (number|null);
            taskName?: (Long|null);
            taskContent?: (Long|null);
            playerNum?: (number|null);
            rewardItem?: (string|null);
        }

        class ActFriendSupportCfgItem implements IActFriendSupportCfgItem {
            constructor(p?: ActivityFriendSupportProto.IActFriendSupportCfgItem);
            public id: number;
            public name: string;
            public taskType: number;
            public taskName: Long;
            public taskContent: Long;
            public playerNum: number;
            public rewardItem: string;
            public static create(properties?: ActivityFriendSupportProto.IActFriendSupportCfgItem): ActivityFriendSupportProto.ActFriendSupportCfgItem;
            public static encode(m: ActivityFriendSupportProto.ActFriendSupportCfgItem, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityFriendSupportProto.ActFriendSupportCfgItem;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetActFriendSupportMyInfoReq {
        }

        class GetActFriendSupportMyInfoReq implements IGetActFriendSupportMyInfoReq {
            constructor(p?: ActivityFriendSupportProto.IGetActFriendSupportMyInfoReq);
            public static create(properties?: ActivityFriendSupportProto.IGetActFriendSupportMyInfoReq): ActivityFriendSupportProto.GetActFriendSupportMyInfoReq;
            public static encode(m: ActivityFriendSupportProto.GetActFriendSupportMyInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityFriendSupportProto.GetActFriendSupportMyInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetActFriendSupportMyInfoRsp {
            resultCode?: (number|null);
            isJoin?: (boolean|null);
            taskRewardReceived?: (string|null);
            inviteCode?: (string|null);
            items?: (ActivityFriendSupportProto.ActFriendSupportCfgItem[]|null);
            bindNum?: (number|null);
            compTaskNum?: (number|null);
        }

        class GetActFriendSupportMyInfoRsp implements IGetActFriendSupportMyInfoRsp {
            constructor(p?: ActivityFriendSupportProto.IGetActFriendSupportMyInfoRsp);
            public resultCode: number;
            public isJoin: boolean;
            public taskRewardReceived: string;
            public inviteCode: string;
            public items: ActivityFriendSupportProto.ActFriendSupportCfgItem[];
            public bindNum: number;
            public compTaskNum: number;
            public static create(properties?: ActivityFriendSupportProto.IGetActFriendSupportMyInfoRsp): ActivityFriendSupportProto.GetActFriendSupportMyInfoRsp;
            public static encode(m: ActivityFriendSupportProto.GetActFriendSupportMyInfoRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityFriendSupportProto.GetActFriendSupportMyInfoRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IReceiveActFriendSupportTaskRewardReq {
            taskItemId?: (Long|null);
        }

        class ReceiveActFriendSupportTaskRewardReq implements IReceiveActFriendSupportTaskRewardReq {
            constructor(p?: ActivityFriendSupportProto.IReceiveActFriendSupportTaskRewardReq);
            public taskItemId: Long;
            public static create(properties?: ActivityFriendSupportProto.IReceiveActFriendSupportTaskRewardReq): ActivityFriendSupportProto.ReceiveActFriendSupportTaskRewardReq;
            public static encode(m: ActivityFriendSupportProto.ReceiveActFriendSupportTaskRewardReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityFriendSupportProto.ReceiveActFriendSupportTaskRewardReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IReceiveActFriendSupportTaskRewardRsp {
            resultCode?: (number|null);
            taskItemId?: (Long|null);
            taskRewardReceived?: (string|null);
        }

        class ReceiveActFriendSupportTaskRewardRsp implements IReceiveActFriendSupportTaskRewardRsp {
            constructor(p?: ActivityFriendSupportProto.IReceiveActFriendSupportTaskRewardRsp);
            public resultCode: number;
            public taskItemId: Long;
            public taskRewardReceived: string;
            public static create(properties?: ActivityFriendSupportProto.IReceiveActFriendSupportTaskRewardRsp): ActivityFriendSupportProto.ReceiveActFriendSupportTaskRewardRsp;
            public static encode(m: ActivityFriendSupportProto.ReceiveActFriendSupportTaskRewardRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityFriendSupportProto.ReceiveActFriendSupportTaskRewardRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetActFriendSupportBindListReq {
        }

        class GetActFriendSupportBindListReq implements IGetActFriendSupportBindListReq {
            constructor(p?: ActivityFriendSupportProto.IGetActFriendSupportBindListReq);
            public static create(properties?: ActivityFriendSupportProto.IGetActFriendSupportBindListReq): ActivityFriendSupportProto.GetActFriendSupportBindListReq;
            public static encode(m: ActivityFriendSupportProto.GetActFriendSupportBindListReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityFriendSupportProto.GetActFriendSupportBindListReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetActFriendSupportBindListRsp {
            resultCode?: (number|null);
            list?: (ActivityFriendSupportProto.ActFriendSupportBindInfo[]|null);
        }

        class GetActFriendSupportBindListRsp implements IGetActFriendSupportBindListRsp {
            constructor(p?: ActivityFriendSupportProto.IGetActFriendSupportBindListRsp);
            public resultCode: number;
            public list: ActivityFriendSupportProto.ActFriendSupportBindInfo[];
            public static create(properties?: ActivityFriendSupportProto.IGetActFriendSupportBindListRsp): ActivityFriendSupportProto.GetActFriendSupportBindListRsp;
            public static encode(m: ActivityFriendSupportProto.GetActFriendSupportBindListRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityFriendSupportProto.GetActFriendSupportBindListRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IActFriendSupportBindInfo {
            id?: (Long|null);
            name?: (string|null);
            deposit?: (number|null);
            matchNum?: (number|null);
            matchMax?: (number|null);
            createTime?: (Long|null);
        }

        class ActFriendSupportBindInfo implements IActFriendSupportBindInfo {
            constructor(p?: ActivityFriendSupportProto.IActFriendSupportBindInfo);
            public id: Long;
            public name: string;
            public deposit: number;
            public matchNum: number;
            public matchMax: number;
            public createTime: Long;
            public static create(properties?: ActivityFriendSupportProto.IActFriendSupportBindInfo): ActivityFriendSupportProto.ActFriendSupportBindInfo;
            public static encode(m: ActivityFriendSupportProto.ActFriendSupportBindInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityFriendSupportProto.ActFriendSupportBindInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }

    namespace ActivityTaskProto {

        interface IActTaskInfo {
            id?: (Long|null);
            taskType?: (number|null);
            curNum?: (number|null);
            targetNum?: (number|null);
            rewardTool?: (string|null);
            received?: (boolean|null);
            tierId?: (string|null);
            taskCash?: (number|null);
            taskScore?: (number|null);
            taskNum?: (number|null);
            isLock?: (boolean|null);
            taskRank?: (number|null);
            taskUpLevel?: (number|null);
            taskAidCnt?: (number|null);
            taskTicketCnt?: (number|null);
        }

        class ActTaskInfo implements IActTaskInfo {
            constructor(p?: ActivityTaskProto.IActTaskInfo);
            public id: Long;
            public taskType: number;
            public curNum: number;
            public targetNum: number;
            public rewardTool: string;
            public received: boolean;
            public tierId: string;
            public taskCash: number;
            public taskScore: number;
            public taskNum: number;
            public isLock: boolean;
            public taskRank: number;
            public taskUpLevel: number;
            public taskAidCnt: number;
            public taskTicketCnt: number;
            public static create(properties?: ActivityTaskProto.IActTaskInfo): ActivityTaskProto.ActTaskInfo;
            public static encode(m: ActivityTaskProto.ActTaskInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityTaskProto.ActTaskInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetActTaskMyInfoReq {
            aid?: (Long|null);
        }

        class GetActTaskMyInfoReq implements IGetActTaskMyInfoReq {
            constructor(p?: ActivityTaskProto.IGetActTaskMyInfoReq);
            public aid: Long;
            public static create(properties?: ActivityTaskProto.IGetActTaskMyInfoReq): ActivityTaskProto.GetActTaskMyInfoReq;
            public static encode(m: ActivityTaskProto.GetActTaskMyInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityTaskProto.GetActTaskMyInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetActTaskMyInfoRsp {
            resultCode?: (number|null);
            taskList?: (ActivityTaskProto.ActTaskInfo[]|null);
            aid?: (Long|null);
        }

        class GetActTaskMyInfoRsp implements IGetActTaskMyInfoRsp {
            constructor(p?: ActivityTaskProto.IGetActTaskMyInfoRsp);
            public resultCode: number;
            public taskList: ActivityTaskProto.ActTaskInfo[];
            public aid: Long;
            public static create(properties?: ActivityTaskProto.IGetActTaskMyInfoRsp): ActivityTaskProto.GetActTaskMyInfoRsp;
            public static encode(m: ActivityTaskProto.GetActTaskMyInfoRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityTaskProto.GetActTaskMyInfoRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IActTaskReceiveRewardReq {
            id?: (Long|null);
        }

        class ActTaskReceiveRewardReq implements IActTaskReceiveRewardReq {
            constructor(p?: ActivityTaskProto.IActTaskReceiveRewardReq);
            public id: Long;
            public static create(properties?: ActivityTaskProto.IActTaskReceiveRewardReq): ActivityTaskProto.ActTaskReceiveRewardReq;
            public static encode(m: ActivityTaskProto.ActTaskReceiveRewardReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityTaskProto.ActTaskReceiveRewardReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IActTaskReceiveRewardRsp {
            resultCode?: (number|null);
            id?: (Long|null);
        }

        class ActTaskReceiveRewardRsp implements IActTaskReceiveRewardRsp {
            constructor(p?: ActivityTaskProto.IActTaskReceiveRewardRsp);
            public resultCode: number;
            public id: Long;
            public static create(properties?: ActivityTaskProto.IActTaskReceiveRewardRsp): ActivityTaskProto.ActTaskReceiveRewardRsp;
            public static encode(m: ActivityTaskProto.ActTaskReceiveRewardRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityTaskProto.ActTaskReceiveRewardRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IActTaskReceiveRewardBatchReq {
            ids?: (Long[]|null);
        }

        class ActTaskReceiveRewardBatchReq implements IActTaskReceiveRewardBatchReq {
            constructor(p?: ActivityTaskProto.IActTaskReceiveRewardBatchReq);
            public ids: Long[];
            public static create(properties?: ActivityTaskProto.IActTaskReceiveRewardBatchReq): ActivityTaskProto.ActTaskReceiveRewardBatchReq;
            public static encode(m: ActivityTaskProto.ActTaskReceiveRewardBatchReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityTaskProto.ActTaskReceiveRewardBatchReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IActTaskReceiveRewardBatchRsp {
            resultCode?: (number|null);
            ids?: (Long[]|null);
        }

        class ActTaskReceiveRewardBatchRsp implements IActTaskReceiveRewardBatchRsp {
            constructor(p?: ActivityTaskProto.IActTaskReceiveRewardBatchRsp);
            public resultCode: number;
            public ids: Long[];
            public static create(properties?: ActivityTaskProto.IActTaskReceiveRewardBatchRsp): ActivityTaskProto.ActTaskReceiveRewardBatchRsp;
            public static encode(m: ActivityTaskProto.ActTaskReceiveRewardBatchRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityTaskProto.ActTaskReceiveRewardBatchRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetActTaskMyInfoBatchReq {
            aid?: (Long[]|null);
        }

        class GetActTaskMyInfoBatchReq implements IGetActTaskMyInfoBatchReq {
            constructor(p?: ActivityTaskProto.IGetActTaskMyInfoBatchReq);
            public aid: Long[];
            public static create(properties?: ActivityTaskProto.IGetActTaskMyInfoBatchReq): ActivityTaskProto.GetActTaskMyInfoBatchReq;
            public static encode(m: ActivityTaskProto.GetActTaskMyInfoBatchReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityTaskProto.GetActTaskMyInfoBatchReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetActTaskMyInfoBatchRsp {
            resultCode?: (number|null);
            list?: (ActivityTaskProto.GetActTaskMyInfoRsp[]|null);
        }

        class GetActTaskMyInfoBatchRsp implements IGetActTaskMyInfoBatchRsp {
            constructor(p?: ActivityTaskProto.IGetActTaskMyInfoBatchRsp);
            public resultCode: number;
            public list: ActivityTaskProto.GetActTaskMyInfoRsp[];
            public static create(properties?: ActivityTaskProto.IGetActTaskMyInfoBatchRsp): ActivityTaskProto.GetActTaskMyInfoBatchRsp;
            public static encode(m: ActivityTaskProto.GetActTaskMyInfoBatchRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ActivityTaskProto.GetActTaskMyInfoBatchRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }

    namespace BubbleProto {

        interface IBubbleGame {
            seq?: (number|null);
            leftMS?: (number|null);
            rows?: (BubbleProto.RowData[]|null);
            bubbles?: (BubbleProto.Emitter[]|null);
            shots?: (number|null);
            scoreData?: (BubbleProto.ScoreData|null);
            randSeed?: (number|null);
            randCnt?: (number|null);
            maxPauseUnixMS?: (Long|null);
            bubbleProp?: (BubbleProto.BubbleProp|null);
        }

        class BubbleGame implements IBubbleGame {
            constructor(p?: BubbleProto.IBubbleGame);
            public seq: number;
            public leftMS: number;
            public rows: BubbleProto.RowData[];
            public bubbles: BubbleProto.Emitter[];
            public shots: number;
            public scoreData?: (BubbleProto.ScoreData|null);
            public randSeed: number;
            public randCnt: number;
            public maxPauseUnixMS: Long;
            public bubbleProp?: (BubbleProto.BubbleProp|null);
            public static create(properties?: BubbleProto.IBubbleGame): BubbleProto.BubbleGame;
            public static encode(m: BubbleProto.BubbleGame, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BubbleProto.BubbleGame;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IEmitter {
            bubble?: (number|null);
            bubbleEnum?: (BubbleProto.BubbleEnum|null);
        }

        class Emitter implements IEmitter {
            constructor(p?: BubbleProto.IEmitter);
            public bubble: number;
            public bubbleEnum: BubbleProto.BubbleEnum;
            public static create(properties?: BubbleProto.IEmitter): BubbleProto.Emitter;
            public static encode(m: BubbleProto.Emitter, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BubbleProto.Emitter;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        enum BubbleEnum {
            Ordinary = 0,
            AddTime = 101,
            DoubleSource = 102,
            Bomb = 103,
            Omnipotent = 104,
            ChangeColor = 105
        }

        interface IRowData {
            cols?: (BubbleProto.Cell[]|null);
            offset?: (boolean|null);
        }

        class RowData implements IRowData {
            constructor(p?: BubbleProto.IRowData);
            public cols: BubbleProto.Cell[];
            public offset: boolean;
            public static create(properties?: BubbleProto.IRowData): BubbleProto.RowData;
            public static encode(m: BubbleProto.RowData, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BubbleProto.RowData;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ICell {
            x?: (number|null);
            y?: (number|null);
            val?: (number|null);
        }

        class Cell implements ICell {
            constructor(p?: BubbleProto.ICell);
            public x: number;
            public y: number;
            public val: number;
            public static create(properties?: BubbleProto.ICell): BubbleProto.Cell;
            public static encode(m: BubbleProto.Cell, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BubbleProto.Cell;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IScoreData {
            totalScore?: (number|null);
            baseScore?: (number|null);
            timeBonus?: (number|null);
            clearScore?: (number|null);
        }

        class ScoreData implements IScoreData {
            constructor(p?: BubbleProto.IScoreData);
            public totalScore: number;
            public baseScore: number;
            public timeBonus: number;
            public clearScore: number;
            public static create(properties?: BubbleProto.IScoreData): BubbleProto.ScoreData;
            public static encode(m: BubbleProto.ScoreData, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BubbleProto.ScoreData;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IBubbleStartGameNotify {
            resultCode?: (number|null);
            game?: (BubbleProto.BubbleGame|null);
        }

        class BubbleStartGameNotify implements IBubbleStartGameNotify {
            constructor(p?: BubbleProto.IBubbleStartGameNotify);
            public resultCode: number;
            public game?: (BubbleProto.BubbleGame|null);
            public static create(properties?: BubbleProto.IBubbleStartGameNotify): BubbleProto.BubbleStartGameNotify;
            public static encode(m: BubbleProto.BubbleStartGameNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BubbleProto.BubbleStartGameNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IBubbleReConnReq {
        }

        class BubbleReConnReq implements IBubbleReConnReq {
            constructor(p?: BubbleProto.IBubbleReConnReq);
            public static create(properties?: BubbleProto.IBubbleReConnReq): BubbleProto.BubbleReConnReq;
            public static encode(m: BubbleProto.BubbleReConnReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BubbleProto.BubbleReConnReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IBubbleReConnRsp {
            resultCode?: (number|null);
            game?: (BubbleProto.BubbleGame|null);
        }

        class BubbleReConnRsp implements IBubbleReConnRsp {
            constructor(p?: BubbleProto.IBubbleReConnRsp);
            public resultCode: number;
            public game?: (BubbleProto.BubbleGame|null);
            public static create(properties?: BubbleProto.IBubbleReConnRsp): BubbleProto.BubbleReConnRsp;
            public static encode(m: BubbleProto.BubbleReConnRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BubbleProto.BubbleReConnRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IActionReportReq {
            action?: (BubbleProto.Action[]|null);
        }

        class ActionReportReq implements IActionReportReq {
            constructor(p?: BubbleProto.IActionReportReq);
            public action: BubbleProto.Action[];
            public static create(properties?: BubbleProto.IActionReportReq): BubbleProto.ActionReportReq;
            public static encode(m: BubbleProto.ActionReportReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BubbleProto.ActionReportReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IActionReportRsp {
            resultCode?: (number|null);
            seq?: (number|null);
        }

        class ActionReportRsp implements IActionReportRsp {
            constructor(p?: BubbleProto.IActionReportRsp);
            public resultCode: number;
            public seq: number;
            public static create(properties?: BubbleProto.IActionReportRsp): BubbleProto.ActionReportRsp;
            public static encode(m: BubbleProto.ActionReportRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BubbleProto.ActionReportRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IAction {
            seq?: (number|null);
            leftMS?: (number|null);
            launch?: (BubbleProto.Launch|null);
            over?: (BubbleProto.GameOver|null);
            prop?: (BubbleProto.BubbleProp|null);
        }

        class Action implements IAction {
            constructor(p?: BubbleProto.IAction);
            public seq: number;
            public leftMS: number;
            public launch?: (BubbleProto.Launch|null);
            public over?: (BubbleProto.GameOver|null);
            public prop?: (BubbleProto.BubbleProp|null);
            public static create(properties?: BubbleProto.IAction): BubbleProto.Action;
            public static encode(m: BubbleProto.Action, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BubbleProto.Action;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ILaunch {
            angle?: (number|null);
            cell?: (BubbleProto.Cell|null);
            bubbleEnum?: (BubbleProto.BubbleEnum|null);
        }

        class Launch implements ILaunch {
            constructor(p?: BubbleProto.ILaunch);
            public angle: number;
            public cell?: (BubbleProto.Cell|null);
            public bubbleEnum: BubbleProto.BubbleEnum;
            public static create(properties?: BubbleProto.ILaunch): BubbleProto.Launch;
            public static encode(m: BubbleProto.Launch, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BubbleProto.Launch;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IBubbleProp {
            bubbleEnum?: (BubbleProto.BubbleEnum|null);
            Energy?: (number|null);
            useBubble?: (number|null);
        }

        class BubbleProp implements IBubbleProp {
            constructor(p?: BubbleProto.IBubbleProp);
            public bubbleEnum: BubbleProto.BubbleEnum;
            public Energy: number;
            public useBubble: number;
            public static create(properties?: BubbleProto.IBubbleProp): BubbleProto.BubbleProp;
            public static encode(m: BubbleProto.BubbleProp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BubbleProto.BubbleProp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameOver {
            scoreData?: (BubbleProto.ScoreData|null);
        }

        class GameOver implements IGameOver {
            constructor(p?: BubbleProto.IGameOver);
            public scoreData?: (BubbleProto.ScoreData|null);
            public static create(properties?: BubbleProto.IGameOver): BubbleProto.GameOver;
            public static encode(m: BubbleProto.GameOver, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BubbleProto.GameOver;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        enum Status {
            Invalid = 0,
            Success = 1,
            AllClear = 2,
            Overflow = 3,
            OutOfTime = 4
        }

        interface IGameEndNotify {
            status?: (BubbleProto.Status|null);
            scoreData?: (BubbleProto.ScoreData|null);
            leftMs?: (Long|null);
        }

        class GameEndNotify implements IGameEndNotify {
            constructor(p?: BubbleProto.IGameEndNotify);
            public status: BubbleProto.Status;
            public scoreData?: (BubbleProto.ScoreData|null);
            public leftMs: Long;
            public static create(properties?: BubbleProto.IGameEndNotify): BubbleProto.GameEndNotify;
            public static encode(m: BubbleProto.GameEndNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BubbleProto.GameEndNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IReceiveNewbieRewardReq {
        }

        class ReceiveNewbieRewardReq implements IReceiveNewbieRewardReq {
            constructor(p?: BubbleProto.IReceiveNewbieRewardReq);
            public static create(properties?: BubbleProto.IReceiveNewbieRewardReq): BubbleProto.ReceiveNewbieRewardReq;
            public static encode(m: BubbleProto.ReceiveNewbieRewardReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BubbleProto.ReceiveNewbieRewardReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IReceiveNewbieRewardRsp {
            resultCode?: (number|null);
        }

        class ReceiveNewbieRewardRsp implements IReceiveNewbieRewardRsp {
            constructor(p?: BubbleProto.IReceiveNewbieRewardRsp);
            public resultCode: number;
            public static create(properties?: BubbleProto.IReceiveNewbieRewardRsp): BubbleProto.ReceiveNewbieRewardRsp;
            public static encode(m: BubbleProto.ReceiveNewbieRewardRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BubbleProto.ReceiveNewbieRewardRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }

    namespace XGameRetCode {

        enum RetCodeEnum {
            SUCCESS = 0,
            SYS_ERROR = 1,
            SYS_BUSY = 2,
            INNER_ERROR = 3,
            PACKAGE_ERROR = 4,
            ARG_NULL_ERROR = 5,
            ARG_INVALIDATE_ERROR = 6,
            LOGIN_MULTIPLE_LOGIN = 301,
            LOGIN_PARAM_ERROR = 302,
            LOGIN_SERVER_ERROR = 303,
            LOGIN_BLACK_LIST = 304,
            LOGIN_PASSWD_ERROR = 305,
            LOGIN_TOKEN_INCONSISTENT = 306,
            LOGIN_TOKEN_EXPIRED = 307,
            LOGIN_GETHTTP_ERROR = 308,
            LOGIN_GETHTTP_DATA_ERROR = 309,
            LOGIN_GOOGLE_APPID_ERROR = 310,
            LOGIN_GOOGLE_OPENID_ERROR = 311,
            LOGIN_FACEBOOK_AUTH_ERROR = 312,
            LOGIN_FACEBOOK_DATA_ERROR = 313,
            LOGIN_EMAIL_AUTH_CODE_ERROR = 314,
            LOGIN_EMAIL_AUTH_CODE_TIMEROUT = 315,
            LOGIN_EMAIL_EMAIL_FROMAT_EROOR = 316,
            LOGIN_EMAIL_PASSWD_ERROR_LIMIT = 317,
            LOGIN_EMAIL_ACCOUNT_NOT_EXSIT = 318,
            LOGIN_EMAIL_ACCOUNT_EXSITED = 319,
            LOGIN_SMS_DOMAIN_CODE_ERRPR = 320,
            LOGIN_SMS_PHONE_NUMBER_ERROR = 321,
            LOGIN_SMS_LOGIN_SOURCE_ERROR = 322,
            LOG_SMS_VERIFY_CODE_ERROR = 323,
            LOG_SMS_RESTRICTED_ERROR = 324,
            USER_INFO_PHONE_ALREADY_BIND = 507,
            USER_INFO_PHONE_AUTH_CODE_ERROR = 508,
            USER_INFO_PHONE_AUTH_CODE_LIMIT = 509,
            USER_INFO_PHONE_AUTH_CODE_OVERDUE = 512,
            USER_INFO_PHONE_ALREADY_USED = 513,
            USER_INFO_PHONE_FORMAT_ERROR = 516,
            USER_INFO_PHONE_PASSWD_ERROR_LIMIT = 517,
            USER_INFO_PHONE_ACCOUNT_NOT_EXSIT = 518,
            USER_INFO_PHOME_SERVICE_UNAVAILABLE = 519,
            USER_INFO_NICKNAME_NO_CHANGE = 502,
            USER_INFO_NICKNAME_HAVE_SENSITIVE_WORDS = 503,
            USER_INFO_NO_NICKNAME = 504,
            USER_INFO_NICKNAME_SPECIAL_CHARACTER = 505,
            USER_INFO_NO_CHANGE = 506,
            USER_INFO_EXCHANGE_PWD_INVALID = 510,
            USER_INFO_EXCHANGE_PWD_ERROR = 511,
            USER_INFO_FACEBOOK_ALREADY_USED = 514,
            USER_INFO_ACCOUNT_ALREADY_BIND = 515,
            USER_PHONE_DEVICE_CHANGE = 530,
            ROOM_USER_NO_LOGIN = 1000,
            ROOM_GOLD_NOT_ENOUGH = 1001,
            ROOM_DIAMOND_NOT_ENOUGH = 1002,
            ROOM_CHAT_CD = 1003,
            ROOM_ADD_GOLD_SUCCESS = 1004,
            ROOM_JOIN_QUEUQ_ERR = 1005,
            ROOM_RECOME_INVALID = 1006,
            ROOM_ALIGNMENT_GOLD_SUCCESS = 1007,
            ROOM_BUY_GOLD_SUCCESS = 1008,
            GAME_NO_SERVICE_CONFIG = 1101,
            GAME_USER_NOT_EXIST = 1102,
            GAME_CHANGE_TABLE_NOT_SIT = 1103,
            GAME_WAIT_NEXT_GAME = 1104,
            GAME_TWO_NOT_OPTION = 1105,
            GAME_WAIT_TIMEOUT = 1106,
            GAME_WATCH_NOT_EXIST = 1107,
            GAME_PAUSE_TIMEOUT = 1108,
            GAME_GOLD_REACHED_MAX_LIMIT = 1300,
            GAME_GOLD_LACK = 1301,
            GAME_GOLD_BUY_INSUFFICIENT = 1302,
            GAME_GOLD_BUY_OUT_OF_RANGE = 1303,
            GAME_GOLD_BUY_NOT_LOWER = 1304,
            GAME_GOLD_BUY_NOT_LESS_CUR = 1305,
            GAME_GOLD_SIT_UNAVAILABLE = 1306,
            GAME_ROOM_NOT_EXIST = 1307,
            GAME_ROOM_NOT_AVAILTABLE_TABLE = 1308,
            GAME_ROOM_PARAM_ERR = 1309,
            GAME_ROOM_COUNT_LIMIT = 1310,
            GAME_ROOM_FULL = 1311,
            GAME_ROOM_MATCH_ERR = 1312,
            GAME_ROOM_BET_ERR = 1313,
            GAME_ROOM_EXIST_ROOM = 1314,
            GAME_ROOM_NOT_SEAT = 1315,
            GAME_ROOM_EXIST_SEAT = 1316,
            GAME_ROOM_SEAT_UNAVAILABLE = 1317,
            GAME_ROOM_EXCEED_BET_LIMIT = 1318,
            GAME_ROOM_PRE_NOT_DOBET = 1319,
            GAME_ROOM_INTERVAL_LACK = 1320,
            SERVER_UPDATE_NOTIFY = 1601,
            CONNECTTION_IDLE_TOO_LONG = 1602
        }
    }

    namespace BombCommonCode {

        enum EnumReturnCode {
            SUCCESS = 0,
            SYS_ERR = 1,
            SYS_BUSY = 2,
            PACKAGE_ERR = 3,
            PARAM_ERR = 4,
            LOGIN_EMAIL_AUTH_CODE_ERROR = 314,
            LOGIN_EMAIL_AUTH_CODE_TIMEROUT = 315,
            LOGIN_EMAIL_EMAIL_FROMAT_EROOR = 316,
            LOGIN_EMAIL_PASSWD_ERROR_LIMIT = 317,
            LOGIN_EMAIL_ACCOUNT_NOT_EXSIT = 318,
            LOGIN_EMAIL_ACCOUNT_EXSITED = 319,
            LOGIN_EMAIL_ACCOUNT_DELETE = 326,
            LOGIN_SMS_DOMAIN_CODE_ERROR = 320,
            LOGIN_SMS_PHONE_NUMBER_ERROR = 321,
            LOGIN_SMS_LOGIN_SOURCE_ERROR = 322,
            LOGIN_SMS_VERIFY_CODE_ERROR = 323,
            LOGIN_SMS_RESTRICTED_ERROR = 324,
            LOGIN_SMS_VERIFY_CODE_EXPIRE = 325,
            LOGIN_SMS_ACCOUNT_DELETE = 327,
            LOGIN_SMS_ACCOUNT_LIMIT = 328,
            USER_INFO_PHONE_ALREADY_BIND = 507,
            USER_INFO_PHONE_AUTH_CODE_ERROR = 508,
            USER_INFO_PHONE_AUTH_CODE_LIMIT = 509,
            USER_INFO_PHONE_AUTH_CODE_OVERDUE = 512,
            USER_INFO_PHONE_ALREADY_USED = 513,
            USER_INFO_PHONE_FORMAT_ERROR = 516,
            USER_INFO_PHONE_PASSWD_ERROR_LIMIT = 517,
            USER_INFO_PHONE_ACCOUNT_NOT_EXSIT = 518,
            USER_INFO_PHOME_SERVICE_UNAVAILABLE = 519,
            USER_INFO_NICKNAME_EXIST = 501,
            USER_INFO_NICKNAME_NO_CHANGE = 502,
            USER_INFO_NICKNAME_HAVE_SENSITIVE_WORDS = 503,
            USER_INFO_NO_NICKNAME = 504,
            USER_INFO_NICKNAME_SPECIAL_CHARACTER = 505,
            USER_INFO_NO_CHANGE = 506,
            USER_INFO_EXCHANGE_PWD_INVALID = 510,
            USER_INFO_EXCHANGE_PWD_ERROR = 511,
            USER_INFO_FACEBOOK_ALREADY_USED = 514,
            USER_INFO_ACCOUNT_ALREADY_BIND = 515,
            USER_PHONE_DEVICE_CHANGE = 530,
            COMMON_RELOGIN_NON_BEGIN = 800,
            COMMON_RELOGIN_NON_END = 899,
            COMMON_RELOGIN_TIPS_BEGIN = 900,
            LOGIN_USER_LOGIN_TOKEN_DISABLE = 901,
            LOGIN_USER_LOGIN_SYS_BUSY = 902,
            LOGIN_USER_ACCOUNT_LIMIT = 903,
            COMMON_RELOGIN_TIPS_END = 999,
            LOGIN_USER_REGISTER_USERNAME_ALREADY = 1001,
            LOGIN_USER_REGISTER_USERNAME_RULE_ERR = 1002,
            LOGIN_USER_REGISTER_PASSWORD_RULE_ERR = 1003,
            LOGIN_USER_REGISTER_LIMIT_ERR = 1004,
            LOGIN_USER_LOGIN_USER_NO_EXIT = 1050,
            LOGIN_USER_LOGIN_PASSWORD_NO_MATCH = 1051,
            LOGIN_USER_ACCOUNT_BIND_ERR = 1060,
            LOGIN_USER_VERIFY_CODE_ERR = 1061,
            LOGIN_USER_BIND_PHONE_EXIT = 1062,
            LOGIN_USER_DEVICE_BIND_PHONE_EXIT = 1063,
            LOGIN_USER_BIND_EMAIL_EXIT = 1064,
            LOGIN_SEND_FREQUENTLY_ERR = 1065,
            LOGIN_VERIFY_CODE_DISABLE = 1066,
            LOGIN_PHONE_NUMBER_NOT_ALLOW_ERR = 1067,
            LOGIN_PHONE_NUMBER_BIND_DEVICE_ERROR = 1068,
            LOGIN_PHONE_NUMBER_ACCOUNT_NOT_EXIST = 1069,
            MATCH_USER_IN_QUEUE_ALREADY = 2001,
            MATCH_USER_NOT_IN_QUEUE = 2002,
            MATCH_USER_NO_MONEY = 2003,
            MATCH_USER_DO_NOT_OPEN = 2004,
            MATCH_USER_ACTIVITY_ERROR = 2005,
            MATCH_USER_LEVEL_LESS = 2006,
            MATCH_USER_MAX_TIMES_LIMIT = 2007,
            MATCh_USER_IN_ROOM = 2008,
            ROOM_GAME_NOT_FIND = 3003,
            ROOM_NOT_EXIST = 3004,
            GAME_ACTION_CHECK_ERR = 4001,
            SHOP_GOODS_NOT_EXIST_ERR = 5001,
            SHOP_IAP_RECEIPT_CHECK_ERR = 5002,
            SHOP_IAP_RECEIPT_CHECK_REQ_ERR = 5003,
            SHOP_IAP_RECEIPT_RESP_CHECK_ERR = 5004,
            SHOP_NEED_FIX_ORDER_ERR = 5005,
            DRAW_MONEY_MON_LIMIT_ERR = 5201,
            DRAW_MONEY_DAY_CREATE_LIMIT_ERR = 5202,
            DRAW_MONEY_PAY_CNT_LIMIT_ERR = 5203,
            ACTIVITY_NO_EXIST = 5301,
            INVITE_CODE_INVALID = 5302,
            INVITE_CODE_CANT_BIND_SELF = 5303,
            INVITE_CODE_BOUND = 5304,
            CASH_RAIN_RED_PACK_NOT_EXIST = 5320,
            GAME_RECORD_NOT_FOUND = 5401,
            RECEIVED_GUIDE_REWARD = 100001
        }
    }

    namespace BombCommonHttp {

        interface IUserUID {
            lUid?: (Long|null);
            sToken?: (string|null);
        }

        class UserUID implements IUserUID {
            constructor(p?: BombCommonHttp.IUserUID);
            public lUid: Long;
            public sToken: string;
            public static create(properties?: BombCommonHttp.IUserUID): BombCommonHttp.UserUID;
            public static encode(m: BombCommonHttp.UserUID, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BombCommonHttp.UserUID;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        enum EumCommHttpMsgID {
            E_MSGID_DEFAULT = 0,
            E_MSGID_USER_REGISTER_REQ = 1,
            E_MSGID_USER_REGISTER_RSP = 2,
            E_MSGID_USER_LOGIN_REQ = 3,
            E_MSGID_USER_LOGIN_RSP = 4,
            E_MSGID_USER_LOGOUT_REQ = 5,
            E_MSGID_USER_LOGOUT_RSP = 6,
            E_MSGID_PLATFORM_LOGIN_REQ = 7,
            E_MSGID_PLATFORM_LOGIN_RSP = 8,
            E_MSGID_SMS_SEND_REQ = 9,
            E_MSGID_SMS_SEND_RSP = 10,
            E_MSGID_SMS_VERIFY_REQ = 11,
            E_MSGID_SMS_VERIFY_RSP = 12,
            E_MSGID_PLATFORM_RECOVERY_REQ = 13,
            E_MSGID_PLATFORM_RECOVERY_RSP = 14,
            E_MSGID_BURIAL_POINT_DATA_SUBMIT_REQ = 15,
            E_MSGID_BURIAL_POINT_DATA_SUBMIT_RSP = 16,
            E_MSGID_USER_UPDATE_CUPS_REQ = 17,
            E_MSGID_USER_UPDATE_CUPS_RSP = 18
        }

        interface IMessageHttpPackage {
            iVersion?: (number|null);
            iSequence?: (number|null);
            dUserUID?: (BombCommonHttp.UserUID|null);
            iMsgID?: (number|null);
            iResult?: (number|null);
            vData?: (Uint8Array|null);
        }

        class MessageHttpPackage implements IMessageHttpPackage {
            constructor(p?: BombCommonHttp.IMessageHttpPackage);
            public iVersion: number;
            public iSequence: number;
            public dUserUID?: (BombCommonHttp.UserUID|null);
            public iMsgID: number;
            public iResult: number;
            public vData: Uint8Array;
            public static create(properties?: BombCommonHttp.IMessageHttpPackage): BombCommonHttp.MessageHttpPackage;
            public static encode(m: BombCommonHttp.MessageHttpPackage, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BombCommonHttp.MessageHttpPackage;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserRegisterReq {
            sUserName?: (string|null);
            sPassword?: (string|null);
        }

        class UserRegisterReq implements IUserRegisterReq {
            constructor(p?: BombCommonHttp.IUserRegisterReq);
            public sUserName: string;
            public sPassword: string;
            public static create(properties?: BombCommonHttp.IUserRegisterReq): BombCommonHttp.UserRegisterReq;
            public static encode(m: BombCommonHttp.UserRegisterReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BombCommonHttp.UserRegisterReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserRegisterResp {
            iResult?: (number|null);
        }

        class UserRegisterResp implements IUserRegisterResp {
            constructor(p?: BombCommonHttp.IUserRegisterResp);
            public iResult: number;
            public static create(properties?: BombCommonHttp.IUserRegisterResp): BombCommonHttp.UserRegisterResp;
            public static encode(m: BombCommonHttp.UserRegisterResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BombCommonHttp.UserRegisterResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        enum LoginType {
            Guest = 0,
            Account = 1,
            Phone = 2,
            Default = 3
        }

        interface IPlatformLoginReq {
            sUserName?: (string|null);
            sPassword?: (string|null);
            sDeviceCode?: (string|null);
            guest?: (boolean|null);
            clean?: (boolean|null);
            loginType?: (BombCommonHttp.LoginType|null);
            sLoginSource?: (string|null);
            sPhoneAreaCode?: (string|null);
            sPhoneNumber?: (string|null);
            sVerifyCode?: (string|null);
            sBirthday?: (string|null);
            sClientPlatform?: (string|null);
            sAFID?: (string|null);
        }

        class PlatformLoginReq implements IPlatformLoginReq {
            constructor(p?: BombCommonHttp.IPlatformLoginReq);
            public sUserName: string;
            public sPassword: string;
            public sDeviceCode: string;
            public guest: boolean;
            public clean: boolean;
            public loginType: BombCommonHttp.LoginType;
            public sLoginSource: string;
            public sPhoneAreaCode: string;
            public sPhoneNumber: string;
            public sVerifyCode: string;
            public sBirthday: string;
            public sClientPlatform: string;
            public sAFID: string;
            public static create(properties?: BombCommonHttp.IPlatformLoginReq): BombCommonHttp.PlatformLoginReq;
            public static encode(m: BombCommonHttp.PlatformLoginReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BombCommonHttp.PlatformLoginReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPlatformLoginResp {
            iResult?: (number|null);
            iPlatformId?: (Long|null);
            sToken?: (string|null);
            iSendAF?: (number|null);
        }

        class PlatformLoginResp implements IPlatformLoginResp {
            constructor(p?: BombCommonHttp.IPlatformLoginResp);
            public iResult: number;
            public iPlatformId: Long;
            public sToken: string;
            public iSendAF: number;
            public static create(properties?: BombCommonHttp.IPlatformLoginResp): BombCommonHttp.PlatformLoginResp;
            public static encode(m: BombCommonHttp.PlatformLoginResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BombCommonHttp.PlatformLoginResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserLoginReq {
            sUserName?: (string|null);
            token?: (string|null);
            ssid?: (string|null);
            guest?: (boolean|null);
            api?: (string|null);
            company?: (string|null);
            productName?: (string|null);
            productVersion?: (string|null);
            locale?: (string|null);
            iPlatformId?: (Long|null);
        }

        class UserLoginReq implements IUserLoginReq {
            constructor(p?: BombCommonHttp.IUserLoginReq);
            public sUserName: string;
            public token: string;
            public ssid: string;
            public guest: boolean;
            public api: string;
            public company: string;
            public productName: string;
            public productVersion: string;
            public locale: string;
            public iPlatformId: Long;
            public static create(properties?: BombCommonHttp.IUserLoginReq): BombCommonHttp.UserLoginReq;
            public static encode(m: BombCommonHttp.UserLoginReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BombCommonHttp.UserLoginReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserLoginResp {
            iResult?: (number|null);
            sAddress?: (string|null);
            iPlatformId?: (Long|null);
        }

        class UserLoginResp implements IUserLoginResp {
            constructor(p?: BombCommonHttp.IUserLoginResp);
            public iResult: number;
            public sAddress: string;
            public iPlatformId: Long;
            public static create(properties?: BombCommonHttp.IUserLoginResp): BombCommonHttp.UserLoginResp;
            public static encode(m: BombCommonHttp.UserLoginResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BombCommonHttp.UserLoginResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ISmsSendReq {
            domainCode?: (string|null);
            phoneNumber?: (string|null);
            loginSource?: (string|null);
            deviceCode?: (string|null);
        }

        class SmsSendReq implements ISmsSendReq {
            constructor(p?: BombCommonHttp.ISmsSendReq);
            public domainCode: string;
            public phoneNumber: string;
            public loginSource: string;
            public deviceCode: string;
            public static create(properties?: BombCommonHttp.ISmsSendReq): BombCommonHttp.SmsSendReq;
            public static encode(m: BombCommonHttp.SmsSendReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BombCommonHttp.SmsSendReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ISmsSendRsp {
            success?: (boolean|null);
            statusCode?: (number|null);
        }

        class SmsSendRsp implements ISmsSendRsp {
            constructor(p?: BombCommonHttp.ISmsSendRsp);
            public success: boolean;
            public statusCode: number;
            public static create(properties?: BombCommonHttp.ISmsSendRsp): BombCommonHttp.SmsSendRsp;
            public static encode(m: BombCommonHttp.SmsSendRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BombCommonHttp.SmsSendRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ISmsVerifyReq {
            domainCode?: (string|null);
            phoneNumber?: (string|null);
            loginSource?: (string|null);
            code?: (string|null);
        }

        class SmsVerifyReq implements ISmsVerifyReq {
            constructor(p?: BombCommonHttp.ISmsVerifyReq);
            public domainCode: string;
            public phoneNumber: string;
            public loginSource: string;
            public code: string;
            public static create(properties?: BombCommonHttp.ISmsVerifyReq): BombCommonHttp.SmsVerifyReq;
            public static encode(m: BombCommonHttp.SmsVerifyReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BombCommonHttp.SmsVerifyReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ISmsVerifyRsp {
            success?: (boolean|null);
            statusCode?: (number|null);
            times?: (number|null);
        }

        class SmsVerifyRsp implements ISmsVerifyRsp {
            constructor(p?: BombCommonHttp.ISmsVerifyRsp);
            public success: boolean;
            public statusCode: number;
            public times: number;
            public static create(properties?: BombCommonHttp.ISmsVerifyRsp): BombCommonHttp.SmsVerifyRsp;
            public static encode(m: BombCommonHttp.SmsVerifyRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BombCommonHttp.SmsVerifyRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPlatformRecoveryReq {
            domainCode?: (string|null);
            phoneNumber?: (string|null);
            loginSource?: (string|null);
            code?: (string|null);
        }

        class PlatformRecoveryReq implements IPlatformRecoveryReq {
            constructor(p?: BombCommonHttp.IPlatformRecoveryReq);
            public domainCode: string;
            public phoneNumber: string;
            public loginSource: string;
            public code: string;
            public static create(properties?: BombCommonHttp.IPlatformRecoveryReq): BombCommonHttp.PlatformRecoveryReq;
            public static encode(m: BombCommonHttp.PlatformRecoveryReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BombCommonHttp.PlatformRecoveryReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPlatformRecoveryRsp {
            iResult?: (number|null);
        }

        class PlatformRecoveryRsp implements IPlatformRecoveryRsp {
            constructor(p?: BombCommonHttp.IPlatformRecoveryRsp);
            public iResult: number;
            public static create(properties?: BombCommonHttp.IPlatformRecoveryRsp): BombCommonHttp.PlatformRecoveryRsp;
            public static encode(m: BombCommonHttp.PlatformRecoveryRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BombCommonHttp.PlatformRecoveryRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        enum BurialDataType {
            E_BURIAL_POINT_TYPE_ACTIVITY_ENTRANCE = 0,
            E_BURIAL_POINT_TYPE_ACTIVITY_DETAIL_CHECK = 1,
            E_BURIAL_POINT_TYPE_ACTIVITY_PARTICIPATION_AND_BEHAVIOR = 3,
            E_BURIAL_POINT_TYPE_ACTIVITY_ACCOMPLISHMENT = 4,
            E_BURIAL_POINT_TYPE_ACTIVITY_AWARD_COLLECTION = 5,
            E_BURIAL_POINT_TYPE_ACTIVITY_USER_SIGN_BEHAVIOR = 6,
            E_BURIAL_POINT_TYPE_ACTIVITY_USER_PAY_BEHAVIOR = 7,
            E_BURIAL_POINT_TYPE_ACTIVITY_POP_WINDOW_DISPLAY = 8,
            E_BURIAL_POINT_TYPE_ACTIVITY_TRIGGER_TIME = 9,
            E_BURIAL_POINT_TYPE_ACTIVITY_CONSUME_BEHAVIOR = 10,
            E_BURIAL_POINT_TYPE_ACTIVITY_REWARD_SETTLEMENT = 11,
            E_BURIAL_POINT_TYPE_ACTIVITY_REFRESH = 12,
            E_BURIAL_POINT_TYPE_ACTIVITY_ACCOMPLISH = 13,
            E_BURIAL_POINT_TYPE_SOLITAIRE_APP_LAUNCH_TIMES = 10101,
            E_BURIAL_POINT_TYPE_SOLITAIRE_SUCCESS_GAME_ENTRY = 10102,
            E_BURIAL_POINT_TYPE_SOLITAIRE_USER_SOURCE = 10103,
            E_BURIAL_POINT_TYPE_SOLITAIRE_REGISTER_ACCOUNT = 10201,
            E_BURIAL_POINT_TYPE_SOLITAIRE_SUCCESSFUL_REGISTER_ACCOUNT = 10202,
            E_BURIAL_POINT_TYPE_SOLITAIRE_FAIL_REGISTER_ACCOUNT = 10203
        }

        interface IBurialPointDataSubmitReq {
            dataType?: (BombCommonHttp.BurialDataType|null);
            data?: (string|null);
        }

        class BurialPointDataSubmitReq implements IBurialPointDataSubmitReq {
            constructor(p?: BombCommonHttp.IBurialPointDataSubmitReq);
            public dataType: BombCommonHttp.BurialDataType;
            public data: string;
            public static create(properties?: BombCommonHttp.IBurialPointDataSubmitReq): BombCommonHttp.BurialPointDataSubmitReq;
            public static encode(m: BombCommonHttp.BurialPointDataSubmitReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BombCommonHttp.BurialPointDataSubmitReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IBurialPointDataSubmitRsp {
            success?: (boolean|null);
        }

        class BurialPointDataSubmitRsp implements IBurialPointDataSubmitRsp {
            constructor(p?: BombCommonHttp.IBurialPointDataSubmitRsp);
            public success: boolean;
            public static create(properties?: BombCommonHttp.IBurialPointDataSubmitRsp): BombCommonHttp.BurialPointDataSubmitRsp;
            public static encode(m: BombCommonHttp.BurialPointDataSubmitRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BombCommonHttp.BurialPointDataSubmitRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserUpdateCupsReq {
            uid?: (Long|null);
            pid?: (Long|null);
            addCash?: (Long|null);
        }

        class UserUpdateCupsReq implements IUserUpdateCupsReq {
            constructor(p?: BombCommonHttp.IUserUpdateCupsReq);
            public uid: Long;
            public pid: Long;
            public addCash: Long;
            public static create(properties?: BombCommonHttp.IUserUpdateCupsReq): BombCommonHttp.UserUpdateCupsReq;
            public static encode(m: BombCommonHttp.UserUpdateCupsReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BombCommonHttp.UserUpdateCupsReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserUpdateCupsRsp {
            Success?: (boolean|null);
        }

        class UserUpdateCupsRsp implements IUserUpdateCupsRsp {
            constructor(p?: BombCommonHttp.IUserUpdateCupsRsp);
            public Success: boolean;
            public static create(properties?: BombCommonHttp.IUserUpdateCupsRsp): BombCommonHttp.UserUpdateCupsRsp;
            public static encode(m: BombCommonHttp.UserUpdateCupsRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): BombCommonHttp.UserUpdateCupsRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }

    namespace XGameProto {

        enum ActionName {
            ACTION_NAME_DEFAULT = 0,
            LOGIN_LOGOUT = 153,
            LOGIN_DEVICE = 154,
            USER_LOGIN = 155,
            USER_REGISTER = 156,
            LOGIN_PHONE_ACCOUNT = 157,
            LOGIN_PHONE_ACCOUNT_REGISTER = 158,
            LOGIN_PHONE_ACCOUNT_RESET_PASSWD = 159,
            LOGIN_GOOGLE = 161,
            LOGIN_FACEBOOK = 162,
            LOGIN_QUICK = 163,
            USER_ROUNTER = 164,
            LOGIN_APPLE = 165,
            LOGIN_EMAIL = 166,
            USER_GET_USER_DETAIL = 200,
            USER_GET_USER_BASIC = 201,
            USER_GET_USERACCOUNT = 202,
            USER_UPDATE_USER_REAL_NAME = 203,
            USER_TRANSFER_ACCOUNT = 206,
            USER_LIST_USER_BASIC = 207,
            USER_UPDATE_USER_SIGNATURE = 208,
            USER_SEND_PHONE_CODE = 209,
            USER_BIND_PHONE_ACCOUNT = 212,
            USER_UPDATE_USER_INFO = 213,
            USER_FRIEND_BASIC = 215,
            USER_GET_USER_REWARD = 217,
            USER_MODIFY_USER_SETTING = 218,
            USER_GET_SEASON_INFO = 219,
            USER_LIST_USER_ACCOUNT = 220,
            USER_MODIFY_EXCHANGE_PWD = 221,
            USER_BIND_THIRDPARTY_ACCOUNT = 222,
            USER_ID_BY_SHOW = 223,
            USER_VISITOR_BIND_ACCOUNT = 224,
            USER_STATE_GET_GAME_STATE = 400,
            USER_STATE_BATCH_ONLINE_STATE = 401,
            USER_STATE_COUNT_STATISTICS = 402,
            USER_STATE_BATCH_GAME_STATE = 403,
            USER_STATE_ZERO_ONLINE_UPDATE = 404,
            USER_ACTION_REPORT_STATISTICS = 450,
            SYS_MSG_RECEIVE = 1010,
            SYS_MSG_PUSH_ONLIEN = 1011,
            SYS_FRAME_GET = 1012,
            PUSH_MATCH_BEGIN = 1600,
            PUSH_COIN_CHANGE = 1602,
            PUSH_CHAT_UPDATE = 1603,
            PUSH_TICKET_STATUS = 1604,
            PUSH_INVITE_PLAYER = 1605,
            PUSH_ADD_FRIEND = 1606,
            PUSH_GAME_UPDATE = 1607,
            PUSH_TASK_FINISH = 1608,
            PUSH_GIVE_PROPS = 1609,
            PUSH_RECHARGE_REWARDS = 1610,
            PUSH_NEW_MAIL_NOTIFY = 1611,
            PUSH_SERVER_UPDATE_NOTIFY = 1612,
            PUSH_SERVER_CHANGE_NOTIFY = 1613,
            PUSH_AI_REPORT_DATA = 1614,
            PUSH_PROPS_CHANGE_NOTIFY = 1615,
            PUSH_REWARD_NOTIFY = 1616,
            PUSH_MSG_TYPE_GET_BOX_NOTIFY = 1617,
            PUSH_MULTIPLE_LOGIN = 2000,
            PUSH_RESULT_CODE = 9999
        }

        interface ICommonReqHead {
            actionName?: (XGameProto.ActionName|null);
            reqBodyBytes?: (Uint8Array|null);
        }

        class CommonReqHead implements ICommonReqHead {
            constructor(p?: XGameProto.ICommonReqHead);
            public actionName: XGameProto.ActionName;
            public reqBodyBytes: Uint8Array;
            public static create(properties?: XGameProto.ICommonReqHead): XGameProto.CommonReqHead;
            public static encode(m: XGameProto.CommonReqHead, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): XGameProto.CommonReqHead;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ICommonRespHead {
            resultCode?: (number|null);
            actionName?: (XGameProto.ActionName|null);
            respBodyBytes?: (Uint8Array|null);
        }

        class CommonRespHead implements ICommonRespHead {
            constructor(p?: XGameProto.ICommonRespHead);
            public resultCode: number;
            public actionName: XGameProto.ActionName;
            public respBodyBytes: Uint8Array;
            public static create(properties?: XGameProto.ICommonRespHead): XGameProto.CommonRespHead;
            public static encode(m: XGameProto.CommonRespHead, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): XGameProto.CommonRespHead;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        enum PushMessageType {
            MESSAGE_TYPE_DEFAULT = 0,
            USER_ACCOUNT_CHANGE = 10000,
            USER_EXIT_ROOM = 10001,
            USER_EXIT_MATCH = 10002
        }
    }

    namespace GameProto {

        interface IGetUserDetailReq {
            lUid?: (Long|null);
        }

        class GetUserDetailReq implements IGetUserDetailReq {
            constructor(p?: GameProto.IGetUserDetailReq);
            public lUid: Long;
            public static create(properties?: GameProto.IGetUserDetailReq): GameProto.GetUserDetailReq;
            public static encode(m: GameProto.GetUserDetailReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserDetailReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserDetailResp {
            lUid?: (Long|null);
            sNickname?: (string|null);
            sAvater?: (string|null);
            iLevel?: (number|null);
            lCash?: (Long|null);
            lDiamon?: (Long|null);
            sInviteCode?: (string|null);
            lExp?: (Long|null);
            iGuide?: (number|null);
            sCurrency?: (string|null);
            lElo?: (Long|null);
            firstDayLogin?: (boolean|null);
            iAccountType?: (number|null);
            sPhoneAreaCode?: (string|null);
            sPhoneNumber?: (string|null);
            sEmail?: (string|null);
            sBirthday?: (string|null);
            lBonusCash?: (Long|null);
            lFreeEndTime?: (Long|null);
            iGuideTimes?: (number|null);
            iDebug?: (number|null);
            iGiveName?: (number|null);
            iGiveBind?: (number|null);
            iCashTimes?: (number|null);
            iPayTimes?: (number|null);
            iTakeCashGuide?: (number|null);
            iDrawGuide?: (number|null);
            iDrawMinAmount?: (number|null);
        }

        class GetUserDetailResp implements IGetUserDetailResp {
            constructor(p?: GameProto.IGetUserDetailResp);
            public lUid: Long;
            public sNickname: string;
            public sAvater: string;
            public iLevel: number;
            public lCash: Long;
            public lDiamon: Long;
            public sInviteCode: string;
            public lExp: Long;
            public iGuide: number;
            public sCurrency: string;
            public lElo: Long;
            public firstDayLogin: boolean;
            public iAccountType: number;
            public sPhoneAreaCode: string;
            public sPhoneNumber: string;
            public sEmail: string;
            public sBirthday: string;
            public lBonusCash: Long;
            public lFreeEndTime: Long;
            public iGuideTimes: number;
            public iDebug: number;
            public iGiveName: number;
            public iGiveBind: number;
            public iCashTimes: number;
            public iPayTimes: number;
            public iTakeCashGuide: number;
            public iDrawGuide: number;
            public iDrawMinAmount: number;
            public static create(properties?: GameProto.IGetUserDetailResp): GameProto.GetUserDetailResp;
            public static encode(m: GameProto.GetUserDetailResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserDetailResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        enum NotifyEnum {
            None = 0,
            Game = 1,
            Sign = 2,
            Pay = 3,
            DiamondActivity = 4,
            ManageOperator = 5,
            LevelUp = 6,
            OneBuyOneFreeActivity = 7,
            PiggyBankActiivty = 8,
            SevenDaysRewardsActivity = 9,
            TwoDaysPassActivity = 10,
            FreeEndTime = 11,
            InviteCodeBind = 12,
            ChangeName = 13,
            BindPhone = 14,
            CdKey = 15,
            FriendSupportTask = 16,
            FriendRewardTask = 17,
            WeeklyStageUpgrade = 18,
            WeeklySettle = 19,
            DailyLotteryDraw = 20,
            CashRainReward = 21,
            TaskActMissionReward = 22,
            TaskActMissionRewardBatch = 23,
            QuestionsReward = 24,
            FeedBackReward = 25,
            DailyADGetBonus = 26
        }

        interface IUserInfoUpdateNotify {
            lUid?: (Long|null);
            sNickname?: (string|null);
            sAvater?: (string|null);
            iLevel?: (number|null);
            lCash?: (Long|null);
            lDiamon?: (Long|null);
            sInviteCode?: (string|null);
            lExp?: (Long|null);
            iGuide?: (number|null);
            lElo?: (Long|null);
            iNotifyType?: (GameProto.NotifyEnum|null);
            lBonusCash?: (Long|null);
            lFreeEndTime?: (Long|null);
            iGiveName?: (number|null);
            iGiveBind?: (number|null);
            iCashTimes?: (number|null);
        }

        class UserInfoUpdateNotify implements IUserInfoUpdateNotify {
            constructor(p?: GameProto.IUserInfoUpdateNotify);
            public lUid: Long;
            public sNickname: string;
            public sAvater: string;
            public iLevel: number;
            public lCash: Long;
            public lDiamon: Long;
            public sInviteCode: string;
            public lExp: Long;
            public iGuide: number;
            public lElo: Long;
            public iNotifyType: GameProto.NotifyEnum;
            public lBonusCash: Long;
            public lFreeEndTime: Long;
            public iGiveName: number;
            public iGiveBind: number;
            public iCashTimes: number;
            public static create(properties?: GameProto.IUserInfoUpdateNotify): GameProto.UserInfoUpdateNotify;
            public static encode(m: GameProto.UserInfoUpdateNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserInfoUpdateNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserLevelUpInfoNotify {
            lUid?: (Long|null);
            lDiamond?: (Long|null);
            lBonus?: (Long|null);
            lExp?: (Long|null);
        }

        class UserLevelUpInfoNotify implements IUserLevelUpInfoNotify {
            constructor(p?: GameProto.IUserLevelUpInfoNotify);
            public lUid: Long;
            public lDiamond: Long;
            public lBonus: Long;
            public lExp: Long;
            public static create(properties?: GameProto.IUserLevelUpInfoNotify): GameProto.UserLevelUpInfoNotify;
            public static encode(m: GameProto.UserLevelUpInfoNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserLevelUpInfoNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserStatusReq {
            lUid?: (Long|null);
        }

        class GetUserStatusReq implements IGetUserStatusReq {
            constructor(p?: GameProto.IGetUserStatusReq);
            public lUid: Long;
            public static create(properties?: GameProto.IGetUserStatusReq): GameProto.GetUserStatusReq;
            public static encode(m: GameProto.GetUserStatusReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserStatusReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserStatusResp {
            lUid?: (Long|null);
            iStatus?: (number|null);
            iGameType?: (number|null);
            iGameID?: (number|null);
            lMatchID?: (Long|null);
            iRoomID?: (number|null);
            iTimeCount?: (number|null);
        }

        class GetUserStatusResp implements IGetUserStatusResp {
            constructor(p?: GameProto.IGetUserStatusResp);
            public lUid: Long;
            public iStatus: number;
            public iGameType: number;
            public iGameID: number;
            public lMatchID: Long;
            public iRoomID: number;
            public iTimeCount: number;
            public static create(properties?: GameProto.IGetUserStatusResp): GameProto.GetUserStatusResp;
            public static encode(m: GameProto.GetUserStatusResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserStatusResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ILocaleInfo {
            id?: (string|null);
            name?: (string|null);
        }

        class LocaleInfo implements ILocaleInfo {
            constructor(p?: GameProto.ILocaleInfo);
            public id: string;
            public name: string;
            public static create(properties?: GameProto.ILocaleInfo): GameProto.LocaleInfo;
            public static encode(m: GameProto.LocaleInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.LocaleInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetLocaleReq {
            lUid?: (Long|null);
        }

        class GetLocaleReq implements IGetLocaleReq {
            constructor(p?: GameProto.IGetLocaleReq);
            public lUid: Long;
            public static create(properties?: GameProto.IGetLocaleReq): GameProto.GetLocaleReq;
            public static encode(m: GameProto.GetLocaleReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetLocaleReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetLocaleResp {
            infos?: (GameProto.LocaleInfo[]|null);
        }

        class GetLocaleResp implements IGetLocaleResp {
            constructor(p?: GameProto.IGetLocaleResp);
            public infos: GameProto.LocaleInfo[];
            public static create(properties?: GameProto.IGetLocaleResp): GameProto.GetLocaleResp;
            public static encode(m: GameProto.GetLocaleResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetLocaleResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUpdateLocaleReq {
            sLocale?: (string|null);
        }

        class UpdateLocaleReq implements IUpdateLocaleReq {
            constructor(p?: GameProto.IUpdateLocaleReq);
            public sLocale: string;
            public static create(properties?: GameProto.IUpdateLocaleReq): GameProto.UpdateLocaleReq;
            public static encode(m: GameProto.UpdateLocaleReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UpdateLocaleReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUpdateLocaleResp {
            sLocale?: (string|null);
        }

        class UpdateLocaleResp implements IUpdateLocaleResp {
            constructor(p?: GameProto.IUpdateLocaleResp);
            public sLocale: string;
            public static create(properties?: GameProto.IUpdateLocaleResp): GameProto.UpdateLocaleResp;
            public static encode(m: GameProto.UpdateLocaleResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UpdateLocaleResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserLevelUpInfo {
            LevelId?: (number|null);
            Brl?: (number|null);
            Cny?: (number|null);
            Idr?: (number|null);
            Inr?: (number|null);
            Jpy?: (number|null);
            Mxn?: (number|null);
            Thb?: (number|null);
            Vnd?: (number|null);
            Usd?: (number|null);
        }

        class UserLevelUpInfo implements IUserLevelUpInfo {
            constructor(p?: GameProto.IUserLevelUpInfo);
            public LevelId: number;
            public Brl: number;
            public Cny: number;
            public Idr: number;
            public Inr: number;
            public Jpy: number;
            public Mxn: number;
            public Thb: number;
            public Vnd: number;
            public Usd: number;
            public static create(properties?: GameProto.IUserLevelUpInfo): GameProto.UserLevelUpInfo;
            public static encode(m: GameProto.UserLevelUpInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserLevelUpInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserLevelUpInfoReq {
            lUid?: (Long|null);
        }

        class GetUserLevelUpInfoReq implements IGetUserLevelUpInfoReq {
            constructor(p?: GameProto.IGetUserLevelUpInfoReq);
            public lUid: Long;
            public static create(properties?: GameProto.IGetUserLevelUpInfoReq): GameProto.GetUserLevelUpInfoReq;
            public static encode(m: GameProto.GetUserLevelUpInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserLevelUpInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserLevelUpInfoResp {
            infos?: (GameProto.UserLevelUpInfo[]|null);
        }

        class GetUserLevelUpInfoResp implements IGetUserLevelUpInfoResp {
            constructor(p?: GameProto.IGetUserLevelUpInfoResp);
            public infos: GameProto.UserLevelUpInfo[];
            public static create(properties?: GameProto.IGetUserLevelUpInfoResp): GameProto.GetUserLevelUpInfoResp;
            public static encode(m: GameProto.GetUserLevelUpInfoResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserLevelUpInfoResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IHallUserLevelInfo {
            Level?: (number|null);
            NeedExp?: (number|null);
            GemsNum?: (number|null);
            BonusNum?: (number|null);
            ExpNum?: (number|null);
        }

        class HallUserLevelInfo implements IHallUserLevelInfo {
            constructor(p?: GameProto.IHallUserLevelInfo);
            public Level: number;
            public NeedExp: number;
            public GemsNum: number;
            public BonusNum: number;
            public ExpNum: number;
            public static create(properties?: GameProto.IHallUserLevelInfo): GameProto.HallUserLevelInfo;
            public static encode(m: GameProto.HallUserLevelInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.HallUserLevelInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetHallUserLevelInfoReq {
            lUid?: (Long|null);
        }

        class GetHallUserLevelInfoReq implements IGetHallUserLevelInfoReq {
            constructor(p?: GameProto.IGetHallUserLevelInfoReq);
            public lUid: Long;
            public static create(properties?: GameProto.IGetHallUserLevelInfoReq): GameProto.GetHallUserLevelInfoReq;
            public static encode(m: GameProto.GetHallUserLevelInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetHallUserLevelInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetHallUserLevelInfoResp {
            infos?: (GameProto.HallUserLevelInfo[]|null);
        }

        class GetHallUserLevelInfoResp implements IGetHallUserLevelInfoResp {
            constructor(p?: GameProto.IGetHallUserLevelInfoResp);
            public infos: GameProto.HallUserLevelInfo[];
            public static create(properties?: GameProto.IGetHallUserLevelInfoResp): GameProto.GetHallUserLevelInfoResp;
            public static encode(m: GameProto.GetHallUserLevelInfoResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetHallUserLevelInfoResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IForeignInfo {
            Id?: (number|null);
            Name?: (string|null);
            ZhCn?: (string|null);
            EnUs?: (string|null);
            PtBr?: (string|null);
            HiIn?: (string|null);
            ViVn?: (string|null);
        }

        class ForeignInfo implements IForeignInfo {
            constructor(p?: GameProto.IForeignInfo);
            public Id: number;
            public Name: string;
            public ZhCn: string;
            public EnUs: string;
            public PtBr: string;
            public HiIn: string;
            public ViVn: string;
            public static create(properties?: GameProto.IForeignInfo): GameProto.ForeignInfo;
            public static encode(m: GameProto.ForeignInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.ForeignInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetForeignInfoReq {
            lUid?: (Long|null);
        }

        class GetForeignInfoReq implements IGetForeignInfoReq {
            constructor(p?: GameProto.IGetForeignInfoReq);
            public lUid: Long;
            public static create(properties?: GameProto.IGetForeignInfoReq): GameProto.GetForeignInfoReq;
            public static encode(m: GameProto.GetForeignInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetForeignInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetForeignInfoResp {
            infos?: (GameProto.ForeignInfo[]|null);
        }

        class GetForeignInfoResp implements IGetForeignInfoResp {
            constructor(p?: GameProto.IGetForeignInfoResp);
            public infos: GameProto.ForeignInfo[];
            public static create(properties?: GameProto.IGetForeignInfoResp): GameProto.GetForeignInfoResp;
            public static encode(m: GameProto.GetForeignInfoResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetForeignInfoResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IConstInfo {
            Id?: (number|null);
            Name?: (string|null);
            Value?: (string|null);
            Describe?: (string|null);
        }

        class ConstInfo implements IConstInfo {
            constructor(p?: GameProto.IConstInfo);
            public Id: number;
            public Name: string;
            public Value: string;
            public Describe: string;
            public static create(properties?: GameProto.IConstInfo): GameProto.ConstInfo;
            public static encode(m: GameProto.ConstInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.ConstInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetConstInfoReq {
            lUid?: (Long|null);
        }

        class GetConstInfoReq implements IGetConstInfoReq {
            constructor(p?: GameProto.IGetConstInfoReq);
            public lUid: Long;
            public static create(properties?: GameProto.IGetConstInfoReq): GameProto.GetConstInfoReq;
            public static encode(m: GameProto.GetConstInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetConstInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetConstInfoResp {
            infos?: (GameProto.ConstInfo[]|null);
        }

        class GetConstInfoResp implements IGetConstInfoResp {
            constructor(p?: GameProto.IGetConstInfoResp);
            public infos: GameProto.ConstInfo[];
            public static create(properties?: GameProto.IGetConstInfoResp): GameProto.GetConstInfoResp;
            public static encode(m: GameProto.GetConstInfoResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetConstInfoResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameNameChangeInfo {
            iId?: (number|null);
            iCoinType?: (number|null);
            iCoinValue?: (number|null);
            iUseTimes?: (number|null);
            iRankSort?: (number|null);
        }

        class GameNameChangeInfo implements IGameNameChangeInfo {
            constructor(p?: GameProto.IGameNameChangeInfo);
            public iId: number;
            public iCoinType: number;
            public iCoinValue: number;
            public iUseTimes: number;
            public iRankSort: number;
            public static create(properties?: GameProto.IGameNameChangeInfo): GameProto.GameNameChangeInfo;
            public static encode(m: GameProto.GameNameChangeInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GameNameChangeInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetConfigPackageReq {
            lUid?: (Long|null);
        }

        class GetConfigPackageReq implements IGetConfigPackageReq {
            constructor(p?: GameProto.IGetConfigPackageReq);
            public lUid: Long;
            public static create(properties?: GameProto.IGetConfigPackageReq): GameProto.GetConfigPackageReq;
            public static encode(m: GameProto.GetConfigPackageReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetConfigPackageReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetConfigPackageResp {
            locales?: (GameProto.LocaleInfo[]|null);
            ups?: (GameProto.UserLevelUpInfo[]|null);
            foreigns?: (GameProto.ForeignInfo[]|null);
            consts?: (GameProto.ConstInfo[]|null);
            infos?: (GameProto.SystemMessageInfo[]|null);
            bigs?: (GameProto.GameBigAwardMatchInfo[]|null);
            levels?: (GameProto.HallUserLevelInfo[]|null);
            names?: (GameProto.GameNameChangeInfo[]|null);
            times?: (GameProto.GameActivityTimes[]|null);
        }

        class GetConfigPackageResp implements IGetConfigPackageResp {
            constructor(p?: GameProto.IGetConfigPackageResp);
            public locales: GameProto.LocaleInfo[];
            public ups: GameProto.UserLevelUpInfo[];
            public foreigns: GameProto.ForeignInfo[];
            public consts: GameProto.ConstInfo[];
            public infos: GameProto.SystemMessageInfo[];
            public bigs: GameProto.GameBigAwardMatchInfo[];
            public levels: GameProto.HallUserLevelInfo[];
            public names: GameProto.GameNameChangeInfo[];
            public times: GameProto.GameActivityTimes[];
            public static create(properties?: GameProto.IGetConfigPackageResp): GameProto.GetConfigPackageResp;
            public static encode(m: GameProto.GetConfigPackageResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetConfigPackageResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        enum MSGSYSTEMTYPE {
            MSGSYSTEMTYPE_NON = 0,
            MSGSYSTEMTYPE_RED_POINT = 1,
            MSGSYSTEMTYPE_GAME_OVER = 2,
            MSGSYSTEMTYPE_ACTIVITY = 3,
            MSGSYSTEMTYPE_ACTIVITY_RED_POINT = 4,
            MSGSYSTEMTYPE_ACTIVITY_FRIEND_SUPPORT_TASK = 5,
            MSGSYSTEMTYPE_ACTIVITY_FRIEND_REWARD_TASK = 6,
            MSGSYSTEMTYPE_ACTIVITY_TASK_PERCENT = 7,
            MSGSYSTEMTYPE_GAME_OTHER_OVER = 8
        }

        interface ISystemMessageInfo {
            nType?: (GameProto.MSGSYSTEMTYPE|null);
            lValue?: (Long|null);
            aidInfo?: (GameProto.ActivityDataNotify|null);
            friendSupportTaskInfo?: (GameProto.ActFriendSupportTaskNotify|null);
            expireTime?: (Long|null);
            param?: (Long[]|null);
        }

        class SystemMessageInfo implements ISystemMessageInfo {
            constructor(p?: GameProto.ISystemMessageInfo);
            public nType: GameProto.MSGSYSTEMTYPE;
            public lValue: Long;
            public aidInfo?: (GameProto.ActivityDataNotify|null);
            public friendSupportTaskInfo?: (GameProto.ActFriendSupportTaskNotify|null);
            public expireTime: Long;
            public param: Long[];
            public static create(properties?: GameProto.ISystemMessageInfo): GameProto.SystemMessageInfo;
            public static encode(m: GameProto.SystemMessageInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.SystemMessageInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ISystemMessageNotify {
            infos?: (GameProto.SystemMessageInfo[]|null);
        }

        class SystemMessageNotify implements ISystemMessageNotify {
            constructor(p?: GameProto.ISystemMessageNotify);
            public infos: GameProto.SystemMessageInfo[];
            public static create(properties?: GameProto.ISystemMessageNotify): GameProto.SystemMessageNotify;
            public static encode(m: GameProto.SystemMessageNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.SystemMessageNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameBigAwardMatchInfo {
            lActivityID?: (Long|null);
            iCount?: (number|null);
        }

        class GameBigAwardMatchInfo implements IGameBigAwardMatchInfo {
            constructor(p?: GameProto.IGameBigAwardMatchInfo);
            public lActivityID: Long;
            public iCount: number;
            public static create(properties?: GameProto.IGameBigAwardMatchInfo): GameProto.GameBigAwardMatchInfo;
            public static encode(m: GameProto.GameBigAwardMatchInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GameBigAwardMatchInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameBigAwardMatchCountNotify {
            infos?: (GameProto.GameBigAwardMatchInfo[]|null);
        }

        class GameBigAwardMatchCountNotify implements IGameBigAwardMatchCountNotify {
            constructor(p?: GameProto.IGameBigAwardMatchCountNotify);
            public infos: GameProto.GameBigAwardMatchInfo[];
            public static create(properties?: GameProto.IGameBigAwardMatchCountNotify): GameProto.GameBigAwardMatchCountNotify;
            public static encode(m: GameProto.GameBigAwardMatchCountNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GameBigAwardMatchCountNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameActivityTimes {
            lActivityID?: (Long|null);
            iCount?: (number|null);
            iTimeLimit?: (number|null);
        }

        class GameActivityTimes implements IGameActivityTimes {
            constructor(p?: GameProto.IGameActivityTimes);
            public lActivityID: Long;
            public iCount: number;
            public iTimeLimit: number;
            public static create(properties?: GameProto.IGameActivityTimes): GameProto.GameActivityTimes;
            public static encode(m: GameProto.GameActivityTimes, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GameActivityTimes;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameActivityTimesNotify {
            infos?: (GameProto.GameActivityTimes[]|null);
        }

        class GameActivityTimesNotify implements IGameActivityTimesNotify {
            constructor(p?: GameProto.IGameActivityTimesNotify);
            public infos: GameProto.GameActivityTimes[];
            public static create(properties?: GameProto.IGameActivityTimesNotify): GameProto.GameActivityTimesNotify;
            public static encode(m: GameProto.GameActivityTimesNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GameActivityTimesNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameGetActivityTimesReq {
            lUid?: (Long|null);
        }

        class GameGetActivityTimesReq implements IGameGetActivityTimesReq {
            constructor(p?: GameProto.IGameGetActivityTimesReq);
            public lUid: Long;
            public static create(properties?: GameProto.IGameGetActivityTimesReq): GameProto.GameGetActivityTimesReq;
            public static encode(m: GameProto.GameGetActivityTimesReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GameGetActivityTimesReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameGetActivityTimesRsp {
            times?: (GameProto.GameActivityTimes[]|null);
        }

        class GameGetActivityTimesRsp implements IGameGetActivityTimesRsp {
            constructor(p?: GameProto.IGameGetActivityTimesRsp);
            public times: GameProto.GameActivityTimes[];
            public static create(properties?: GameProto.IGameGetActivityTimesRsp): GameProto.GameGetActivityTimesRsp;
            public static encode(m: GameProto.GameGetActivityTimesRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GameGetActivityTimesRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameUserChangeAvatarReq {
            sAvatar?: (string|null);
            sNickname?: (string|null);
        }

        class GameUserChangeAvatarReq implements IGameUserChangeAvatarReq {
            constructor(p?: GameProto.IGameUserChangeAvatarReq);
            public sAvatar: string;
            public sNickname: string;
            public static create(properties?: GameProto.IGameUserChangeAvatarReq): GameProto.GameUserChangeAvatarReq;
            public static encode(m: GameProto.GameUserChangeAvatarReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GameUserChangeAvatarReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameUserChangeAvatarRsp {
            resultCode?: (number|null);
        }

        class GameUserChangeAvatarRsp implements IGameUserChangeAvatarRsp {
            constructor(p?: GameProto.IGameUserChangeAvatarRsp);
            public resultCode: number;
            public static create(properties?: GameProto.IGameUserChangeAvatarRsp): GameProto.GameUserChangeAvatarRsp;
            public static encode(m: GameProto.GameUserChangeAvatarRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GameUserChangeAvatarRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameUserChangeInfo {
            iId?: (number|null);
            iTimes?: (number|null);
        }

        class GameUserChangeInfo implements IGameUserChangeInfo {
            constructor(p?: GameProto.IGameUserChangeInfo);
            public iId: number;
            public iTimes: number;
            public static create(properties?: GameProto.IGameUserChangeInfo): GameProto.GameUserChangeInfo;
            public static encode(m: GameProto.GameUserChangeInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GameUserChangeInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameUserGetChangeInfoReq {
        }

        class GameUserGetChangeInfoReq implements IGameUserGetChangeInfoReq {
            constructor(p?: GameProto.IGameUserGetChangeInfoReq);
            public static create(properties?: GameProto.IGameUserGetChangeInfoReq): GameProto.GameUserGetChangeInfoReq;
            public static encode(m: GameProto.GameUserGetChangeInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GameUserGetChangeInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameUserGetChangeInfoRsp {
            resultCode?: (number|null);
            infos?: (GameProto.GameUserChangeInfo[]|null);
        }

        class GameUserGetChangeInfoRsp implements IGameUserGetChangeInfoRsp {
            constructor(p?: GameProto.IGameUserGetChangeInfoRsp);
            public resultCode: number;
            public infos: GameProto.GameUserChangeInfo[];
            public static create(properties?: GameProto.IGameUserGetChangeInfoRsp): GameProto.GameUserGetChangeInfoRsp;
            public static encode(m: GameProto.GameUserGetChangeInfoRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GameUserGetChangeInfoRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameUserCheckNameReq {
            sNickname?: (string|null);
        }

        class GameUserCheckNameReq implements IGameUserCheckNameReq {
            constructor(p?: GameProto.IGameUserCheckNameReq);
            public sNickname: string;
            public static create(properties?: GameProto.IGameUserCheckNameReq): GameProto.GameUserCheckNameReq;
            public static encode(m: GameProto.GameUserCheckNameReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GameUserCheckNameReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameUserCheckNameRsp {
            resultCode?: (number|null);
        }

        class GameUserCheckNameRsp implements IGameUserCheckNameRsp {
            constructor(p?: GameProto.IGameUserCheckNameRsp);
            public resultCode: number;
            public static create(properties?: GameProto.IGameUserCheckNameRsp): GameProto.GameUserCheckNameRsp;
            public static encode(m: GameProto.GameUserCheckNameRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GameUserCheckNameRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameUserSetGuideTimesReq {
            iTimes?: (number|null);
        }

        class GameUserSetGuideTimesReq implements IGameUserSetGuideTimesReq {
            constructor(p?: GameProto.IGameUserSetGuideTimesReq);
            public iTimes: number;
            public static create(properties?: GameProto.IGameUserSetGuideTimesReq): GameProto.GameUserSetGuideTimesReq;
            public static encode(m: GameProto.GameUserSetGuideTimesReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GameUserSetGuideTimesReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameUserSetGuideTimesRsp {
            resultCode?: (number|null);
        }

        class GameUserSetGuideTimesRsp implements IGameUserSetGuideTimesRsp {
            constructor(p?: GameProto.IGameUserSetGuideTimesRsp);
            public resultCode: number;
            public static create(properties?: GameProto.IGameUserSetGuideTimesRsp): GameProto.GameUserSetGuideTimesRsp;
            public static encode(m: GameProto.GameUserSetGuideTimesRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GameUserSetGuideTimesRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserSignDataReq {
            lUid?: (Long|null);
        }

        class GetUserSignDataReq implements IGetUserSignDataReq {
            constructor(p?: GameProto.IGetUserSignDataReq);
            public lUid: Long;
            public static create(properties?: GameProto.IGetUserSignDataReq): GameProto.GetUserSignDataReq;
            public static encode(m: GameProto.GetUserSignDataReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserSignDataReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserSignDataResp {
            iSignDays?: (number|null);
            iTotalSignDays?: (number|null);
            signItems?: (GameProto.SignItemData[]|null);
            totalSignItems?: (GameProto.SignItemData[]|null);
        }

        class GetUserSignDataResp implements IGetUserSignDataResp {
            constructor(p?: GameProto.IGetUserSignDataResp);
            public iSignDays: number;
            public iTotalSignDays: number;
            public signItems: GameProto.SignItemData[];
            public totalSignItems: GameProto.SignItemData[];
            public static create(properties?: GameProto.IGetUserSignDataResp): GameProto.GetUserSignDataResp;
            public static encode(m: GameProto.GetUserSignDataResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserSignDataResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserSignRewardReq {
            lUid?: (Long|null);
        }

        class GetUserSignRewardReq implements IGetUserSignRewardReq {
            constructor(p?: GameProto.IGetUserSignRewardReq);
            public lUid: Long;
            public static create(properties?: GameProto.IGetUserSignRewardReq): GameProto.GetUserSignRewardReq;
            public static encode(m: GameProto.GetUserSignRewardReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserSignRewardReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserSignRewardResp {
            resultCode?: (number|null);
            UserSignRewards?: (GameProto.UserSignRewardData[]|null);
        }

        class GetUserSignRewardResp implements IGetUserSignRewardResp {
            constructor(p?: GameProto.IGetUserSignRewardResp);
            public resultCode: number;
            public UserSignRewards: GameProto.UserSignRewardData[];
            public static create(properties?: GameProto.IGetUserSignRewardResp): GameProto.GetUserSignRewardResp;
            public static encode(m: GameProto.GetUserSignRewardResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserSignRewardResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ISignItemData {
            iDay?: (number|null);
            iStatus?: (number|null);
            signRewards?: (GameProto.SignRewardData[]|null);
        }

        class SignItemData implements ISignItemData {
            constructor(p?: GameProto.ISignItemData);
            public iDay: number;
            public iStatus: number;
            public signRewards: GameProto.SignRewardData[];
            public static create(properties?: GameProto.ISignItemData): GameProto.SignItemData;
            public static encode(m: GameProto.SignItemData, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.SignItemData;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ISignRewardData {
            iRewardType?: (number|null);
            iRewardNum?: (number|null);
        }

        class SignRewardData implements ISignRewardData {
            constructor(p?: GameProto.ISignRewardData);
            public iRewardType: number;
            public iRewardNum: number;
            public static create(properties?: GameProto.ISignRewardData): GameProto.SignRewardData;
            public static encode(m: GameProto.SignRewardData, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.SignRewardData;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserSignRewardData {
            iType?: (number|null);
            iDay?: (number|null);
            signRewards?: (GameProto.SignRewardData[]|null);
        }

        class UserSignRewardData implements IUserSignRewardData {
            constructor(p?: GameProto.IUserSignRewardData);
            public iType: number;
            public iDay: number;
            public signRewards: GameProto.SignRewardData[];
            public static create(properties?: GameProto.IUserSignRewardData): GameProto.UserSignRewardData;
            public static encode(m: GameProto.UserSignRewardData, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserSignRewardData;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserAccountBindReq {
            sName?: (string|null);
            sPwd?: (string|null);
        }

        class UserAccountBindReq implements IUserAccountBindReq {
            constructor(p?: GameProto.IUserAccountBindReq);
            public sName: string;
            public sPwd: string;
            public static create(properties?: GameProto.IUserAccountBindReq): GameProto.UserAccountBindReq;
            public static encode(m: GameProto.UserAccountBindReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserAccountBindReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserAccountBindResp {
            resultCode?: (number|null);
        }

        class UserAccountBindResp implements IUserAccountBindResp {
            constructor(p?: GameProto.IUserAccountBindResp);
            public resultCode: number;
            public static create(properties?: GameProto.IUserAccountBindResp): GameProto.UserAccountBindResp;
            public static encode(m: GameProto.UserAccountBindResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserAccountBindResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IDiamondObtainReq {
            view?: (boolean|null);
        }

        class DiamondObtainReq implements IDiamondObtainReq {
            constructor(p?: GameProto.IDiamondObtainReq);
            public view: boolean;
            public static create(properties?: GameProto.IDiamondObtainReq): GameProto.DiamondObtainReq;
            public static encode(m: GameProto.DiamondObtainReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.DiamondObtainReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IDiamondObtainResp {
            span?: (Long|null);
            viewTimes?: (Long|null);
            viewTime?: (Long|null);
        }

        class DiamondObtainResp implements IDiamondObtainResp {
            constructor(p?: GameProto.IDiamondObtainResp);
            public span: Long;
            public viewTimes: Long;
            public viewTime: Long;
            public static create(properties?: GameProto.IDiamondObtainResp): GameProto.DiamondObtainResp;
            public static encode(m: GameProto.DiamondObtainResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.DiamondObtainResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IDiamondObtainSpanReq {
        }

        class DiamondObtainSpanReq implements IDiamondObtainSpanReq {
            constructor(p?: GameProto.IDiamondObtainSpanReq);
            public static create(properties?: GameProto.IDiamondObtainSpanReq): GameProto.DiamondObtainSpanReq;
            public static encode(m: GameProto.DiamondObtainSpanReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.DiamondObtainSpanReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IDiamondObtainSpanResp {
            span?: (Long|null);
            viewTimes?: (Long|null);
            viewTime?: (Long|null);
        }

        class DiamondObtainSpanResp implements IDiamondObtainSpanResp {
            constructor(p?: GameProto.IDiamondObtainSpanResp);
            public span: Long;
            public viewTimes: Long;
            public viewTime: Long;
            public static create(properties?: GameProto.IDiamondObtainSpanResp): GameProto.DiamondObtainSpanResp;
            public static encode(m: GameProto.DiamondObtainSpanResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.DiamondObtainSpanResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGoogleReverseGeocodingReq {
            lo?: (number|null);
            la?: (number|null);
            gameID?: (number|null);
        }

        class GoogleReverseGeocodingReq implements IGoogleReverseGeocodingReq {
            constructor(p?: GameProto.IGoogleReverseGeocodingReq);
            public lo: number;
            public la: number;
            public gameID: number;
            public static create(properties?: GameProto.IGoogleReverseGeocodingReq): GameProto.GoogleReverseGeocodingReq;
            public static encode(m: GameProto.GoogleReverseGeocodingReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GoogleReverseGeocodingReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGoogleReverseGeocodingResp {
            allow?: (boolean|null);
        }

        class GoogleReverseGeocodingResp implements IGoogleReverseGeocodingResp {
            constructor(p?: GameProto.IGoogleReverseGeocodingResp);
            public allow: boolean;
            public static create(properties?: GameProto.IGoogleReverseGeocodingResp): GameProto.GoogleReverseGeocodingResp;
            public static encode(m: GameProto.GoogleReverseGeocodingResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GoogleReverseGeocodingResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserBindPhoneReq {
            sPhoneAreaCode?: (string|null);
            sPhoneNumber?: (string|null);
            sVerifyCode?: (string|null);
            sBirthday?: (string|null);
        }

        class UserBindPhoneReq implements IUserBindPhoneReq {
            constructor(p?: GameProto.IUserBindPhoneReq);
            public sPhoneAreaCode: string;
            public sPhoneNumber: string;
            public sVerifyCode: string;
            public sBirthday: string;
            public static create(properties?: GameProto.IUserBindPhoneReq): GameProto.UserBindPhoneReq;
            public static encode(m: GameProto.UserBindPhoneReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserBindPhoneReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserBindPhoneResp {
            resultCode?: (number|null);
        }

        class UserBindPhoneResp implements IUserBindPhoneResp {
            constructor(p?: GameProto.IUserBindPhoneResp);
            public resultCode: number;
            public static create(properties?: GameProto.IUserBindPhoneResp): GameProto.UserBindPhoneResp;
            public static encode(m: GameProto.UserBindPhoneResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserBindPhoneResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserBindEmailReq {
            sEmail?: (string|null);
            sVerifyCode?: (string|null);
            sourceType?: (number|null);
        }

        class UserBindEmailReq implements IUserBindEmailReq {
            constructor(p?: GameProto.IUserBindEmailReq);
            public sEmail: string;
            public sVerifyCode: string;
            public sourceType: number;
            public static create(properties?: GameProto.IUserBindEmailReq): GameProto.UserBindEmailReq;
            public static encode(m: GameProto.UserBindEmailReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserBindEmailReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserBindEmailResp {
            resultCode?: (number|null);
        }

        class UserBindEmailResp implements IUserBindEmailResp {
            constructor(p?: GameProto.IUserBindEmailResp);
            public resultCode: number;
            public static create(properties?: GameProto.IUserBindEmailResp): GameProto.UserBindEmailResp;
            public static encode(m: GameProto.UserBindEmailResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserBindEmailResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserDeleteReq {
            lUid?: (Long|null);
        }

        class UserDeleteReq implements IUserDeleteReq {
            constructor(p?: GameProto.IUserDeleteReq);
            public lUid: Long;
            public static create(properties?: GameProto.IUserDeleteReq): GameProto.UserDeleteReq;
            public static encode(m: GameProto.UserDeleteReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserDeleteReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserDeleteResp {
            resultCode?: (number|null);
        }

        class UserDeleteResp implements IUserDeleteResp {
            constructor(p?: GameProto.IUserDeleteResp);
            public resultCode: number;
            public static create(properties?: GameProto.IUserDeleteResp): GameProto.UserDeleteResp;
            public static encode(m: GameProto.UserDeleteResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserDeleteResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserAccountIsOldReq {
            deviceCode?: (string|null);
            loginSource?: (string|null);
        }

        class UserAccountIsOldReq implements IUserAccountIsOldReq {
            constructor(p?: GameProto.IUserAccountIsOldReq);
            public deviceCode: string;
            public loginSource: string;
            public static create(properties?: GameProto.IUserAccountIsOldReq): GameProto.UserAccountIsOldReq;
            public static encode(m: GameProto.UserAccountIsOldReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserAccountIsOldReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserAccountIsOldResp {
            isOld?: (boolean|null);
        }

        class UserAccountIsOldResp implements IUserAccountIsOldResp {
            constructor(p?: GameProto.IUserAccountIsOldResp);
            public isOld: boolean;
            public static create(properties?: GameProto.IUserAccountIsOldResp): GameProto.UserAccountIsOldResp;
            public static encode(m: GameProto.UserAccountIsOldResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserAccountIsOldResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGoogleReverseGeocodingNotLoginReq {
            lo?: (number|null);
            la?: (number|null);
            phoneNumber?: (string|null);
            loginSource?: (string|null);
            gameID?: (number|null);
        }

        class GoogleReverseGeocodingNotLoginReq implements IGoogleReverseGeocodingNotLoginReq {
            constructor(p?: GameProto.IGoogleReverseGeocodingNotLoginReq);
            public lo: number;
            public la: number;
            public phoneNumber: string;
            public loginSource: string;
            public gameID: number;
            public static create(properties?: GameProto.IGoogleReverseGeocodingNotLoginReq): GameProto.GoogleReverseGeocodingNotLoginReq;
            public static encode(m: GameProto.GoogleReverseGeocodingNotLoginReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GoogleReverseGeocodingNotLoginReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGoogleReverseGeocodingNotLoginRsp {
            allow?: (boolean|null);
        }

        class GoogleReverseGeocodingNotLoginRsp implements IGoogleReverseGeocodingNotLoginRsp {
            constructor(p?: GameProto.IGoogleReverseGeocodingNotLoginRsp);
            public allow: boolean;
            public static create(properties?: GameProto.IGoogleReverseGeocodingNotLoginRsp): GameProto.GoogleReverseGeocodingNotLoginRsp;
            public static encode(m: GameProto.GoogleReverseGeocodingNotLoginRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GoogleReverseGeocodingNotLoginRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ISmsSendReq {
            domainCode?: (string|null);
            phoneNumber?: (string|null);
            loginSource?: (string|null);
            deviceCode?: (string|null);
        }

        class SmsSendReq implements ISmsSendReq {
            constructor(p?: GameProto.ISmsSendReq);
            public domainCode: string;
            public phoneNumber: string;
            public loginSource: string;
            public deviceCode: string;
            public static create(properties?: GameProto.ISmsSendReq): GameProto.SmsSendReq;
            public static encode(m: GameProto.SmsSendReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.SmsSendReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ISmsSendRsp {
            success?: (boolean|null);
            statusCode?: (number|null);
        }

        class SmsSendRsp implements ISmsSendRsp {
            constructor(p?: GameProto.ISmsSendRsp);
            public success: boolean;
            public statusCode: number;
            public static create(properties?: GameProto.ISmsSendRsp): GameProto.SmsSendRsp;
            public static encode(m: GameProto.SmsSendRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.SmsSendRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ISmsCodeVerifyReq {
            domainCode?: (string|null);
            phoneNumber?: (string|null);
            loginSource?: (string|null);
            code?: (string|null);
        }

        class SmsCodeVerifyReq implements ISmsCodeVerifyReq {
            constructor(p?: GameProto.ISmsCodeVerifyReq);
            public domainCode: string;
            public phoneNumber: string;
            public loginSource: string;
            public code: string;
            public static create(properties?: GameProto.ISmsCodeVerifyReq): GameProto.SmsCodeVerifyReq;
            public static encode(m: GameProto.SmsCodeVerifyReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.SmsCodeVerifyReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ISmsCodeVerifyRsp {
            success?: (boolean|null);
        }

        class SmsCodeVerifyRsp implements ISmsCodeVerifyRsp {
            constructor(p?: GameProto.ISmsCodeVerifyRsp);
            public success: boolean;
            public static create(properties?: GameProto.ISmsCodeVerifyRsp): GameProto.SmsCodeVerifyRsp;
            public static encode(m: GameProto.SmsCodeVerifyRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.SmsCodeVerifyRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IDrawMoneyOrderInfo {
            orderID?: (Long|null);
            orderNo?: (string|null);
            drawMoney?: (Long|null);
            commissionMoney?: (Long|null);
            takeMoney?: (Long|null);
            cash?: (Long|null);
            orderState?: (number|null);
            isReuseExtendInfo?: (number|null);
            userConfirm?: (number|null);
            createTime?: (Long|null);
            rejectReason?: (string|null);
        }

        class DrawMoneyOrderInfo implements IDrawMoneyOrderInfo {
            constructor(p?: GameProto.IDrawMoneyOrderInfo);
            public orderID: Long;
            public orderNo: string;
            public drawMoney: Long;
            public commissionMoney: Long;
            public takeMoney: Long;
            public cash: Long;
            public orderState: number;
            public isReuseExtendInfo: number;
            public userConfirm: number;
            public createTime: Long;
            public rejectReason: string;
            public static create(properties?: GameProto.IDrawMoneyOrderInfo): GameProto.DrawMoneyOrderInfo;
            public static encode(m: GameProto.DrawMoneyOrderInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.DrawMoneyOrderInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IDrawMoneyOrderCreateReq {
            vcode?: (string|null);
            bindEmail?: (string|null);
            drawMoney?: (number|null);
        }

        class DrawMoneyOrderCreateReq implements IDrawMoneyOrderCreateReq {
            constructor(p?: GameProto.IDrawMoneyOrderCreateReq);
            public vcode: string;
            public bindEmail: string;
            public drawMoney: number;
            public static create(properties?: GameProto.IDrawMoneyOrderCreateReq): GameProto.DrawMoneyOrderCreateReq;
            public static encode(m: GameProto.DrawMoneyOrderCreateReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.DrawMoneyOrderCreateReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IDrawMoneyOrderCreateResp {
            resultCode?: (number|null);
            info?: (GameProto.DrawMoneyOrderInfo|null);
        }

        class DrawMoneyOrderCreateResp implements IDrawMoneyOrderCreateResp {
            constructor(p?: GameProto.IDrawMoneyOrderCreateResp);
            public resultCode: number;
            public info?: (GameProto.DrawMoneyOrderInfo|null);
            public static create(properties?: GameProto.IDrawMoneyOrderCreateResp): GameProto.DrawMoneyOrderCreateResp;
            public static encode(m: GameProto.DrawMoneyOrderCreateResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.DrawMoneyOrderCreateResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IDrawMoneyOrderListReq {
            orderState?: (number[]|null);
            skip?: (number|null);
            limit?: (number|null);
        }

        class DrawMoneyOrderListReq implements IDrawMoneyOrderListReq {
            constructor(p?: GameProto.IDrawMoneyOrderListReq);
            public orderState: number[];
            public skip: number;
            public limit: number;
            public static create(properties?: GameProto.IDrawMoneyOrderListReq): GameProto.DrawMoneyOrderListReq;
            public static encode(m: GameProto.DrawMoneyOrderListReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.DrawMoneyOrderListReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IDrawMoneyOrderListResp {
            resultCode?: (number|null);
            list?: (GameProto.DrawMoneyOrderInfo[]|null);
        }

        class DrawMoneyOrderListResp implements IDrawMoneyOrderListResp {
            constructor(p?: GameProto.IDrawMoneyOrderListResp);
            public resultCode: number;
            public list: GameProto.DrawMoneyOrderInfo[];
            public static create(properties?: GameProto.IDrawMoneyOrderListResp): GameProto.DrawMoneyOrderListResp;
            public static encode(m: GameProto.DrawMoneyOrderListResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.DrawMoneyOrderListResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IDrawMoneyOrderCancelReq {
            orderNo?: (string|null);
        }

        class DrawMoneyOrderCancelReq implements IDrawMoneyOrderCancelReq {
            constructor(p?: GameProto.IDrawMoneyOrderCancelReq);
            public orderNo: string;
            public static create(properties?: GameProto.IDrawMoneyOrderCancelReq): GameProto.DrawMoneyOrderCancelReq;
            public static encode(m: GameProto.DrawMoneyOrderCancelReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.DrawMoneyOrderCancelReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IDrawMoneyOrderCancelResp {
            resultCode?: (number|null);
            orderNo?: (string|null);
        }

        class DrawMoneyOrderCancelResp implements IDrawMoneyOrderCancelResp {
            constructor(p?: GameProto.IDrawMoneyOrderCancelResp);
            public resultCode: number;
            public orderNo: string;
            public static create(properties?: GameProto.IDrawMoneyOrderCancelResp): GameProto.DrawMoneyOrderCancelResp;
            public static encode(m: GameProto.DrawMoneyOrderCancelResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.DrawMoneyOrderCancelResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IDrawMoneyOrderUserConfirmReq {
            orderNo?: (string|null);
        }

        class DrawMoneyOrderUserConfirmReq implements IDrawMoneyOrderUserConfirmReq {
            constructor(p?: GameProto.IDrawMoneyOrderUserConfirmReq);
            public orderNo: string;
            public static create(properties?: GameProto.IDrawMoneyOrderUserConfirmReq): GameProto.DrawMoneyOrderUserConfirmReq;
            public static encode(m: GameProto.DrawMoneyOrderUserConfirmReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.DrawMoneyOrderUserConfirmReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IDrawMoneyOrderUserConfirmResp {
            resultCode?: (number|null);
        }

        class DrawMoneyOrderUserConfirmResp implements IDrawMoneyOrderUserConfirmResp {
            constructor(p?: GameProto.IDrawMoneyOrderUserConfirmResp);
            public resultCode: number;
            public static create(properties?: GameProto.IDrawMoneyOrderUserConfirmResp): GameProto.DrawMoneyOrderUserConfirmResp;
            public static encode(m: GameProto.DrawMoneyOrderUserConfirmResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.DrawMoneyOrderUserConfirmResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IDrawMoneyOrderLimitReq {
        }

        class DrawMoneyOrderLimitReq implements IDrawMoneyOrderLimitReq {
            constructor(p?: GameProto.IDrawMoneyOrderLimitReq);
            public static create(properties?: GameProto.IDrawMoneyOrderLimitReq): GameProto.DrawMoneyOrderLimitReq;
            public static encode(m: GameProto.DrawMoneyOrderLimitReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.DrawMoneyOrderLimitReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IDrawMoneyOrderLimitResp {
            resultCode?: (number|null);
            curMonTakeMoney?: (Long|null);
            curMonTakeMoneyLimit?: (Long|null);
            minAmount?: (number|null);
            maxAmount?: (number|null);
            maxMonAmount?: (number|null);
            minTransactionFee?: (number|null);
            minFeeThresholdAmount?: (number|null);
            excessFeePercentage?: (number|null);
            depositValidityDays?: (number|null);
            payCnt?: (number|null);
            lastPayTime?: (Long|null);
        }

        class DrawMoneyOrderLimitResp implements IDrawMoneyOrderLimitResp {
            constructor(p?: GameProto.IDrawMoneyOrderLimitResp);
            public resultCode: number;
            public curMonTakeMoney: Long;
            public curMonTakeMoneyLimit: Long;
            public minAmount: number;
            public maxAmount: number;
            public maxMonAmount: number;
            public minTransactionFee: number;
            public minFeeThresholdAmount: number;
            public excessFeePercentage: number;
            public depositValidityDays: number;
            public payCnt: number;
            public lastPayTime: Long;
            public static create(properties?: GameProto.IDrawMoneyOrderLimitResp): GameProto.DrawMoneyOrderLimitResp;
            public static encode(m: GameProto.DrawMoneyOrderLimitResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.DrawMoneyOrderLimitResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IDrawMoneyOrderCalcReq {
            drawMoney?: (number|null);
            payWay?: (number|null);
        }

        class DrawMoneyOrderCalcReq implements IDrawMoneyOrderCalcReq {
            constructor(p?: GameProto.IDrawMoneyOrderCalcReq);
            public drawMoney: number;
            public payWay: number;
            public static create(properties?: GameProto.IDrawMoneyOrderCalcReq): GameProto.DrawMoneyOrderCalcReq;
            public static encode(m: GameProto.DrawMoneyOrderCalcReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.DrawMoneyOrderCalcReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IDrawMoneyOrderCalcResp {
            resultCode?: (number|null);
            drawMoney?: (Long|null);
            commissionMoney?: (Long|null);
            takeMoney?: (Long|null);
            cash?: (Long|null);
        }

        class DrawMoneyOrderCalcResp implements IDrawMoneyOrderCalcResp {
            constructor(p?: GameProto.IDrawMoneyOrderCalcResp);
            public resultCode: number;
            public drawMoney: Long;
            public commissionMoney: Long;
            public takeMoney: Long;
            public cash: Long;
            public static create(properties?: GameProto.IDrawMoneyOrderCalcResp): GameProto.DrawMoneyOrderCalcResp;
            public static encode(m: GameProto.DrawMoneyOrderCalcResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.DrawMoneyOrderCalcResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserExtendLinkReq {
            orderNo?: (string|null);
        }

        class GetUserExtendLinkReq implements IGetUserExtendLinkReq {
            constructor(p?: GameProto.IGetUserExtendLinkReq);
            public orderNo: string;
            public static create(properties?: GameProto.IGetUserExtendLinkReq): GameProto.GetUserExtendLinkReq;
            public static encode(m: GameProto.GetUserExtendLinkReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserExtendLinkReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserExtendLinkResp {
            resultCode?: (number|null);
            url?: (string|null);
            expire?: (Long|null);
        }

        class GetUserExtendLinkResp implements IGetUserExtendLinkResp {
            constructor(p?: GameProto.IGetUserExtendLinkResp);
            public resultCode: number;
            public url: string;
            public expire: Long;
            public static create(properties?: GameProto.IGetUserExtendLinkResp): GameProto.GetUserExtendLinkResp;
            public static encode(m: GameProto.GetUserExtendLinkResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserExtendLinkResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IEmailSendReq {
            email?: (string|null);
            sourceType?: (number|null);
        }

        class EmailSendReq implements IEmailSendReq {
            constructor(p?: GameProto.IEmailSendReq);
            public email: string;
            public sourceType: number;
            public static create(properties?: GameProto.IEmailSendReq): GameProto.EmailSendReq;
            public static encode(m: GameProto.EmailSendReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.EmailSendReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IEmailSendRsp {
            resultCode?: (number|null);
        }

        class EmailSendRsp implements IEmailSendRsp {
            constructor(p?: GameProto.IEmailSendRsp);
            public resultCode: number;
            public static create(properties?: GameProto.IEmailSendRsp): GameProto.EmailSendRsp;
            public static encode(m: GameProto.EmailSendRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.EmailSendRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IEmailCodeVerifyReq {
            email?: (string|null);
            sourceType?: (number|null);
            code?: (string|null);
        }

        class EmailCodeVerifyReq implements IEmailCodeVerifyReq {
            constructor(p?: GameProto.IEmailCodeVerifyReq);
            public email: string;
            public sourceType: number;
            public code: string;
            public static create(properties?: GameProto.IEmailCodeVerifyReq): GameProto.EmailCodeVerifyReq;
            public static encode(m: GameProto.EmailCodeVerifyReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.EmailCodeVerifyReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IEmailCodeVerifyRsp {
            resultCode?: (number|null);
        }

        class EmailCodeVerifyRsp implements IEmailCodeVerifyRsp {
            constructor(p?: GameProto.IEmailCodeVerifyRsp);
            public resultCode: number;
            public static create(properties?: GameProto.IEmailCodeVerifyRsp): GameProto.EmailCodeVerifyRsp;
            public static encode(m: GameProto.EmailCodeVerifyRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.EmailCodeVerifyRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserBillRecordInfo {
            attachId?: (string|null);
            recordType?: (number|null);
            gameType?: (number|null);
            diamond?: (Long|null);
            cash?: (Long|null);
            afterDiamond?: (Long|null);
            afterCash?: (Long|null);
            recordTime?: (Long|null);
        }

        class UserBillRecordInfo implements IUserBillRecordInfo {
            constructor(p?: GameProto.IUserBillRecordInfo);
            public attachId: string;
            public recordType: number;
            public gameType: number;
            public diamond: Long;
            public cash: Long;
            public afterDiamond: Long;
            public afterCash: Long;
            public recordTime: Long;
            public static create(properties?: GameProto.IUserBillRecordInfo): GameProto.UserBillRecordInfo;
            public static encode(m: GameProto.UserBillRecordInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserBillRecordInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameUserBillRecordReq {
            page?: (number|null);
            row?: (number|null);
        }

        class GameUserBillRecordReq implements IGameUserBillRecordReq {
            constructor(p?: GameProto.IGameUserBillRecordReq);
            public page: number;
            public row: number;
            public static create(properties?: GameProto.IGameUserBillRecordReq): GameProto.GameUserBillRecordReq;
            public static encode(m: GameProto.GameUserBillRecordReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GameUserBillRecordReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameUserBillRecordResp {
            resultCode?: (number|null);
            count?: (number|null);
            records?: (GameProto.UserBillRecordInfo[]|null);
            pageIndex?: (number|null);
            pageNum?: (number|null);
        }

        class GameUserBillRecordResp implements IGameUserBillRecordResp {
            constructor(p?: GameProto.IGameUserBillRecordResp);
            public resultCode: number;
            public count: number;
            public records: GameProto.UserBillRecordInfo[];
            public pageIndex: number;
            public pageNum: number;
            public static create(properties?: GameProto.IGameUserBillRecordResp): GameProto.GameUserBillRecordResp;
            public static encode(m: GameProto.GameUserBillRecordResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GameUserBillRecordResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IOrderInfo {
            orderID?: (Long|null);
            orderNo?: (string|null);
            orderState?: (number|null);
            productID?: (number|null);
            amount?: (number|null);
            actID?: (number|null);
            actRound?: (number|null);
            payWay?: (number|null);
            totalPrice?: (number|null);
            currency?: (string|null);
        }

        class OrderInfo implements IOrderInfo {
            constructor(p?: GameProto.IOrderInfo);
            public orderID: Long;
            public orderNo: string;
            public orderState: number;
            public productID: number;
            public amount: number;
            public actID: number;
            public actRound: number;
            public payWay: number;
            public totalPrice: number;
            public currency: string;
            public static create(properties?: GameProto.IOrderInfo): GameProto.OrderInfo;
            public static encode(m: GameProto.OrderInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.OrderInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetOrderListReq {
            orderState?: (number|null);
            limit?: (number|null);
        }

        class GetOrderListReq implements IGetOrderListReq {
            constructor(p?: GameProto.IGetOrderListReq);
            public orderState: number;
            public limit: number;
            public static create(properties?: GameProto.IGetOrderListReq): GameProto.GetOrderListReq;
            public static encode(m: GameProto.GetOrderListReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetOrderListReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetOrderListResp {
            resultCode?: (number|null);
            list?: (GameProto.OrderInfo[]|null);
        }

        class GetOrderListResp implements IGetOrderListResp {
            constructor(p?: GameProto.IGetOrderListResp);
            public resultCode: number;
            public list: GameProto.OrderInfo[];
            public static create(properties?: GameProto.IGetOrderListResp): GameProto.GetOrderListResp;
            public static encode(m: GameProto.GetOrderListResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetOrderListResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IReceiveOrderRewardReq {
            orderNo?: (string|null);
        }

        class ReceiveOrderRewardReq implements IReceiveOrderRewardReq {
            constructor(p?: GameProto.IReceiveOrderRewardReq);
            public orderNo: string;
            public static create(properties?: GameProto.IReceiveOrderRewardReq): GameProto.ReceiveOrderRewardReq;
            public static encode(m: GameProto.ReceiveOrderRewardReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.ReceiveOrderRewardReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IReceiveOrderRewardResp {
            resultCode?: (number|null);
            info?: (GameProto.OrderInfo|null);
            payCnt?: (number|null);
        }

        class ReceiveOrderRewardResp implements IReceiveOrderRewardResp {
            constructor(p?: GameProto.IReceiveOrderRewardResp);
            public resultCode: number;
            public info?: (GameProto.OrderInfo|null);
            public payCnt: number;
            public static create(properties?: GameProto.IReceiveOrderRewardResp): GameProto.ReceiveOrderRewardResp;
            public static encode(m: GameProto.ReceiveOrderRewardResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.ReceiveOrderRewardResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserActivityInfo {
            aid?: (number|null);
            times?: (number|null);
        }

        class UserActivityInfo implements IUserActivityInfo {
            constructor(p?: GameProto.IUserActivityInfo);
            public aid: number;
            public times: number;
            public static create(properties?: GameProto.IUserActivityInfo): GameProto.UserActivityInfo;
            public static encode(m: GameProto.UserActivityInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserActivityInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetAllEnableActivityInfoReq {
        }

        class GetAllEnableActivityInfoReq implements IGetAllEnableActivityInfoReq {
            constructor(p?: GameProto.IGetAllEnableActivityInfoReq);
            public static create(properties?: GameProto.IGetAllEnableActivityInfoReq): GameProto.GetAllEnableActivityInfoReq;
            public static encode(m: GameProto.GetAllEnableActivityInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetAllEnableActivityInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPlatformActivityInfo {
            aid?: (number|null);
            price?: (number|null);
            paymentType?: (number|null);
            cash?: (number|null);
            diamond?: (number|null);
            limitTimes?: (number|null);
            sid?: (number|null);
        }

        class PlatformActivityInfo implements IPlatformActivityInfo {
            constructor(p?: GameProto.IPlatformActivityInfo);
            public aid: number;
            public price: number;
            public paymentType: number;
            public cash: number;
            public diamond: number;
            public limitTimes: number;
            public sid: number;
            public static create(properties?: GameProto.IPlatformActivityInfo): GameProto.PlatformActivityInfo;
            public static encode(m: GameProto.PlatformActivityInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.PlatformActivityInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetAllEnableActivityInfoRsp {
            PlatformInfo?: (GameProto.PlatformActivityInfo[]|null);
            UserInfo?: (GameProto.UserActivityInfo[]|null);
        }

        class GetAllEnableActivityInfoRsp implements IGetAllEnableActivityInfoRsp {
            constructor(p?: GameProto.IGetAllEnableActivityInfoRsp);
            public PlatformInfo: GameProto.PlatformActivityInfo[];
            public UserInfo: GameProto.UserActivityInfo[];
            public static create(properties?: GameProto.IGetAllEnableActivityInfoRsp): GameProto.GetAllEnableActivityInfoRsp;
            public static encode(m: GameProto.GetAllEnableActivityInfoRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetAllEnableActivityInfoRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPayPalGetVerifiedStatusReq {
            email?: (string|null);
        }

        class PayPalGetVerifiedStatusReq implements IPayPalGetVerifiedStatusReq {
            constructor(p?: GameProto.IPayPalGetVerifiedStatusReq);
            public email: string;
            public static create(properties?: GameProto.IPayPalGetVerifiedStatusReq): GameProto.PayPalGetVerifiedStatusReq;
            public static encode(m: GameProto.PayPalGetVerifiedStatusReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.PayPalGetVerifiedStatusReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPayPalGetVerifiedStatusResp {
            resultCode?: (number|null);
            email?: (string|null);
            verified?: (boolean|null);
        }

        class PayPalGetVerifiedStatusResp implements IPayPalGetVerifiedStatusResp {
            constructor(p?: GameProto.IPayPalGetVerifiedStatusResp);
            public resultCode: number;
            public email: string;
            public verified: boolean;
            public static create(properties?: GameProto.IPayPalGetVerifiedStatusResp): GameProto.PayPalGetVerifiedStatusResp;
            public static encode(m: GameProto.PayPalGetVerifiedStatusResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.PayPalGetVerifiedStatusResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetActivityListReq {
        }

        class GetActivityListReq implements IGetActivityListReq {
            constructor(p?: GameProto.IGetActivityListReq);
            public static create(properties?: GameProto.IGetActivityListReq): GameProto.GetActivityListReq;
            public static encode(m: GameProto.GetActivityListReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetActivityListReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetActivityListResp {
            resultCode?: (number|null);
            list?: (GameProto.ActivityData[]|null);
            timestamp?: (Long|null);
            myActInfo?: (GameProto.MyActivityInfo|null);
        }

        class GetActivityListResp implements IGetActivityListResp {
            constructor(p?: GameProto.IGetActivityListResp);
            public resultCode: number;
            public list: GameProto.ActivityData[];
            public timestamp: Long;
            public myActInfo?: (GameProto.MyActivityInfo|null);
            public static create(properties?: GameProto.IGetActivityListResp): GameProto.GetActivityListResp;
            public static encode(m: GameProto.GetActivityListResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetActivityListResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IActivityData {
            id?: (Long|null);
            category?: (number|null);
            name?: (string|null);
            describle?: (string|null);
            accessType?: (string|null);
            levelRange?: (string|null);
            regDays?: (number|null);
            accCash?: (number|null);
            prevTask?: (number|null);
            accessTicket?: (number|null);
            shareText?: (string|null);
            loginType?: (number|null);
            rewardCash?: (number|null);
            rewardBonus?: (number|null);
            rewardDiamond?: (number|null);
            rewardTool?: (string|null);
            rewardProdID?: (Long|null);
            discount?: (string|null);
            rewardByDays?: (string|null);
            alertType?: (string|null);
            beginTime?: (Long|null);
            endTime?: (Long|null);
            rewardInc?: (number|null);
            recycle?: (string|null);
            accessTimes?: (number|null);
            templateStyle?: (number|null);
            cycleType?: (number|null);
            showOnIcon?: (number|null);
            iconLine?: (number|null);
            iconSort?: (number|null);
            showOnTaskPage?: (number|null);
            taskPageSort?: (number|null);
            showOnShop?: (number|null);
            shopSort?: (number|null);
            state?: (number|null);
            gid?: (number|null);
            foreignName?: (string|null);
            alertThreshold?: (string|null);
            cap?: (number|null);
            floor?: (number|null);
            curStartUnix?: (Long|null);
            curEndUnix?: (Long|null);
            round?: (number|null);
            payCfg?: (GameProto.ActivityPayInfo|null);
            tag?: (string|null);
            countDown?: (string|null);
            rewardPresentation?: (string|null);
            displayCount?: (string|null);
            showBannerReward?: (string|null);
            rewardToolShared?: (string|null);
            missionSort?: (string|null);
            bannerReward?: (string|null);
            joinLimitMinute?: (number|null);
            myJoinLimitEndUnix?: (Long|null);
            androidShareText?: (string|null);
            isBigIcon?: (number|null);
        }

        class ActivityData implements IActivityData {
            constructor(p?: GameProto.IActivityData);
            public id: Long;
            public category: number;
            public name: string;
            public describle: string;
            public accessType: string;
            public levelRange: string;
            public regDays: number;
            public accCash: number;
            public prevTask: number;
            public accessTicket: number;
            public shareText: string;
            public loginType: number;
            public rewardCash: number;
            public rewardBonus: number;
            public rewardDiamond: number;
            public rewardTool: string;
            public rewardProdID: Long;
            public discount: string;
            public rewardByDays: string;
            public alertType: string;
            public beginTime: Long;
            public endTime: Long;
            public rewardInc: number;
            public recycle: string;
            public accessTimes: number;
            public templateStyle: number;
            public cycleType: number;
            public showOnIcon: number;
            public iconLine: number;
            public iconSort: number;
            public showOnTaskPage: number;
            public taskPageSort: number;
            public showOnShop: number;
            public shopSort: number;
            public state: number;
            public gid: number;
            public foreignName: string;
            public alertThreshold: string;
            public cap: number;
            public floor: number;
            public curStartUnix: Long;
            public curEndUnix: Long;
            public round: number;
            public payCfg?: (GameProto.ActivityPayInfo|null);
            public tag: string;
            public countDown: string;
            public rewardPresentation: string;
            public displayCount: string;
            public showBannerReward: string;
            public rewardToolShared: string;
            public missionSort: string;
            public bannerReward: string;
            public joinLimitMinute: number;
            public myJoinLimitEndUnix: Long;
            public androidShareText: string;
            public isBigIcon: number;
            public static create(properties?: GameProto.IActivityData): GameProto.ActivityData;
            public static encode(m: GameProto.ActivityData, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.ActivityData;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IActivityPayInfo {
            paySuccess?: (boolean|null);
            payTime?: (Long|null);
            activityEndTime?: (Long|null);
        }

        class ActivityPayInfo implements IActivityPayInfo {
            constructor(p?: GameProto.IActivityPayInfo);
            public paySuccess: boolean;
            public payTime: Long;
            public activityEndTime: Long;
            public static create(properties?: GameProto.IActivityPayInfo): GameProto.ActivityPayInfo;
            public static encode(m: GameProto.ActivityPayInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.ActivityPayInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IMyActivityInfo {
            level?: (number|null);
            regDays?: (number|null);
            totalPay?: (Long|null);
            joinActivityIdList?: (Long[]|null);
            gameType?: (number|null);
            expendCash?: (Long|null);
            uid?: (Long|null);
            pid?: (Long|null);
        }

        class MyActivityInfo implements IMyActivityInfo {
            constructor(p?: GameProto.IMyActivityInfo);
            public level: number;
            public regDays: number;
            public totalPay: Long;
            public joinActivityIdList: Long[];
            public gameType: number;
            public expendCash: Long;
            public uid: Long;
            public pid: Long;
            public static create(properties?: GameProto.IMyActivityInfo): GameProto.MyActivityInfo;
            public static encode(m: GameProto.MyActivityInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.MyActivityInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IActivityDataNotify {
            act?: (GameProto.ActivityData|null);
            closeAids?: (Long[]|null);
            timestamp?: (Long|null);
        }

        class ActivityDataNotify implements IActivityDataNotify {
            constructor(p?: GameProto.IActivityDataNotify);
            public act?: (GameProto.ActivityData|null);
            public closeAids: Long[];
            public timestamp: Long;
            public static create(properties?: GameProto.IActivityDataNotify): GameProto.ActivityDataNotify;
            public static encode(m: GameProto.ActivityDataNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.ActivityDataNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetActivityJoinCntReq {
        }

        class GetActivityJoinCntReq implements IGetActivityJoinCntReq {
            constructor(p?: GameProto.IGetActivityJoinCntReq);
            public static create(properties?: GameProto.IGetActivityJoinCntReq): GameProto.GetActivityJoinCntReq;
            public static encode(m: GameProto.GetActivityJoinCntReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetActivityJoinCntReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetActivityJoinCntResp {
            resultCode?: (number|null);
            actJoinCnt?: ({ [k: string]: number }|null);
        }

        class GetActivityJoinCntResp implements IGetActivityJoinCntResp {
            constructor(p?: GameProto.IGetActivityJoinCntResp);
            public resultCode: number;
            public actJoinCnt: { [k: string]: number };
            public static create(properties?: GameProto.IGetActivityJoinCntResp): GameProto.GetActivityJoinCntResp;
            public static encode(m: GameProto.GetActivityJoinCntResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetActivityJoinCntResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetMyActJoinLimitEndUnixReq {
            aid?: (Long|null);
        }

        class GetMyActJoinLimitEndUnixReq implements IGetMyActJoinLimitEndUnixReq {
            constructor(p?: GameProto.IGetMyActJoinLimitEndUnixReq);
            public aid: Long;
            public static create(properties?: GameProto.IGetMyActJoinLimitEndUnixReq): GameProto.GetMyActJoinLimitEndUnixReq;
            public static encode(m: GameProto.GetMyActJoinLimitEndUnixReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetMyActJoinLimitEndUnixReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetMyActJoinLimitEndUnixRsp {
            resultCode?: (number|null);
            aid?: (Long|null);
            myJoinLimitEndUnix?: (Long|null);
        }

        class GetMyActJoinLimitEndUnixRsp implements IGetMyActJoinLimitEndUnixRsp {
            constructor(p?: GameProto.IGetMyActJoinLimitEndUnixRsp);
            public resultCode: number;
            public aid: Long;
            public myJoinLimitEndUnix: Long;
            public static create(properties?: GameProto.IGetMyActJoinLimitEndUnixRsp): GameProto.GetMyActJoinLimitEndUnixRsp;
            public static encode(m: GameProto.GetMyActJoinLimitEndUnixRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetMyActJoinLimitEndUnixRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IOneBuyOneFreeUserInfoReq {
            pid?: (Long|null);
            round?: (number|null);
            aid?: (number|null);
        }

        class OneBuyOneFreeUserInfoReq implements IOneBuyOneFreeUserInfoReq {
            constructor(p?: GameProto.IOneBuyOneFreeUserInfoReq);
            public pid: Long;
            public round: number;
            public aid: number;
            public static create(properties?: GameProto.IOneBuyOneFreeUserInfoReq): GameProto.OneBuyOneFreeUserInfoReq;
            public static encode(m: GameProto.OneBuyOneFreeUserInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.OneBuyOneFreeUserInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IOneBuyOneFreeUserInfoRsp {
            PaySuccess?: (boolean|null);
            BuyTimes?: (number|null);
            AquireTimes?: (number|null);
        }

        class OneBuyOneFreeUserInfoRsp implements IOneBuyOneFreeUserInfoRsp {
            constructor(p?: GameProto.IOneBuyOneFreeUserInfoRsp);
            public PaySuccess: boolean;
            public BuyTimes: number;
            public AquireTimes: number;
            public static create(properties?: GameProto.IOneBuyOneFreeUserInfoRsp): GameProto.OneBuyOneFreeUserInfoRsp;
            public static encode(m: GameProto.OneBuyOneFreeUserInfoRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.OneBuyOneFreeUserInfoRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IOneBuyOneFreeCheckUserCanAquireReq {
            pid?: (Long|null);
            round?: (number|null);
            aid?: (number|null);
        }

        class OneBuyOneFreeCheckUserCanAquireReq implements IOneBuyOneFreeCheckUserCanAquireReq {
            constructor(p?: GameProto.IOneBuyOneFreeCheckUserCanAquireReq);
            public pid: Long;
            public round: number;
            public aid: number;
            public static create(properties?: GameProto.IOneBuyOneFreeCheckUserCanAquireReq): GameProto.OneBuyOneFreeCheckUserCanAquireReq;
            public static encode(m: GameProto.OneBuyOneFreeCheckUserCanAquireReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.OneBuyOneFreeCheckUserCanAquireReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IOneBuyOneFreeCheckUserCanAquireRsp {
            can?: (boolean|null);
        }

        class OneBuyOneFreeCheckUserCanAquireRsp implements IOneBuyOneFreeCheckUserCanAquireRsp {
            constructor(p?: GameProto.IOneBuyOneFreeCheckUserCanAquireRsp);
            public can: boolean;
            public static create(properties?: GameProto.IOneBuyOneFreeCheckUserCanAquireRsp): GameProto.OneBuyOneFreeCheckUserCanAquireRsp;
            public static encode(m: GameProto.OneBuyOneFreeCheckUserCanAquireRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.OneBuyOneFreeCheckUserCanAquireRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IOneBuyOneFreeAquireRewardReq {
            pid?: (Long|null);
            round?: (number|null);
            aid?: (number|null);
        }

        class OneBuyOneFreeAquireRewardReq implements IOneBuyOneFreeAquireRewardReq {
            constructor(p?: GameProto.IOneBuyOneFreeAquireRewardReq);
            public pid: Long;
            public round: number;
            public aid: number;
            public static create(properties?: GameProto.IOneBuyOneFreeAquireRewardReq): GameProto.OneBuyOneFreeAquireRewardReq;
            public static encode(m: GameProto.OneBuyOneFreeAquireRewardReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.OneBuyOneFreeAquireRewardReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IOneBuyOneFreeAquireRewardRsp {
            success?: (boolean|null);
        }

        class OneBuyOneFreeAquireRewardRsp implements IOneBuyOneFreeAquireRewardRsp {
            constructor(p?: GameProto.IOneBuyOneFreeAquireRewardRsp);
            public success: boolean;
            public static create(properties?: GameProto.IOneBuyOneFreeAquireRewardRsp): GameProto.OneBuyOneFreeAquireRewardRsp;
            public static encode(m: GameProto.OneBuyOneFreeAquireRewardRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.OneBuyOneFreeAquireRewardRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IOneBuyOneFreeRewardListReq {
            aid?: (number|null);
        }

        class OneBuyOneFreeRewardListReq implements IOneBuyOneFreeRewardListReq {
            constructor(p?: GameProto.IOneBuyOneFreeRewardListReq);
            public aid: number;
            public static create(properties?: GameProto.IOneBuyOneFreeRewardListReq): GameProto.OneBuyOneFreeRewardListReq;
            public static encode(m: GameProto.OneBuyOneFreeRewardListReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.OneBuyOneFreeRewardListReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IOneBuyOneFreeRewardListRsp {
            reward?: (string|null);
        }

        class OneBuyOneFreeRewardListRsp implements IOneBuyOneFreeRewardListRsp {
            constructor(p?: GameProto.IOneBuyOneFreeRewardListRsp);
            public reward: string;
            public static create(properties?: GameProto.IOneBuyOneFreeRewardListRsp): GameProto.OneBuyOneFreeRewardListRsp;
            public static encode(m: GameProto.OneBuyOneFreeRewardListRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.OneBuyOneFreeRewardListRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPiggyBankInfoReq {
            aid?: (Long|null);
            round?: (number|null);
        }

        class PiggyBankInfoReq implements IPiggyBankInfoReq {
            constructor(p?: GameProto.IPiggyBankInfoReq);
            public aid: Long;
            public round: number;
            public static create(properties?: GameProto.IPiggyBankInfoReq): GameProto.PiggyBankInfoReq;
            public static encode(m: GameProto.PiggyBankInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.PiggyBankInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPiggyBankInfoResp {
            value?: (Long|null);
            cash?: (Long|null);
            bonus?: (Long|null);
            diamond?: (Long|null);
            exp?: (Long|null);
            perExp?: (Long|null);
        }

        class PiggyBankInfoResp implements IPiggyBankInfoResp {
            constructor(p?: GameProto.IPiggyBankInfoResp);
            public value: Long;
            public cash: Long;
            public bonus: Long;
            public diamond: Long;
            public exp: Long;
            public perExp: Long;
            public static create(properties?: GameProto.IPiggyBankInfoResp): GameProto.PiggyBankInfoResp;
            public static encode(m: GameProto.PiggyBankInfoResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.PiggyBankInfoResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPiggyBankInfoNotify {
            pid?: (Long|null);
            pre?: (Long|null);
            nxt?: (Long|null);
        }

        class PiggyBankInfoNotify implements IPiggyBankInfoNotify {
            constructor(p?: GameProto.IPiggyBankInfoNotify);
            public pid: Long;
            public pre: Long;
            public nxt: Long;
            public static create(properties?: GameProto.IPiggyBankInfoNotify): GameProto.PiggyBankInfoNotify;
            public static encode(m: GameProto.PiggyBankInfoNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.PiggyBankInfoNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ISevenDaysRewardsUserInfoReq {
            pid?: (Long|null);
            aid?: (Long|null);
            round?: (Long|null);
        }

        class SevenDaysRewardsUserInfoReq implements ISevenDaysRewardsUserInfoReq {
            constructor(p?: GameProto.ISevenDaysRewardsUserInfoReq);
            public pid: Long;
            public aid: Long;
            public round: Long;
            public static create(properties?: GameProto.ISevenDaysRewardsUserInfoReq): GameProto.SevenDaysRewardsUserInfoReq;
            public static encode(m: GameProto.SevenDaysRewardsUserInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.SevenDaysRewardsUserInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ISevenDaysRewardsUserInfoRsp {
            reward?: (string|null);
            paySuccess?: (boolean|null);
            daysAquireInfo?: (boolean[]|null);
            daysCanAquireInfo?: (boolean[]|null);
            timestamp?: (Long|null);
            endTimestamp?: (Long|null);
        }

        class SevenDaysRewardsUserInfoRsp implements ISevenDaysRewardsUserInfoRsp {
            constructor(p?: GameProto.ISevenDaysRewardsUserInfoRsp);
            public reward: string;
            public paySuccess: boolean;
            public daysAquireInfo: boolean[];
            public daysCanAquireInfo: boolean[];
            public timestamp: Long;
            public endTimestamp: Long;
            public static create(properties?: GameProto.ISevenDaysRewardsUserInfoRsp): GameProto.SevenDaysRewardsUserInfoRsp;
            public static encode(m: GameProto.SevenDaysRewardsUserInfoRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.SevenDaysRewardsUserInfoRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ISevenDaysRewardUserAquireRewardsReq {
            pid?: (Long|null);
            aid?: (Long|null);
            round?: (Long|null);
            aquireDays?: (number[]|null);
            flag?: (boolean|null);
        }

        class SevenDaysRewardUserAquireRewardsReq implements ISevenDaysRewardUserAquireRewardsReq {
            constructor(p?: GameProto.ISevenDaysRewardUserAquireRewardsReq);
            public pid: Long;
            public aid: Long;
            public round: Long;
            public aquireDays: number[];
            public flag: boolean;
            public static create(properties?: GameProto.ISevenDaysRewardUserAquireRewardsReq): GameProto.SevenDaysRewardUserAquireRewardsReq;
            public static encode(m: GameProto.SevenDaysRewardUserAquireRewardsReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.SevenDaysRewardUserAquireRewardsReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ISevenDaysRewardUserAquireRewardsRsp {
            success?: (boolean|null);
        }

        class SevenDaysRewardUserAquireRewardsRsp implements ISevenDaysRewardUserAquireRewardsRsp {
            constructor(p?: GameProto.ISevenDaysRewardUserAquireRewardsRsp);
            public success: boolean;
            public static create(properties?: GameProto.ISevenDaysRewardUserAquireRewardsRsp): GameProto.SevenDaysRewardUserAquireRewardsRsp;
            public static encode(m: GameProto.SevenDaysRewardUserAquireRewardsRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.SevenDaysRewardUserAquireRewardsRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPayNoADSInfoReq {
            aid?: (Long|null);
        }

        class PayNoADSInfoReq implements IPayNoADSInfoReq {
            constructor(p?: GameProto.IPayNoADSInfoReq);
            public aid: Long;
            public static create(properties?: GameProto.IPayNoADSInfoReq): GameProto.PayNoADSInfoReq;
            public static encode(m: GameProto.PayNoADSInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.PayNoADSInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPayNoADSInfoResp {
            freeEndTime?: (Long|null);
        }

        class PayNoADSInfoResp implements IPayNoADSInfoResp {
            constructor(p?: GameProto.IPayNoADSInfoResp);
            public freeEndTime: Long;
            public static create(properties?: GameProto.IPayNoADSInfoResp): GameProto.PayNoADSInfoResp;
            public static encode(m: GameProto.PayNoADSInfoResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.PayNoADSInfoResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetTwoDaysPassUserInfoReq {
            pid?: (Long|null);
            aid?: (Long|null);
            round?: (Long|null);
        }

        class GetTwoDaysPassUserInfoReq implements IGetTwoDaysPassUserInfoReq {
            constructor(p?: GameProto.IGetTwoDaysPassUserInfoReq);
            public pid: Long;
            public aid: Long;
            public round: Long;
            public static create(properties?: GameProto.IGetTwoDaysPassUserInfoReq): GameProto.GetTwoDaysPassUserInfoReq;
            public static encode(m: GameProto.GetTwoDaysPassUserInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetTwoDaysPassUserInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetTwoDaysPassUserInfoResp {
            paySuccess?: (boolean|null);
            payTime?: (Long|null);
            dayOne?: (boolean|null);
            dayTwo?: (boolean|null);
            endTimestamp?: (Long|null);
        }

        class GetTwoDaysPassUserInfoResp implements IGetTwoDaysPassUserInfoResp {
            constructor(p?: GameProto.IGetTwoDaysPassUserInfoResp);
            public paySuccess: boolean;
            public payTime: Long;
            public dayOne: boolean;
            public dayTwo: boolean;
            public endTimestamp: Long;
            public static create(properties?: GameProto.IGetTwoDaysPassUserInfoResp): GameProto.GetTwoDaysPassUserInfoResp;
            public static encode(m: GameProto.GetTwoDaysPassUserInfoResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetTwoDaysPassUserInfoResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IAquireTwoDaysPassReq {
            pid?: (Long|null);
            aid?: (Long|null);
            round?: (Long|null);
        }

        class AquireTwoDaysPassReq implements IAquireTwoDaysPassReq {
            constructor(p?: GameProto.IAquireTwoDaysPassReq);
            public pid: Long;
            public aid: Long;
            public round: Long;
            public static create(properties?: GameProto.IAquireTwoDaysPassReq): GameProto.AquireTwoDaysPassReq;
            public static encode(m: GameProto.AquireTwoDaysPassReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.AquireTwoDaysPassReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IAquireTwoDaysPassResp {
            success?: (boolean|null);
        }

        class AquireTwoDaysPassResp implements IAquireTwoDaysPassResp {
            constructor(p?: GameProto.IAquireTwoDaysPassResp);
            public success: boolean;
            public static create(properties?: GameProto.IAquireTwoDaysPassResp): GameProto.AquireTwoDaysPassResp;
            public static encode(m: GameProto.AquireTwoDaysPassResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.AquireTwoDaysPassResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IInviteCodeGetReq {
        }

        class InviteCodeGetReq implements IInviteCodeGetReq {
            constructor(p?: GameProto.IInviteCodeGetReq);
            public static create(properties?: GameProto.IInviteCodeGetReq): GameProto.InviteCodeGetReq;
            public static encode(m: GameProto.InviteCodeGetReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.InviteCodeGetReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IInviteCodeGetRsp {
            inviteCode?: (string|null);
            bindInvitePid?: (Long|null);
        }

        class InviteCodeGetRsp implements IInviteCodeGetRsp {
            constructor(p?: GameProto.IInviteCodeGetRsp);
            public inviteCode: string;
            public bindInvitePid: Long;
            public static create(properties?: GameProto.IInviteCodeGetRsp): GameProto.InviteCodeGetRsp;
            public static encode(m: GameProto.InviteCodeGetRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.InviteCodeGetRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IInviteCodeBindReq {
            inviteCode?: (string|null);
        }

        class InviteCodeBindReq implements IInviteCodeBindReq {
            constructor(p?: GameProto.IInviteCodeBindReq);
            public inviteCode: string;
            public static create(properties?: GameProto.IInviteCodeBindReq): GameProto.InviteCodeBindReq;
            public static encode(m: GameProto.InviteCodeBindReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.InviteCodeBindReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IInviteCodeBindRsp {
            resultCode?: (number|null);
        }

        class InviteCodeBindRsp implements IInviteCodeBindRsp {
            constructor(p?: GameProto.IInviteCodeBindRsp);
            public resultCode: number;
            public static create(properties?: GameProto.IInviteCodeBindRsp): GameProto.InviteCodeBindRsp;
            public static encode(m: GameProto.InviteCodeBindRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.InviteCodeBindRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IInviteCodeVerifyReq {
            inviteCode?: (string|null);
        }

        class InviteCodeVerifyReq implements IInviteCodeVerifyReq {
            constructor(p?: GameProto.IInviteCodeVerifyReq);
            public inviteCode: string;
            public static create(properties?: GameProto.IInviteCodeVerifyReq): GameProto.InviteCodeVerifyReq;
            public static encode(m: GameProto.InviteCodeVerifyReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.InviteCodeVerifyReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IInviteCodeVerifyRsp {
            resultCode?: (number|null);
        }

        class InviteCodeVerifyRsp implements IInviteCodeVerifyRsp {
            constructor(p?: GameProto.IInviteCodeVerifyRsp);
            public resultCode: number;
            public static create(properties?: GameProto.IInviteCodeVerifyRsp): GameProto.InviteCodeVerifyRsp;
            public static encode(m: GameProto.InviteCodeVerifyRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.InviteCodeVerifyRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IInviteCodeInfo {
            id?: (Long|null);
            newPid?: (Long|null);
            nickname?: (string|null);
            createTime?: (Long|null);
            received?: (number|null);
            rewardTool?: (string|null);
        }

        class InviteCodeInfo implements IInviteCodeInfo {
            constructor(p?: GameProto.IInviteCodeInfo);
            public id: Long;
            public newPid: Long;
            public nickname: string;
            public createTime: Long;
            public received: number;
            public rewardTool: string;
            public static create(properties?: GameProto.IInviteCodeInfo): GameProto.InviteCodeInfo;
            public static encode(m: GameProto.InviteCodeInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.InviteCodeInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IInviteCodeBindListReq {
            actID?: (Long|null);
            round?: (number|null);
            received?: (number|null);
        }

        class InviteCodeBindListReq implements IInviteCodeBindListReq {
            constructor(p?: GameProto.IInviteCodeBindListReq);
            public actID: Long;
            public round: number;
            public received: number;
            public static create(properties?: GameProto.IInviteCodeBindListReq): GameProto.InviteCodeBindListReq;
            public static encode(m: GameProto.InviteCodeBindListReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.InviteCodeBindListReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IInviteCodeBindListRsp {
            resultCode?: (number|null);
            list?: (GameProto.InviteCodeInfo[]|null);
        }

        class InviteCodeBindListRsp implements IInviteCodeBindListRsp {
            constructor(p?: GameProto.IInviteCodeBindListRsp);
            public resultCode: number;
            public list: GameProto.InviteCodeInfo[];
            public static create(properties?: GameProto.IInviteCodeBindListRsp): GameProto.InviteCodeBindListRsp;
            public static encode(m: GameProto.InviteCodeBindListRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.InviteCodeBindListRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IInviteCodeReceiveRewardReq {
            id?: (Long|null);
        }

        class InviteCodeReceiveRewardReq implements IInviteCodeReceiveRewardReq {
            constructor(p?: GameProto.IInviteCodeReceiveRewardReq);
            public id: Long;
            public static create(properties?: GameProto.IInviteCodeReceiveRewardReq): GameProto.InviteCodeReceiveRewardReq;
            public static encode(m: GameProto.InviteCodeReceiveRewardReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.InviteCodeReceiveRewardReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IInviteCodeReceiveRewardRsp {
            resultCode?: (number|null);
            id?: (Long|null);
        }

        class InviteCodeReceiveRewardRsp implements IInviteCodeReceiveRewardRsp {
            constructor(p?: GameProto.IInviteCodeReceiveRewardRsp);
            public resultCode: number;
            public id: Long;
            public static create(properties?: GameProto.IInviteCodeReceiveRewardRsp): GameProto.InviteCodeReceiveRewardRsp;
            public static encode(m: GameProto.InviteCodeReceiveRewardRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.InviteCodeReceiveRewardRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IMarkCodeGradeReq {
            matchguid?: (Long|null);
            grade?: (number|null);
        }

        class MarkCodeGradeReq implements IMarkCodeGradeReq {
            constructor(p?: GameProto.IMarkCodeGradeReq);
            public matchguid: Long;
            public grade: number;
            public static create(properties?: GameProto.IMarkCodeGradeReq): GameProto.MarkCodeGradeReq;
            public static encode(m: GameProto.MarkCodeGradeReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.MarkCodeGradeReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IMarkCodeGradeRsp {
            resultCode?: (number|null);
        }

        class MarkCodeGradeRsp implements IMarkCodeGradeRsp {
            constructor(p?: GameProto.IMarkCodeGradeRsp);
            public resultCode: number;
            public static create(properties?: GameProto.IMarkCodeGradeRsp): GameProto.MarkCodeGradeRsp;
            public static encode(m: GameProto.MarkCodeGradeRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.MarkCodeGradeRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetMarkCodeGradeReq {
            matchguid?: (Long|null);
        }

        class GetMarkCodeGradeReq implements IGetMarkCodeGradeReq {
            constructor(p?: GameProto.IGetMarkCodeGradeReq);
            public matchguid: Long;
            public static create(properties?: GameProto.IGetMarkCodeGradeReq): GameProto.GetMarkCodeGradeReq;
            public static encode(m: GameProto.GetMarkCodeGradeReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetMarkCodeGradeReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetMarkCodeGradeRsp {
            resultCode?: (number|null);
            matchguid?: (Long|null);
            grade?: (number|null);
        }

        class GetMarkCodeGradeRsp implements IGetMarkCodeGradeRsp {
            constructor(p?: GameProto.IGetMarkCodeGradeRsp);
            public resultCode: number;
            public matchguid: Long;
            public grade: number;
            public static create(properties?: GameProto.IGetMarkCodeGradeRsp): GameProto.GetMarkCodeGradeRsp;
            public static encode(m: GameProto.GetMarkCodeGradeRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetMarkCodeGradeRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ICdKeyReq {
            cdKey?: (string|null);
        }

        class CdKeyReq implements ICdKeyReq {
            constructor(p?: GameProto.ICdKeyReq);
            public cdKey: string;
            public static create(properties?: GameProto.ICdKeyReq): GameProto.CdKeyReq;
            public static encode(m: GameProto.CdKeyReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.CdKeyReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ICdKeyRsp {
            resultCode?: (number|null);
        }

        class CdKeyRsp implements ICdKeyRsp {
            constructor(p?: GameProto.ICdKeyRsp);
            public resultCode: number;
            public static create(properties?: GameProto.ICdKeyRsp): GameProto.CdKeyRsp;
            public static encode(m: GameProto.CdKeyRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.CdKeyRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ICodeCheckReq {
            code?: (string|null);
        }

        class CodeCheckReq implements ICodeCheckReq {
            constructor(p?: GameProto.ICodeCheckReq);
            public code: string;
            public static create(properties?: GameProto.ICodeCheckReq): GameProto.CodeCheckReq;
            public static encode(m: GameProto.CodeCheckReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.CodeCheckReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ICodeCheckRsp {
            resultCode?: (number|null);
            rewards?: (string|null);
            status?: (number|null);
        }

        class CodeCheckRsp implements ICodeCheckRsp {
            constructor(p?: GameProto.ICodeCheckRsp);
            public resultCode: number;
            public rewards: string;
            public status: number;
            public static create(properties?: GameProto.ICodeCheckRsp): GameProto.CodeCheckRsp;
            public static encode(m: GameProto.CodeCheckRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.CodeCheckRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserUpdateCupsReq {
            uid?: (Long|null);
            pid?: (Long|null);
            addCash?: (Long|null);
        }

        class UserUpdateCupsReq implements IUserUpdateCupsReq {
            constructor(p?: GameProto.IUserUpdateCupsReq);
            public uid: Long;
            public pid: Long;
            public addCash: Long;
            public static create(properties?: GameProto.IUserUpdateCupsReq): GameProto.UserUpdateCupsReq;
            public static encode(m: GameProto.UserUpdateCupsReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserUpdateCupsReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserUpdateCupsRsp {
            success?: (boolean|null);
        }

        class UserUpdateCupsRsp implements IUserUpdateCupsRsp {
            constructor(p?: GameProto.IUserUpdateCupsRsp);
            public success: boolean;
            public static create(properties?: GameProto.IUserUpdateCupsRsp): GameProto.UserUpdateCupsRsp;
            public static encode(m: GameProto.UserUpdateCupsRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserUpdateCupsRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserStageReq {
            uid?: (Long|null);
            pid?: (Long|null);
        }

        class GetUserStageReq implements IGetUserStageReq {
            constructor(p?: GameProto.IGetUserStageReq);
            public uid: Long;
            public pid: Long;
            public static create(properties?: GameProto.IGetUserStageReq): GameProto.GetUserStageReq;
            public static encode(m: GameProto.GetUserStageReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserStageReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserStageRsp {
            stage?: (Long|null);
            cups?: (Long|null);
            timestamp?: (Long|null);
            endTimestamp?: (Long|null);
            hasReward?: (boolean|null);
            isActive?: (boolean|null);
            isAck?: (boolean|null);
            isOnSettling?: (boolean|null);
        }

        class GetUserStageRsp implements IGetUserStageRsp {
            constructor(p?: GameProto.IGetUserStageRsp);
            public stage: Long;
            public cups: Long;
            public timestamp: Long;
            public endTimestamp: Long;
            public hasReward: boolean;
            public isActive: boolean;
            public isAck: boolean;
            public isOnSettling: boolean;
            public static create(properties?: GameProto.IGetUserStageRsp): GameProto.GetUserStageRsp;
            public static encode(m: GameProto.GetUserStageRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserStageRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IRankInfo {
            uid?: (Long|null);
            pid?: (Long|null);
            cups?: (Long|null);
            order?: (Long|null);
            name?: (string|null);
            avatar?: (string|null);
        }

        class RankInfo implements IRankInfo {
            constructor(p?: GameProto.IRankInfo);
            public uid: Long;
            public pid: Long;
            public cups: Long;
            public order: Long;
            public name: string;
            public avatar: string;
            public static create(properties?: GameProto.IRankInfo): GameProto.RankInfo;
            public static encode(m: GameProto.RankInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.RankInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserGroupInfoReq {
            pid?: (Long|null);
        }

        class GetUserGroupInfoReq implements IGetUserGroupInfoReq {
            constructor(p?: GameProto.IGetUserGroupInfoReq);
            public pid: Long;
            public static create(properties?: GameProto.IGetUserGroupInfoReq): GameProto.GetUserGroupInfoReq;
            public static encode(m: GameProto.GetUserGroupInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserGroupInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserGroupInfoRsp {
            "null"?: (boolean|null);
            rankInfo?: (GameProto.RankInfo[]|null);
        }

        class GetUserGroupInfoRsp implements IGetUserGroupInfoRsp {
            constructor(p?: GameProto.IGetUserGroupInfoRsp);
            public null: boolean;
            public rankInfo: GameProto.RankInfo[];
            public static create(properties?: GameProto.IGetUserGroupInfoRsp): GameProto.GetUserGroupInfoRsp;
            public static encode(m: GameProto.GetUserGroupInfoRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserGroupInfoRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserProtoRewardInfoReq {
            pid?: (Long|null);
        }

        class GetUserProtoRewardInfoReq implements IGetUserProtoRewardInfoReq {
            constructor(p?: GameProto.IGetUserProtoRewardInfoReq);
            public pid: Long;
            public static create(properties?: GameProto.IGetUserProtoRewardInfoReq): GameProto.GetUserProtoRewardInfoReq;
            public static encode(m: GameProto.GetUserProtoRewardInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserProtoRewardInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IRankRewardInfo {
            stage?: (Long|null);
            reward?: (string|null);
            weeks?: (Long|null);
            cups?: (Long|null);
            rank?: (Long|null);
            isUpgrade?: (boolean|null);
        }

        class RankRewardInfo implements IRankRewardInfo {
            constructor(p?: GameProto.IRankRewardInfo);
            public stage: Long;
            public reward: string;
            public weeks: Long;
            public cups: Long;
            public rank: Long;
            public isUpgrade: boolean;
            public static create(properties?: GameProto.IRankRewardInfo): GameProto.RankRewardInfo;
            public static encode(m: GameProto.RankRewardInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.RankRewardInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserProtoRewardInfoRsp {
            "null"?: (boolean|null);
            rewards?: (GameProto.RankRewardInfo[]|null);
        }

        class GetUserProtoRewardInfoRsp implements IGetUserProtoRewardInfoRsp {
            constructor(p?: GameProto.IGetUserProtoRewardInfoRsp);
            public null: boolean;
            public rewards: GameProto.RankRewardInfo[];
            public static create(properties?: GameProto.IGetUserProtoRewardInfoRsp): GameProto.GetUserProtoRewardInfoRsp;
            public static encode(m: GameProto.GetUserProtoRewardInfoRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserProtoRewardInfoRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserWeeklyRankSettleRewardReq {
            pid?: (Long|null);
        }

        class GetUserWeeklyRankSettleRewardReq implements IGetUserWeeklyRankSettleRewardReq {
            constructor(p?: GameProto.IGetUserWeeklyRankSettleRewardReq);
            public pid: Long;
            public static create(properties?: GameProto.IGetUserWeeklyRankSettleRewardReq): GameProto.GetUserWeeklyRankSettleRewardReq;
            public static encode(m: GameProto.GetUserWeeklyRankSettleRewardReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserWeeklyRankSettleRewardReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserWeeklyRankSettleRewardRsp {
            "null"?: (boolean|null);
            rewards?: (GameProto.RankRewardInfo[]|null);
        }

        class GetUserWeeklyRankSettleRewardRsp implements IGetUserWeeklyRankSettleRewardRsp {
            constructor(p?: GameProto.IGetUserWeeklyRankSettleRewardRsp);
            public null: boolean;
            public rewards: GameProto.RankRewardInfo[];
            public static create(properties?: GameProto.IGetUserWeeklyRankSettleRewardRsp): GameProto.GetUserWeeklyRankSettleRewardRsp;
            public static encode(m: GameProto.GetUserWeeklyRankSettleRewardRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserWeeklyRankSettleRewardRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IActFriendSupportTaskNotify {
            taskCfg?: (GameProto.ActFriendSupportCfgItem|null);
            bindNum?: (number|null);
            compTaskNum?: (number|null);
        }

        class ActFriendSupportTaskNotify implements IActFriendSupportTaskNotify {
            constructor(p?: GameProto.IActFriendSupportTaskNotify);
            public taskCfg?: (GameProto.ActFriendSupportCfgItem|null);
            public bindNum: number;
            public compTaskNum: number;
            public static create(properties?: GameProto.IActFriendSupportTaskNotify): GameProto.ActFriendSupportTaskNotify;
            public static encode(m: GameProto.ActFriendSupportTaskNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.ActFriendSupportTaskNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IActFriendSupportCfgItem {
            id?: (number|null);
            name?: (string|null);
            taskType?: (number|null);
            taskName?: (Long|null);
            taskContent?: (Long|null);
            playerNum?: (number|null);
            rewardItem?: (string|null);
        }

        class ActFriendSupportCfgItem implements IActFriendSupportCfgItem {
            constructor(p?: GameProto.IActFriendSupportCfgItem);
            public id: number;
            public name: string;
            public taskType: number;
            public taskName: Long;
            public taskContent: Long;
            public playerNum: number;
            public rewardItem: string;
            public static create(properties?: GameProto.IActFriendSupportCfgItem): GameProto.ActFriendSupportCfgItem;
            public static encode(m: GameProto.ActFriendSupportCfgItem, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.ActFriendSupportCfgItem;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IWeeklyRankConst {
            Id?: (Long|null);
            Stage?: (Long|null);
            Rewards?: (string|null);
            PromotionCup?: (Long|null);
            AutoPromotionRanking?: (Long|null);
        }

        class WeeklyRankConst implements IWeeklyRankConst {
            constructor(p?: GameProto.IWeeklyRankConst);
            public Id: Long;
            public Stage: Long;
            public Rewards: string;
            public PromotionCup: Long;
            public AutoPromotionRanking: Long;
            public static create(properties?: GameProto.IWeeklyRankConst): GameProto.WeeklyRankConst;
            public static encode(m: GameProto.WeeklyRankConst, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.WeeklyRankConst;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IWeeklyRankConstReq {
        }

        class WeeklyRankConstReq implements IWeeklyRankConstReq {
            constructor(p?: GameProto.IWeeklyRankConstReq);
            public static create(properties?: GameProto.IWeeklyRankConstReq): GameProto.WeeklyRankConstReq;
            public static encode(m: GameProto.WeeklyRankConstReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.WeeklyRankConstReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IWeeklyRankConstRsp {
            Const?: (GameProto.WeeklyRankConst[]|null);
            EligibilityLevel?: (Long|null);
            CashToCupRates?: (Long|null);
            Others?: (string|null);
        }

        class WeeklyRankConstRsp implements IWeeklyRankConstRsp {
            constructor(p?: GameProto.IWeeklyRankConstRsp);
            public Const: GameProto.WeeklyRankConst[];
            public EligibilityLevel: Long;
            public CashToCupRates: Long;
            public Others: string;
            public static create(properties?: GameProto.IWeeklyRankConstRsp): GameProto.WeeklyRankConstRsp;
            public static encode(m: GameProto.WeeklyRankConstRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.WeeklyRankConstRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserStageUpgradeRewardReq {
            pid?: (Long|null);
            stage?: (Long|null);
            week?: (Long|null);
        }

        class GetUserStageUpgradeRewardReq implements IGetUserStageUpgradeRewardReq {
            constructor(p?: GameProto.IGetUserStageUpgradeRewardReq);
            public pid: Long;
            public stage: Long;
            public week: Long;
            public static create(properties?: GameProto.IGetUserStageUpgradeRewardReq): GameProto.GetUserStageUpgradeRewardReq;
            public static encode(m: GameProto.GetUserStageUpgradeRewardReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserStageUpgradeRewardReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserStageUpgradeRewardRsp {
            success?: (boolean|null);
        }

        class GetUserStageUpgradeRewardRsp implements IGetUserStageUpgradeRewardRsp {
            constructor(p?: GameProto.IGetUserStageUpgradeRewardRsp);
            public success: boolean;
            public static create(properties?: GameProto.IGetUserStageUpgradeRewardRsp): GameProto.GetUserStageUpgradeRewardRsp;
            public static encode(m: GameProto.GetUserStageUpgradeRewardRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserStageUpgradeRewardRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserWeeklySettleRewardReq {
            pid?: (Long|null);
            stage?: (Long|null);
            week?: (Long|null);
        }

        class GetUserWeeklySettleRewardReq implements IGetUserWeeklySettleRewardReq {
            constructor(p?: GameProto.IGetUserWeeklySettleRewardReq);
            public pid: Long;
            public stage: Long;
            public week: Long;
            public static create(properties?: GameProto.IGetUserWeeklySettleRewardReq): GameProto.GetUserWeeklySettleRewardReq;
            public static encode(m: GameProto.GetUserWeeklySettleRewardReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserWeeklySettleRewardReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserWeeklySettleRewardRsp {
            success?: (boolean|null);
        }

        class GetUserWeeklySettleRewardRsp implements IGetUserWeeklySettleRewardRsp {
            constructor(p?: GameProto.IGetUserWeeklySettleRewardRsp);
            public success: boolean;
            public static create(properties?: GameProto.IGetUserWeeklySettleRewardRsp): GameProto.GetUserWeeklySettleRewardRsp;
            public static encode(m: GameProto.GetUserWeeklySettleRewardRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserWeeklySettleRewardRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetQuestionConstReq {
        }

        class GetQuestionConstReq implements IGetQuestionConstReq {
            constructor(p?: GameProto.IGetQuestionConstReq);
            public static create(properties?: GameProto.IGetQuestionConstReq): GameProto.GetQuestionConstReq;
            public static encode(m: GameProto.GetQuestionConstReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetQuestionConstReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IOption {
            id?: (Long|null);
            type?: (number|null);
            displayOrder?: (number|null);
            text?: (string|null);
            attachID?: (Long|null);
        }

        class Option implements IOption {
            constructor(p?: GameProto.IOption);
            public id: Long;
            public type: number;
            public displayOrder: number;
            public text: string;
            public attachID: Long;
            public static create(properties?: GameProto.IOption): GameProto.Option;
            public static encode(m: GameProto.Option, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.Option;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IQuestion {
            id?: (Long|null);
            type?: (number|null);
            displayOrder?: (number|null);
            question?: (Long|null);
            text?: (string|null);
            options?: (GameProto.Option[]|null);
        }

        class Question implements IQuestion {
            constructor(p?: GameProto.IQuestion);
            public id: Long;
            public type: number;
            public displayOrder: number;
            public question: Long;
            public text: string;
            public options: GameProto.Option[];
            public static create(properties?: GameProto.IQuestion): GameProto.Question;
            public static encode(m: GameProto.Question, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.Question;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetQuestionConstResp {
            Questions?: (GameProto.Question[]|null);
            isJoin?: (boolean|null);
            rewardQ?: (string|null);
            rewardF?: (string|null);
            count?: (number|null);
            hasRewards?: (boolean|null);
            myFeedbackNum?: (number|null);
            myFeedbackWord?: (number|null);
        }

        class GetQuestionConstResp implements IGetQuestionConstResp {
            constructor(p?: GameProto.IGetQuestionConstResp);
            public Questions: GameProto.Question[];
            public isJoin: boolean;
            public rewardQ: string;
            public rewardF: string;
            public count: number;
            public hasRewards: boolean;
            public myFeedbackNum: number;
            public myFeedbackWord: number;
            public static create(properties?: GameProto.IGetQuestionConstResp): GameProto.GetQuestionConstResp;
            public static encode(m: GameProto.GetQuestionConstResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetQuestionConstResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface Ianswer {
            id?: (Long|null);
            type?: (number|null);
            options?: (Long[]|null);
        }

        class answer implements Ianswer {
            constructor(p?: GameProto.Ianswer);
            public id: Long;
            public type: number;
            public options: Long[];
            public static create(properties?: GameProto.Ianswer): GameProto.answer;
            public static encode(m: GameProto.answer, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.answer;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserQuestionDataUploadReq {
            Answers?: (GameProto.answer[]|null);
        }

        class UserQuestionDataUploadReq implements IUserQuestionDataUploadReq {
            constructor(p?: GameProto.IUserQuestionDataUploadReq);
            public Answers: GameProto.answer[];
            public static create(properties?: GameProto.IUserQuestionDataUploadReq): GameProto.UserQuestionDataUploadReq;
            public static encode(m: GameProto.UserQuestionDataUploadReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserQuestionDataUploadReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserQuestionDataUploadResp {
            success?: (boolean|null);
        }

        class UserQuestionDataUploadResp implements IUserQuestionDataUploadResp {
            constructor(p?: GameProto.IUserQuestionDataUploadResp);
            public success: boolean;
            public static create(properties?: GameProto.IUserQuestionDataUploadResp): GameProto.UserQuestionDataUploadResp;
            public static encode(m: GameProto.UserQuestionDataUploadResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserQuestionDataUploadResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserFeedBackInfoReq {
            limit?: (number|null);
            offset?: (number|null);
        }

        class GetUserFeedBackInfoReq implements IGetUserFeedBackInfoReq {
            constructor(p?: GameProto.IGetUserFeedBackInfoReq);
            public limit: number;
            public offset: number;
            public static create(properties?: GameProto.IGetUserFeedBackInfoReq): GameProto.GetUserFeedBackInfoReq;
            public static encode(m: GameProto.GetUserFeedBackInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserFeedBackInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IFeedBack {
            id?: (Long|null);
            data?: (string|null);
            status?: (number|null);
            timestamp?: (Long|null);
            rewards?: (string|null);
            remarks?: (string|null);
        }

        class FeedBack implements IFeedBack {
            constructor(p?: GameProto.IFeedBack);
            public id: Long;
            public data: string;
            public status: number;
            public timestamp: Long;
            public rewards: string;
            public remarks: string;
            public static create(properties?: GameProto.IFeedBack): GameProto.FeedBack;
            public static encode(m: GameProto.FeedBack, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.FeedBack;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserFeedbackInfoResp {
            reward?: (string|null);
            feedback?: (GameProto.FeedBack[]|null);
        }

        class GetUserFeedbackInfoResp implements IGetUserFeedbackInfoResp {
            constructor(p?: GameProto.IGetUserFeedbackInfoResp);
            public reward: string;
            public feedback: GameProto.FeedBack[];
            public static create(properties?: GameProto.IGetUserFeedbackInfoResp): GameProto.GetUserFeedbackInfoResp;
            public static encode(m: GameProto.GetUserFeedbackInfoResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserFeedbackInfoResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserFeedBackUploadReq {
            feedback?: (string|null);
            aid?: (Long|null);
        }

        class UserFeedBackUploadReq implements IUserFeedBackUploadReq {
            constructor(p?: GameProto.IUserFeedBackUploadReq);
            public feedback: string;
            public aid: Long;
            public static create(properties?: GameProto.IUserFeedBackUploadReq): GameProto.UserFeedBackUploadReq;
            public static encode(m: GameProto.UserFeedBackUploadReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserFeedBackUploadReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserFeedBackUploadResp {
            success?: (boolean|null);
        }

        class UserFeedBackUploadResp implements IUserFeedBackUploadResp {
            constructor(p?: GameProto.IUserFeedBackUploadResp);
            public success: boolean;
            public static create(properties?: GameProto.IUserFeedBackUploadResp): GameProto.UserFeedBackUploadResp;
            public static encode(m: GameProto.UserFeedBackUploadResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserFeedBackUploadResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserFeedBackRewardReq {
            pid?: (Long|null);
            ID?: (Long[]|null);
            getAll?: (boolean|null);
        }

        class GetUserFeedBackRewardReq implements IGetUserFeedBackRewardReq {
            constructor(p?: GameProto.IGetUserFeedBackRewardReq);
            public pid: Long;
            public ID: Long[];
            public getAll: boolean;
            public static create(properties?: GameProto.IGetUserFeedBackRewardReq): GameProto.GetUserFeedBackRewardReq;
            public static encode(m: GameProto.GetUserFeedBackRewardReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserFeedBackRewardReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserFeedBackRewardResp {
            success?: (boolean|null);
            hasReward?: (boolean|null);
        }

        class GetUserFeedBackRewardResp implements IGetUserFeedBackRewardResp {
            constructor(p?: GameProto.IGetUserFeedBackRewardResp);
            public success: boolean;
            public hasReward: boolean;
            public static create(properties?: GameProto.IGetUserFeedBackRewardResp): GameProto.GetUserFeedBackRewardResp;
            public static encode(m: GameProto.GetUserFeedBackRewardResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserFeedBackRewardResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserFlipOfFateInfoReq {
            aid?: (Long|null);
        }

        class GetUserFlipOfFateInfoReq implements IGetUserFlipOfFateInfoReq {
            constructor(p?: GameProto.IGetUserFlipOfFateInfoReq);
            public aid: Long;
            public static create(properties?: GameProto.IGetUserFlipOfFateInfoReq): GameProto.GetUserFlipOfFateInfoReq;
            public static encode(m: GameProto.GetUserFlipOfFateInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserFlipOfFateInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserFlipOfFateInfoRsp {
            goodsID?: (Long|null);
            cards?: (Long[]|null);
            hasDisplay?: (boolean|null);
            hasPay?: (boolean|null);
            recordID?: (Long|null);
            per?: (Long|null);
        }

        class GetUserFlipOfFateInfoRsp implements IGetUserFlipOfFateInfoRsp {
            constructor(p?: GameProto.IGetUserFlipOfFateInfoRsp);
            public goodsID: Long;
            public cards: Long[];
            public hasDisplay: boolean;
            public hasPay: boolean;
            public recordID: Long;
            public per: Long;
            public static create(properties?: GameProto.IGetUserFlipOfFateInfoRsp): GameProto.GetUserFlipOfFateInfoRsp;
            public static encode(m: GameProto.GetUserFlipOfFateInfoRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.GetUserFlipOfFateInfoRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserFlipThreeCardsInfoUploadReq {
            aid?: (Long|null);
        }

        class UserFlipThreeCardsInfoUploadReq implements IUserFlipThreeCardsInfoUploadReq {
            constructor(p?: GameProto.IUserFlipThreeCardsInfoUploadReq);
            public aid: Long;
            public static create(properties?: GameProto.IUserFlipThreeCardsInfoUploadReq): GameProto.UserFlipThreeCardsInfoUploadReq;
            public static encode(m: GameProto.UserFlipThreeCardsInfoUploadReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserFlipThreeCardsInfoUploadReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserFlipThreeCardsInfoUploadResp {
            success?: (boolean|null);
        }

        class UserFlipThreeCardsInfoUploadResp implements IUserFlipThreeCardsInfoUploadResp {
            constructor(p?: GameProto.IUserFlipThreeCardsInfoUploadResp);
            public success: boolean;
            public static create(properties?: GameProto.IUserFlipThreeCardsInfoUploadResp): GameProto.UserFlipThreeCardsInfoUploadResp;
            public static encode(m: GameProto.UserFlipThreeCardsInfoUploadResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserFlipThreeCardsInfoUploadResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IADGetBonusInfoReq {
        }

        class ADGetBonusInfoReq implements IADGetBonusInfoReq {
            constructor(p?: GameProto.IADGetBonusInfoReq);
            public static create(properties?: GameProto.IADGetBonusInfoReq): GameProto.ADGetBonusInfoReq;
            public static encode(m: GameProto.ADGetBonusInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.ADGetBonusInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IADGetBonusInfoRsp {
            resultCode?: (number|null);
            adGetBonusEnable?: (number|null);
            adGetBonusCnt?: (number|null);
            adGetBonusMaxVal?: (number|null);
            adGetBonusMultiRW?: (string|null);
            leftCnt?: (number|null);
            nextUnix?: (Long|null);
            tomorrowZeroUnix?: (Long|null);
            curBonus?: (number|null);
            curMulti?: (number|null);
        }

        class ADGetBonusInfoRsp implements IADGetBonusInfoRsp {
            constructor(p?: GameProto.IADGetBonusInfoRsp);
            public resultCode: number;
            public adGetBonusEnable: number;
            public adGetBonusCnt: number;
            public adGetBonusMaxVal: number;
            public adGetBonusMultiRW: string;
            public leftCnt: number;
            public nextUnix: Long;
            public tomorrowZeroUnix: Long;
            public curBonus: number;
            public curMulti: number;
            public static create(properties?: GameProto.IADGetBonusInfoRsp): GameProto.ADGetBonusInfoRsp;
            public static encode(m: GameProto.ADGetBonusInfoRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.ADGetBonusInfoRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IADGetBonusReceiveRewardReq {
        }

        class ADGetBonusReceiveRewardReq implements IADGetBonusReceiveRewardReq {
            constructor(p?: GameProto.IADGetBonusReceiveRewardReq);
            public static create(properties?: GameProto.IADGetBonusReceiveRewardReq): GameProto.ADGetBonusReceiveRewardReq;
            public static encode(m: GameProto.ADGetBonusReceiveRewardReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.ADGetBonusReceiveRewardReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IADGetBonusReceiveRewardRsp {
            resultCode?: (number|null);
            leftCnt?: (number|null);
            nextUnix?: (Long|null);
            bonus?: (number|null);
        }

        class ADGetBonusReceiveRewardRsp implements IADGetBonusReceiveRewardRsp {
            constructor(p?: GameProto.IADGetBonusReceiveRewardRsp);
            public resultCode: number;
            public leftCnt: number;
            public nextUnix: Long;
            public bonus: number;
            public static create(properties?: GameProto.IADGetBonusReceiveRewardRsp): GameProto.ADGetBonusReceiveRewardRsp;
            public static encode(m: GameProto.ADGetBonusReceiveRewardRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.ADGetBonusReceiveRewardRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IADGetBonusRandValReq {
        }

        class ADGetBonusRandValReq implements IADGetBonusRandValReq {
            constructor(p?: GameProto.IADGetBonusRandValReq);
            public static create(properties?: GameProto.IADGetBonusRandValReq): GameProto.ADGetBonusRandValReq;
            public static encode(m: GameProto.ADGetBonusRandValReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.ADGetBonusRandValReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IADGetBonusRandValRsp {
            resultCode?: (number|null);
            curBonus?: (number|null);
            nextUnix?: (Long|null);
        }

        class ADGetBonusRandValRsp implements IADGetBonusRandValRsp {
            constructor(p?: GameProto.IADGetBonusRandValRsp);
            public resultCode: number;
            public curBonus: number;
            public nextUnix: Long;
            public static create(properties?: GameProto.IADGetBonusRandValRsp): GameProto.ADGetBonusRandValRsp;
            public static encode(m: GameProto.ADGetBonusRandValRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.ADGetBonusRandValRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IADGetBonusRandMultiReq {
        }

        class ADGetBonusRandMultiReq implements IADGetBonusRandMultiReq {
            constructor(p?: GameProto.IADGetBonusRandMultiReq);
            public static create(properties?: GameProto.IADGetBonusRandMultiReq): GameProto.ADGetBonusRandMultiReq;
            public static encode(m: GameProto.ADGetBonusRandMultiReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.ADGetBonusRandMultiReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IADGetBonusRandMultiRsp {
            resultCode?: (number|null);
            curMulti?: (number|null);
        }

        class ADGetBonusRandMultiRsp implements IADGetBonusRandMultiRsp {
            constructor(p?: GameProto.IADGetBonusRandMultiRsp);
            public resultCode: number;
            public curMulti: number;
            public static create(properties?: GameProto.IADGetBonusRandMultiRsp): GameProto.ADGetBonusRandMultiRsp;
            public static encode(m: GameProto.ADGetBonusRandMultiRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.ADGetBonusRandMultiRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserWithDrawNotify {
            lUid?: (Long|null);
            lId?: (Long|null);
            lValue?: (Long|null);
            iTimes?: (Long|null);
        }

        class UserWithDrawNotify implements IUserWithDrawNotify {
            constructor(p?: GameProto.IUserWithDrawNotify);
            public lUid: Long;
            public lId: Long;
            public lValue: Long;
            public iTimes: Long;
            public static create(properties?: GameProto.IUserWithDrawNotify): GameProto.UserWithDrawNotify;
            public static encode(m: GameProto.UserWithDrawNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserWithDrawNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserWithDrawReq {
            lId?: (Long|null);
        }

        class UserWithDrawReq implements IUserWithDrawReq {
            constructor(p?: GameProto.IUserWithDrawReq);
            public lId: Long;
            public static create(properties?: GameProto.IUserWithDrawReq): GameProto.UserWithDrawReq;
            public static encode(m: GameProto.UserWithDrawReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UserWithDrawReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUploadDeviceCodeReq {
            sDeviceCode?: (string|null);
        }

        class UploadDeviceCodeReq implements IUploadDeviceCodeReq {
            constructor(p?: GameProto.IUploadDeviceCodeReq);
            public sDeviceCode: string;
            public static create(properties?: GameProto.IUploadDeviceCodeReq): GameProto.UploadDeviceCodeReq;
            public static encode(m: GameProto.UploadDeviceCodeReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UploadDeviceCodeReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ICheckGetAdRsp {
            lUid?: (Long|null);
            iOk?: (number|null);
        }

        class CheckGetAdRsp implements ICheckGetAdRsp {
            constructor(p?: GameProto.ICheckGetAdRsp);
            public lUid: Long;
            public iOk: number;
            public static create(properties?: GameProto.ICheckGetAdRsp): GameProto.CheckGetAdRsp;
            public static encode(m: GameProto.CheckGetAdRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.CheckGetAdRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUpdateGuideReq {
            iGuide?: (number|null);
        }

        class UpdateGuideReq implements IUpdateGuideReq {
            constructor(p?: GameProto.IUpdateGuideReq);
            public iGuide: number;
            public static create(properties?: GameProto.IUpdateGuideReq): GameProto.UpdateGuideReq;
            public static encode(m: GameProto.UpdateGuideReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): GameProto.UpdateGuideReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }

    namespace LobbyProto {

        interface IVipConfigGetReq {
        }

        class VipConfigGetReq implements IVipConfigGetReq {
            constructor(p?: LobbyProto.IVipConfigGetReq);
            public static create(properties?: LobbyProto.IVipConfigGetReq): LobbyProto.VipConfigGetReq;
            public static encode(m: LobbyProto.VipConfigGetReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.VipConfigGetReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IVipConfigGetRsp {
            resultCode?: (number|null);
            level?: (LobbyProto.VipInfo[]|null);
            privileges?: (LobbyProto.VipPrivileges[]|null);
        }

        class VipConfigGetRsp implements IVipConfigGetRsp {
            constructor(p?: LobbyProto.IVipConfigGetRsp);
            public resultCode: number;
            public level: LobbyProto.VipInfo[];
            public privileges: LobbyProto.VipPrivileges[];
            public static create(properties?: LobbyProto.IVipConfigGetRsp): LobbyProto.VipConfigGetRsp;
            public static encode(m: LobbyProto.VipConfigGetRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.VipConfigGetRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IVipInfo {
            id?: (number|null);
            category?: (number|null);
            upDeposit?: (Long|null);
            upWager?: (Long|null);
            lowActivityTimeType?: (number|null);
            lowActivityTimeParam?: (number|null);
            activityDepositCond?: (Long|null);
            lowActivityDecDeposit?: (Long|null);
            icon?: (string|null);
            avatar?: (string|null);
            color?: (string|null);
            dailyWithdrawalLimit?: (Long|null);
            dailyWithdrawalFreeCnt?: (Long|null);
            withdrawalBaseFee?: (Long|null);
            withdrawalPercentFee?: (number|null);
            gameDepositBackPercent?: (string|null);
            depositRewardPercent?: (Long|null);
            depositRewardCnt?: (Long|null);
            state?: (number|null);
        }

        class VipInfo implements IVipInfo {
            constructor(p?: LobbyProto.IVipInfo);
            public id: number;
            public category: number;
            public upDeposit: Long;
            public upWager: Long;
            public lowActivityTimeType: number;
            public lowActivityTimeParam: number;
            public activityDepositCond: Long;
            public lowActivityDecDeposit: Long;
            public icon: string;
            public avatar: string;
            public color: string;
            public dailyWithdrawalLimit: Long;
            public dailyWithdrawalFreeCnt: Long;
            public withdrawalBaseFee: Long;
            public withdrawalPercentFee: number;
            public gameDepositBackPercent: string;
            public depositRewardPercent: Long;
            public depositRewardCnt: Long;
            public state: number;
            public static create(properties?: LobbyProto.IVipInfo): LobbyProto.VipInfo;
            public static encode(m: LobbyProto.VipInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.VipInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IVipPrivileges {
            id?: (Long|null);
            vipLevel?: (number|null);
            category?: (number|null);
            icon?: (string|null);
            title?: (string|null);
            titleParam?: (string|null);
            sort?: (Long|null);
            state?: (number|null);
        }

        class VipPrivileges implements IVipPrivileges {
            constructor(p?: LobbyProto.IVipPrivileges);
            public id: Long;
            public vipLevel: number;
            public category: number;
            public icon: string;
            public title: string;
            public titleParam: string;
            public sort: Long;
            public state: number;
            public static create(properties?: LobbyProto.IVipPrivileges): LobbyProto.VipPrivileges;
            public static encode(m: LobbyProto.VipPrivileges, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.VipPrivileges;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IOrderCreateReq {
            deposit?: (Long|null);
        }

        class OrderCreateReq implements IOrderCreateReq {
            constructor(p?: LobbyProto.IOrderCreateReq);
            public deposit: Long;
            public static create(properties?: LobbyProto.IOrderCreateReq): LobbyProto.OrderCreateReq;
            public static encode(m: LobbyProto.OrderCreateReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.OrderCreateReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IOrderCreateRsp {
            resultCode?: (number|null);
            orderNo?: (string|null);
        }

        class OrderCreateRsp implements IOrderCreateRsp {
            constructor(p?: LobbyProto.IOrderCreateRsp);
            public resultCode: number;
            public orderNo: string;
            public static create(properties?: LobbyProto.IOrderCreateRsp): LobbyProto.OrderCreateRsp;
            public static encode(m: LobbyProto.OrderCreateRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.OrderCreateRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IOrderReceiveRewardReq {
            orderNo?: (string|null);
        }

        class OrderReceiveRewardReq implements IOrderReceiveRewardReq {
            constructor(p?: LobbyProto.IOrderReceiveRewardReq);
            public orderNo: string;
            public static create(properties?: LobbyProto.IOrderReceiveRewardReq): LobbyProto.OrderReceiveRewardReq;
            public static encode(m: LobbyProto.OrderReceiveRewardReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.OrderReceiveRewardReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IOrderReceiveRewardRsp {
            resultCode?: (number|null);
            vipLevel?: (Long|null);
            vipExp?: (Long|null);
        }

        class OrderReceiveRewardRsp implements IOrderReceiveRewardRsp {
            constructor(p?: LobbyProto.IOrderReceiveRewardRsp);
            public resultCode: number;
            public vipLevel: Long;
            public vipExp: Long;
            public static create(properties?: LobbyProto.IOrderReceiveRewardRsp): LobbyProto.OrderReceiveRewardRsp;
            public static encode(m: LobbyProto.OrderReceiveRewardRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.OrderReceiveRewardRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IHallGameTypeInfo {
            lId?: (Long|null);
            lParentId?: (Long|null);
            sName?: (string|null);
            sIconUrl?: (string|null);
            sImgUrl?: (string|null);
            sChoseImgUrl?: (string|null);
            iSort?: (number|null);
            iContentStyle?: (number|null);
            iShowLine?: (number|null);
            iIsRecommend?: (number|null);
        }

        class HallGameTypeInfo implements IHallGameTypeInfo {
            constructor(p?: LobbyProto.IHallGameTypeInfo);
            public lId: Long;
            public lParentId: Long;
            public sName: string;
            public sIconUrl: string;
            public sImgUrl: string;
            public sChoseImgUrl: string;
            public iSort: number;
            public iContentStyle: number;
            public iShowLine: number;
            public iIsRecommend: number;
            public static create(properties?: LobbyProto.IHallGameTypeInfo): LobbyProto.HallGameTypeInfo;
            public static encode(m: LobbyProto.HallGameTypeInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.HallGameTypeInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IHallGameTypeInfoReq {
            lParentId?: (Long|null);
        }

        class HallGameTypeInfoReq implements IHallGameTypeInfoReq {
            constructor(p?: LobbyProto.IHallGameTypeInfoReq);
            public lParentId: Long;
            public static create(properties?: LobbyProto.IHallGameTypeInfoReq): LobbyProto.HallGameTypeInfoReq;
            public static encode(m: LobbyProto.HallGameTypeInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.HallGameTypeInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IHallGameTypeInfoRsp {
            iResultCode?: (number|null);
            lParentId?: (Long|null);
            vInfo?: (LobbyProto.HallGameTypeInfo[]|null);
        }

        class HallGameTypeInfoRsp implements IHallGameTypeInfoRsp {
            constructor(p?: LobbyProto.IHallGameTypeInfoRsp);
            public iResultCode: number;
            public lParentId: Long;
            public vInfo: LobbyProto.HallGameTypeInfo[];
            public static create(properties?: LobbyProto.IHallGameTypeInfoRsp): LobbyProto.HallGameTypeInfoRsp;
            public static encode(m: LobbyProto.HallGameTypeInfoRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.HallGameTypeInfoRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IHallGameOneInfo {
            lId?: (Long|null);
            lParentId?: (Long|null);
            sName?: (string|null);
            sIconUrl?: (string|null);
            iSort?: (number|null);
            iContentStyle?: (number|null);
            iJumpCategory?: (number|null);
            sJumpValue?: (string|null);
            iShowLine?: (number|null);
            iIsRecommend?: (number|null);
        }

        class HallGameOneInfo implements IHallGameOneInfo {
            constructor(p?: LobbyProto.IHallGameOneInfo);
            public lId: Long;
            public lParentId: Long;
            public sName: string;
            public sIconUrl: string;
            public iSort: number;
            public iContentStyle: number;
            public iJumpCategory: number;
            public sJumpValue: string;
            public iShowLine: number;
            public iIsRecommend: number;
            public static create(properties?: LobbyProto.IHallGameOneInfo): LobbyProto.HallGameOneInfo;
            public static encode(m: LobbyProto.HallGameOneInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.HallGameOneInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IHallGameOneInfoReq {
            lPid?: (Long|null);
        }

        class HallGameOneInfoReq implements IHallGameOneInfoReq {
            constructor(p?: LobbyProto.IHallGameOneInfoReq);
            public lPid: Long;
            public static create(properties?: LobbyProto.IHallGameOneInfoReq): LobbyProto.HallGameOneInfoReq;
            public static encode(m: LobbyProto.HallGameOneInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.HallGameOneInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IHallGameOneInfoRsp {
            iResultCode?: (number|null);
            vInfo?: (LobbyProto.HallGameOneInfo[]|null);
        }

        class HallGameOneInfoRsp implements IHallGameOneInfoRsp {
            constructor(p?: LobbyProto.IHallGameOneInfoRsp);
            public iResultCode: number;
            public vInfo: LobbyProto.HallGameOneInfo[];
            public static create(properties?: LobbyProto.IHallGameOneInfoRsp): LobbyProto.HallGameOneInfoRsp;
            public static encode(m: LobbyProto.HallGameOneInfoRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.HallGameOneInfoRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IHallGameTwoInfo {
            lId?: (Long|null);
            lParentId?: (Long|null);
            sName?: (string|null);
            sIconUrl?: (string|null);
            RecommendType?: (number|null);
            sGameId?: (string|null);
            iSort?: (number|null);
            iContentStyle?: (number|null);
        }

        class HallGameTwoInfo implements IHallGameTwoInfo {
            constructor(p?: LobbyProto.IHallGameTwoInfo);
            public lId: Long;
            public lParentId: Long;
            public sName: string;
            public sIconUrl: string;
            public RecommendType: number;
            public sGameId: string;
            public iSort: number;
            public iContentStyle: number;
            public static create(properties?: LobbyProto.IHallGameTwoInfo): LobbyProto.HallGameTwoInfo;
            public static encode(m: LobbyProto.HallGameTwoInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.HallGameTwoInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IHallGameTwoInfoReq {
            vParentIds?: (Long[]|null);
        }

        class HallGameTwoInfoReq implements IHallGameTwoInfoReq {
            constructor(p?: LobbyProto.IHallGameTwoInfoReq);
            public vParentIds: Long[];
            public static create(properties?: LobbyProto.IHallGameTwoInfoReq): LobbyProto.HallGameTwoInfoReq;
            public static encode(m: LobbyProto.HallGameTwoInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.HallGameTwoInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IHallGameTwoInfoRsp {
            iResultCode?: (number|null);
            vInfo?: (LobbyProto.HallGameTwoInfo[]|null);
        }

        class HallGameTwoInfoRsp implements IHallGameTwoInfoRsp {
            constructor(p?: LobbyProto.IHallGameTwoInfoRsp);
            public iResultCode: number;
            public vInfo: LobbyProto.HallGameTwoInfo[];
            public static create(properties?: LobbyProto.IHallGameTwoInfoRsp): LobbyProto.HallGameTwoInfoRsp;
            public static encode(m: LobbyProto.HallGameTwoInfoRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.HallGameTwoInfoRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IHallGameThreeInfo {
            lId?: (Long|null);
            lParentId?: (Long|null);
            sName?: (string|null);
            sIconUrl?: (string|null);
            iGameType?: (number|null);
            sGameId?: (string|null);
            iSort?: (number|null);
            iContentStyle?: (number|null);
            iShowType?: (number|null);
        }

        class HallGameThreeInfo implements IHallGameThreeInfo {
            constructor(p?: LobbyProto.IHallGameThreeInfo);
            public lId: Long;
            public lParentId: Long;
            public sName: string;
            public sIconUrl: string;
            public iGameType: number;
            public sGameId: string;
            public iSort: number;
            public iContentStyle: number;
            public iShowType: number;
            public static create(properties?: LobbyProto.IHallGameThreeInfo): LobbyProto.HallGameThreeInfo;
            public static encode(m: LobbyProto.HallGameThreeInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.HallGameThreeInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IHallGameThreeInfoReq {
            lParentId?: (Long|null);
        }

        class HallGameThreeInfoReq implements IHallGameThreeInfoReq {
            constructor(p?: LobbyProto.IHallGameThreeInfoReq);
            public lParentId: Long;
            public static create(properties?: LobbyProto.IHallGameThreeInfoReq): LobbyProto.HallGameThreeInfoReq;
            public static encode(m: LobbyProto.HallGameThreeInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.HallGameThreeInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IHallGameThreeInfoRsp {
            iResultCode?: (number|null);
            vInfo?: (LobbyProto.HallGameThreeInfo[]|null);
        }

        class HallGameThreeInfoRsp implements IHallGameThreeInfoRsp {
            constructor(p?: LobbyProto.IHallGameThreeInfoRsp);
            public iResultCode: number;
            public vInfo: LobbyProto.HallGameThreeInfo[];
            public static create(properties?: LobbyProto.IHallGameThreeInfoRsp): LobbyProto.HallGameThreeInfoRsp;
            public static encode(m: LobbyProto.HallGameThreeInfoRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.HallGameThreeInfoRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserEmailDigestReq {
            offset?: (Long|null);
            limit?: (Long|null);
        }

        class GetUserEmailDigestReq implements IGetUserEmailDigestReq {
            constructor(p?: LobbyProto.IGetUserEmailDigestReq);
            public offset: Long;
            public limit: Long;
            public static create(properties?: LobbyProto.IGetUserEmailDigestReq): LobbyProto.GetUserEmailDigestReq;
            public static encode(m: LobbyProto.GetUserEmailDigestReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.GetUserEmailDigestReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserEmailDigest {
            eid?: (number|null);
            type?: (number|null);
            status?: (number|null);
            head?: (string|null);
            digest?: (string|null);
            timestamp?: (Long|null);
        }

        class UserEmailDigest implements IUserEmailDigest {
            constructor(p?: LobbyProto.IUserEmailDigest);
            public eid: number;
            public type: number;
            public status: number;
            public head: string;
            public digest: string;
            public timestamp: Long;
            public static create(properties?: LobbyProto.IUserEmailDigest): LobbyProto.UserEmailDigest;
            public static encode(m: LobbyProto.UserEmailDigest, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.UserEmailDigest;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserEmailDigestRsp {
            resultCode?: (number|null);
            peCount?: (number|null);
            plCount?: (number|null);
            list?: (LobbyProto.UserEmailDigest[]|null);
        }

        class GetUserEmailDigestRsp implements IGetUserEmailDigestRsp {
            constructor(p?: LobbyProto.IGetUserEmailDigestRsp);
            public resultCode: number;
            public peCount: number;
            public plCount: number;
            public list: LobbyProto.UserEmailDigest[];
            public static create(properties?: LobbyProto.IGetUserEmailDigestRsp): LobbyProto.GetUserEmailDigestRsp;
            public static encode(m: LobbyProto.GetUserEmailDigestRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.GetUserEmailDigestRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserEmailReq {
            eid?: (number|null);
            et?: (number|null);
        }

        class GetUserEmailReq implements IGetUserEmailReq {
            constructor(p?: LobbyProto.IGetUserEmailReq);
            public eid: number;
            public et: number;
            public static create(properties?: LobbyProto.IGetUserEmailReq): LobbyProto.GetUserEmailReq;
            public static encode(m: LobbyProto.GetUserEmailReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.GetUserEmailReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserEmail {
            body?: (string|null);
            pictureUrl?: (string|null);
            hasRewards?: (number|null);
            taskIds?: (string|null);
            taskExpireType?: (number|null);
            taskExpireTime?: (number|null);
            jumpType?: (number|null);
            jumpDst?: (string|null);
        }

        class UserEmail implements IUserEmail {
            constructor(p?: LobbyProto.IUserEmail);
            public body: string;
            public pictureUrl: string;
            public hasRewards: number;
            public taskIds: string;
            public taskExpireType: number;
            public taskExpireTime: number;
            public jumpType: number;
            public jumpDst: string;
            public static create(properties?: LobbyProto.IUserEmail): LobbyProto.UserEmail;
            public static encode(m: LobbyProto.UserEmail, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.UserEmail;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetUserEmailRsp {
            iResultCode?: (number|null);
            email?: (LobbyProto.UserEmail|null);
        }

        class GetUserEmailRsp implements IGetUserEmailRsp {
            constructor(p?: LobbyProto.IGetUserEmailRsp);
            public iResultCode: number;
            public email?: (LobbyProto.UserEmail|null);
            public static create(properties?: LobbyProto.IGetUserEmailRsp): LobbyProto.GetUserEmailRsp;
            public static encode(m: LobbyProto.GetUserEmailRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.GetUserEmailRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IAlterUserEmailStatusReq {
            eid?: (number|null);
            et?: (number|null);
        }

        class AlterUserEmailStatusReq implements IAlterUserEmailStatusReq {
            constructor(p?: LobbyProto.IAlterUserEmailStatusReq);
            public eid: number;
            public et: number;
            public static create(properties?: LobbyProto.IAlterUserEmailStatusReq): LobbyProto.AlterUserEmailStatusReq;
            public static encode(m: LobbyProto.AlterUserEmailStatusReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.AlterUserEmailStatusReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IAlterUserEmailStatusRsp {
            iResultCode?: (number|null);
            eid?: (number|null);
            et?: (number|null);
        }

        class AlterUserEmailStatusRsp implements IAlterUserEmailStatusRsp {
            constructor(p?: LobbyProto.IAlterUserEmailStatusRsp);
            public iResultCode: number;
            public eid: number;
            public et: number;
            public static create(properties?: LobbyProto.IAlterUserEmailStatusRsp): LobbyProto.AlterUserEmailStatusRsp;
            public static encode(m: LobbyProto.AlterUserEmailStatusRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.AlterUserEmailStatusRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserRemoveEmailReq {
            eid?: (number|null);
            et?: (number|null);
        }

        class UserRemoveEmailReq implements IUserRemoveEmailReq {
            constructor(p?: LobbyProto.IUserRemoveEmailReq);
            public eid: number;
            public et: number;
            public static create(properties?: LobbyProto.IUserRemoveEmailReq): LobbyProto.UserRemoveEmailReq;
            public static encode(m: LobbyProto.UserRemoveEmailReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.UserRemoveEmailReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserRemoveEmailRsp {
            iResultCode?: (number|null);
            eid?: (number|null);
            et?: (number|null);
        }

        class UserRemoveEmailRsp implements IUserRemoveEmailRsp {
            constructor(p?: LobbyProto.IUserRemoveEmailRsp);
            public iResultCode: number;
            public eid: number;
            public et: number;
            public static create(properties?: LobbyProto.IUserRemoveEmailRsp): LobbyProto.UserRemoveEmailRsp;
            public static encode(m: LobbyProto.UserRemoveEmailRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.UserRemoveEmailRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserEmailRemoveAllReq {
        }

        class UserEmailRemoveAllReq implements IUserEmailRemoveAllReq {
            constructor(p?: LobbyProto.IUserEmailRemoveAllReq);
            public static create(properties?: LobbyProto.IUserEmailRemoveAllReq): LobbyProto.UserEmailRemoveAllReq;
            public static encode(m: LobbyProto.UserEmailRemoveAllReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.UserEmailRemoveAllReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserEmailRemoveAllRsp {
            iResultCode?: (number|null);
            plEids?: (Long[]|null);
            peEids?: (Long[]|null);
        }

        class UserEmailRemoveAllRsp implements IUserEmailRemoveAllRsp {
            constructor(p?: LobbyProto.IUserEmailRemoveAllRsp);
            public iResultCode: number;
            public plEids: Long[];
            public peEids: Long[];
            public static create(properties?: LobbyProto.IUserEmailRemoveAllRsp): LobbyProto.UserEmailRemoveAllRsp;
            public static encode(m: LobbyProto.UserEmailRemoveAllRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.UserEmailRemoveAllRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserMarkAllReadEmailReq {
        }

        class UserMarkAllReadEmailReq implements IUserMarkAllReadEmailReq {
            constructor(p?: LobbyProto.IUserMarkAllReadEmailReq);
            public static create(properties?: LobbyProto.IUserMarkAllReadEmailReq): LobbyProto.UserMarkAllReadEmailReq;
            public static encode(m: LobbyProto.UserMarkAllReadEmailReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.UserMarkAllReadEmailReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserMarkAllReadEmailRsp {
            iResultCode?: (number|null);
            plEids?: (Long[]|null);
            peEids?: (Long[]|null);
        }

        class UserMarkAllReadEmailRsp implements IUserMarkAllReadEmailRsp {
            constructor(p?: LobbyProto.IUserMarkAllReadEmailRsp);
            public iResultCode: number;
            public plEids: Long[];
            public peEids: Long[];
            public static create(properties?: LobbyProto.IUserMarkAllReadEmailRsp): LobbyProto.UserMarkAllReadEmailRsp;
            public static encode(m: LobbyProto.UserMarkAllReadEmailRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.UserMarkAllReadEmailRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetClubConfReq {
        }

        class GetClubConfReq implements IGetClubConfReq {
            constructor(p?: LobbyProto.IGetClubConfReq);
            public static create(properties?: LobbyProto.IGetClubConfReq): LobbyProto.GetClubConfReq;
            public static encode(m: LobbyProto.GetClubConfReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.GetClubConfReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetClubConfRsp {
            iResultCode?: (number|null);
            level?: (LobbyProto.ConfClubLevelData[]|null);
            bindLevel?: (LobbyProto.ConfClubBindLevelData[]|null);
            rebate?: (LobbyProto.ConfClubRebateData[]|null);
            rule?: (LobbyProto.ConfClubRuleData[]|null);
        }

        class GetClubConfRsp implements IGetClubConfRsp {
            constructor(p?: LobbyProto.IGetClubConfRsp);
            public iResultCode: number;
            public level: LobbyProto.ConfClubLevelData[];
            public bindLevel: LobbyProto.ConfClubBindLevelData[];
            public rebate: LobbyProto.ConfClubRebateData[];
            public rule: LobbyProto.ConfClubRuleData[];
            public static create(properties?: LobbyProto.IGetClubConfRsp): LobbyProto.GetClubConfRsp;
            public static encode(m: LobbyProto.GetClubConfRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.GetClubConfRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IConfClubLevelData {
            id?: (number|null);
            name?: (string|null);
            showName?: (string|null);
            memberCond?: (Long|null);
            betCond?: (Long|null);
        }

        class ConfClubLevelData implements IConfClubLevelData {
            constructor(p?: LobbyProto.IConfClubLevelData);
            public id: number;
            public name: string;
            public showName: string;
            public memberCond: Long;
            public betCond: Long;
            public static create(properties?: LobbyProto.IConfClubLevelData): LobbyProto.ConfClubLevelData;
            public static encode(m: LobbyProto.ConfClubLevelData, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.ConfClubLevelData;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IConfClubBindLevelData {
            id?: (number|null);
            name?: (string|null);
            showName?: (string|null);
        }

        class ConfClubBindLevelData implements IConfClubBindLevelData {
            constructor(p?: LobbyProto.IConfClubBindLevelData);
            public id: number;
            public name: string;
            public showName: string;
            public static create(properties?: LobbyProto.IConfClubBindLevelData): LobbyProto.ConfClubBindLevelData;
            public static encode(m: LobbyProto.ConfClubBindLevelData, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.ConfClubBindLevelData;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IConfClubRebateData {
            id?: (number|null);
            bindLevel?: (number|null);
            clubLevel?: (number|null);
            betRebate?: (number|null);
            depositRebate?: (number|null);
        }

        class ConfClubRebateData implements IConfClubRebateData {
            constructor(p?: LobbyProto.IConfClubRebateData);
            public id: number;
            public bindLevel: number;
            public clubLevel: number;
            public betRebate: number;
            public depositRebate: number;
            public static create(properties?: LobbyProto.IConfClubRebateData): LobbyProto.ConfClubRebateData;
            public static encode(m: LobbyProto.ConfClubRebateData, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.ConfClubRebateData;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IConfClubRuleData {
            id?: (Long|null);
            name?: (string|null);
            imgUrl?: (string|null);
            context?: (string|null);
            showButton?: (number|null);
            buttonName?: (string|null);
            buttonEventType?: (number|null);
            buttonEventParam?: (string|null);
            sortNum?: (number|null);
            page?: (string|null);
        }

        class ConfClubRuleData implements IConfClubRuleData {
            constructor(p?: LobbyProto.IConfClubRuleData);
            public id: Long;
            public name: string;
            public imgUrl: string;
            public context: string;
            public showButton: number;
            public buttonName: string;
            public buttonEventType: number;
            public buttonEventParam: string;
            public sortNum: number;
            public page: string;
            public static create(properties?: LobbyProto.IConfClubRuleData): LobbyProto.ConfClubRuleData;
            public static encode(m: LobbyProto.ConfClubRuleData, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.ConfClubRuleData;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetClubSharePosterConfReq {
        }

        class GetClubSharePosterConfReq implements IGetClubSharePosterConfReq {
            constructor(p?: LobbyProto.IGetClubSharePosterConfReq);
            public static create(properties?: LobbyProto.IGetClubSharePosterConfReq): LobbyProto.GetClubSharePosterConfReq;
            public static encode(m: LobbyProto.GetClubSharePosterConfReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.GetClubSharePosterConfReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetClubSharePosterConfRsp {
            iResultCode?: (number|null);
            list?: (LobbyProto.ConfClubSharePosterData[]|null);
        }

        class GetClubSharePosterConfRsp implements IGetClubSharePosterConfRsp {
            constructor(p?: LobbyProto.IGetClubSharePosterConfRsp);
            public iResultCode: number;
            public list: LobbyProto.ConfClubSharePosterData[];
            public static create(properties?: LobbyProto.IGetClubSharePosterConfRsp): LobbyProto.GetClubSharePosterConfRsp;
            public static encode(m: LobbyProto.GetClubSharePosterConfRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.GetClubSharePosterConfRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IConfClubSharePosterData {
            id?: (Long|null);
            name?: (string|null);
            imgURL?: (string|null);
            state?: (number|null);
        }

        class ConfClubSharePosterData implements IConfClubSharePosterData {
            constructor(p?: LobbyProto.IConfClubSharePosterData);
            public id: Long;
            public name: string;
            public imgURL: string;
            public state: number;
            public static create(properties?: LobbyProto.IConfClubSharePosterData): LobbyProto.ConfClubSharePosterData;
            public static encode(m: LobbyProto.ConfClubSharePosterData, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.ConfClubSharePosterData;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IBindInviteCodeReq {
            inviteCode?: (string|null);
        }

        class BindInviteCodeReq implements IBindInviteCodeReq {
            constructor(p?: LobbyProto.IBindInviteCodeReq);
            public inviteCode: string;
            public static create(properties?: LobbyProto.IBindInviteCodeReq): LobbyProto.BindInviteCodeReq;
            public static encode(m: LobbyProto.BindInviteCodeReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.BindInviteCodeReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IBindInviteCodeRsp {
            resultCode?: (number|null);
            inviteCode?: (string|null);
        }

        class BindInviteCodeRsp implements IBindInviteCodeRsp {
            constructor(p?: LobbyProto.IBindInviteCodeRsp);
            public resultCode: number;
            public inviteCode: string;
            public static create(properties?: LobbyProto.IBindInviteCodeRsp): LobbyProto.BindInviteCodeRsp;
            public static encode(m: LobbyProto.BindInviteCodeRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.BindInviteCodeRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetMyClubInfoReq {
        }

        class GetMyClubInfoReq implements IGetMyClubInfoReq {
            constructor(p?: LobbyProto.IGetMyClubInfoReq);
            public static create(properties?: LobbyProto.IGetMyClubInfoReq): LobbyProto.GetMyClubInfoReq;
            public static encode(m: LobbyProto.GetMyClubInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.GetMyClubInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetMyClubInfoRsp {
            resultCode?: (number|null);
            id?: (Long|null);
            level?: (number|null);
            member?: (Long|null);
            bet?: (Long|null);
        }

        class GetMyClubInfoRsp implements IGetMyClubInfoRsp {
            constructor(p?: LobbyProto.IGetMyClubInfoRsp);
            public resultCode: number;
            public id: Long;
            public level: number;
            public member: Long;
            public bet: Long;
            public static create(properties?: LobbyProto.IGetMyClubInfoRsp): LobbyProto.GetMyClubInfoRsp;
            public static encode(m: LobbyProto.GetMyClubInfoRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.GetMyClubInfoRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetCLubMemberReq {
            level?: (number|null);
        }

        class GetCLubMemberReq implements IGetCLubMemberReq {
            constructor(p?: LobbyProto.IGetCLubMemberReq);
            public level: number;
            public static create(properties?: LobbyProto.IGetCLubMemberReq): LobbyProto.GetCLubMemberReq;
            public static encode(m: LobbyProto.GetCLubMemberReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.GetCLubMemberReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetCLubMemberRsp {
            resultCode?: (number|null);
            level?: (number|null);
            list?: (LobbyProto.BindLevelMemberData[]|null);
            todayAddMember?: (Long|null);
            yesterdayAddMember?: (Long|null);
            monthAddMember?: (Long|null);
            levelMemberNum?: ({ [k: string]: Long }|null);
        }

        class GetCLubMemberRsp implements IGetCLubMemberRsp {
            constructor(p?: LobbyProto.IGetCLubMemberRsp);
            public resultCode: number;
            public level: number;
            public list: LobbyProto.BindLevelMemberData[];
            public todayAddMember: Long;
            public yesterdayAddMember: Long;
            public monthAddMember: Long;
            public levelMemberNum: { [k: string]: Long };
            public static create(properties?: LobbyProto.IGetCLubMemberRsp): LobbyProto.GetCLubMemberRsp;
            public static encode(m: LobbyProto.GetCLubMemberRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.GetCLubMemberRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IBindLevelMemberData {
            pid?: (Long|null);
            nickname?: (string|null);
            avatar?: (string|null);
            deposit?: (Long|null);
            commission?: (Long|null);
            phoneArea?: (string|null);
            phone?: (string|null);
            createTime?: (string|null);
        }

        class BindLevelMemberData implements IBindLevelMemberData {
            constructor(p?: LobbyProto.IBindLevelMemberData);
            public pid: Long;
            public nickname: string;
            public avatar: string;
            public deposit: Long;
            public commission: Long;
            public phoneArea: string;
            public phone: string;
            public createTime: string;
            public static create(properties?: LobbyProto.IBindLevelMemberData): LobbyProto.BindLevelMemberData;
            public static encode(m: LobbyProto.BindLevelMemberData, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LobbyProto.BindLevelMemberData;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }

    namespace LoginProto {

        interface ILogoutReq {
            uid?: (number|null);
        }

        class LogoutReq implements ILogoutReq {
            constructor(p?: LoginProto.ILogoutReq);
            public uid: number;
            public static create(properties?: LoginProto.ILogoutReq): LoginProto.LogoutReq;
            public static encode(m: LoginProto.LogoutReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.LogoutReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ILogoutResp {
            resultCode?: (number|null);
        }

        class LogoutResp implements ILogoutResp {
            constructor(p?: LoginProto.ILogoutResp);
            public resultCode: number;
            public static create(properties?: LoginProto.ILogoutResp): LoginProto.LogoutResp;
            public static encode(m: LoginProto.LogoutResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.LogoutResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ICheckLoginTokenReq {
            lUid?: (Long|null);
            sToken?: (string|null);
        }

        class CheckLoginTokenReq implements ICheckLoginTokenReq {
            constructor(p?: LoginProto.ICheckLoginTokenReq);
            public lUid: Long;
            public sToken: string;
            public static create(properties?: LoginProto.ICheckLoginTokenReq): LoginProto.CheckLoginTokenReq;
            public static encode(m: LoginProto.CheckLoginTokenReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.CheckLoginTokenReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IDeviceLoginReq {
            deviceNo?: (string|null);
            deviceID?: (string|null);
            deviceType?: (string|null);
            platform?: (LoginProto.E_Platform_Type|null);
            channnelID?: (LoginProto.E_Channel_ID|null);
            areaID?: (number|null);
            language?: (string|null);
        }

        class DeviceLoginReq implements IDeviceLoginReq {
            constructor(p?: LoginProto.IDeviceLoginReq);
            public deviceNo: string;
            public deviceID: string;
            public deviceType: string;
            public platform: LoginProto.E_Platform_Type;
            public channnelID: LoginProto.E_Channel_ID;
            public areaID: number;
            public language: string;
            public static create(properties?: LoginProto.IDeviceLoginReq): LoginProto.DeviceLoginReq;
            public static encode(m: LoginProto.DeviceLoginReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.DeviceLoginReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IDeviceLoginResp {
            resultCode?: (number|null);
            uid?: (number|null);
            token?: (string|null);
            flag?: (number|null);
        }

        class DeviceLoginResp implements IDeviceLoginResp {
            constructor(p?: LoginProto.IDeviceLoginResp);
            public resultCode: number;
            public uid: number;
            public token: string;
            public flag: number;
            public static create(properties?: LoginProto.IDeviceLoginResp): LoginProto.DeviceLoginResp;
            public static encode(m: LoginProto.DeviceLoginResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.DeviceLoginResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserLoginReq {
            userName?: (string|null);
            passwd?: (string|null);
        }

        class UserLoginReq implements IUserLoginReq {
            constructor(p?: LoginProto.IUserLoginReq);
            public userName: string;
            public passwd: string;
            public static create(properties?: LoginProto.IUserLoginReq): LoginProto.UserLoginReq;
            public static encode(m: LoginProto.UserLoginReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.UserLoginReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserLoginResp {
            resultCode?: (number|null);
            uid?: (Long|null);
            token?: (string|null);
            passwdErrCount?: (number|null);
        }

        class UserLoginResp implements IUserLoginResp {
            constructor(p?: LoginProto.IUserLoginResp);
            public resultCode: number;
            public uid: Long;
            public token: string;
            public passwdErrCount: number;
            public static create(properties?: LoginProto.IUserLoginResp): LoginProto.UserLoginResp;
            public static encode(m: LoginProto.UserLoginResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.UserLoginResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        enum E_Platform_Type {
            E_PLATFORM_TYPE_UNKNOWN = 0,
            E_PLATFORM_TYPE_IOS = 1,
            E_PLATFORM_TYPE_ANDROID = 2,
            E_PLATFORM_TYPE_H5 = 3
        }

        enum E_Channel_ID {
            E_CHANNEL_ID_UNKNOWN = 0,
            E_CHANNEL_ID_TEST = 1,
            E_CHANNEL_ID_GOOGLE = 2,
            E_CHANNEL_ID_FACEBOOK = 3,
            E_CHANNEL_ID_APPLE = 4,
            E_CHANNEL_ID_EMAIL = 5,
            E_CHANNEL_ID_PHOME = 6
        }

        interface IRegisterReq {
            userName?: (string|null);
            passwd?: (string|null);
            deviceID?: (string|null);
            deviceType?: (string|null);
            platform?: (LoginProto.E_Platform_Type|null);
            channnelID?: (LoginProto.E_Channel_ID|null);
            areaID?: (number|null);
            nickName?: (string|null);
            gender?: (number|null);
            language?: (string|null);
        }

        class RegisterReq implements IRegisterReq {
            constructor(p?: LoginProto.IRegisterReq);
            public userName: string;
            public passwd: string;
            public deviceID: string;
            public deviceType: string;
            public platform: LoginProto.E_Platform_Type;
            public channnelID: LoginProto.E_Channel_ID;
            public areaID: number;
            public nickName: string;
            public gender: number;
            public language: string;
            public static create(properties?: LoginProto.IRegisterReq): LoginProto.RegisterReq;
            public static encode(m: LoginProto.RegisterReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.RegisterReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IRegisterResp {
            resultCode?: (number|null);
            uid?: (Long|null);
        }

        class RegisterResp implements IRegisterResp {
            constructor(p?: LoginProto.IRegisterResp);
            public resultCode: number;
            public uid: Long;
            public static create(properties?: LoginProto.IRegisterResp): LoginProto.RegisterResp;
            public static encode(m: LoginProto.RegisterResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.RegisterResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        enum E_LOGIN_TYPE {
            E_LOGIN_GOOGLE = 0,
            E_LOGIN_FACEBOOK = 1,
            E_LOGIN_APPLE = 2
        }

        interface IThirdPartyLoginReq {
            loginType?: (LoginProto.E_LOGIN_TYPE|null);
            openId?: (string|null);
            token?: (string|null);
            deviceNo?: (string|null);
            platform?: (LoginProto.E_Platform_Type|null);
            channnelID?: (LoginProto.E_Channel_ID|null);
            areaID?: (number|null);
        }

        class ThirdPartyLoginReq implements IThirdPartyLoginReq {
            constructor(p?: LoginProto.IThirdPartyLoginReq);
            public loginType: LoginProto.E_LOGIN_TYPE;
            public openId: string;
            public token: string;
            public deviceNo: string;
            public platform: LoginProto.E_Platform_Type;
            public channnelID: LoginProto.E_Channel_ID;
            public areaID: number;
            public static create(properties?: LoginProto.IThirdPartyLoginReq): LoginProto.ThirdPartyLoginReq;
            public static encode(m: LoginProto.ThirdPartyLoginReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.ThirdPartyLoginReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IThirdPartyLoginResp {
            resultCode?: (number|null);
            uid?: (Long|null);
            token?: (string|null);
            flag?: (number|null);
        }

        class ThirdPartyLoginResp implements IThirdPartyLoginResp {
            constructor(p?: LoginProto.IThirdPartyLoginResp);
            public resultCode: number;
            public uid: Long;
            public token: string;
            public flag: number;
            public static create(properties?: LoginProto.IThirdPartyLoginResp): LoginProto.ThirdPartyLoginResp;
            public static encode(m: LoginProto.ThirdPartyLoginResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.ThirdPartyLoginResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IQuickLoginReq {
            uid?: (Long|null);
            token?: (string|null);
        }

        class QuickLoginReq implements IQuickLoginReq {
            constructor(p?: LoginProto.IQuickLoginReq);
            public uid: Long;
            public token: string;
            public static create(properties?: LoginProto.IQuickLoginReq): LoginProto.QuickLoginReq;
            public static encode(m: LoginProto.QuickLoginReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.QuickLoginReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IQuickLoginResp {
            resultCode?: (number|null);
            uid?: (Long|null);
            token?: (string|null);
            flag?: (number|null);
        }

        class QuickLoginResp implements IQuickLoginResp {
            constructor(p?: LoginProto.IQuickLoginResp);
            public resultCode: number;
            public uid: Long;
            public token: string;
            public flag: number;
            public static create(properties?: LoginProto.IQuickLoginResp): LoginProto.QuickLoginResp;
            public static encode(m: LoginProto.QuickLoginResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.QuickLoginResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPhoneRegisterReq {
            msgCode?: (string|null);
            registerReq?: (LoginProto.RegisterReq|null);
        }

        class PhoneRegisterReq implements IPhoneRegisterReq {
            constructor(p?: LoginProto.IPhoneRegisterReq);
            public msgCode: string;
            public registerReq?: (LoginProto.RegisterReq|null);
            public static create(properties?: LoginProto.IPhoneRegisterReq): LoginProto.PhoneRegisterReq;
            public static encode(m: LoginProto.PhoneRegisterReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.PhoneRegisterReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPhoneRegisterResp {
            resultCode?: (number|null);
            uid?: (Long|null);
        }

        class PhoneRegisterResp implements IPhoneRegisterResp {
            constructor(p?: LoginProto.IPhoneRegisterResp);
            public resultCode: number;
            public uid: Long;
            public static create(properties?: LoginProto.IPhoneRegisterResp): LoginProto.PhoneRegisterResp;
            public static encode(m: LoginProto.PhoneRegisterResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.PhoneRegisterResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPhoneLoginReq {
            phone?: (string|null);
            passwd?: (string|null);
            areaID?: (number|null);
            deviceID?: (string|null);
            deviceType?: (string|null);
            platform?: (LoginProto.E_Platform_Type|null);
            channnelID?: (LoginProto.E_Channel_ID|null);
            nickName?: (string|null);
            gender?: (number|null);
        }

        class PhoneLoginReq implements IPhoneLoginReq {
            constructor(p?: LoginProto.IPhoneLoginReq);
            public phone: string;
            public passwd: string;
            public areaID: number;
            public deviceID: string;
            public deviceType: string;
            public platform: LoginProto.E_Platform_Type;
            public channnelID: LoginProto.E_Channel_ID;
            public nickName: string;
            public gender: number;
            public static create(properties?: LoginProto.IPhoneLoginReq): LoginProto.PhoneLoginReq;
            public static encode(m: LoginProto.PhoneLoginReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.PhoneLoginReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPhoneLoginResp {
            uid?: (number|null);
            token?: (string|null);
            resultCode?: (number|null);
            passwdErrCount?: (number|null);
        }

        class PhoneLoginResp implements IPhoneLoginResp {
            constructor(p?: LoginProto.IPhoneLoginResp);
            public uid: number;
            public token: string;
            public resultCode: number;
            public passwdErrCount: number;
            public static create(properties?: LoginProto.IPhoneLoginResp): LoginProto.PhoneLoginResp;
            public static encode(m: LoginProto.PhoneLoginResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.PhoneLoginResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPhoneModifyPasswordReq {
            userName?: (string|null);
            msgCode?: (string|null);
            newPassword?: (string|null);
        }

        class PhoneModifyPasswordReq implements IPhoneModifyPasswordReq {
            constructor(p?: LoginProto.IPhoneModifyPasswordReq);
            public userName: string;
            public msgCode: string;
            public newPassword: string;
            public static create(properties?: LoginProto.IPhoneModifyPasswordReq): LoginProto.PhoneModifyPasswordReq;
            public static encode(m: LoginProto.PhoneModifyPasswordReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.PhoneModifyPasswordReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPhoneModifyPasswordResp {
            resultCode?: (number|null);
        }

        class PhoneModifyPasswordResp implements IPhoneModifyPasswordResp {
            constructor(p?: LoginProto.IPhoneModifyPasswordResp);
            public resultCode: number;
            public static create(properties?: LoginProto.IPhoneModifyPasswordResp): LoginProto.PhoneModifyPasswordResp;
            public static encode(m: LoginProto.PhoneModifyPasswordResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.PhoneModifyPasswordResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ISendPhoneMessageCodeReq {
            phone?: (string|null);
        }

        class SendPhoneMessageCodeReq implements ISendPhoneMessageCodeReq {
            constructor(p?: LoginProto.ISendPhoneMessageCodeReq);
            public phone: string;
            public static create(properties?: LoginProto.ISendPhoneMessageCodeReq): LoginProto.SendPhoneMessageCodeReq;
            public static encode(m: LoginProto.SendPhoneMessageCodeReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.SendPhoneMessageCodeReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ISendPhoneMessageCodeResp {
            resultCode?: (number|null);
        }

        class SendPhoneMessageCodeResp implements ISendPhoneMessageCodeResp {
            constructor(p?: LoginProto.ISendPhoneMessageCodeResp);
            public resultCode: number;
            public static create(properties?: LoginProto.ISendPhoneMessageCodeResp): LoginProto.SendPhoneMessageCodeResp;
            public static encode(m: LoginProto.SendPhoneMessageCodeResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.SendPhoneMessageCodeResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IEmailRegisterReq {
            msgCode?: (string|null);
            registerReq?: (LoginProto.RegisterReq|null);
        }

        class EmailRegisterReq implements IEmailRegisterReq {
            constructor(p?: LoginProto.IEmailRegisterReq);
            public msgCode: string;
            public registerReq?: (LoginProto.RegisterReq|null);
            public static create(properties?: LoginProto.IEmailRegisterReq): LoginProto.EmailRegisterReq;
            public static encode(m: LoginProto.EmailRegisterReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.EmailRegisterReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IEmailRegisterResp {
            resultCode?: (number|null);
            uid?: (Long|null);
        }

        class EmailRegisterResp implements IEmailRegisterResp {
            constructor(p?: LoginProto.IEmailRegisterResp);
            public resultCode: number;
            public uid: Long;
            public static create(properties?: LoginProto.IEmailRegisterResp): LoginProto.EmailRegisterResp;
            public static encode(m: LoginProto.EmailRegisterResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.EmailRegisterResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IEmailModifyPasswordReq {
            userName?: (string|null);
            msgCode?: (string|null);
            oldPassword?: (string|null);
            newPassword?: (string|null);
        }

        class EmailModifyPasswordReq implements IEmailModifyPasswordReq {
            constructor(p?: LoginProto.IEmailModifyPasswordReq);
            public userName: string;
            public msgCode: string;
            public oldPassword: string;
            public newPassword: string;
            public static create(properties?: LoginProto.IEmailModifyPasswordReq): LoginProto.EmailModifyPasswordReq;
            public static encode(m: LoginProto.EmailModifyPasswordReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.EmailModifyPasswordReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IEmailModifyPasswordResp {
            resultCode?: (number|null);
        }

        class EmailModifyPasswordResp implements IEmailModifyPasswordResp {
            constructor(p?: LoginProto.IEmailModifyPasswordResp);
            public resultCode: number;
            public static create(properties?: LoginProto.IEmailModifyPasswordResp): LoginProto.EmailModifyPasswordResp;
            public static encode(m: LoginProto.EmailModifyPasswordResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.EmailModifyPasswordResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ISendEmailMessageCodeReq {
            email?: (string|null);
        }

        class SendEmailMessageCodeReq implements ISendEmailMessageCodeReq {
            constructor(p?: LoginProto.ISendEmailMessageCodeReq);
            public email: string;
            public static create(properties?: LoginProto.ISendEmailMessageCodeReq): LoginProto.SendEmailMessageCodeReq;
            public static encode(m: LoginProto.SendEmailMessageCodeReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.SendEmailMessageCodeReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ISendEmailMessageCodeResp {
            resultCode?: (number|null);
        }

        class SendEmailMessageCodeResp implements ISendEmailMessageCodeResp {
            constructor(p?: LoginProto.ISendEmailMessageCodeResp);
            public resultCode: number;
            public static create(properties?: LoginProto.ISendEmailMessageCodeResp): LoginProto.SendEmailMessageCodeResp;
            public static encode(m: LoginProto.SendEmailMessageCodeResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.SendEmailMessageCodeResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserRounterInfoReq {
            reserve?: (number|null);
        }

        class UserRounterInfoReq implements IUserRounterInfoReq {
            constructor(p?: LoginProto.IUserRounterInfoReq);
            public reserve: number;
            public static create(properties?: LoginProto.IUserRounterInfoReq): LoginProto.UserRounterInfoReq;
            public static encode(m: LoginProto.UserRounterInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.UserRounterInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserRounterInfoResp {
            resultCode?: (number|null);
            routerAddr?: (string|null);
            routerPort?: (number|null);
        }

        class UserRounterInfoResp implements IUserRounterInfoResp {
            constructor(p?: LoginProto.IUserRounterInfoResp);
            public resultCode: number;
            public routerAddr: string;
            public routerPort: number;
            public static create(properties?: LoginProto.IUserRounterInfoResp): LoginProto.UserRounterInfoResp;
            public static encode(m: LoginProto.UserRounterInfoResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.UserRounterInfoResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IBindThirdPartyAccountReq {
            accountType?: (LoginProto.E_LOGIN_TYPE|null);
            channnelID?: (LoginProto.E_Channel_ID|null);
            openId?: (string|null);
        }

        class BindThirdPartyAccountReq implements IBindThirdPartyAccountReq {
            constructor(p?: LoginProto.IBindThirdPartyAccountReq);
            public accountType: LoginProto.E_LOGIN_TYPE;
            public channnelID: LoginProto.E_Channel_ID;
            public openId: string;
            public static create(properties?: LoginProto.IBindThirdPartyAccountReq): LoginProto.BindThirdPartyAccountReq;
            public static encode(m: LoginProto.BindThirdPartyAccountReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.BindThirdPartyAccountReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IBindThirdPartyAccountResp {
            resultCode?: (number|null);
        }

        class BindThirdPartyAccountResp implements IBindThirdPartyAccountResp {
            constructor(p?: LoginProto.IBindThirdPartyAccountResp);
            public resultCode: number;
            public static create(properties?: LoginProto.IBindThirdPartyAccountResp): LoginProto.BindThirdPartyAccountResp;
            public static encode(m: LoginProto.BindThirdPartyAccountResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.BindThirdPartyAccountResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IOnlineUserZeroUpdateReq {
            uid?: (Long|null);
        }

        class OnlineUserZeroUpdateReq implements IOnlineUserZeroUpdateReq {
            constructor(p?: LoginProto.IOnlineUserZeroUpdateReq);
            public uid: Long;
            public static create(properties?: LoginProto.IOnlineUserZeroUpdateReq): LoginProto.OnlineUserZeroUpdateReq;
            public static encode(m: LoginProto.OnlineUserZeroUpdateReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.OnlineUserZeroUpdateReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IOnlineUserZeroUpdateResp {
            resultCode?: (number|null);
        }

        class OnlineUserZeroUpdateResp implements IOnlineUserZeroUpdateResp {
            constructor(p?: LoginProto.IOnlineUserZeroUpdateResp);
            public resultCode: number;
            public static create(properties?: LoginProto.IOnlineUserZeroUpdateResp): LoginProto.OnlineUserZeroUpdateResp;
            public static encode(m: LoginProto.OnlineUserZeroUpdateResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.OnlineUserZeroUpdateResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        enum E_Event_Type {
            E_EVENT_TYPE_UNKNOWN = 0,
            E_EVENT_TYPE_CLIENT_START = 1,
            E_EVENT_TYPE_VERSION_CHECK = 2,
            E_EVENT_TYPE_UPDATE_START = 3,
            E_EVENT_TYPE_UPDATE_END = 4,
            E_EVENT_TYPE_LOGIN_PAGE = 5,
            E_EVENT_TYPE_LOGIN_CLICK = 6,
            E_EVENT_TYPE_LOGIN_AUTO = 7,
            E_EVENT_TYPE_LOGIN_MAIN = 8,
            E_EVENT_TYPE_INITIAL_CHIPS_PAGE = 9,
            E_EVENT_TYPE_INITIAL_CHIPS_CLICK = 10,
            E_EVENT_TYPE_HALL_GUIDE = 11,
            E_EVENT_TYPE_HALL_GUIDE_END = 12,
            E_EVENT_TYPE_PLAY_GUIDE = 13,
            E_EVENT_TYPE_PLAY_GUIDE_SELECT = 14,
            E_EVENT_TYPE_PLAY_GUIDE_QUIT = 15,
            E_EVENT_TYPE_PLAY_GUIDE_QUITED = 16,
            E_EVENT_TYPE_CAREER_START = 17,
            E_EVENT_TYPE_WORLD_START = 18,
            E_EVENT_TYPE_CAREER_PAGE_CLICK = 19,
            E_EVENT_TYPE_CAREER_ENTER_CLICK = 20,
            E_EVENT_TYPE_GRADE_RANK_CLICK = 21,
            E_EVENT_TYPE_GRADE_REWARD_CLICK = 22,
            E_EVENT_TYPE_EXCHANGE_CLICK = 23,
            E_EVENT_TYPE_HALL_FREECHIP_CLICK = 24,
            E_EVENT_TYPE_SNG_FREECHIP_CLICK = 25,
            E_EVENT_TYPE_QS_FREECHIP_CLICK = 26,
            E_EVENT_TYPE_WORLD_PAGE_CLICK = 27,
            E_EVENT_TYPE_TICKET_PAGE = 28,
            E_EVENT_TYPE_TICKET_GET = 29,
            E_EVENT_TYPE_PLAY_NOW = 30,
            E_EVENT_TYPE_SNG_EXIT = 31,
            E_EVENT_TYPE_SNG_EXIT_OK = 32,
            E_EVENT_TYPE_SNG_SETTLE_HALF = 33,
            E_EVENT_TYPE_SNG_SETTLE_NORMAL = 34,
            E_EVENT_TYPE_SNG_AGAIN = 35,
            E_EVENT_TYPE_SNG_EXIT_SETTLE = 36,
            E_EVENT_TYPE_EXCHANGE_CLICKFIRST = 37,
            E_EVENT_TYPE_EXCHANGE_ENTER = 38,
            E_EVENT_TYPE_EXCHANGE_1K = 39,
            E_EVENT_TYPE_EXCHANGE_EXIT = 40,
            E_EVENT_TYPE_EXCHANGE_GET_FIRST = 41,
            E_EVENT_TYPE_GET_TICKET_SEASON = 42,
            E_EVENT_TYPE_GET_TICKET_TASK = 43,
            E_EVENT_TYPE_GET_TICKET_LEVEL = 44,
            E_EVENT_TYPE_FRTPOP_EX_CLICK = 45,
            E_EVENT_TYPE_FRTPOP_EX_CLOSE = 46,
            E_EVENT_TYPE_FRTPOP_NEW_CLICK = 47,
            E_EVENT_TYPE_FRTPOP_NEW_CLOSE = 48,
            E_EVENT_TYPE_FRTPOP_SIGN_CLICK = 49,
            E_EVENT_TYPE_FRTPOP_SIGN_CLOSE = 50,
            E_EVENT_TYPE_FRTPOP_TH_RECHARGE = 51,
            E_EVENT_TYPE_FRTPOP_TH_CLOSE = 52,
            E_EVENT_TYPE_FRTPOP_LB_RECHARGE = 53,
            E_EVENT_TYPE_FRTPOP_LB_CLOSE = 54,
            E_EVENT_TYPE_FRTPOP_PCJL_GET = 55,
            E_EVENT_TYPE_FRTPOP_PCJL_CLOSE = 56,
            E_EVENT_TYPE_CAREER_DATA_START = 57,
            E_EVENT_TYPE_MTT_CLICK = 58,
            E_EVENT_TYPE_POP_PCYH_CLOSE = 59,
            E_EVENT_TYPE_POP_PCYH_GOTO = 60,
            E_EVENT_TYPE_POP_DSYH_CLOSE = 61,
            E_EVENT_TYPE_POP_DSYH_GOTO = 62,
            E_EVENT_TYPE_FREECHIP_NEW_BONUS = 63,
            E_EVENT_TYPE_FREECHIP_RECHARGE = 64,
            E_EVENT_TYPE_FREECHIP_LUCKY_SPIN = 65,
            E_EVENT_TYPE_FREECHIP_DAILY_SIGN = 66,
            E_EVENT_TYPE_FREECHIP_ACTIVITY = 67,
            E_EVENT_TYPE_CAREER_DATA_END = 68,
            E_EVENT_TYPE_AI_START = 78,
            E_EVENT_TYPE_AI_PRIMARY = 79,
            E_EVENT_TYPE_AI_MIDDLE = 80,
            E_EVENT_TYPE_AI_HIGH = 81,
            E_EVENT_TYPE_AI_UNLOCK_ADVANCE = 82
        }

        enum E_Button_Type {
            E_BUTTON_TYPE_UNKNOWN = 0,
            E_BUTTON_TYPE_GUEST = 1,
            E_BUTTON_TYPE_FACEBOOK = 2,
            E_BUTTON_TYPE_APPLE = 3
        }

        enum E_Enter_Type {
            E_ENTER_TYPE_UNKNOWN = 0,
            E_ENTER_TYPE_ENGLAND = 1,
            E_ENTER_TYPE_PARIS = 2,
            E_ENTER_TYPE_NEWYORK = 3,
            E_ENTER_TYPE_MOSCOW = 4,
            E_ENTER_TYPE_LASVEGAS = 5
        }

        interface IUserActionReportReq {
            eventType?: (number|null);
            subType?: (number|null);
            device?: (string|null);
            uid?: (Long|null);
            extend?: (string[]|null);
        }

        class UserActionReportReq implements IUserActionReportReq {
            constructor(p?: LoginProto.IUserActionReportReq);
            public eventType: number;
            public subType: number;
            public device: string;
            public uid: Long;
            public extend: string[];
            public static create(properties?: LoginProto.IUserActionReportReq): LoginProto.UserActionReportReq;
            public static encode(m: LoginProto.UserActionReportReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.UserActionReportReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserActionReportResp {
            resultCode?: (number|null);
        }

        class UserActionReportResp implements IUserActionReportResp {
            constructor(p?: LoginProto.IUserActionReportResp);
            public resultCode: number;
            public static create(properties?: LoginProto.IUserActionReportResp): LoginProto.UserActionReportResp;
            public static encode(m: LoginProto.UserActionReportResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): LoginProto.UserActionReportResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }

    namespace MatchProto {

        interface IGamePrizePoolInfo {
            iGetRewardNum?: (number|null);
            mPrizePoolMap?: ({ [k: string]: number }|null);
            vInfos?: (MatchProto.PrizeInfo[]|null);
        }

        class GamePrizePoolInfo implements IGamePrizePoolInfo {
            constructor(p?: MatchProto.IGamePrizePoolInfo);
            public iGetRewardNum: number;
            public mPrizePoolMap: { [k: string]: number };
            public vInfos: MatchProto.PrizeInfo[];
            public static create(properties?: MatchProto.IGamePrizePoolInfo): MatchProto.GamePrizePoolInfo;
            public static encode(m: MatchProto.GamePrizePoolInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): MatchProto.GamePrizePoolInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPrizeInfo {
            iRankBegin?: (number|null);
            iRankEnd?: (number|null);
            reward?: ({ [k: string]: number }|null);
        }

        class PrizeInfo implements IPrizeInfo {
            constructor(p?: MatchProto.IPrizeInfo);
            public iRankBegin: number;
            public iRankEnd: number;
            public reward: { [k: string]: number };
            public static create(properties?: MatchProto.IPrizeInfo): MatchProto.PrizeInfo;
            public static encode(m: MatchProto.PrizeInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): MatchProto.PrizeInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameMatchRoomInfo {
            iId?: (number|null);
            iGameType?: (number|null);
            sName?: (string|null);
            mTicketMap?: ({ [k: string]: number }|null);
            iPeople?: (number|null);
            iBattleType?: (number|null);
            iVipLevel?: (number|null);
            iDailyOpenTime?: (number|null);
            iContiuneTime?: (number|null);
            iFixOpenTime?: (number|null);
            iFixCloseTime?: (number|null);
            iDelyTime?: (number|null);
            iDiscount?: (number|null);
            iDiscountBeginTime?: (number|null);
            iDiscountEndTime?: (number|null);
            iSort?: (number|null);
            dPrizePool?: (MatchProto.GamePrizePoolInfo|null);
            sBgurl?: (string|null);
            iMaxPlayTimes?: (number|null);
            iMatch?: (number|null);
            iGuide?: (number|null);
            iVipLevelMax?: (number|null);
            iRTP?: (number|null);
            iMenuType?: (number|null);
        }

        class GameMatchRoomInfo implements IGameMatchRoomInfo {
            constructor(p?: MatchProto.IGameMatchRoomInfo);
            public iId: number;
            public iGameType: number;
            public sName: string;
            public mTicketMap: { [k: string]: number };
            public iPeople: number;
            public iBattleType: number;
            public iVipLevel: number;
            public iDailyOpenTime: number;
            public iContiuneTime: number;
            public iFixOpenTime: number;
            public iFixCloseTime: number;
            public iDelyTime: number;
            public iDiscount: number;
            public iDiscountBeginTime: number;
            public iDiscountEndTime: number;
            public iSort: number;
            public dPrizePool?: (MatchProto.GamePrizePoolInfo|null);
            public sBgurl: string;
            public iMaxPlayTimes: number;
            public iMatch: number;
            public iGuide: number;
            public iVipLevelMax: number;
            public iRTP: number;
            public iMenuType: number;
            public static create(properties?: MatchProto.IGameMatchRoomInfo): MatchProto.GameMatchRoomInfo;
            public static encode(m: MatchProto.GameMatchRoomInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): MatchProto.GameMatchRoomInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameMatchUser {
            lUid?: (Long|null);
            sAvater?: (string|null);
        }

        class GameMatchUser implements IGameMatchUser {
            constructor(p?: MatchProto.IGameMatchUser);
            public lUid: Long;
            public sAvater: string;
            public static create(properties?: MatchProto.IGameMatchUser): MatchProto.GameMatchUser;
            public static encode(m: MatchProto.GameMatchUser, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): MatchProto.GameMatchUser;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameMatchListReq {
            iGameType?: (number|null);
        }

        class GameMatchListReq implements IGameMatchListReq {
            constructor(p?: MatchProto.IGameMatchListReq);
            public iGameType: number;
            public static create(properties?: MatchProto.IGameMatchListReq): MatchProto.GameMatchListReq;
            public static encode(m: MatchProto.GameMatchListReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): MatchProto.GameMatchListReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameMatchListRsp {
            iGameType?: (number|null);
            vInfo?: (MatchProto.GameMatchRoomInfo[]|null);
        }

        class GameMatchListRsp implements IGameMatchListRsp {
            constructor(p?: MatchProto.IGameMatchListRsp);
            public iGameType: number;
            public vInfo: MatchProto.GameMatchRoomInfo[];
            public static create(properties?: MatchProto.IGameMatchListRsp): MatchProto.GameMatchListRsp;
            public static encode(m: MatchProto.GameMatchListRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): MatchProto.GameMatchListRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameMatchBeginReq {
            iGameType?: (number|null);
            iGameID?: (number|null);
            sAvater?: (string|null);
            iShowId?: (number|null);
        }

        class GameMatchBeginReq implements IGameMatchBeginReq {
            constructor(p?: MatchProto.IGameMatchBeginReq);
            public iGameType: number;
            public iGameID: number;
            public sAvater: string;
            public iShowId: number;
            public static create(properties?: MatchProto.IGameMatchBeginReq): MatchProto.GameMatchBeginReq;
            public static encode(m: MatchProto.GameMatchBeginReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): MatchProto.GameMatchBeginReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameMatchBeginRsp {
            iResultID?: (number|null);
            iGameType?: (number|null);
            iGameID?: (number|null);
        }

        class GameMatchBeginRsp implements IGameMatchBeginRsp {
            constructor(p?: MatchProto.IGameMatchBeginRsp);
            public iResultID: number;
            public iGameType: number;
            public iGameID: number;
            public static create(properties?: MatchProto.IGameMatchBeginRsp): MatchProto.GameMatchBeginRsp;
            public static encode(m: MatchProto.GameMatchBeginRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): MatchProto.GameMatchBeginRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameMatchCancelReq {
            iGameType?: (number|null);
            iGameID?: (number|null);
        }

        class GameMatchCancelReq implements IGameMatchCancelReq {
            constructor(p?: MatchProto.IGameMatchCancelReq);
            public iGameType: number;
            public iGameID: number;
            public static create(properties?: MatchProto.IGameMatchCancelReq): MatchProto.GameMatchCancelReq;
            public static encode(m: MatchProto.GameMatchCancelReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): MatchProto.GameMatchCancelReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameMatchCancelRsp {
            iResultID?: (number|null);
            iGameType?: (number|null);
            iGameID?: (number|null);
        }

        class GameMatchCancelRsp implements IGameMatchCancelRsp {
            constructor(p?: MatchProto.IGameMatchCancelRsp);
            public iResultID: number;
            public iGameType: number;
            public iGameID: number;
            public static create(properties?: MatchProto.IGameMatchCancelRsp): MatchProto.GameMatchCancelRsp;
            public static encode(m: MatchProto.GameMatchCancelRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): MatchProto.GameMatchCancelRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameMatchTimeoutNotify {
            iGameType?: (number|null);
            iGameID?: (number|null);
        }

        class GameMatchTimeoutNotify implements IGameMatchTimeoutNotify {
            constructor(p?: MatchProto.IGameMatchTimeoutNotify);
            public iGameType: number;
            public iGameID: number;
            public static create(properties?: MatchProto.IGameMatchTimeoutNotify): MatchProto.GameMatchTimeoutNotify;
            public static encode(m: MatchProto.GameMatchTimeoutNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): MatchProto.GameMatchTimeoutNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameMatchSucceedNotify {
            iMatchID?: (Long|null);
            iRoomID?: (number|null);
        }

        class GameMatchSucceedNotify implements IGameMatchSucceedNotify {
            constructor(p?: MatchProto.IGameMatchSucceedNotify);
            public iMatchID: Long;
            public iRoomID: number;
            public static create(properties?: MatchProto.IGameMatchSucceedNotify): MatchProto.GameMatchSucceedNotify;
            public static encode(m: MatchProto.GameMatchSucceedNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): MatchProto.GameMatchSucceedNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameMatchPushNotify {
            infos?: (MatchProto.GameMatchUser[]|null);
        }

        class GameMatchPushNotify implements IGameMatchPushNotify {
            constructor(p?: MatchProto.IGameMatchPushNotify);
            public infos: MatchProto.GameMatchUser[];
            public static create(properties?: MatchProto.IGameMatchPushNotify): MatchProto.GameMatchPushNotify;
            public static encode(m: MatchProto.GameMatchPushNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): MatchProto.GameMatchPushNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameMatchGetNotifyReq {
            iGameType?: (number|null);
            iGameID?: (number|null);
        }

        class GameMatchGetNotifyReq implements IGameMatchGetNotifyReq {
            constructor(p?: MatchProto.IGameMatchGetNotifyReq);
            public iGameType: number;
            public iGameID: number;
            public static create(properties?: MatchProto.IGameMatchGetNotifyReq): MatchProto.GameMatchGetNotifyReq;
            public static encode(m: MatchProto.GameMatchGetNotifyReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): MatchProto.GameMatchGetNotifyReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameMatchGetNotifyRsp {
            infos?: (MatchProto.GameMatchUser[]|null);
        }

        class GameMatchGetNotifyRsp implements IGameMatchGetNotifyRsp {
            constructor(p?: MatchProto.IGameMatchGetNotifyRsp);
            public infos: MatchProto.GameMatchUser[];
            public static create(properties?: MatchProto.IGameMatchGetNotifyRsp): MatchProto.GameMatchGetNotifyRsp;
            public static encode(m: MatchProto.GameMatchGetNotifyRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): MatchProto.GameMatchGetNotifyRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }

    namespace PlatformProto {

        interface IGetPlatformAccountDetailReq {
            lPid?: (Long|null);
        }

        class GetPlatformAccountDetailReq implements IGetPlatformAccountDetailReq {
            constructor(p?: PlatformProto.IGetPlatformAccountDetailReq);
            public lPid: Long;
            public static create(properties?: PlatformProto.IGetPlatformAccountDetailReq): PlatformProto.GetPlatformAccountDetailReq;
            public static encode(m: PlatformProto.GetPlatformAccountDetailReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): PlatformProto.GetPlatformAccountDetailReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetPlatformAccountDetailRsp {
            iResultCode?: (number|null);
            lPid?: (Long|null);
            iAccountType?: (number|null);
            sPhoneAreaCode?: (string|null);
            sPhoneNumber?: (string|null);
            sPassword?: (string|null);
            sNickname?: (string|null);
            sAvatar?: (string|null);
            lVipLevel?: (Long|null);
            lVipExp?: (Long|null);
            lCash?: (Long|null);
            lBonus?: (Long|null);
            lDiamond?: (Long|null);
        }

        class GetPlatformAccountDetailRsp implements IGetPlatformAccountDetailRsp {
            constructor(p?: PlatformProto.IGetPlatformAccountDetailRsp);
            public iResultCode: number;
            public lPid: Long;
            public iAccountType: number;
            public sPhoneAreaCode: string;
            public sPhoneNumber: string;
            public sPassword: string;
            public sNickname: string;
            public sAvatar: string;
            public lVipLevel: Long;
            public lVipExp: Long;
            public lCash: Long;
            public lBonus: Long;
            public lDiamond: Long;
            public static create(properties?: PlatformProto.IGetPlatformAccountDetailRsp): PlatformProto.GetPlatformAccountDetailRsp;
            public static encode(m: PlatformProto.GetPlatformAccountDetailRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): PlatformProto.GetPlatformAccountDetailRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPlatformAccountBindingPhoneReq {
            sPhoneAreaCode?: (string|null);
            sPhoneNumber?: (string|null);
            sPhoneCode?: (string|null);
        }

        class PlatformAccountBindingPhoneReq implements IPlatformAccountBindingPhoneReq {
            constructor(p?: PlatformProto.IPlatformAccountBindingPhoneReq);
            public sPhoneAreaCode: string;
            public sPhoneNumber: string;
            public sPhoneCode: string;
            public static create(properties?: PlatformProto.IPlatformAccountBindingPhoneReq): PlatformProto.PlatformAccountBindingPhoneReq;
            public static encode(m: PlatformProto.PlatformAccountBindingPhoneReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): PlatformProto.PlatformAccountBindingPhoneReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPlatformAccountBindingPhoneRsp {
            iResultCode?: (number|null);
            sPhoneAreaCode?: (string|null);
            sPhoneNumber?: (string|null);
        }

        class PlatformAccountBindingPhoneRsp implements IPlatformAccountBindingPhoneRsp {
            constructor(p?: PlatformProto.IPlatformAccountBindingPhoneRsp);
            public iResultCode: number;
            public sPhoneAreaCode: string;
            public sPhoneNumber: string;
            public static create(properties?: PlatformProto.IPlatformAccountBindingPhoneRsp): PlatformProto.PlatformAccountBindingPhoneRsp;
            public static encode(m: PlatformProto.PlatformAccountBindingPhoneRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): PlatformProto.PlatformAccountBindingPhoneRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPlatformAccountSetPasswordReq {
            sPhoneCode?: (string|null);
            sPassword?: (string|null);
        }

        class PlatformAccountSetPasswordReq implements IPlatformAccountSetPasswordReq {
            constructor(p?: PlatformProto.IPlatformAccountSetPasswordReq);
            public sPhoneCode: string;
            public sPassword: string;
            public static create(properties?: PlatformProto.IPlatformAccountSetPasswordReq): PlatformProto.PlatformAccountSetPasswordReq;
            public static encode(m: PlatformProto.PlatformAccountSetPasswordReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): PlatformProto.PlatformAccountSetPasswordReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPlatformAccountSetPasswordRsp {
            iResultCode?: (number|null);
        }

        class PlatformAccountSetPasswordRsp implements IPlatformAccountSetPasswordRsp {
            constructor(p?: PlatformProto.IPlatformAccountSetPasswordRsp);
            public iResultCode: number;
            public static create(properties?: PlatformProto.IPlatformAccountSetPasswordRsp): PlatformProto.PlatformAccountSetPasswordRsp;
            public static encode(m: PlatformProto.PlatformAccountSetPasswordRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): PlatformProto.PlatformAccountSetPasswordRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }

    namespace PushProto {

        interface IMatchBeginNotify {
            matchID?: (number|null);
            sRoomID?: (string|null);
        }

        class MatchBeginNotify implements IMatchBeginNotify {
            constructor(p?: PushProto.IMatchBeginNotify);
            public matchID: number;
            public sRoomID: string;
            public static create(properties?: PushProto.IMatchBeginNotify): PushProto.MatchBeginNotify;
            public static encode(m: PushProto.MatchBeginNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): PushProto.MatchBeginNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IDefaultNotify {
            resultCode?: (number|null);
        }

        class DefaultNotify implements IDefaultNotify {
            constructor(p?: PushProto.IDefaultNotify);
            public resultCode: number;
            public static create(properties?: PushProto.IDefaultNotify): PushProto.DefaultNotify;
            public static encode(m: PushProto.DefaultNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): PushProto.DefaultNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ICoinNotify {
            changeType?: (number|null);
            gold?: (Long|null);
            diamond?: (Long|null);
            point?: (Long|null);
            tickets?: (Long|null);
            level?: (number|null);
            experience?: (number|null);
            vipLevel?: (number|null);
            vipExperience?: (number|null);
            safeBalance?: (Long|null);
        }

        class CoinNotify implements ICoinNotify {
            constructor(p?: PushProto.ICoinNotify);
            public changeType: number;
            public gold: Long;
            public diamond: Long;
            public point: Long;
            public tickets: Long;
            public level: number;
            public experience: number;
            public vipLevel: number;
            public vipExperience: number;
            public safeBalance: Long;
            public static create(properties?: PushProto.ICoinNotify): PushProto.CoinNotify;
            public static encode(m: PushProto.CoinNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): PushProto.CoinNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IInvitedPlayerNotify {
            sRoomID?: (string|null);
            sRoomName?: (string|null);
            sNickName?: (string|null);
            lPlayerID?: (Long|null);
            lBigBlind?: (Long|null);
            lSmallBlind?: (Long|null);
            matchID?: (number|null);
            tableID?: (number|null);
            sRoomKey?: (string|null);
        }

        class InvitedPlayerNotify implements IInvitedPlayerNotify {
            constructor(p?: PushProto.IInvitedPlayerNotify);
            public sRoomID: string;
            public sRoomName: string;
            public sNickName: string;
            public lPlayerID: Long;
            public lBigBlind: Long;
            public lSmallBlind: Long;
            public matchID: number;
            public tableID: number;
            public sRoomKey: string;
            public static create(properties?: PushProto.IInvitedPlayerNotify): PushProto.InvitedPlayerNotify;
            public static encode(m: PushProto.InvitedPlayerNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): PushProto.InvitedPlayerNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IAddFriendNotify {
            lPlayerID?: (Long|null);
            sNickName?: (string|null);
        }

        class AddFriendNotify implements IAddFriendNotify {
            constructor(p?: PushProto.IAddFriendNotify);
            public lPlayerID: Long;
            public sNickName: string;
            public static create(properties?: PushProto.IAddFriendNotify): PushProto.AddFriendNotify;
            public static encode(m: PushProto.AddFriendNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): PushProto.AddFriendNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameUpdateNotify {
            isReboot?: (number|null);
            isResUpdate?: (number|null);
            isCodeUpdate?: (number|null);
        }

        class GameUpdateNotify implements IGameUpdateNotify {
            constructor(p?: PushProto.IGameUpdateNotify);
            public isReboot: number;
            public isResUpdate: number;
            public isCodeUpdate: number;
            public static create(properties?: PushProto.IGameUpdateNotify): PushProto.GameUpdateNotify;
            public static encode(m: PushProto.GameUpdateNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): PushProto.GameUpdateNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ITaskFinishNotify {
            taskList?: (number[]|null);
        }

        class TaskFinishNotify implements ITaskFinishNotify {
            constructor(p?: PushProto.ITaskFinishNotify);
            public taskList: number[];
            public static create(properties?: PushProto.ITaskFinishNotify): PushProto.TaskFinishNotify;
            public static encode(m: PushProto.TaskFinishNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): PushProto.TaskFinishNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IRechargeRewardsNotify {
            isLimitedTime?: (number|null);
            isFirstTime?: (number|null);
            isDailyTime?: (number|null);
        }

        class RechargeRewardsNotify implements IRechargeRewardsNotify {
            constructor(p?: PushProto.IRechargeRewardsNotify);
            public isLimitedTime: number;
            public isFirstTime: number;
            public isDailyTime: number;
            public static create(properties?: PushProto.IRechargeRewardsNotify): PushProto.RechargeRewardsNotify;
            public static encode(m: PushProto.RechargeRewardsNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): PushProto.RechargeRewardsNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IServerUpdateNotify {
            iMinutes?: (number|null);
        }

        class ServerUpdateNotify implements IServerUpdateNotify {
            constructor(p?: PushProto.IServerUpdateNotify);
            public iMinutes: number;
            public static create(properties?: PushProto.IServerUpdateNotify): PushProto.ServerUpdateNotify;
            public static encode(m: PushProto.ServerUpdateNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): PushProto.ServerUpdateNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        enum NotifyType {
            NOTIFY_DEFAULT = 0,
            CONNECTION_IDLE = 1,
            SERVICE_MAINTAIN = 2
        }

        interface IServerChangeNotify {
            iNotifyType?: (number|null);
            iReturnLoginGUI?: (number|null);
        }

        class ServerChangeNotify implements IServerChangeNotify {
            constructor(p?: PushProto.IServerChangeNotify);
            public iNotifyType: number;
            public iReturnLoginGUI: number;
            public static create(properties?: PushProto.IServerChangeNotify): PushProto.ServerChangeNotify;
            public static encode(m: PushProto.ServerChangeNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): PushProto.ServerChangeNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPropsChangeNotify {
            resultCode?: (number|null);
            propsId?: (number|null);
            currCount?: (Long|null);
        }

        class PropsChangeNotify implements IPropsChangeNotify {
            constructor(p?: PushProto.IPropsChangeNotify);
            public resultCode: number;
            public propsId: number;
            public currCount: Long;
            public static create(properties?: PushProto.IPropsChangeNotify): PushProto.PropsChangeNotify;
            public static encode(m: PushProto.PropsChangeNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): PushProto.PropsChangeNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IRewardNotify {
            id?: (number|null);
            type?: (number|null);
            data?: (string|null);
            param?: (PushProto.RewardNotify.RewardParam|null);
        }

        class RewardNotify implements IRewardNotify {
            constructor(p?: PushProto.IRewardNotify);
            public id: number;
            public type: number;
            public data: string;
            public param?: (PushProto.RewardNotify.RewardParam|null);
            public static create(properties?: PushProto.IRewardNotify): PushProto.RewardNotify;
            public static encode(m: PushProto.RewardNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): PushProto.RewardNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        namespace RewardNotify {

            enum E_Reward_Mold_ID {
                E_REWARD_MOLD_INVALID = 0,
                E_REWARD_MOLD_BLIND_NOTE = 1,
                E_REWARD_MOLD_AOF_CONTEST = 2,
                E_REWARD_MOLD_DUAN_PAI = 3,
                E_REWARD_MOLD_SNG_CONTEST = 4,
                E_REWARD_MOLD_MTT_CONTEST = 5,
                E_REWARD_MOLD_TOKEN_LOTTERY = 6,
                E_REWARD_MOLD_HUNDRED = 7
            }

            interface IRewardParam {
                sNickName?: (string|null);
                sPlace?: (string|null);
                ranking?: (number|null);
                sPrize?: (PushProto.PropsChangeNotify[]|null);
                intervalTime?: (Long|null);
                views?: (Long|null);
            }

            class RewardParam implements IRewardParam {
                constructor(p?: PushProto.RewardNotify.IRewardParam);
                public sNickName: string;
                public sPlace: string;
                public ranking: number;
                public sPrize: PushProto.PropsChangeNotify[];
                public intervalTime: Long;
                public views: Long;
                public static create(properties?: PushProto.RewardNotify.IRewardParam): PushProto.RewardNotify.RewardParam;
                public static encode(m: PushProto.RewardNotify.RewardParam, w?: $protobuf.Writer): $protobuf.Writer;
                public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): PushProto.RewardNotify.RewardParam;
                public static getTypeUrl(typeUrlPrefix?: string): string;
            }
        }

        interface IPreciousBoxNotify {
            iBetId?: (number|null);
            number?: (number|null);
        }

        class PreciousBoxNotify implements IPreciousBoxNotify {
            constructor(p?: PushProto.IPreciousBoxNotify);
            public iBetId: number;
            public number: number;
            public static create(properties?: PushProto.IPreciousBoxNotify): PushProto.PreciousBoxNotify;
            public static encode(m: PushProto.PreciousBoxNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): PushProto.PreciousBoxNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }

    namespace RecordProto {

        interface IReward {
            type?: (number|null);
            amount?: (number|null);
        }

        class Reward implements IReward {
            constructor(p?: RecordProto.IReward);
            public type: number;
            public amount: number;
            public static create(properties?: RecordProto.IReward): RecordProto.Reward;
            public static encode(m: RecordProto.Reward, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RecordProto.Reward;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IPrizeReward {
            rankBegin?: (number|null);
            rankEnd?: (number|null);
            reward?: (RecordProto.Reward[]|null);
        }

        class PrizeReward implements IPrizeReward {
            constructor(p?: RecordProto.IPrizeReward);
            public rankBegin: number;
            public rankEnd: number;
            public reward: RecordProto.Reward[];
            public static create(properties?: RecordProto.IPrizeReward): RecordProto.PrizeReward;
            public static encode(m: RecordProto.PrizeReward, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RecordProto.PrizeReward;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGamePlayerInfo {
            uid?: (Long|null);
            name?: (string|null);
            avater?: (string|null);
            reward?: (RecordProto.Reward[]|null);
            state?: (number|null);
            ranking?: (number|null);
            elo?: (number|null);
            replay?: (number|null);
        }

        class GamePlayerInfo implements IGamePlayerInfo {
            constructor(p?: RecordProto.IGamePlayerInfo);
            public uid: Long;
            public name: string;
            public avater: string;
            public reward: RecordProto.Reward[];
            public state: number;
            public ranking: number;
            public elo: number;
            public replay: number;
            public static create(properties?: RecordProto.IGamePlayerInfo): RecordProto.GamePlayerInfo;
            public static encode(m: RecordProto.GamePlayerInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RecordProto.GamePlayerInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameSummarizeInfo {
            matchGuid?: (Long|null);
            matchName?: (string|null);
            matchState?: (number|null);
            playerCount?: (number|null);
            beginTime?: (number|null);
            overTime?: (number|null);
            reward?: (RecordProto.Reward[]|null);
            redState?: (number|null);
            rank?: (number|null);
            info?: (RecordProto.GamePlayerInfo[]|null);
            activityType?: (number|null);
            activityID?: (number|null);
            activityScore?: (Long|null);
            activityReward?: (RecordProto.PrizeReward[]|null);
            takeState?: (number|null);
            showId?: (number|null);
            replay?: (number|null);
            prodId?: (number|null);
        }

        class GameSummarizeInfo implements IGameSummarizeInfo {
            constructor(p?: RecordProto.IGameSummarizeInfo);
            public matchGuid: Long;
            public matchName: string;
            public matchState: number;
            public playerCount: number;
            public beginTime: number;
            public overTime: number;
            public reward: RecordProto.Reward[];
            public redState: number;
            public rank: number;
            public info: RecordProto.GamePlayerInfo[];
            public activityType: number;
            public activityID: number;
            public activityScore: Long;
            public activityReward: RecordProto.PrizeReward[];
            public takeState: number;
            public showId: number;
            public replay: number;
            public prodId: number;
            public static create(properties?: RecordProto.IGameSummarizeInfo): RecordProto.GameSummarizeInfo;
            public static encode(m: RecordProto.GameSummarizeInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RecordProto.GameSummarizeInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameSummarizeListReq {
            gameType?: (number|null);
            playerID?: (Long|null);
            pageIndex?: (number|null);
        }

        class GameSummarizeListReq implements IGameSummarizeListReq {
            constructor(p?: RecordProto.IGameSummarizeListReq);
            public gameType: number;
            public playerID: Long;
            public pageIndex: number;
            public static create(properties?: RecordProto.IGameSummarizeListReq): RecordProto.GameSummarizeListReq;
            public static encode(m: RecordProto.GameSummarizeListReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RecordProto.GameSummarizeListReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameSummarizeListRsp {
            gameType?: (number|null);
            pageIndex?: (number|null);
            pageNum?: (number|null);
            vInfo?: (RecordProto.GameSummarizeInfo[]|null);
            takeAll?: (number|null);
        }

        class GameSummarizeListRsp implements IGameSummarizeListRsp {
            constructor(p?: RecordProto.IGameSummarizeListRsp);
            public gameType: number;
            public pageIndex: number;
            public pageNum: number;
            public vInfo: RecordProto.GameSummarizeInfo[];
            public takeAll: number;
            public static create(properties?: RecordProto.IGameSummarizeListRsp): RecordProto.GameSummarizeListRsp;
            public static encode(m: RecordProto.GameSummarizeListRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RecordProto.GameSummarizeListRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameSummarizeInfoReq {
            matchGuid?: (Long|null);
        }

        class GameSummarizeInfoReq implements IGameSummarizeInfoReq {
            constructor(p?: RecordProto.IGameSummarizeInfoReq);
            public matchGuid: Long;
            public static create(properties?: RecordProto.IGameSummarizeInfoReq): RecordProto.GameSummarizeInfoReq;
            public static encode(m: RecordProto.GameSummarizeInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RecordProto.GameSummarizeInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameSummarizeInfoRsp {
            info?: (RecordProto.GameSummarizeInfo|null);
        }

        class GameSummarizeInfoRsp implements IGameSummarizeInfoRsp {
            constructor(p?: RecordProto.IGameSummarizeInfoRsp);
            public info?: (RecordProto.GameSummarizeInfo|null);
            public static create(properties?: RecordProto.IGameSummarizeInfoRsp): RecordProto.GameSummarizeInfoRsp;
            public static encode(m: RecordProto.GameSummarizeInfoRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RecordProto.GameSummarizeInfoRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGamePlayerMoreInfoReq {
            matchGuid?: (Long|null);
        }

        class GamePlayerMoreInfoReq implements IGamePlayerMoreInfoReq {
            constructor(p?: RecordProto.IGamePlayerMoreInfoReq);
            public matchGuid: Long;
            public static create(properties?: RecordProto.IGamePlayerMoreInfoReq): RecordProto.GamePlayerMoreInfoReq;
            public static encode(m: RecordProto.GamePlayerMoreInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RecordProto.GamePlayerMoreInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGamePlayerMoreInfoRsp {
            matchGuid?: (Long|null);
            vPlayer?: (RecordProto.GamePlayerInfo[]|null);
            finished?: (number|null);
            rank?: (number|null);
            activityScore?: (Long|null);
            activityType?: (number|null);
            activityID?: (number|null);
            activityReward?: (RecordProto.PrizeReward[]|null);
            playerCount?: (number|null);
            replay?: (number|null);
            matchName?: (string|null);
            takeState?: (number|null);
            prodId?: (number|null);
        }

        class GamePlayerMoreInfoRsp implements IGamePlayerMoreInfoRsp {
            constructor(p?: RecordProto.IGamePlayerMoreInfoRsp);
            public matchGuid: Long;
            public vPlayer: RecordProto.GamePlayerInfo[];
            public finished: number;
            public rank: number;
            public activityScore: Long;
            public activityType: number;
            public activityID: number;
            public activityReward: RecordProto.PrizeReward[];
            public playerCount: number;
            public replay: number;
            public matchName: string;
            public takeState: number;
            public prodId: number;
            public static create(properties?: RecordProto.IGamePlayerMoreInfoRsp): RecordProto.GamePlayerMoreInfoRsp;
            public static encode(m: RecordProto.GamePlayerMoreInfoRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RecordProto.GamePlayerMoreInfoRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameUpdaeRedStateReq {
            matchGuid?: (Long|null);
        }

        class GameUpdaeRedStateReq implements IGameUpdaeRedStateReq {
            constructor(p?: RecordProto.IGameUpdaeRedStateReq);
            public matchGuid: Long;
            public static create(properties?: RecordProto.IGameUpdaeRedStateReq): RecordProto.GameUpdaeRedStateReq;
            public static encode(m: RecordProto.GameUpdaeRedStateReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RecordProto.GameUpdaeRedStateReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGamePlayerSocreInfo {
            score?: (Long|null);
        }

        class GamePlayerSocreInfo implements IGamePlayerSocreInfo {
            constructor(p?: RecordProto.IGamePlayerSocreInfo);
            public score: Long;
            public static create(properties?: RecordProto.IGamePlayerSocreInfo): RecordProto.GamePlayerSocreInfo;
            public static encode(m: RecordProto.GamePlayerSocreInfo, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RecordProto.GamePlayerSocreInfo;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGamePlayerScoreInfoReq {
            uid?: (Long|null);
            ActivityID?: (number|null);
        }

        class GamePlayerScoreInfoReq implements IGamePlayerScoreInfoReq {
            constructor(p?: RecordProto.IGamePlayerScoreInfoReq);
            public uid: Long;
            public ActivityID: number;
            public static create(properties?: RecordProto.IGamePlayerScoreInfoReq): RecordProto.GamePlayerScoreInfoReq;
            public static encode(m: RecordProto.GamePlayerScoreInfoReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RecordProto.GamePlayerScoreInfoReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGamePlayerScoreInfoRsp {
            ActivityID?: (Long|null);
            infos?: (RecordProto.GamePlayerSocreInfo[]|null);
        }

        class GamePlayerScoreInfoRsp implements IGamePlayerScoreInfoRsp {
            constructor(p?: RecordProto.IGamePlayerScoreInfoRsp);
            public ActivityID: Long;
            public infos: RecordProto.GamePlayerSocreInfo[];
            public static create(properties?: RecordProto.IGamePlayerScoreInfoRsp): RecordProto.GamePlayerScoreInfoRsp;
            public static encode(m: RecordProto.GamePlayerScoreInfoRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RecordProto.GamePlayerScoreInfoRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameSummarizeTakeRewardReq {
            matchGuid?: (Long|null);
        }

        class GameSummarizeTakeRewardReq implements IGameSummarizeTakeRewardReq {
            constructor(p?: RecordProto.IGameSummarizeTakeRewardReq);
            public matchGuid: Long;
            public static create(properties?: RecordProto.IGameSummarizeTakeRewardReq): RecordProto.GameSummarizeTakeRewardReq;
            public static encode(m: RecordProto.GameSummarizeTakeRewardReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RecordProto.GameSummarizeTakeRewardReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameSummarizeTakeRewardRsp {
            resultCode?: (number|null);
            matchGuid?: (Long|null);
            reward?: (RecordProto.Reward[]|null);
            takeAll?: (number|null);
        }

        class GameSummarizeTakeRewardRsp implements IGameSummarizeTakeRewardRsp {
            constructor(p?: RecordProto.IGameSummarizeTakeRewardRsp);
            public resultCode: number;
            public matchGuid: Long;
            public reward: RecordProto.Reward[];
            public takeAll: number;
            public static create(properties?: RecordProto.IGameSummarizeTakeRewardRsp): RecordProto.GameSummarizeTakeRewardRsp;
            public static encode(m: RecordProto.GameSummarizeTakeRewardRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RecordProto.GameSummarizeTakeRewardRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameSummarizeGetTakeRewardReq {
            uid?: (Long|null);
        }

        class GameSummarizeGetTakeRewardReq implements IGameSummarizeGetTakeRewardReq {
            constructor(p?: RecordProto.IGameSummarizeGetTakeRewardReq);
            public uid: Long;
            public static create(properties?: RecordProto.IGameSummarizeGetTakeRewardReq): RecordProto.GameSummarizeGetTakeRewardReq;
            public static encode(m: RecordProto.GameSummarizeGetTakeRewardReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RecordProto.GameSummarizeGetTakeRewardReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGameSummarizeGetTakeRewardRsp {
            resultCode?: (number|null);
            reward?: (RecordProto.Reward[]|null);
            count?: (number|null);
        }

        class GameSummarizeGetTakeRewardRsp implements IGameSummarizeGetTakeRewardRsp {
            constructor(p?: RecordProto.IGameSummarizeGetTakeRewardRsp);
            public resultCode: number;
            public reward: RecordProto.Reward[];
            public count: number;
            public static create(properties?: RecordProto.IGameSummarizeGetTakeRewardRsp): RecordProto.GameSummarizeGetTakeRewardRsp;
            public static encode(m: RecordProto.GameSummarizeGetTakeRewardRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RecordProto.GameSummarizeGetTakeRewardRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }

    namespace RoomProto {

        interface IRoomEnterReq {
            roomID?: (Long|null);
            matchID?: (Long|null);
        }

        class RoomEnterReq implements IRoomEnterReq {
            constructor(p?: RoomProto.IRoomEnterReq);
            public roomID: Long;
            public matchID: Long;
            public static create(properties?: RoomProto.IRoomEnterReq): RoomProto.RoomEnterReq;
            public static encode(m: RoomProto.RoomEnterReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RoomProto.RoomEnterReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IRoomEnterRsp {
            roomID?: (Long|null);
            matchID?: (Long|null);
            resultCode?: (number|null);
        }

        class RoomEnterRsp implements IRoomEnterRsp {
            constructor(p?: RoomProto.IRoomEnterRsp);
            public roomID: Long;
            public matchID: Long;
            public resultCode: number;
            public static create(properties?: RoomProto.IRoomEnterRsp): RoomProto.RoomEnterRsp;
            public static encode(m: RoomProto.RoomEnterRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RoomProto.RoomEnterRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IRoomExitReq {
            roomID?: (Long|null);
            matchID?: (Long|null);
        }

        class RoomExitReq implements IRoomExitReq {
            constructor(p?: RoomProto.IRoomExitReq);
            public roomID: Long;
            public matchID: Long;
            public static create(properties?: RoomProto.IRoomExitReq): RoomProto.RoomExitReq;
            public static encode(m: RoomProto.RoomExitReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RoomProto.RoomExitReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IRoomExitRsp {
            roomID?: (Long|null);
            matchID?: (Long|null);
            resultCode?: (number|null);
        }

        class RoomExitRsp implements IRoomExitRsp {
            constructor(p?: RoomProto.IRoomExitRsp);
            public roomID: Long;
            public matchID: Long;
            public resultCode: number;
            public static create(properties?: RoomProto.IRoomExitRsp): RoomProto.RoomExitRsp;
            public static encode(m: RoomProto.RoomExitRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RoomProto.RoomExitRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IRoomGameStartReq {
            roomID?: (Long|null);
            matchID?: (Long|null);
        }

        class RoomGameStartReq implements IRoomGameStartReq {
            constructor(p?: RoomProto.IRoomGameStartReq);
            public roomID: Long;
            public matchID: Long;
            public static create(properties?: RoomProto.IRoomGameStartReq): RoomProto.RoomGameStartReq;
            public static encode(m: RoomProto.RoomGameStartReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RoomProto.RoomGameStartReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IRoomGameStartRsp {
            roomID?: (Long|null);
            matchID?: (Long|null);
            resultCode?: (number|null);
        }

        class RoomGameStartRsp implements IRoomGameStartRsp {
            constructor(p?: RoomProto.IRoomGameStartRsp);
            public roomID: Long;
            public matchID: Long;
            public resultCode: number;
            public static create(properties?: RoomProto.IRoomGameStartRsp): RoomProto.RoomGameStartRsp;
            public static encode(m: RoomProto.RoomGameStartRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RoomProto.RoomGameStartRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IRoomGamePauseReq {
            roomID?: (Long|null);
            matchID?: (Long|null);
        }

        class RoomGamePauseReq implements IRoomGamePauseReq {
            constructor(p?: RoomProto.IRoomGamePauseReq);
            public roomID: Long;
            public matchID: Long;
            public static create(properties?: RoomProto.IRoomGamePauseReq): RoomProto.RoomGamePauseReq;
            public static encode(m: RoomProto.RoomGamePauseReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RoomProto.RoomGamePauseReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IRoomGamePauseRsp {
            roomID?: (Long|null);
            matchID?: (Long|null);
            resultCode?: (number|null);
            maxPauseUnixMS?: (Long|null);
        }

        class RoomGamePauseRsp implements IRoomGamePauseRsp {
            constructor(p?: RoomProto.IRoomGamePauseRsp);
            public roomID: Long;
            public matchID: Long;
            public resultCode: number;
            public maxPauseUnixMS: Long;
            public static create(properties?: RoomProto.IRoomGamePauseRsp): RoomProto.RoomGamePauseRsp;
            public static encode(m: RoomProto.RoomGamePauseRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RoomProto.RoomGamePauseRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IRoomGameResumeReq {
            roomID?: (Long|null);
            matchID?: (Long|null);
            resultCode?: (number|null);
        }

        class RoomGameResumeReq implements IRoomGameResumeReq {
            constructor(p?: RoomProto.IRoomGameResumeReq);
            public roomID: Long;
            public matchID: Long;
            public resultCode: number;
            public static create(properties?: RoomProto.IRoomGameResumeReq): RoomProto.RoomGameResumeReq;
            public static encode(m: RoomProto.RoomGameResumeReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RoomProto.RoomGameResumeReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IRoomGameResumeRsp {
            roomID?: (Long|null);
            matchID?: (Long|null);
            resultCode?: (number|null);
        }

        class RoomGameResumeRsp implements IRoomGameResumeRsp {
            constructor(p?: RoomProto.IRoomGameResumeRsp);
            public roomID: Long;
            public matchID: Long;
            public resultCode: number;
            public static create(properties?: RoomProto.IRoomGameResumeRsp): RoomProto.RoomGameResumeRsp;
            public static encode(m: RoomProto.RoomGameResumeRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RoomProto.RoomGameResumeRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IRoomGameFastStartReq {
            gameType?: (number|null);
            roomID?: (Long|null);
            matchID?: (Long|null);
        }

        class RoomGameFastStartReq implements IRoomGameFastStartReq {
            constructor(p?: RoomProto.IRoomGameFastStartReq);
            public gameType: number;
            public roomID: Long;
            public matchID: Long;
            public static create(properties?: RoomProto.IRoomGameFastStartReq): RoomProto.RoomGameFastStartReq;
            public static encode(m: RoomProto.RoomGameFastStartReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RoomProto.RoomGameFastStartReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IRoomGameFastStartRsp {
            resultCode?: (number|null);
        }

        class RoomGameFastStartRsp implements IRoomGameFastStartRsp {
            constructor(p?: RoomProto.IRoomGameFastStartRsp);
            public resultCode: number;
            public static create(properties?: RoomProto.IRoomGameFastStartRsp): RoomProto.RoomGameFastStartRsp;
            public static encode(m: RoomProto.RoomGameFastStartRsp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): RoomProto.RoomGameFastStartRsp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }

    namespace ShopProto {

        interface IShopGoodsListReq {
            category?: (number|null);
        }

        class ShopGoodsListReq implements IShopGoodsListReq {
            constructor(p?: ShopProto.IShopGoodsListReq);
            public category: number;
            public static create(properties?: ShopProto.IShopGoodsListReq): ShopProto.ShopGoodsListReq;
            public static encode(m: ShopProto.ShopGoodsListReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ShopProto.ShopGoodsListReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IShopGoodsListResp {
            resultCode?: (number|null);
            goods?: (ShopProto.ShopGoods[]|null);
        }

        class ShopGoodsListResp implements IShopGoodsListResp {
            constructor(p?: ShopProto.IShopGoodsListResp);
            public resultCode: number;
            public goods: ShopProto.ShopGoods[];
            public static create(properties?: ShopProto.IShopGoodsListResp): ShopProto.ShopGoodsListResp;
            public static encode(m: ShopProto.ShopGoodsListResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ShopProto.ShopGoodsListResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IShopGoods {
            productID?: (number|null);
            currency?: (string|null);
            price?: (number|null);
            nameID?: (string|null);
            name?: (string|null);
            currencyType?: (number[]|null);
            rewardNum?: (number[]|null);
            type?: (number|null);
            topUpEventID?: (Long|null);
            openLevel?: (number|null);
            openPreActivity?: (number|null);
            currencyBG?: (string|null);
            promotionRewardNum?: (number[]|null);
            promotionCurrencyType?: (number[]|null);
            promotionTimes?: (number|null);
            promotionStart?: (Long|null);
            promotionEnd?: (Long|null);
            promotionGrade?: (number|null);
            promotionBuyTimes?: (number|null);
        }

        class ShopGoods implements IShopGoods {
            constructor(p?: ShopProto.IShopGoods);
            public productID: number;
            public currency: string;
            public price: number;
            public nameID: string;
            public name: string;
            public currencyType: number[];
            public rewardNum: number[];
            public type: number;
            public topUpEventID: Long;
            public openLevel: number;
            public openPreActivity: number;
            public currencyBG: string;
            public promotionRewardNum: number[];
            public promotionCurrencyType: number[];
            public promotionTimes: number;
            public promotionStart: Long;
            public promotionEnd: Long;
            public promotionGrade: number;
            public promotionBuyTimes: number;
            public static create(properties?: ShopProto.IShopGoods): ShopProto.ShopGoods;
            public static encode(m: ShopProto.ShopGoods, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ShopProto.ShopGoods;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IOrderCreateReq {
            productID?: (Long|null);
            amount?: (number|null);
            payWay?: (number|null);
            activityID?: (number|null);
            payWaySub?: (number|null);
            attachID?: (string|null);
        }

        class OrderCreateReq implements IOrderCreateReq {
            constructor(p?: ShopProto.IOrderCreateReq);
            public productID: Long;
            public amount: number;
            public payWay: number;
            public activityID: number;
            public payWaySub: number;
            public attachID: string;
            public static create(properties?: ShopProto.IOrderCreateReq): ShopProto.OrderCreateReq;
            public static encode(m: ShopProto.OrderCreateReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ShopProto.OrderCreateReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IOrderCreateResp {
            resultCode?: (number|null);
            productID?: (Long|null);
            amount?: (number|null);
            orderNo?: (string|null);
            approveUrl?: (string|null);
            activityID?: (number|null);
            payCnt?: (number|null);
            payWaySub?: (number|null);
        }

        class OrderCreateResp implements IOrderCreateResp {
            constructor(p?: ShopProto.IOrderCreateResp);
            public resultCode: number;
            public productID: Long;
            public amount: number;
            public orderNo: string;
            public approveUrl: string;
            public activityID: number;
            public payCnt: number;
            public payWaySub: number;
            public static create(properties?: ShopProto.IOrderCreateResp): ShopProto.OrderCreateResp;
            public static encode(m: ShopProto.OrderCreateResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ShopProto.OrderCreateResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IVerifyIAPReceiptDataReq {
            orderNo?: (string|null);
            transactionID?: (string|null);
            receiptData?: (string|null);
        }

        class VerifyIAPReceiptDataReq implements IVerifyIAPReceiptDataReq {
            constructor(p?: ShopProto.IVerifyIAPReceiptDataReq);
            public orderNo: string;
            public transactionID: string;
            public receiptData: string;
            public static create(properties?: ShopProto.IVerifyIAPReceiptDataReq): ShopProto.VerifyIAPReceiptDataReq;
            public static encode(m: ShopProto.VerifyIAPReceiptDataReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ShopProto.VerifyIAPReceiptDataReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IVerifyIAPReceiptDataResp {
            resultCode?: (number|null);
            orderNo?: (string|null);
            iapStatus?: (number|null);
            productID?: (Long|null);
            productStr?: (string|null);
            amount?: (number|null);
        }

        class VerifyIAPReceiptDataResp implements IVerifyIAPReceiptDataResp {
            constructor(p?: ShopProto.IVerifyIAPReceiptDataResp);
            public resultCode: number;
            public orderNo: string;
            public iapStatus: number;
            public productID: Long;
            public productStr: string;
            public amount: number;
            public static create(properties?: ShopProto.IVerifyIAPReceiptDataResp): ShopProto.VerifyIAPReceiptDataResp;
            public static encode(m: ShopProto.VerifyIAPReceiptDataResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ShopProto.VerifyIAPReceiptDataResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IOrderRewardNotify {
            productID?: (Long|null);
            orderNo?: (string|null);
        }

        class OrderRewardNotify implements IOrderRewardNotify {
            constructor(p?: ShopProto.IOrderRewardNotify);
            public productID: Long;
            public orderNo: string;
            public static create(properties?: ShopProto.IOrderRewardNotify): ShopProto.OrderRewardNotify;
            public static encode(m: ShopProto.OrderRewardNotify, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): ShopProto.OrderRewardNotify;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }

    namespace UserStateProto {

        enum E_Online_State {
            E_ONLINE_STATE_OFFLINE = 0,
            E_ONLINE_STATE_ONLINE = 1
        }

        interface IBatchOnlineStateReq {
            uidList?: (Long[]|null);
        }

        class BatchOnlineStateReq implements IBatchOnlineStateReq {
            constructor(p?: UserStateProto.IBatchOnlineStateReq);
            public uidList: Long[];
            public static create(properties?: UserStateProto.IBatchOnlineStateReq): UserStateProto.BatchOnlineStateReq;
            public static encode(m: UserStateProto.BatchOnlineStateReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): UserStateProto.BatchOnlineStateReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserOnlineState {
            state?: (UserStateProto.E_Online_State|null);
            accessAddr?: (string|null);
        }

        class UserOnlineState implements IUserOnlineState {
            constructor(p?: UserStateProto.IUserOnlineState);
            public state: UserStateProto.E_Online_State;
            public accessAddr: string;
            public static create(properties?: UserStateProto.IUserOnlineState): UserStateProto.UserOnlineState;
            public static encode(m: UserStateProto.UserOnlineState, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): UserStateProto.UserOnlineState;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IBatchOnlineStateResp {
            resultCode?: (number|null);
            data?: ({ [k: string]: UserStateProto.UserOnlineState }|null);
        }

        class BatchOnlineStateResp implements IBatchOnlineStateResp {
            constructor(p?: UserStateProto.IBatchOnlineStateResp);
            public resultCode: number;
            public data: { [k: string]: UserStateProto.UserOnlineState };
            public static create(properties?: UserStateProto.IBatchOnlineStateResp): UserStateProto.BatchOnlineStateResp;
            public static encode(m: UserStateProto.BatchOnlineStateResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): UserStateProto.BatchOnlineStateResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetGameStateReq {
            uid?: (Long|null);
        }

        class GetGameStateReq implements IGetGameStateReq {
            constructor(p?: UserStateProto.IGetGameStateReq);
            public uid: Long;
            public static create(properties?: UserStateProto.IGetGameStateReq): UserStateProto.GetGameStateReq;
            public static encode(m: UserStateProto.GetGameStateReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): UserStateProto.GetGameStateReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IGetGameStateResp {
            resultCode?: (number|null);
            sRoomID?: (string|null);
            tableID?: (number|null);
            matchID?: (string|null);
            level?: (number|null);
            smallBlind?: (Long|null);
            bigBlind?: (Long|null);
            minGold?: (Long|null);
            maxGold?: (Long|null);
            maxSeat?: (number|null);
        }

        class GetGameStateResp implements IGetGameStateResp {
            constructor(p?: UserStateProto.IGetGameStateResp);
            public resultCode: number;
            public sRoomID: string;
            public tableID: number;
            public matchID: string;
            public level: number;
            public smallBlind: Long;
            public bigBlind: Long;
            public minGold: Long;
            public maxGold: Long;
            public maxSeat: number;
            public static create(properties?: UserStateProto.IGetGameStateResp): UserStateProto.GetGameStateResp;
            public static encode(m: UserStateProto.GetGameStateResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): UserStateProto.GetGameStateResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IUserGameState {
            sRoomID?: (string|null);
            tableID?: (number|null);
            level?: (number|null);
            smallBlind?: (Long|null);
            bigBlind?: (Long|null);
            minGold?: (Long|null);
            maxGold?: (Long|null);
            maxSeat?: (number|null);
            matchID?: (string|null);
        }

        class UserGameState implements IUserGameState {
            constructor(p?: UserStateProto.IUserGameState);
            public sRoomID: string;
            public tableID: number;
            public level: number;
            public smallBlind: Long;
            public bigBlind: Long;
            public minGold: Long;
            public maxGold: Long;
            public maxSeat: number;
            public matchID: string;
            public static create(properties?: UserStateProto.IUserGameState): UserStateProto.UserGameState;
            public static encode(m: UserStateProto.UserGameState, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): UserStateProto.UserGameState;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IBatchGameStateReq {
            uidList?: (Long[]|null);
        }

        class BatchGameStateReq implements IBatchGameStateReq {
            constructor(p?: UserStateProto.IBatchGameStateReq);
            public uidList: Long[];
            public static create(properties?: UserStateProto.IBatchGameStateReq): UserStateProto.BatchGameStateReq;
            public static encode(m: UserStateProto.BatchGameStateReq, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): UserStateProto.BatchGameStateReq;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface IBatchGameStateResp {
            resultCode?: (number|null);
            data?: ({ [k: string]: UserStateProto.UserGameState }|null);
        }

        class BatchGameStateResp implements IBatchGameStateResp {
            constructor(p?: UserStateProto.IBatchGameStateResp);
            public resultCode: number;
            public data: { [k: string]: UserStateProto.UserGameState };
            public static create(properties?: UserStateProto.IBatchGameStateResp): UserStateProto.BatchGameStateResp;
            public static encode(m: UserStateProto.BatchGameStateResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): UserStateProto.BatchGameStateResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ICountStatisticsResp {
            resultCode?: (number|null);
            lCount?: (Long|null);
        }

        class CountStatisticsResp implements ICountStatisticsResp {
            constructor(p?: UserStateProto.ICountStatisticsResp);
            public resultCode: number;
            public lCount: Long;
            public static create(properties?: UserStateProto.ICountStatisticsResp): UserStateProto.CountStatisticsResp;
            public static encode(m: UserStateProto.CountStatisticsResp, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): UserStateProto.CountStatisticsResp;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }

    namespace XGameComm {

        interface ITUid {
            lUid?: (Long|null);
            sToken?: (string|null);
        }

        class TUid implements ITUid {
            constructor(p?: XGameComm.ITUid);
            public lUid: Long;
            public sToken: string;
            public static create(properties?: XGameComm.ITUid): XGameComm.TUid;
            public static encode(m: XGameComm.TUid, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): XGameComm.TUid;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        enum MSGTYPE {
            MSGTYPE_REQUEST = 0,
            MSGTYPE_RESPONSE = 1,
            MSGTYPE_NOTIFY = 2
        }

        enum SERVICE_TYPE {
            SERVICE_TYPE_DEFAULT = 0,
            SERVICE_TYPE_LOGIN = 1,
            SERVICE_TYPE_GAME = 2,
            SERVICE_TYPE_ROOM = 3,
            SERVICE_TYPE_MATCH = 4,
            SERVICE_TYPE_RECORD = 5,
            SERVICE_TYPE_PUSH = 6,
            SERVICE_TYPE_ACTIVITY = 7,
            SERVICE_TYPE_BINGO = 10,
            SERVICE_TYPE_COOKIE = 11,
            SERVICE_TYPE_SOLITAIRE = 12,
            SERVICE_TYPE_UNO = 13,
            SERVICE_TYPE_CASH21 = 14,
            SERVICE_TYPE_TETRIS = 15,
            SERVICE_TYPE_TILE = 16,
            SERVICE_TYPE_WATER = 17,
            SERVICE_TYPE_BUBBLE = 18,
            SERVICE_TYPE_CHAT = 105,
            SERVICE_TYPE_MAIL = 106,
            SERVICE_TYPE_MALL = 107,
            SERVICE_TYPE_SIGNIN = 108,
            SERVICE_TYPE_USER_STATE = 109
        }

        interface ITMsgHead {
            nMsgID?: (number|null);
            nMsgType?: (XGameComm.MSGTYPE|null);
            serviceType?: (XGameComm.SERVICE_TYPE|null);
            nResultID?: (number|null);
        }

        class TMsgHead implements ITMsgHead {
            constructor(p?: XGameComm.ITMsgHead);
            public nMsgID: number;
            public nMsgType: XGameComm.MSGTYPE;
            public serviceType: XGameComm.SERVICE_TYPE;
            public nResultID: number;
            public static create(properties?: XGameComm.ITMsgHead): XGameComm.TMsgHead;
            public static encode(m: XGameComm.TMsgHead, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): XGameComm.TMsgHead;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ITPackage {
            iVersion?: (number|null);
            stUid?: (XGameComm.TUid|null);
            iGameID?: (number|null);
            sRoomID?: (string|null);
            iRoomServerID?: (number|null);
            iSequence?: (number|null);
            iFlag?: (number|null);
            vecMsgHead?: (XGameComm.TMsgHead[]|null);
            vecMsgData?: (Uint8Array[]|null);
            iActiveCount?: (number|null);
        }

        class TPackage implements ITPackage {
            constructor(p?: XGameComm.ITPackage);
            public iVersion: number;
            public stUid?: (XGameComm.TUid|null);
            public iGameID: number;
            public sRoomID: string;
            public iRoomServerID: number;
            public iSequence: number;
            public iFlag: number;
            public vecMsgHead: XGameComm.TMsgHead[];
            public vecMsgData: Uint8Array[];
            public iActiveCount: number;
            public static create(properties?: XGameComm.ITPackage): XGameComm.TPackage;
            public static encode(m: XGameComm.TPackage, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): XGameComm.TPackage;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        enum Eum_Comm_Msgid {
            E_MSGID_DEFAULT = 0,
            E_MSGID_PUSH_MULTIPLE_LOGIN_NOTIFY = 10,
            E_MSGID_LOGIN_HALL_REQ = 11,
            E_MSGID_LOGIN_HALL_RESP = 12,
            E_MSGID_KEEP_ALIVE_REQ = 13,
            E_MSGID_KEEP_ALIVE_RESP = 14,
            E_MSGID_GET_PLATFORM_ACCOUNT_DETAIL_REQ = 2000,
            E_MSGID_GET_PLATFORM_ACCOUNT_DETAIL_RSP = 2001,
            E_MSGID_GET_PLATFORM_HALL_GAME_TYPE_REQ = 2004,
            E_MSGID_GET_PLATFORM_HALL_GAME_TYPE_RSP = 2005,
            E_MSGID_GET_PLATFORM_HALL_GAME_ONE_REQ = 2006,
            E_MSGID_GET_PLATFORM_HALL_GAME_ONE_RSP = 2007,
            E_MSGID_GET_PLATFORM_HALL_GAME_TWO_REQ = 2008,
            E_MSGID_GET_PLATFORM_HALL_GAME_TWO_RSP = 2009,
            E_MSGID_GET_PLATFORM_HALL_GAME_THREE_REQ = 2010,
            E_MSGID_GET_PLATFORM_HALL_GAME_THREE_RSP = 2011,
            E_MSGID_PLATFORM_ACCOUNT_BINDING_PHONE_REQ = 2012,
            E_MSGID_PLATFORM_ACCOUNT_BINDING_PHONE_RSP = 2013,
            E_MSGID_PLATFORM_ACCOUNT_SET_PASSWORD_REQ = 2014,
            E_MSGID_PLATFORM_ACCOUNT_SET_PASSWORD_RSP = 2015,
            E_MSGID_VIP_CONFIG_GET_REQ = 21000,
            E_MSGID_VIP_CONFIG_GET_RSP = 21001,
            E_MSGID_ORDER_CREATE_REQ = 21100,
            E_MSGID_ORDER_CREATE_RSP = 21101,
            E_MSGID_ORDER_RECEIVE_REWARD_REQ = 21102,
            E_MSGID_ORDER_RECEIVE_REWARD_RSP = 21103,
            E_MSGID_GET_EMAIL_DIGEST_LIST_REQ = 21104,
            E_MSGID_GET_EMAIL_DIGEST_LIST_RSP = 21105,
            E_MSGID_GET_USER_EMAIL_DETAIL_REQ = 21106,
            E_MSGID_GET_USER_EMAIL_DETAIL_RSP = 21107,
            E_MSGID_ALTER_USER_EMAIL_STATUS_REQ = 21108,
            E_MSGID_ALTER_USER_EMAIL_STATUS_RSP = 21109,
            E_MSGID_REMOVE_USER_EMAIL_REQ = 21110,
            E_MSGID_REMOVE_USER_EMAIL_RSP = 21111,
            E_MSGID_REMOVE_ALL_USER_REQ = 21112,
            E_MSGID_REMOVE_ALL_USER_RSP = 21113,
            E_MSGID_MARK_ALL_READ_REQ = 21134,
            E_MSGID_MARK_ALL_READ_RSP = 21135,
            E_MSGID_CLUB_CONFIG_GET_REQ = 21300,
            E_MSGID_CLUB_CONFIG_GET_RSP = 21301,
            E_MSGID_CLUB_POSTER_CONFIG_GET_REQ = 21302,
            E_MSGID_CLUB_POSTER_CONFIG_GET_RSP = 21303,
            E_MSGID_CLUB_BIND_INVITE_CODE_REQ = 21304,
            E_MSGID_CLUB_BIND_INVITE_CODE_RSP = 21305,
            E_MSGID_CLUB_GET_INFO_REQ = 21306,
            E_MSGID_CLUB_GET_INFO_RSP = 21307,
            E_MSGID_CLUB_GET_MEMBER_REQ = 21308,
            E_MSGID_CLUB_GET_MEMBER_RSP = 21309
        }

        interface ITMsgRespLoginHall {
            iResultID?: (number|null);
            sPubKey?: (string|null);
        }

        class TMsgRespLoginHall implements ITMsgRespLoginHall {
            constructor(p?: XGameComm.ITMsgRespLoginHall);
            public iResultID: number;
            public sPubKey: string;
            public static create(properties?: XGameComm.ITMsgRespLoginHall): XGameComm.TMsgRespLoginHall;
            public static encode(m: XGameComm.TMsgRespLoginHall, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): XGameComm.TMsgRespLoginHall;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }

    namespace XGameHttp {

        interface ITUid {
            lUid?: (Long|null);
            sToken?: (string|null);
        }

        class TUid implements ITUid {
            constructor(p?: XGameHttp.ITUid);
            public lUid: Long;
            public sToken: string;
            public static create(properties?: XGameHttp.ITUid): XGameHttp.TUid;
            public static encode(m: XGameHttp.TUid, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): XGameHttp.TUid;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        interface ITHttpPackage {
            iVer?: (number|null);
            iSeq?: (number|null);
            stUid?: (XGameHttp.TUid|null);
            nMsgID?: (number|null);
            vecData?: (Uint8Array|null);
        }

        class THttpPackage implements ITHttpPackage {
            constructor(p?: XGameHttp.ITHttpPackage);
            public iVer: number;
            public iSeq: number;
            public stUid?: (XGameHttp.TUid|null);
            public nMsgID: number;
            public vecData: Uint8Array;
            public static create(properties?: XGameHttp.ITHttpPackage): XGameHttp.THttpPackage;
            public static encode(m: XGameHttp.THttpPackage, w?: $protobuf.Writer): $protobuf.Writer;
            public static decode(r: ($protobuf.Reader|Uint8Array), l?: number): XGameHttp.THttpPackage;
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }
}
