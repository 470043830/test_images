declare module "cc" {
    interface IViewParam {
        /** 子包 */
        bundle?: string,
        /** 场景名字 */
        name?: string,
        /** 数据 */
        data?: any;
        /** 桌子数据 */
        deskBean?: any;
    }

    /** */
    interface Node {
        /** 子元素 */
        Items: { [key: string]: Node },
        /** 参数 */
        viewParam: IViewParam;

        /** */
        customMethod(): void;
    }
}

