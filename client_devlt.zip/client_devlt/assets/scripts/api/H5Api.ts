import { _decorator } from 'cc';
import { AudioMgr } from '../framework/manager/AudioMgr';
import AccountModel from '../model/AccountModel';
import { Logger } from '../framework/utils/Logger';
import EventMgr from '../framework/event/EventMgr';
import { GAME_EVENT } from '../framework/event/EventDefine';
import { AppConfig } from '../config/Config';

const { ccclass, property } = _decorator;

window.receiveDataH5Api = (message: string) => {
    H5Api.receiveDataH5Api(message)
}

export class H5Api {
    /** H5 接收处理*/
    public static receiveDataH5Api(message: any) {
        Logger.info('cocos 接收APP :', message);
        switch (message.action) {
            case "getToken":
                AccountModel.Instance.token = message.data.token;
                if (message.data.platform) {
                    // AppConfig.os = message.data.platform;
                }
                //
                if (message.data.id) {
                    //AccountModel.Instance.battlegroundId = parseInt(message.data.id);
                }
                //
                break;
            default:
                break;
        }
    }

    /** 获取token */
    public static getToken() {
        Logger.info('获取token');
        this.sendMessageH5Api("getToken")
    }

    /** 请求手机振动 */
    public static vibrate() {
        Logger.info('请求手机振动');
        if (AudioMgr.Instance.isVibrate == false) {
            this.sendMessageH5Api("vibrate")
            setTimeout(() => {
                AudioMgr.Instance.recoverBgMusic();
            }, 500)
        }
    }

    /**加载资源错误 */
    public static loadingError() {
        Logger.info('资源加载异常');
        EventMgr.Instance.emit(GAME_EVENT.GAME_THE_CLOSE);
        this.sendMessageH5Api("loadingError")
    }

    /** 返回上一个界面退出游戏 */
    public static navigateBack() {
        Logger.info('返回上一个界面退出游戏');
        this.showSplash(false);
        EventMgr.Instance.emit(GAME_EVENT.GAME_THE_CLOSE);
        this.sendMessageH5Api("navigateBack")
    }

    /** 关闭遮罩 */
    public static showSplash(isShow) {
        if (window.showSplash) {
            window.showSplash(isShow);
        }
    }

    /** 更新进度条 */
    public static showLoad(num) {
        if (window.showLoad) {
            window.showLoad(num);
        }
    }

    /** H5发送处理*/
    private static sendMessageH5Api(action: string, data: string = null) {
        if (window.sendMessageToUniApp) {
            window.sendMessageToUniApp(action, data);
        }
    }
}

declare global {
    interface Window {
        /** 接受webview上级返回消息返回 */
        receiveDataH5Api: (message: string) => void;
        /** 给webview上级发送消息 */
        sendMessageToUniApp: (action: string, data: string) => void;
        /** 显示关闭h5遮罩 */
        showSplash: (isShow: boolean) => void;
        /** 显示进度条完成进度*/
        showLoad: (time: number) => void;
    }
}
