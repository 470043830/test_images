// 扩展dataView
DataView.prototype.write_utf8 = function (offset, str) {
    var now = offset;
    var dataview = this;
    for (var i = 0; i < str.length; ++i) {
        var charcode = str.charCodeAt(i);
        if (charcode < 0x80) {
            dataview.setUint8(now, charcode);
            now++;
        } else if (charcode < 0x800) {
            dataview.setUint8(now, (0xc0 | (charcode >> 6)));
            now++;

            dataview.setUint8(now, 0x80 | (charcode & 0x3f));
            now++;
        } else if (charcode < 0xd800 || charcode >= 0xe000) {
            dataview.setUint8(now, (0xe0 | (charcode >> 12)));
            now++;

            dataview.setUint8(now, 0x80 | ((charcode >> 6) & 0x3f));
            now++;

            dataview.setUint8(now, 0x80 | (charcode & 0x3f));
            now++;
        } else {
            i++;
            charcode = 0x10000 + (((charcode & 0x3ff) << 10)
                | (str.charCodeAt(i) & 0x3ff));

            dataview.setUint8(now, 0xf0 | (charcode >> 18));
            now++;

            dataview.setUint8(now, 0x80 | ((charcode >> 12) & 0x3f));
            now++;

            dataview.setUint8(now, 0x80 | ((charcode >> 6) & 0x3f));
            now++;

            dataview.setUint8(now, 0x80 | (charcode & 0x3f));
            now++;

        }
    }
}
DataView.prototype.read_utf8 = function (offset, byte_length) {
    var out, i, len, c;
    var char2, char3;
    var dataview = this;

    out = "";
    len = byte_length;
    i = offset;
    while (i < len) {
        c = dataview.getUint8(i);
        i++;
        switch (c >> 4) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
                out += String.fromCharCode(c);
                break;
            case 12:
            case 13:
                char2 = array[i++];
                out += String.fromCharCode(((c & 0x1f) << 6) | (char2 & 0x3F));
                break;
                case14:
                char2 = dataview.getUint8(i);
                ++i;
                char3 = dataview.getUint8(i);
                ++i;
                out += String.fromCharCode(((c & 0x0f) << 12) |
                    ((char2 & 0x3F) << 6) |
                    ((char3 & 0x3f) << 0));
                break;
        }
    }
}
// end
// 扩展Node
cc.Node.prototype.customMethod = function () {
    console.log("This is a custom method added to cc.Node prototype");
};
// /**
//  * @author: silencetea
//  * @name: 
//  * @description: 数字格式化，默认每三位用英文逗号分隔
//  * @param {number} number 要格式化的数字
//  * @param {number} decimals 保留几位小数，默认不保留小数
//  * @param {string} dec_point 小数点符号，默认“.”
//  * @param {string} thousands_sep 千分位符号，默认英文逗号
//  * @return {*}
//  */
// Number.format = (number, decimals, dec_point, thousands_sep) => {
//     number = (number + "").replace(/[^0-9+-Ee.]/g, "");

//     let n = !isFinite(+number) ? 0 : +number,
//         prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
//         sep = typeof thousands_sep === "undefined" ? "," : thousands_sep,
//         dec = typeof dec_point === "undefined" ? "." : dec_point,
//         s = "",
//         toFixedFix = function (n, prec) {
//             let k = Math.pow(10, prec);
//             return "" + Math.ceil(n * k) / k;
//         };

//     s = (prec ? toFixedFix(n, prec) : "" + Math.round(n)).split(".");

//     let re = /(-?\d+)(\d{3})/;
//     while (re.test(s[0])) {
//         s[0] = s[0].replace(re, "$1" + sep + "$2");
//     }

//     // 小数点后位数不够补0，需要补0，放开下方被注释的代码即可
//     // if ((s[1] || "").length < prec) {
//     //   s[1] = s[1] || "";
//     //   s[1] += new Array(prec - s[1].length + 1).join("0");
//     // }

//     return s.join(dec);
// };

// /**
//  * @author: silencetea
//  * @name: sortNumberArray
//  * @description: 数字数组排序，默认升序：从小到大
//  * @param {any} fmt 要以何种格式格式化
//  * @return {*}
//  */
// Date.prototype.format = (fmt) => {
//     let o = {
//         'M+': this.getMonth() + 1,
//         'd+': this.getDate(),
//         'H+': this.getHours(),
//         'm+': this.getMinutes(),
//         's+': this.getSeconds(),
//         'S+': this.getMilliseconds()
//     };
//     //因为date.getFullYear()出来的结果是number类型的,所以为了让结果变成字符串型，下面有两种方法：
//     if (/(y+)/.test(fmt)) {
//         //第一种：利用字符串连接符“+”给date.getFullYear()+''，加一个空字符串便可以将number类型转换成字符串。
//         fmt = fmt.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length));
//     }
//     for (var k in o) {
//         if (new RegExp('(' + k + ')').test(fmt)) {
//             //第二种：使用String()类型进行强制数据类型转换String(date.getFullYear())，这种更容易理解。
//             fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (('00' + o[k]).substr(String(o[k]).length)));
//         }
//     }
//     return fmt;
// };


//end
// 扩展scrollview
// end