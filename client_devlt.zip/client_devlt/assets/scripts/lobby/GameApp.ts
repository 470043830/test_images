import { Component, director } from "cc";
import { EventBind } from "./EventBind";
import { EnumScene } from "../config/BundleConfig";

/**
 * 游戏单一app管理类
 */
export class GameApp extends Component {
    /** 当前实例 */
    public static Instance: GameApp = null;
    /** 当前场景 */
    public curScene: EnumScene = EnumScene.none;
    /** 进度变化回调函数 */
    public setLoadingProgress: Function;
    /** 事件绑定 */
    private eventBind: EventBind = null;

    /**
     * 获取应用层
     */
    public get MyAppLayer() {
        let scene = director.getScene()
        let myapp = scene.getChildByName("myapp");
        return myapp;
    }

    /**
     * 销毁
     */
    onDestroy() {

    }

    /**
     * 加载
     * @returns
     */
    onLoad() {
        if (GameApp.Instance === null) {
            GameApp.Instance = this;
        } else {
            this.destroy();
            return;
        }
        //
        this.initData();
        this.initView();
        this.bindEventListener();
    }

    /**
     * 获取app背景层
     */
    getAppLayer() {
        let scene = director.getScene()
        let canvas = scene.getChildByName("Canvas");
        return canvas.Items.UIAppLayer;
    }

    /**
     * 获取app游戏层
     */
    getGameLayer() {
        let scene = director.getScene()
        let canvas = scene.getChildByName("Canvas");
        return canvas.Items.UIGameLayer;
    }

    /**
     * 获取app弹窗层
     */
    getDialogLayer() {
        let scene = director.getScene()
        let canvas = scene.getChildByName("Canvas");
        return canvas.Items.UIDialogLayer;
    }

    /**
     * 获取app加载层
     */
    getLoadingLayer() {
        let scene = director.getScene()
        let canvas = scene.getChildByName("Canvas");
        return canvas.Items.UILoadingLayer;
    }

    /**
     * 初始化数据
     */
    private initData() {
        this.eventBind = new EventBind(GameApp.Instance);
    }

    /**
     * 初始化视图
     */
    private initView() {

    }

    /**
     * 绑定事件监听
     */
    private bindEventListener() {

    }
}
