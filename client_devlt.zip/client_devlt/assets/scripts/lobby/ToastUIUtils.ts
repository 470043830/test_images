import { Node } from 'cc';
import { UIMgr } from '../framework/manager/UIMgr';
import { AlertView, EnumAlertStyle, IAlertMsg } from '../common/AlertView';
import { EnumPrefab, EnumScene } from '../config/BundleConfig';
import { GameApp } from './GameApp';
import { GAME_EVENT, SYS_EVENT } from '../framework/event/EventDefine';
import EventMgr from '../framework/event/EventMgr';
import { H5Api } from '../api/H5Api';
import { Logger } from '../framework/utils/Logger';
import { LoginMgr } from '../framework/manager/LoginMgr';
import GlobalModel from '../model/GlobalModel';

export class ToastUIUtils {
    /**
     * 打开取消匹配弹框
     */
    static openCancelMatch(callBack: Function = null) {
        let title = `<b><size = 80>确定要取消匹配?</size></b>`
        let data: IAlertMsg = this.createAlertData("cancelMatchUI", title, 77, EnumAlertStyle.confirm_cancel);
        data.canLeft_str = "取消"
        data.conRihth_str = "确定"
        data.left_callback = () => {
            Logger.info("关闭无需特殊操作")
            this.closeCancelMatch();
        }
        data.right_callback = () => {
            Logger.info("请求取消匹配退出游戏")
            callBack();
        }
        //
        this.showAlertUI(data);
    }

    /**
     * 关闭取消匹配弹框
     */
    static closeCancelMatch() {
        UIMgr.Instance.removeNameView("cancelMatchUI");
    }

    /**
     * 打开重新匹配弹框
     */
    static openReMatch(callBack: Function = null) {
        let title = `<b><size = 60>匹配超时，请重试</size></b>`
        let data: IAlertMsg = this.createAlertData("reMatchUI", title, 77, EnumAlertStyle.confirm_cancel);
        data.canLeft_str = "退出游戏"
        data.conRihth_str = "重新匹配"
        //
        data.left_callback = () => {
            EventMgr.Instance.emit(GAME_EVENT.ON_LOADING_CIRCLE, true);
            H5Api.navigateBack();
        }
        //
        data.right_callback = () => {
            callBack();
            this.closeReMatch();
        }
        //
        this.showAlertUI(data);
    }

    /**
     * 关闭比赛
     */
    static closeReMatch() {
        UIMgr.Instance.removeNameView("reMatchUI");
    }

    /**
     * 打开重置棋盘弹框
     */
    static openResetUI() {
        let data: IAlertMsg = this.createAlertData("resetUI", "您已经没有可消除的图块了", 55, EnumAlertStyle.confirm_close, "重置技能\n消耗灵丸*10");
        this.showAlertUI(data);
    }

    /**
     * 关闭重置棋盘弹框
     */
    static closeOResetUI() {
        UIMgr.Instance.removeNameView("resetUI");
    }

    /**
     * 打开异常提示弹框
     */
    static openRabnormalUI() {
        let title = `<b>检测到您的游戏行为，安全数据或<br/>游戏环境存在异常，暂时无法匹配，<br/>请在0天24小时59分后重试。</b>`
        let data: IAlertMsg = this.createAlertData("tabnormalUI", title, 55, EnumAlertStyle.confirm, "确定");
        //
        data.close_callback = () => {
            EventMgr.Instance.emit(GAME_EVENT.ON_LOADING_CIRCLE, true);
            H5Api.navigateBack();
        }
        //
        data.right_callback = () => {
            EventMgr.Instance.emit(GAME_EVENT.ON_LOADING_CIRCLE, true);
            H5Api.navigateBack();
        }
        //
        this.showAlertUI(data);
    }

    /**
     * 对局结束
     */
    static openEndofgameUI(callBack: Function = null, txt: string = "查看结果") {
        let title = `<b><size = 60>对局已结束<br/>无法重新连接到游戏</size></b>`
        let data: IAlertMsg = this.createAlertData("EndofgameUI", title, 83, EnumAlertStyle.confirm_close, txt);
        //
        data.close_callback = () => {
            EventMgr.Instance.emit(GAME_EVENT.ON_LOADING_CIRCLE, true);
            H5Api.navigateBack();
        }
        //
        data.right_callback = () => {
            callBack();
            UIMgr.Instance.removeNameView("EndofgameUI");
        }
        //
        this.showAlertUI(data);
    }

    /**
     * 没有余额窗口
     */
    static openNoBalanceUI(txt: string = "") {
        let title = `<b><size = 60>${txt}</size></b>`;
        let data: IAlertMsg = this.createAlertData("NoBalanceUI", title, 83, EnumAlertStyle.confirm, "退出游戏");
        //
        data.right_callback = () => {
            EventMgr.Instance.emit(GAME_EVENT.ON_LOADING_CIRCLE, true);
            H5Api.navigateBack();
        }
        //
        this.showAlertUI(data, GameApp.Instance.MyAppLayer);
    }

    /**
     * 公共弹框弹框
     */
    private static async showAlertUI(data: IAlertMsg, parent: Node = GameApp.Instance.getDialogLayer()) {
        EventMgr.Instance.emit(GAME_EVENT.ON_CIRCLE_SHOW, true)
        let view = await UIMgr.Instance.showView(EnumPrefab.alert, { data: data }, parent, data.name, true,);
        view.addComponent(AlertView);
    }

    /**
     *
     * @param name 弹框名称
     * @param msg 内容
     * @param style 弹框类型
     * @param conRihth_str 左侧名称
     * @param canLeft_str 右侧名称
     * @param title 标题
     * @returns
     */
    private static createAlertData(name: string, msg: string = "内容", lineHeight: number = 55, style: EnumAlertStyle = EnumAlertStyle.confirm_cancel_close, conRihth_str: string = "确定", canLeft_str: string = "取消", title: string = "提示"): IAlertMsg {
        return {
            style: style,
            msg: msg,
            name: name,
            title: title,
            lineHeight: lineHeight,
            conRihth_str: conRihth_str,
            canLeft_str: canLeft_str,
            isMaskClose: false,
        }
    }

    /**
     * http登录失败提示
     */
    static openLoginFailedUI() {
        let title = `<b>登录失败.</b>`
        let data: IAlertMsg = this.createAlertData("loginFailedUI", title, 55, EnumAlertStyle.confirm, "确定");
        data.close_callback = () => {
            EventMgr.Instance.emit(GAME_EVENT.ON_LOADING_CIRCLE, true);
            H5Api.navigateBack();
        }
        data.right_callback = () => {
            // EventMgr.Instance.emit(GAME_EVENT.ON_LOADING_CIRCLE, true);
            // H5Api.navigateBack();

            if (!GlobalModel.Instance.curScene || GlobalModel.Instance.curScene.name != EnumScene.login) {
                EventMgr.Instance.emit(SYS_EVENT.CHANGE_SCENE, { name: EnumScene.login });
            } else {
                UIMgr.Instance.removeNameView("loginFailedUI");
            }
        }
        this.showAlertUI(data, GameApp.Instance.getLoadingLayer());
    }

    /**
     * 网络连接失败提示
     */
    static openConnectFailedUI() {
        let title = `<b>连接服务器失败.</b>`
        let data: IAlertMsg = this.createAlertData("connectUI", title, 55, EnumAlertStyle.confirm, "重试");
        //
        data.close_callback = () => {
            EventMgr.Instance.emit(GAME_EVENT.ON_LOADING_CIRCLE, true);
            H5Api.navigateBack();
        }
        //
        data.right_callback = () => {
            // EventMgr.Instance.emit(GAME_EVENT.ON_LOADING_CIRCLE, true);
            // H5Api.navigateBack();

            LoginMgr.Instance.tryRelogin();
        }
        //
        this.showAlertUI(data, GameApp.Instance.getLoadingLayer());
    }

    /**
     * 连接游戏失败
     */
    static openEnterGameFailedUI(callBack) {
        let title = `<b>连接游戏失败.</b>`
        let data: IAlertMsg = this.createAlertData("connectGameUI", title, 55, EnumAlertStyle.confirm, "返回");

        data.right_callback = () => {
            UIMgr.Instance.removeNameView("connectGameUI");
            callBack && callBack();
        };
        this.showAlertUI(data, GameApp.Instance.getDialogLayer());
    }
}

