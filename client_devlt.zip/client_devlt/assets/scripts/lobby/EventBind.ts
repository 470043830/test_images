import { director, EventTouch, game, Game, isValid, Node, Scene, SceneAsset, sys, tween, Tween, UIOpacity, UITransform, v3 } from "cc";

import { GameApp } from "./GameApp";
import { AlertView } from "../common/AlertView";
import { LoadingView } from "../common/LoadingView";
import { BundleConfig, EnumBundle, EnumPrefab, EnumScene, ISceneParam } from "../config/BundleConfig";
import { GAME_EVENT, NET_EVENT, SYS_EVENT } from "../framework/event/EventDefine";
import EventMgr from "../framework/event/EventMgr";
import { UIMgr } from "../framework/manager/UIMgr";
import { Logger } from "../framework/utils/Logger";
import { ResMgr } from "../framework/manager/ResMgr";
import GlobalModel from "../model/GlobalModel";
import { Utils } from "../framework/utils/Utils";
import AccountModel from "../model/AccountModel";
import SocketMgr from "../framework/net/SocketMgr";
import { HallReqManager } from "../framework/net/HallReqManager";
import { NetworkMaskView } from "../common/NetworkMaskView";
import HeartBeatMgr from "../framework/net/HeartBeatMgr";
import { StringUtils } from "../framework/utils/StringUtils";
import { HttpUtils } from "../framework/utils/HttpUtils";
import { Waiting } from "../common/Waiting";
import { ToastUIUtils } from "./ToastUIUtils";
import { LoginMgr } from "../framework/manager/LoginMgr";
import { DEBUG, PREVIEW } from "cc/env";
import { AppConfig, buildType } from "../config/Config";
import { LoginType } from "../Const";

/**
 * 事件绑定
 */
export class EventBind {
    /** 离线时间 */
    public offlineTime: number = null;
    //
    private myapp: any;
    //
    private loadingView: Node = null;
    //
    private clickView: Node = null;
    //
    private clickAniam: Node = null;
    //
    private networkMask: Node = null;

    private msgBindMap: Map<Number, Function> = new Map();

    constructor(args?) {
        // 初始化参数
        this.myapp = args;
        // end
        // 初始化函数
        this.initData();
        this.initView();
        this.bindEventListener();
        // end
    }

    /**
     * 销毁事件
     */
    public onDestroy(): void {
        EventMgr.Instance.offTarget(this);
        game.off(Game.EVENT_HIDE, this.onEnterBackground, this);
        game.off(Game.EVENT_SHOW, this.onEnterForeground, this);
        // this.myapp.node.off(Node.EventType.TOUCH_START, this.OnClickEffect, this);
        // this.myapp.node.off(Node.EventType.TOUCH_END, this.OnClickEffect, this);
    }

    /**
     * 接收警告
     */
    async OnRecvAlert<T>(param_: T) {
        var tview = await UIMgr.Instance.showView(EnumPrefab.alert, { data: param_ });
        tview.addComponent(AlertView);
    }

    /**
     * 点击效果
     */
    public async OnClickEffect(event: EventTouch) {
        // event.preventSwallow = true
        if (event.type == Node.EventType.TOUCH_END) {
            if (this.clickAniam == null)
                return;
            let nodePoint = this.myapp.node.getComponent(UITransform).convertToNodeSpaceAR(v3(event.getUILocation().x, event.getUILocation().y));
            this.clickAniam.setPosition(nodePoint);
            Tween.stopAllByTarget(this.clickAniam);
            this.clickAniam.getComponent(UIOpacity).opacity = 255;
            tween(this.clickAniam)
                .show()
                .set({ scale: v3(0, 0) })
                .to(0.3, { scale: v3(0.4, 0.4) })
                .hide()
                .start()
        }
    }

    /**
     *  初始化数据
     */
    private initData(): void {

    }

    /**
     * 初始化视图
     */
    private async initView(): Promise<void> {
        await this.onRecvclickAniam();
        await this.onRecvShowNetWork(false);

    }

    /**
     * 绑定事件
     */
    private bindEventListener(): void {
        EventMgr.Instance.on(NET_EVENT.SOCKET_CONNECTED, this.onRecvSokectConnect, this);
        EventMgr.Instance.on(SYS_EVENT.CHANGE_SCENE, this.onRecvChangeScene, this);
        EventMgr.Instance.on(GAME_EVENT.ON_SHOW_LOADING, this.onRecvShowLoading, this);
        EventMgr.Instance.on(GAME_EVENT.ON_SET_LOADING_PROGRESS, this.onsetLoadingProgress, this);
        EventMgr.Instance.on(GAME_EVENT.ON_CIRCLE_SHOW, this.onClickShow, this);
        EventMgr.Instance.on(NET_EVENT.ON_RECV_DATA, this.onRecvNetData, this);
        EventMgr.Instance.on(SYS_EVENT.LOADGAME_FINISH, this.onLoadGameFinish, this);
        EventMgr.Instance.on(GAME_EVENT.ON_LOADING_CIRCLE, this.onRecvShowNetWork, this);

        game.on(Game.EVENT_HIDE, this.onEnterBackground, this);
        game.on(Game.EVENT_SHOW, this.onEnterForeground, this);
        EventMgr.Instance.on(GAME_EVENT.GAME_THE_CLOSE, this.onGameTheClose, this);

        // 此代码会阻止触摸事件传递
        // this.myapp.node.on(Node.EventType.TOUCH_START, this.OnClickEffect, this);
        // this.myapp.node.on(Node.EventType.TOUCH_END, this.OnClickEffect, this);
    }

    private bindNetMsg() {

    }

    /**
     * 接收消息处理
     * @param param
     */
    private onRecvNetData(param) {
        // let cmd: any = param.nMsgID;
        // switch (cmd) {
        //     case EnumCodeID.LoginResp:
        //         EventMgr.Instance.emit(GAME_EVENT.ON_LOADING_CIRCLE, false);
        //         // if (param.code == 200) {
        //         if (param.code == 0) {
        //             // this.setShowLoadingPrecent(92)
        //             //首次登陆从取消匹配
        //             // console.log(param);
        //             // AccountModel.Instance.setData(param.data.data);

        //             //请求用户信息
        //             HallReqManager.sendUserInfo();
        //         } else {
        //             ToastUIUtils.openNoBalanceUI(param.data.info);
        //         }
        //         break;

        //     case EnumCodeID.UserDetailsResp:
        //         let data = param as GameProto.GetUserDetailResp;
        //         // console.log(param);
        //         // this.setShowLoadingPrecent(100);
        //         // GlobalModel.Instance.opt = param.data.data.opt;
        //         // EventMgr.Instance.emit(SYS_EVENT.CHANGE_SCENE, { name: EnumScene.ridCrush });
        //         // UIMgr.Instance.removeNameView(EnumPrefab.reconnect);
        //         break;
        //     //
        //     default:
        //         break;
        // }
    }

    /**
     * 加载游戏完成
     */
    private onLoadGameFinish() {
        LoginMgr.Instance.tryAutoLogin();
    }

    /**
     * 接收网络连接
     */
    private onRecvSokectConnect<T>(param_: T) {
        Logger.info("connect to server succeed!");
    }

    /**
     * 游戏切换后台
     */
    private onEnterBackground() {
        Logger.info("游戏进入后台");
        this.offlineTime = StringUtils.time();
        game.pause();
        director.pause();
        game.frameRate = 5;
        EventMgr.Instance.emit(SYS_EVENT.ON_ENTER_BACKGROUND);
    }

    /**
     * 游戏切换前台
     */
    private onEnterForeground() {
        Logger.info("游戏进入前台");
        // let cuerrTime = StringUtils.time();
        // let time = cuerrTime - this.offlineTime;
        // if (time >= 120) {
        //     H5Api.navigateBack();
        //     return;
        // }
        game.resume();
        director.resume();
        game.frameRate = 60;
        EventMgr.Instance.emit(SYS_EVENT.ON_ENTER_FOREGROUND);
    }

    /**
     * 关闭游戏
     */
    private onGameTheClose() {
        EventMgr.Instance.removeAll();
        SocketMgr.Instance.close();
        HeartBeatMgr.close();
        game.end();
    }

    /**
     * 显示加载界面
     */
    private async onRecvclickAniam() {
        if (null == this.clickAniam) {
            this.clickAniam = await UIMgr.Instance.addPrefabNode(EnumPrefab.clickAniam, null, this.myapp.node);
            this.clickAniam.getComponent(UIOpacity).opacity = 0;
        }
    }

    /**
     * 加载转圈动画
     */
    private async onRecvShowNetWork(isShow: boolean = false) {
        if (null == this.networkMask) {
            // this.networkMask = await UIMgr.Instance.showView(EnumPrefab.networkMask, null, GameApp.Instance.MyAppLayer, EnumPrefab.networkMask, false);
            // this.networkMask.addComponent(NetworkMaskView);
            this.networkMask = await UIMgr.Instance.showView(EnumPrefab.waiting, null, GameApp.Instance.MyAppLayer, EnumPrefab.waiting, false);
        }
        //
        // let networkMask = this.networkMask.getComponent(NetworkMaskView);
        // networkMask!.ShowAnim(isShow);

        this.networkMask.active = isShow;
    }

    /**
     * 显示加载界面
     */
    private async onRecvShowLoading(list: Array<EnumBundle> = null) {
        if (null == this.loadingView || !isValid(this.loadingView)) {
            // this.loadingView = await UIMgr.Instance.showView(EnumPrefab.loading, null, GameApp.Instance.MyAppLayer, EnumPrefab.loading, false);
            this.loadingView = await UIMgr.Instance.showView(EnumPrefab.loading, null, GameApp.Instance.getAppLayer(), EnumPrefab.loading, false);
            this.loadingView.addComponent(LoadingView);
        }
        //
        let loadingCtrl = this.loadingView.getComponent(LoadingView);
        if (list == null) {
            loadingCtrl!.ShowAnim(false);
            return;
        }
        //
        loadingCtrl!.showResult(list);
    }

    onsetLoadingProgress(progress: number) {
        this.setShowLoadingPrecent(progress);
    }

    /**
     * 设置加载进度
     */
    private async setShowLoadingPrecent(num) {
        if (null == this.loadingView || !isValid(this.loadingView)) {
            Logger.info("loadingView is null!");
            return;
        }
        //
        let loadingCtrl = this.loadingView.getComponent(LoadingView);
        loadingCtrl!.showPercent(num);
    }

    /**
     * 显示隐藏防暴力点击
     */
    private async onClickShow(is_back: boolean) {
        if (null == this.clickView) {
            this.clickView = await UIMgr.Instance.addPrefabNode(EnumPrefab.click, null, GameApp.Instance.MyAppLayer, EnumPrefab.click);
        }
        //
        this.clickView.active = is_back;
    }

    /**
     * 切换场景
     */
    private async onRecvChangeScene<T>(param_: T) {
        let sceneName = param_["name"];
        let gameInfo = BundleConfig.ScenesMap.get(sceneName);
        if (gameInfo) {
            let depency = gameInfo.prepkg.depency;
            if (depency && depency.length > 0) {
                for (let i = 0; i < depency.length; i++) {
                    await ResMgr.Instance.loadBundle(depency[i]);
                }
            }
            let param = param_["param"] || {};
            param.bundle = gameInfo.abName;
            let app = director.getScene().getChildByName("myapp");
            app["viewParam"] = param;
            Logger.debug('change scene param:', param)

            if (gameInfo.abName && gameInfo.abName != "") {
                ResMgr.Instance.loadBundle(gameInfo.abName).then((res) => {
                    this.switchScene(gameInfo, sceneName);
                });
            } else {
                this.switchScene(gameInfo, sceneName);
            }
        }
    }

    /**
     * 切换场景
     */
    private switchScene(param: ISceneParam, sceneName: string) {
        // 暂停网络
        let lastScene = GlobalModel.Instance.curScene;
        Logger.debug(`enter ${param.name} success`);
        director.loadScene(sceneName, null, async () => {
            // 卸载所有资源
            if (lastScene && lastScene.abName) {
                let bundle = ResMgr.Instance.getBundle(lastScene.abName);
                bundle.release(lastScene.name, SceneAsset);
                if (lastScene.abName != param.abName && lastScene.is_sub_game != param.is_sub_game) {
                    if (!Utils.isNull(lastScene.unprepkg)) {
                        ResMgr.Instance.unPreLoadPkgRes(lastScene.unprepkg);
                    }
                    bundle.releaseAll();
                }
            }
            //
            GlobalModel.Instance.curScene = param;
        })
    }
}
