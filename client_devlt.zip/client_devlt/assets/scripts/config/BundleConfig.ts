import { Prefab, SpriteFrame } from "cc";

/** bundle信息接口 */
export interface IBundleAsset {
    ABName: EnumBundle | string;
    /** 是不是子游戏 */
    is_sub_game: boolean;
    /** 资源名字 */
    name: string;
    /** 相对路径 */
    path: string;
    /** 绝对路径 */
    src?: string;
}

// 场景
export enum EnumScene {
    none = "none",
    //启动场景
    main = "main",
    //登录
    login = "login",
    //大厅
    lobby = "lobby",
    // 子游戏
    ridCrush = "ridCrush",
    // end
}

export enum EnumBundle {
    // 引擎默认的bundle
    resources = "resources",
    lobby = "lobby",
}

export enum EnumPrefab {
    // 公共资源
    toast = "toast",
    ToastMgrUI = "ToastMgrUI",
    clickAniam = "clickAniam",
    alert = "alert",
    loading = "loading",
    click = "click",
    update = "update",
    guide = "guide",
    mask = "mask",
    reconnect = "reconnect",
    networkMask = "networkMask",
    waiting = "waiting",

    //game
    gameRecommendPage = "gameRecommendPage",
    allGamesOfSupplier = "allGamesOfSupplier",
    enterGame = "enterGame",

    //account
    signIn = "signIn",
    accountCreate = "AccountCreate",
    bindPhone = "bindPhone",
    logoutWarn = "logoutWarn",
    logoutConfirm = "logoutConfirm",
    retrievePasswordStep1 = "retrievePasswordStep1",
    retrievePasswordStep2 = "retrievePasswordStep2",
    setLoginPassWord = "SetLoginPassWord",
    myInfo = "myInfo",
    userAvatarModify = "userAvatarModify",
    userNameModify = "userNameModify",
    userGenderModify = "userGenderModify",
    bindInvitationCode = "bindInvitationCode",
    aboutUs = "aboutUs",
    giftCode = "giftCode",
    balanceDetail = "balanceDetail",
    notifications = "notifications",
    ticket = "ticket",
    liveSupport = "liveSupport",

    //vip
    vipMain = "VipMain",
    vipBonusHistory = "vipBonusHistory",
    vipLevelDiscrition = "vipLevelDiscrition",

    //mail
    mailMain = "MailMain",

    //share
    shareToApp = "shareToApp",

    //task
    taskMain = "TaskMain",
    taskPopup = "TaskPopup",
    //club
    ClubDetail = "ClubDetail",
    ClubHelpInviteNewUser = "ClubHelpInviteNewUser",
    ClubHelpInviteAllUser = "ClubHelpInviteAllUser",
    ClubHistory = "ClubHistory",

}

export interface ISceneParam {
    name: EnumScene | string;
    back?: boolean;
    is_sub_game: boolean;
    abName?: EnumBundle | string;
    path?: string;
    remote_url?: string;
    prepkg?: { depency?: Array<EnumBundle | string> };
    unprepkg?: any;
    param?: {}
}

export interface IbundleParam {
    name: EnumBundle | string;
    is_sub_game: boolean;
    remote_url?: string;
}


/**
 * 预加载资源
 * {
 *      "lobby":
 *      {
 *          remote_url:null
 *          src:[
 *             {
 *              assetType:Prefab
 *              urls:[
 *
 *
 *                  ]
 *              }
 *          ]
 *      }
 * }
 */
// 预制体配置
export namespace BundleConfig {
    // 存放远程地址
    export const bundles: Map<EnumBundle | string, IbundleParam> = new Map<EnumBundle | string, IbundleParam>();
    // 场景配置列表
    export const ScenesMap: Map<EnumScene | string, ISceneParam> = new Map<EnumScene | string, ISceneParam>();
    // ScenesMap.set(EnumScene.ridCrush, {
    //     name: EnumScene.ridCrush,
    //     is_sub_game: false,
    //     abName: EnumBundle.ridCrush,
    //     path: "scenes/ridCrush",
    //     prepkg: {
    //         "ridCrush": {
    //             remote_url: null,
    //             src: [{
    //                 assetType: Prefab,
    //                 urls: [
    //                     "prefabs/ui/matchUI"
    //                 ]
    //             }, {
    //                 assetType: SpriteFrame,
    //                 urls: [
    //                     "texture/icon/1/spriteFrame",
    //                     "texture/icon/2/spriteFrame",
    //                     "texture/icon/3/spriteFrame",
    //                     "texture/icon/4/spriteFrame",
    //                     "texture/icon/5/spriteFrame",
    //                     "texture/icon/6/spriteFrame",
    //                     "texture/icon/7/spriteFrame",
    //                     "texture/icon/8/spriteFrame",
    //                 ]
    //             }]
    //         }
    //     },
    //     /** */
    //     unprepkg: {}
    // });

    ScenesMap.set(EnumScene.lobby, {
        name: EnumScene.lobby,
        is_sub_game: false,
        abName: EnumBundle.lobby,
        path: "lobby",
        prepkg: {},
        unprepkg: {}
    });

    ScenesMap.set(EnumScene.login, {
        name: EnumScene.login,
        is_sub_game: false,
        abName: null,
        path: "login",
        prepkg: {
            depency: []
        },
        unprepkg: {}
    });

    /** */
    export function getBundleAsset(name_: string) {
        return BundleConfig.bundleAssets.get(name_)
    }

    /** */
    export const bundleAssets: Map<string, IBundleAsset> = new Map<string, IBundleAsset>();
    // 公共资源
    bundleAssets.set(EnumPrefab.toast, {
        ABName: EnumBundle.resources,
        is_sub_game: false,
        name: EnumPrefab.toast,
        path: "prefabs/toast"
    });
    //
    bundleAssets.set(EnumPrefab.ToastMgrUI, {
        ABName: EnumBundle.resources,
        is_sub_game: false,
        name: EnumPrefab.ToastMgrUI,
        path: "prefabs/ToastMgrUI"
    });
    //
    bundleAssets.set(EnumPrefab.clickAniam, {
        ABName: EnumBundle.resources,
        is_sub_game: false,
        name: EnumPrefab.clickAniam,
        path: "prefabs/clickAniam"
    });
    //
    bundleAssets.set(EnumPrefab.alert, {
        ABName: EnumBundle.resources,
        is_sub_game: false,
        name: EnumPrefab.alert,
        path: "prefabs/alert"
    });
    //
    bundleAssets.set(EnumPrefab.loading, {
        ABName: EnumBundle.resources,
        is_sub_game: false,
        name: EnumPrefab.loading,
        path: "prefabs/loading"
    });
    //
    bundleAssets.set(EnumPrefab.click, {
        ABName: EnumBundle.resources,
        is_sub_game: false,
        name: EnumPrefab.click,
        path: "prefabs/click"
    });
    //
    bundleAssets.set(EnumPrefab.mask, {
        ABName: EnumBundle.resources,
        is_sub_game: false,
        name: EnumPrefab.mask,
        path: "prefabs/mask"
    });
    //
    bundleAssets.set(EnumPrefab.reconnect, {
        ABName: EnumBundle.resources,
        is_sub_game: false,
        name: EnumPrefab.reconnect,
        path: "prefabs/reconnect"
    });
    //
    bundleAssets.set(EnumPrefab.networkMask, {
        ABName: EnumBundle.resources,
        is_sub_game: false,
        name: EnumPrefab.networkMask,
        path: "prefabs/networkMask"
    });

    bundleAssets.set(EnumPrefab.signIn, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.signIn,
        path: "prefabs/ui/account/SignIn"
    });

    bundleAssets.set(EnumPrefab.accountCreate, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.accountCreate,
        path: "prefabs/ui/account/AccountCreate"
    });

    bundleAssets.set(EnumPrefab.bindPhone, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.bindPhone,
        path: "prefabs/ui/account/BindPhone"
    });

    bundleAssets.set(EnumPrefab.logoutWarn, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.logoutWarn,
        path: "prefabs/ui/account/LogoutWarn"
    });

    bundleAssets.set(EnumPrefab.logoutConfirm, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.logoutConfirm,
        path: "prefabs/ui/account/LogoutConfirm"
    });

    bundleAssets.set(EnumPrefab.retrievePasswordStep1, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.retrievePasswordStep1,
        path: "prefabs/ui/account/RetrievePasswordStep1"
    });

    bundleAssets.set(EnumPrefab.retrievePasswordStep2, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.retrievePasswordStep2,
        path: "prefabs/ui/account/RetrievePasswordStep2"
    });

    bundleAssets.set(EnumPrefab.setLoginPassWord, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.setLoginPassWord,
        path: "prefabs/ui/account/SetLoginPassWord"
    });

    bundleAssets.set(EnumPrefab.myInfo, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.myInfo,
        path: "prefabs/ui/account/MyInfo"
    });

    bundleAssets.set(EnumPrefab.userAvatarModify, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.userAvatarModify,
        path: "prefabs/ui/account/UserAvatarModify"
    });

    bundleAssets.set(EnumPrefab.userNameModify, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.userNameModify,
        path: "prefabs/ui/account/UserNameModify"
    });

    bundleAssets.set(EnumPrefab.userGenderModify, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.userGenderModify,
        path: "prefabs/ui/account/UserGenderModify"
    });

    bundleAssets.set(EnumPrefab.bindInvitationCode, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.bindInvitationCode,
        path: "prefabs/ui/account/BindInvitationCode"
    });

    bundleAssets.set(EnumPrefab.aboutUs, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.aboutUs,
        path: "prefabs/ui/account/AboutUs"
    });

    bundleAssets.set(EnumPrefab.giftCode, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.giftCode,
        path: "prefabs/ui/account/GiftCode"
    });

    bundleAssets.set(EnumPrefab.balanceDetail, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.balanceDetail,
        path: "prefabs/ui/account/BalanceDetail"
    });

    bundleAssets.set(EnumPrefab.notifications, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.notifications,
        path: "prefabs/ui/account/Notifications"
    });

    bundleAssets.set(EnumPrefab.ticket, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.ticket,
        path: "prefabs/ui/account/Ticket"
    });

    bundleAssets.set(EnumPrefab.liveSupport, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.liveSupport,
        path: "prefabs/ui/account/LiveSupport"
    });

    //vip
    bundleAssets.set(EnumPrefab.vipMain, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.vipMain,
        path: "prefabs/ui/vip/VipMain"
    });

    bundleAssets.set(EnumPrefab.vipBonusHistory, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.vipBonusHistory,
        path: "prefabs/ui/vip/VipBonusHistory"
    });

    bundleAssets.set(EnumPrefab.vipLevelDiscrition, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.vipLevelDiscrition,
        path: "prefabs/ui/vip/VipLevelDiscrition"
    });

    bundleAssets.set(EnumPrefab.waiting, {
        ABName: EnumBundle.resources,
        is_sub_game: false,
        name: EnumPrefab.waiting,
        path: "prefabs/waiting"
    });

    bundleAssets.set(EnumPrefab.gameRecommendPage, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.gameRecommendPage,
        path: "prefabs/ui/games/recommend/GameRecommendPage"
    });

    bundleAssets.set(EnumPrefab.allGamesOfSupplier, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.allGamesOfSupplier,
        path: "prefabs/ui/games/allGame/AllGamesOfSupplier"
    });


    //mail
    bundleAssets.set(EnumPrefab.mailMain, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.mailMain,
        path: "prefabs/ui/mail/Mail"
    });

    // task main
    bundleAssets.set(EnumPrefab.taskMain, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.taskMain,
        path: "prefabs/ui/task/TaskMain"
    });
    // end

    // task popup
    bundleAssets.set(EnumPrefab.taskPopup, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.taskPopup,
        path: "prefabs/ui/task/TaskPopup"
    });
    // end

    bundleAssets.set(EnumPrefab.enterGame, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.enterGame,
        path: "prefabs/ui/games/allGame/EnterGame"
    });

    //share
    bundleAssets.set(EnumPrefab.shareToApp, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.shareToApp,
        path: "prefabs/ui/shared/ShareToApp"
    });

    //club
    bundleAssets.set(EnumPrefab.ClubDetail, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.ClubDetail,
        path: "prefabs/ui/club/ClubDetail"
    });

    bundleAssets.set(EnumPrefab.ClubHelpInviteNewUser, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.ClubHelpInviteNewUser,
        path: "prefabs/ui/club/ClubHelpInviteNewUser"
    });

    bundleAssets.set(EnumPrefab.ClubHelpInviteAllUser, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.ClubHelpInviteAllUser,
        path: "prefabs/ui/club/ClubHelpInviteAllUser"
    });

    bundleAssets.set(EnumPrefab.ClubHistory, {
        ABName: EnumBundle.lobby,
        is_sub_game: false,
        name: EnumPrefab.ClubHistory,
        path: "prefabs/ui/club/ClubHistory"
    });

    /** bundle信息接口 */
    export interface IBundlePathData {
        /**类型 */
        assetType: any;
        /** 是否全部加载 */
        isLoadAll: boolean;
        /** 全部加载使用该目录 */
        path?: string;
        /** 指定加载 */
        paths?: Array<string>;
    }

    /** */
    export interface IBundlePrepkg {
        /** 需要加载的包名 */
        ABName: EnumBundle | string;
        /** 绝对路径 */
        src: Array<IBundlePathData>;
    }

    /** */
    export const bundlePrepkg: Map<string, IBundlePrepkg> = new Map<string, IBundlePrepkg>();

    bundlePrepkg.set(EnumBundle.resources, {
        ABName: EnumBundle.resources,
        src: [{
            assetType: Prefab, isLoadAll: true, path: "prefabs/"
        }]
    })

    bundlePrepkg.set(EnumBundle.lobby, {
        ABName: EnumBundle.lobby,
        src: [{
            assetType: Prefab, isLoadAll: true, path: "prefabs/"
        }]
    })
}

