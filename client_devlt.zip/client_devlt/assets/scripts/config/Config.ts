import { macro } from "cc";
import AccountModel from "../model/AccountModel";
import { IGameConfig } from "./IConfig";
import { Config_Dev } from "./Config_Dev";
import { Config_Test } from "./Config_Test";
import { Config_Release } from "./Config_Release";

//有可能会导致ios白屏 提前禁用cocos的webGL2.0后续测试可以考虑ios关闭安卓打开
macro.ENABLE_WEBGL_ANTIALIAS = false;

export namespace AppConfig {
    export enum BuildType {
        DEV,                //开发版
        TEST,               //测试版
        RELEASE             //正式版
    }


    /** 签名配置*/
    export const md5_key = "}a3$F#*O!6+Vrtyuf3QrbR_%^hhh;p4B6?";
}

export let buildType = Number(AppConfig.BuildType.DEV);
export let gameConfig: IGameConfig = null;


/** 游戏配置 */
if (buildType == AppConfig.BuildType.DEV) {
    gameConfig = Config_Dev;
} else if (buildType == AppConfig.BuildType.TEST) {
    gameConfig = Config_Test;
} else if (buildType == AppConfig.BuildType.RELEASE) {
    gameConfig = Config_Release;
}


/** 游戏参数表 */
let params = new URLSearchParams(window.location.search);

/** 游戏密钥 */
let token = params.get('token');
if (token != null) {
    AccountModel.Instance.token = token;
}
/** 游戏标识 */
let id = params.get('id');
if (id != null) {
    //AccountModel.Instance.battlegroundId = parseInt(id)
}
/** 操作系统 */
let platform = params.get('platform');
if (platform != null) {
    // GameConfig.os = platform;
}

