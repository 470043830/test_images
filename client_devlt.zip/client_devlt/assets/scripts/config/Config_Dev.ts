import { IGameConfig } from "./IConfig";

/** 开发版游戏配置 */
export const Config_Dev: IGameConfig = {
    api_url: "http://192.168.1.177:20000/client",
    remote_url: "http://192.168.1.40:8080/remotefiles/",
}
