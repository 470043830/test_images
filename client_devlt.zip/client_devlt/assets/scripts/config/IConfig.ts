
/** 测试版游戏配置 */
export interface IGameConfig {
    api_url: string,                //url
    remote_url: string,              //远程资源地址
}
