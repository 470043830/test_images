import { IGameConfig } from "./IConfig";

/** 正式版游戏配置 */
export const Config_Release: IGameConfig = {
    api_url: "https://hello.91wan.club/client",
    remote_url: "https://game.91wan.club/web-mobile/remotefiles/",
}
