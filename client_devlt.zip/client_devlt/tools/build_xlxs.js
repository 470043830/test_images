
// const XLSX = require('xlsx');
 
// // 读取xlsx文件
// const workbook = XLSX.readFile("./xlsx/Bingo.xlsx");
 
// // 获取工作表的名字
// const sheetNames = workbook.SheetNames;
// for (let i = 0; i < sheetNames.length; i++) {
//     console.log("道具表名称 ==> "+sheetNames[i])
//     const sheet = workbook.Sheets[sheetNames[i]];
//     // console.log("道具表数据 ==> ",sheet)
//     const data = XLSX.utils.sheet_to_json(sheet);
    
//      console.log(sheetNames[i]+"表转json ==> ",data);
// }
const fs = require('fs');
const filePath = './xlsx/item_tbbingoaudio.bytes';
 
fs.readFile(filePath, (err, data) => {
  if (err) {
    return console.error(err);
  }
  // 假设byte文件的内容就是JSON字符串
  const jsonString = data.toString();

  // 将JSON字符串转换为对象
  try {
    const jsonObj = JSON.parse(jsonString);
    console.log(jsonObj); // 这里是转换后的JSON对象
  } catch (e) {
    console.error('Parsing error:', e);
  }
});
