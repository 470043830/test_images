const circleUtil = require('../utils/circle-util');

Component({
    data: {
        isHide: false,
        selected: 0,
        color: "#ddd",
        selectedColor: "#666",
        isShowPublish: false,
        list: [
            {
                "pagePath": "/pages/home/index",
                "text": "商圈",
                "iconPath": "/assets/icons/home1.png",
                "selectedIconPath": "/assets/icons/home2.png",
                flex: 1
            },
            {
                "pagePath": null,
                text: null,
                flex: 0.3
            },
            {
                "pagePath": "/pages/discovery/index",
                "text": "发现",
                "iconPath": "/assets/icons/faxian1.png",
                "selectedIconPath": "/assets/icons/faxian2.png",
                flex: 1
            }
        ]
    },
    attached() {
        console.log('custom-tab-bar attached...');
    },
    methods: {
        switchTab(e) {
            const data = e.currentTarget.dataset;
            const url = data.path;

            console.log('switchTab, url: ', url);
            if (url){
                wx.switchTab({ url });
            }

            // this.setData({
            //     selected: data.index
            // });
        },

        // showTab(isShow) {
        //     this.setData({ isHide: !isShow });
        // },

        onPublishTap() {
            console.log('onPublishTap...');
            // wx.showToast({
            //     title: '已复制',
            // })
            // wx.navigateTo({
            //     url: '/pages/goods_edit/index'
            // });

            this.toGoodsEditPage();

            // 只允许从相机扫码
            // wx.scanCode({
            //     onlyFromCamera: true,
            //     success(res) {
            //         console.log('7777777777: ', res);
            //     }
            // });

            // const url111 = "/pages/webview/index?url=" + 'https://mp.weixin.qq.com/s/6B-mqFEQaxD7mVqZ-esWnQ';

            // url111 && wx.navigateTo({ url: url111 });

        },
        toGoodsEditPage() {
            if (getApp().offline()) {
                circleUtil.showLoginModal();
                return;
            }
            wx.showActionSheet({
                // itemList: ['商品', '求购', '拼单', '二手', '招聘', '出租/转让'],
                itemList: ['求购', '拼单', '二手', '招聘', '出租/转让'],
                success: res => {
                    wx.navigateTo({
                        url: '/pages/goods_edit/index?category=' + (res.tapIndex+1),
                    });
                },
                fail(res) {
                    console.log(res.errMsg);
                }
            });

        },
    }
});
