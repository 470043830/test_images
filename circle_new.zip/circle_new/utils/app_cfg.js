
//...
const defaultShopId = 'A201905291653236670027260';
const openTime = require('./app_time.js').openTime; //new Date(Date.parse('2022/11/18 16:00:00'));
const shopIds = require('./app_shops.js').shopIds;



function getCurrAppId() {
  const info = wx.getAccountInfoSync();
  // const info = ks.getAccountInfoSync();
  // console.log('info: ', info);
  return info.miniProgram.appId;
  // return info.microapp.appId;
}

function getCurrShopId() {
  var timestamp = new Date().getTime();

  console.log('getCurrShopId ', timestamp, openTime);

  if (timestamp > openTime.getTime()) {
    const appid = getCurrAppId();
    for (let i = 0; i < shopIds.length; i++) {
      if (appid == shopIds[i].appid) {
        return shopIds[i].id;
      }
    }
  }
  return defaultShopId;
}

function isInLimitedMode() {
  return getCurrShopId() == defaultShopId;
}


function getStorageShopId() {
  return tt.getStorageSync("StorageShopId");
}

function setStorageShopId() {
  tt.setStorageSync("StorageShopId", getCurrShopId());
}


module.exports = {
  shopIds,
  defaultShopId,
  getCurrAppId,
  getCurrShopId,
  getStorageShopId,
  setStorageShopId,
  isInLimitedMode,
};
