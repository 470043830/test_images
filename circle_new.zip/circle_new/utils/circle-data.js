const util = require('./util.js');
const circleUtil = require('./circle-util.js');
const test_shops = require('./test-shops.js');
const app_cfg = require('./app_cfg.js');
const clog = require('./circle-log.js');

//...
// const testToken = 'ODE4OEFENDg5REQwQkRCMEJGRjAxNTM5MkRFNDFDQUY0NEY2QUQ4OTJCRUY4MDU4NEZEQjg4NkY1MTkyNDNEMzIwM0M5MjI1RjE5MTZGRDZFNjFBQTc3QTVCNUIyODEw';
// const testToken = `RjU4QTZGNUQ2Qzc5OUQ0MjVFQzY5NkFBODZFNzFDNzE5OThEMDI1RjI3RTc4MDUwNjgwRkQ2QjVBMkRBN0EwN0I5NkM5Rjk4REYzRkRBMjhDMDMwOUNDNTI4NEI4MjJGQ0JBNTk2RUU3OTM2RENFOTM5RjMwODY1MzMxNDY0RjA=`;
const testDomain = 'https://www.wsxcme.com'; //'https://www.tapbizz.cn'; //'https://www.w00g.cn'; //''  http://106.52.252.33';//'https://www.w00g.cn';
const isNeiWang = 0; //0; //0;
let errorTipLock = 0;


function getCheckedText() {
  if (circleUtil.isMiniChecked()) {
    return {
      'ruzhu': '入驻',
    }
  } else {
    return {
      'ruzhu': '试试',
    }
  }
}

/**
 * 获取商圈的商户资料或主播资料
 * @param {*} albumId 
 * @returns 
 */
async function getCircleShopInfo(albumId) {
  let applyInfo = await getCircleApply({ albumId });
  if (!applyInfo.shopId) {
    applyInfo = await getAnchorCircleApply({ albumId });
  }
  const { appId: plusAppId } = getApp().getCircleConfig();
  if (!applyInfo.detailAddress) {
    applyInfo.detailAddress = '';
  }
  if (!applyInfo.region) {
    applyInfo.region = '';
  }
  return {
    isBusiness: true,
    mediaInfo: [],
    applyInfo,
    plusAppId, //"wx82768f631dd021fd"
  }
}
function test_getShopTags() {
  return getApp().getCircleCategoryList().map(item => {
    return item.categoryName;
  });
  return ["男装", "女装", "童装", "运动", "时尚潮流", "商务", "居家服", "鞋子", "箱包", "箱包1", "箱包2", "箱包3"];
}

/**
 * 获取商圈基本配置
 */
async function getCircleConfig() {
  let appid = app_cfg.getCurrAppId();
  let url = testDomain + '/circle/api/v3/hzCircle/getCircleConfig?miniAppId=' + appid;
  const { isOk, result = {} } = await circleUtil.fetchNetData({ url });
  clog.log('getCircleConfig: ', isOk, result);

  if (!isNeiWang) {// del the neiwang token
    // setTestStorageSync();
    const storageUserInfo = getApp().getStorageUserInfo();
    clog.log('storageUserInfo: ', storageUserInfo);
    if (storageUserInfo && !storageUserInfo.albumId) {
      getApp().storageUserInfo("");
      getApp().globalData.userInfo = null;
    }
  }


  if (isOk) {
    getApp().setCircleConfig(result);
    clog.log('circleConfig: ', getApp().getCircleConfig());
    getCircleStatus();
    // getPackageDetail();

    // queryRecentMerchants();
    // queryReCommendMerchants();
    // queryMerchantsByShopName('3ad');
    getCircleApply();

    // getCircleCategoryShopData();

    // album_personal_all_test();
    // fetchItemData('A202212191541552710001195', 'I202212201759338942001487');

    // queryMerchantsList();
    getAdminStatus();
    // findDictConfig();
    getCircleCategoryList();
    getAnchorCircleApply();
    // getCircleAnchorApplyList();

    //...
    wx.setTabBarItem({
      index: 2,
      text: '我要' + getCheckedText()["ruzhu"],
      "iconPath": "/assets/tab_icons/ruzhu1.png",
      "selectedIconPath": "/assets/tab_icons/ruzhu2.png"
    });
    return true;
  } else {
    return false;
    if (!errorTipLock) {
      errorTipLock = 1;
      wx.showModal({
        title: '提示',
        content: '网络错误，如果持续不能登陆，请删除本平台后重新登录！',
        showCancel: false,
        success: (result) => {
          if (result.confirm) {
            errorTipLock = 0;
            wx.reLaunch({ url: '/pages/home/index' });
          }
        }
      });
    }

  }
}

/**
 * 获取商圈的状态 0-未开通商圈和填写资料 1-开通了商圈但是没有填写资料 2-没有开通商圈但是已经填写了资料
 * https://yapi.in.szwego.com/project/187/interface/api/19765
 */
async function getCircleStatus() {
  let url = testDomain + '/circle/api/v3/hzCircle/apply/getCircleStatus';

  // clog.log('getCircleStatus1 ', getApp().globalData.userInfo, getApp().globalData.userInfo.token)
  const { isOk, result = {} } = await circleUtil.fetchNetData({ url });
  const { anchorStatus = 0, merchantStatus = 0 } = result;
  clog.log('getCircleStatus ', isOk, result);
  //...cache for some place
  getApp().setCircleStatus(result);
  if (isOk && merchantStatus == 3) {
    wx.setTabBarItem({
      index: 2,
      text: '已入驻',
      "iconPath": "/assets/tab_icons/ruzhu1.png",
      "selectedIconPath": "/assets/tab_icons/ruzhu2.png"
    });
  }
  return result;
}

async function getMyUserInfo() {
  let url = testDomain + `/service/account/get_user_system_status.jsp`;

  const { isOk, result = {} } = await circleUtil.fetchNetData({ url });
  clog.log('getMyUserInfo, result: ', result);
  return result;
}

/**
 * 查询套餐详情信息
 * @param {*} params 
 */
async function getPackageDetail() {
  let url = testDomain + '/increase/api/v3/pack/getPackageDetail?packageCode=package_code_18';
  const { isOk, result = {} } = await circleUtil.fetchNetData({ url });
  clog.log('getPackageDetail ', isOk, result);

  return result;
}

/**
 * 保存商圈资料
 */
async function saveCircleApply(param) {
  let url = testDomain + '/circle/api/v3/hzCircle/apply/saveCircleApply';
  const { data } = await util.fetchPost(url, param);
  clog.log('saveCircleApply, data: ', data);
  return data;
}

/**
 * 获取商圈类别
 * @returns 
 */
async function getCircleCategoryList() {
  let url = testDomain + '/circle/api/v3/hzCircle/category/getCircleCategoryList';
  const { isOk, result = [] } = await circleUtil.fetchNetData({ url });
  clog.log('getCircleCategoryList ', isOk, result);

  if (isOk) {
    getApp().setCircleCategoryList(result);
  }
  return result;
}

/**
 * 查询最新入驻商家
 * @returns 
 */
async function queryRecentMerchants() {
  let url = testDomain + '/circle/api/v3/hzCircle/apply/queryRecentMerchants';
  const { isOk, errcode, errmsg, result = [] } = await circleUtil.fetchNetData({ url });
  clog.log('queryRecentMerchants ', isOk, errcode, errmsg, result);

  return result;
}

/**
 * 推荐商家列表
 * @returns 
 */
async function queryReCommendMerchants() {
  let url = testDomain + '/circle/api/v3/hzCircle/apply/queryReCommendMerchants';
  const { isOk, errcode, errmsg, result = [] } = await circleUtil.fetchNetData({ url });
  clog.log('queryReCommendMerchants ', isOk, errcode, errmsg, result);

  return result;
}

/**
 * 据商家名称模糊查询商家列表
 * @returns 
 */
async function queryMerchantsByShopName(searchName) {
  let url = testDomain + '/circle/api/v3/hzCircle/apply/queryMerchantsByShopName';
  const { isOk, result = {} } = await circleUtil.fetchNetData({ url, param: { searchName } });
  clog.log('queryMerchantsByShopName ', isOk, result);

  return result;
}

/**
 * 获取商家的资料
 * @param {*} param 
 * @returns 
 */
async function getCircleApply(param = {}) {
  let url = testDomain + '/circle/api/v3/hzCircle/apply/getCircleApply';
  const { isOk, result = {} } = await circleUtil.fetchNetData({ url, param });
  clog.log('getCircleApply ', isOk, result);

  //save my info
  if (isOk && !param.albumId) {
    getApp().setCircleApplyInfo(result);
  }

  return result;
}

/**
 * 查询分类的商家信息
 * @returns 
 */
async function getCircleCategoryShopData() {
  let url = testDomain + '/circle/api/v3/hzCircle/apply/getCircleCategoryShopData';
  const { isOk, result = [] } = await circleUtil.fetchNetData({ url });
  clog.log('getCircleCategoryShopData ', isOk, result);

  return result;
}

/**
 * 获取商圈管理员状态
 * @returns 
 */
async function getAdminStatus() {
  let url = testDomain + '/circle/api/v3/hzCircle/getAdminStatus';
  const { isOk, result = 1 } = await circleUtil.fetchNetData({ url, param: { miniAppId: app_cfg.getCurrAppId() } });
  clog.log('getAdminStatus ', isOk, result);

  //...cache
  getApp().setCircleAdminValue(result);
  return result;
}

/**
 * 设置推荐商家
 * @returns 
 */
async function recommendMerchant(albumId, isEnable) {
  let url = testDomain + '/circle/api/v3/hzCircle/apply/recommendMerchant';
  // const method = 'POST';
  // const { isOk, result = 1 } = await circleUtil.fetchNetData({ url, method, param: { albumId, miniAppId: app_cfg.getCurrAppId() } });
  // clog.log('recommendMerchant ', isOk, result);
  // return result;
  const param = { albumId, miniAppId: app_cfg.getCurrAppId(), isEnable };
  const { data } = await util.fetchPost(url, param);

  clog.log('recommendMerchant ', data);

  return data.result;
}

/**
 * 设置推荐主播
 * @returns 
 */
async function recommendAnchor(albumId, isEnable) {
  let url = testDomain + '/circle/api/v3/hzCircle/anchor/recommendAnchor';

  const param = { albumId, miniAppId: app_cfg.getCurrAppId(), isEnable };
  const { data } = await util.fetchPost(url, param);

  clog.log('recommendAnchor ', data);

  return data.result;
}

/**
 * 移除商家
 *  circleId	string	商圈id	
    albumId	string	相册id	
    miniAppId	string	小程序的miniAppId	
    isEnable	string	是否移除商家 1-是 0-否
 * @returns 
 */
async function delMerchant(albumId, isEnable) {
  let url = testDomain + '/circle/api/v3/hzCircle/apply/delMerchant';
  // const { isOk, result = 1 } = await circleUtil.fetchNetData({ url, param: { albumId, miniAppId: app_cfg.getCurrAppId() } });
  // clog.log('delMerchant ', isOk, result);

  // return result;
  const param = { albumId, miniAppId: app_cfg.getCurrAppId(), isEnable };
  const { data } = await util.fetchPost(url, param);

  clog.log('delMerchant ', data);

  return data.result;
}

/**
 * 移除商圈主播-管理员后台
 *  circleId	string	商圈id	
    albumId	string	相册id	
    miniAppId	string	小程序的miniAppId	
    isEnable	string	是否移除商家 0-取消删除 1-删除
 * @returns 
 */
async function deleteAnchor(albumId, isEnable) {
  let url = testDomain + '/circle/api/v3/hzCircle/anchor/deleteAnchor';
  const param = { albumId, miniAppId: app_cfg.getCurrAppId(), isEnable };
  const { data } = await util.fetchPost(url, param);

  clog.log('deleteAnchor ', data);

  return data.result;
}

/**
 * 入驻商家列表
 * @returns 
 */
async function queryMerchantsList() {
  let url = testDomain + '/circle/api/v3/hzCircle/apply/queryMerchantsList';
  const { isOk, result = [] } = await circleUtil.fetchNetData({ url, param: { miniAppId: app_cfg.getCurrAppId() } });
  clog.log('queryMerchantsList ', isOk, result);

  return result;
}

/**
 * 获取商圈主播列表---管理员后台
 * @returns 
 */
async function queryAnchorApplyList() {
  let url = testDomain + '/circle/api/v3/hzCircle/anchor/queryAnchorApplyList';
  const { isOk, result = [] } = await circleUtil.fetchNetData({ url, param: { miniAppId: app_cfg.getCurrAppId() } });
  clog.log('queryAnchorApplyList ', isOk, result);

  return result;
}

/**
 * 查询单条字典配置
 * @returns 
 */
async function findDictConfig() {
  let url = testDomain + '/increase/api/v3/dict/findDictConfig';
  const { isOk, result = {} } = await circleUtil.fetchNetData({ url, param: { configKey: 'circle_banner' } });
  clog.log('findDictConfig ', isOk, result);

  if (isOk) {
    const value1 = JSON.parse(result.value1);
    clog.log('value1: ', value1);
  }

  return result;
}


/**
 * 保存商圈主播的资料
 */
async function saveCircleAnchorApply(param) {
  let url = testDomain + '/circle/api/v3/hzCircle/anchor/saveCircleAnchorApply';
  const { data } = await util.fetchPost(url, param);
  clog.log('saveCircleApply, data: ', data);
  return data;
}

/**
 * 获取商圈主播的资料信息
 * @returns 
 */
async function getAnchorCircleApply(param = {}) {
  let url = testDomain + '/circle/api/v3/hzCircle/anchor/getAnchorCircleApply';
  const { isOk, result = {} } = await circleUtil.fetchNetData({ url, param });
  clog.log('getAnchorCircleApply ', isOk, result);

  return result;
}

function getZhuboPriceArray() {
  return ['高端', '中高端', '极致性价比'];
}

function getZhuboPriceIndex(priceDesc) {
  let array = ['高端', '中高端', '极致性价比'];
  for (let index = 0; index < array.length; index++) {
    if (array[index] == priceDesc) return index;
  }
  return -1;
}

/**
 * 首页-获取推荐主播列表
 * @returns 
 */
async function getCircleAnchorApplyList() {
  let url = testDomain + '/circle/api/v3/hzCircle/anchor/getCircleAnchorApplyList';
  const { isOk, errcode, errmsg, result = [] } = await circleUtil.fetchNetData({ url });
  clog.log('getCircleAnchorApplyList ', isOk, errcode, errmsg, result);

  return result;
}




async function getMyShopInfo(albumId) {
  let url = getDomainUrl('/album/personal/all');
  const { isOk, result = {} } = await circleUtil.fetchNetData({ url, param: { albumId } });
  // clog.log('getMyShopInfo ', isOk, result);

  if (isOk) {
    return result.targetAlbum;
  }

  return {};
}


async function getNewShops() {
  const { isOk, result = {} } = test_shops.getTestShops();
  //await circleUtil.fetchNetData({ url: `/circle/circle_new_interface.jsp?act=getNewShops` });

  // wx.hideLoading();
  clog.log('fetchNewShops, result: ', result);
  // clog.log('marketList: ', marketList);

  if (isOk) {
    const { shop_list } = result;
    for (let index = 0; index < shop_list.length; index++) {
      const shop = shop_list[index];
      shop.address = '测试地址111'; //this.getShopAddress(marketList, shop); //shop.floor.split('|')[1] + shop.booth;
    }
    return shop_list;
    // this.setData({ new_booths: shop_list });
    //...
    // this.fetcWxTempShops(shop_list);
  }
  return [];
}

async function getVipShops() {
  const { isOk, result = {} } = test_shops.getTestShops();
  //await circleUtil.fetchNetData({ url: `/circle/circle_new_interface.jsp?act=getVipShops` });

  clog.log('fetchVipShops, result: ', result);

  if (isOk) {
    const { shop_list } = result;
    for (let index = 0; index < shop_list.length; index++) {
      const shop = shop_list[index];
      shop.address = '测试地址222'; //this.getShopAddress(marketList, shop); //shop.floor.split('|')[1] + shop.booth;
    }
    wx.setStorageSync('fetchVipShops', shop_list.slice(0, 10));
    return shop_list;
    // this._vipList = shop_list;
    // this.setData({ vip_booths: shop_list.slice(0, 15) });
  }
  return [];
}

async function test_getShops() {

  return await getCircleCategoryShopData();

  //   categoryList: ["体育", "零食"]
  // imgs: [,…]
  // newItemCount: 6146
  // shopId: "A201807161353475560036829"
  // totalItemCount: 104535
  let shop = {
    shopIcon: "https://xcimg.szwego.com/20211111/i1636616483_7893_0.jpg",
    fansCount: 2171,
    images: ["20220218/i1645164628_7641_0.jpg", "20220218/i1645164628_5752_1.jpg", "20220218/i1645164619_1160_0.jpg"],
    newItemCount: 0,
    shopId: "A202111111452229800001233",
    shopName: "小狍兔毛衣 富康西15-5",
    categoryList: ["男装", "女装", "童装"],
    totalItemCount: 204,
  }

  let shop2 = {
    shopIcon: "https://xcimg.szwego.com/DYAIOgq83eqMJAFSPiajG2kLHqibqn3J7GEiaXeGU5jWcA10iakpvefooNg8m0hw5NTNCAiblDMTryaqLCvoOnn4zhQ",
    fansCount: 2197,
    images: ["20220422/i1650620342_628_0.jpg", "20220422/i1650620342_2530_1.jpg", "20220422/i1650620342_6769_2.jpg"],
    newItemCount: 0,
    shopId: "A202109101946454070002838",
    shopName: "金抱抱 利济中路128-1",
    categoryList: ["童装", "运动", "时尚潮流"],
    totalItemCount: 95,
  }

  let list = [shop, shop2];
  return list;

}


function getTimestamp(items) {
  let top = '', bottom = '';

  if (items) {
    for (var item of items) {
      if (!item.isTop) {
        if (!top || item.time_stamp > top) top = item.time_stamp;
        if (!bottom || item.time_stamp < bottom) bottom = item.time_stamp;
      }
    }
  }
  return {
    top, bottom
  };
}

function getDomainUrl(api) {
  return testDomain ? testDomain + api : 'https://www.wsxcme.com' + api;
}

async function fetchItemData(targetAlbumId, itemId) {
  const url = getDomainUrl('/commodity/view');
  const param = { targetAlbumId, itemId };

  const { isOk, result = {} } = await circleUtil.fetchNetData({ url, param });

  clog.log('fetchItemData: ', isOk, result);

  return { isOk, result };
}

/**
 * slipType	否	
0=下拉，1=上滑
 */
function album_personal_all_test() {
  // const url = `https://www.wsxcme.com/album/personal/all?&albumId=${albumId}&searchValue=${searchValue}&slipType=${slipType}&timestamp=${timestamp}`;
  const param = {
    timestamp: '', //'1671527345716',
    slipType: '',
    searchValue: '',
    albumId: 'A201910211430090851163'//'A202212191541552710001195';
  };
  const url = `https://www.wsxcme.com/album/personal/all`;
  util.fetch(url, param).then(res => {
    const {
      errcode,
      result,
      total_page,
      errmsg
    } = res.data;
    // clog.log('res.data: ', res.data);
    const { items } = result;
    let newArr = items.map(function (item) {// 使用map方法
      return item.isTop + ' ' + item.time_stamp + ' ' + item.title;
    });
    clog.log('newArr getTimestamp: ', getTimestamp(items));
    clog.log('newArr: ', newArr);
  });
}

//获取网络列表项方法...
const getNetItems = (slipType, timestamp) => {
  let list = [];

  if (slipType == 0) {
    let temp = []; //getNetItems();
    for (let index = 0; index < temp.length; index++) {
      const element = temp[index];
      if (element.timestamp > timestamp) { //下拉刷新，只留下较新的
        list.push(element);
      }
    }
  } else if (slipType == 1) {
    let temp = []; //getNetItems();
    for (let index = 0; index < temp.length; index++) {
      const element = temp[index];
      if (element.timestamp < timestamp) { //下拉刷新，只留下较旧的
        list.push(element);
      }
    }
  } else {
    let temp = []; //getNetItems();
    list = temp;
  }

  return list;
}

function setTestStorageSync() {
  const albumInfo = {
    "country": "Israel", "gender": 1, "province": "", "city": "", "avatarUrl": "https://thirdwx.qlogo.cn/mmopen/vi_32/ajNVdqHZLLCfJbJnyu3JQ5MRs9PzjUCJNOZYzhMJmrmWEWu0KpkvHpgFeWiaNDGxNhAKP6XWFsgYPL237zQRXNA/132", "openId": "o71Jq5NiKBpNY06cUkAdrStLyHd0", "nickName": "LiuTao", "albumId": "A201905291653236670027260", "new_token": true,
    "token": "NTIyREJBNDBDMjQzNTA3NjVBOUU2OTMwQTg1MzhCOEU3NUEzODFFMDU0MUU5RkQ1QTdBQzMxRjRDMEMwRDI3RERGODgxQTk0OEE0OUUzNTg1QkIwRjkzQzUwQjRFQUUy",
    "originToken": "RjU4QTZGNUQ2Qzc5OUQ0MjVFQzY5NkFBODZFNzFDNzE5OThEMDI1RjI3RTc4MDUwNjgwRkQ2QjVBMkRBN0EwN0I5NkM5Rjk4REYzRkRBMjhDMDMwOUNDNTI4NEI4MjJGQ0JBNTk2RUU3OTM2RENFOTM5RjMwODY1MzMxNDY0RjA="
  };

  wx.setStorageSync('UserInfo_CID000009', albumInfo);
}

module.exports = {
  test_getShopTags,
  test_getShops,
  getNewShops,
  getVipShops,
  getCircleShopInfo,
  getMyUserInfo,
  getCheckedText,
  getCircleConfig,
  getCircleStatus,
  getPackageDetail,
  saveCircleApply,
  saveCircleAnchorApply,
  getCircleCategoryList,
  queryRecentMerchants,
  queryReCommendMerchants,
  queryMerchantsByShopName,
  getCircleApply,
  getCircleCategoryShopData,
  testDomain,
  isNeiWang,
  getTimestamp,
  getDomainUrl,
  getAdminStatus,
  queryMerchantsList,
  recommendMerchant,
  recommendAnchor,
  delMerchant,
  deleteAnchor,
  getMyShopInfo,
  findDictConfig,
  getAnchorCircleApply,
  getCircleAnchorApplyList,
  queryAnchorApplyList,
};
