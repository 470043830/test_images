import { $wuxToast } from '../components/wux';
import commonGrid, { addUrl, addAlbumUrl } from './common-grid';
const constant = require('./constant');
const util = require('./util');
const logic = require('./logic');

function iconTap(ev) {
    const { shopId, followStatus } = ev.currentTarget.dataset;

    console.log('iconTap ', ev.currentTarget.dataset);
    // wx.navigateTo({
    //     url: `/pages/follow_detail/index?shop_id=${shopId}`
    // });
    let itemList = ['产品图册', 'Ta的发布'];

    wx.showActionSheet({
        itemList,
        success(res) {
            console.log(res.tapIndex);
            if (res.tapIndex == 0) {
                wx.navigateTo({
                    url: `/pages/follow_detail/index?shop_id=${shopId}`
                });
            } else if (res.tapIndex == 1) {
                wx.navigateTo({
                    url: `/pages/follow_detail/index?isCircle=true&shop_id=${shopId}`
                });
            }
        },
        fail(res) {
            console.log(res.errMsg);
        }
    });
}

function titleTap(ev) {
    const { dataset } = ev.currentTarget;
    const { index, rows, themeType, href } = dataset;
    const { list } = this.data;
    const key = `list[${index}].rows`;

    console.info('title', dataset, this.pageName);
    if (themeType === 3) {
        let content = '';
        if (util.isIOS()) {
            content = '此图文需在app中打开。下载app请前往苹果APP store 搜索「微商相册」。';
        } else {
            content = '此图文需在app中打开。下载app请前往百度搜索「微商相册」。';
        }

        wx.showModal({
            title: '提示',
            content: content,
            success: function (res) {
                if (res.confirm) {
                    console.log('用户点击确定');

                    // 跳转至app下载教程页面
                    wx.navigateTo({
                        url: '/pages/app/index'
                    });
                } else if (res.cancel) {
                    console.log('用户点击取消');
                }
            }
        });
    } else {
        this.setData({
            [key]: rows ? 0 : constant.ROWS
        });

        if (this.onTitleTap) {
            this.onTitleTap(dataset);
        }
    }
}

function onViewImg(e) {
    const { index, imgssrc } = e.target.dataset;
    const current = imgssrc[index];
    const { list } = this.data;
    const urls = list.map(item => item.imgsSrc)
        .reduce((prev, curr) => [...prev, ...curr]);

    console.info(index, e);
    wx.previewImage({
        current, // 当前显示图片的http链接
        urls, // 需要预览的图片http链接列表
    });
}

function onAddTheme(e) {
    const { index } = e.target.dataset;
    // const { addUrl, list } = this.data;
    const { list } = this.data;
    const { shop_id, goods_id } = list[index];
    const url = `${addUrl}&shop_id=${shop_id}&goods_id=${goods_id}`;

    console.info("onAddTheme", index, e);
    wx.showLoading({
        mask: true,
        title: '加载中...',
    });
    util.fetch(url)
        .then(res => {
            const { errcode, result } = res.data;

            wx.hideLoading();
            if (errcode == 0) {
                // const { shop_id, goods_id, follow_object } = result;
                const { follow_object } = result;

                // 未关注
                if (follow_object) {
                    this.showGuide(shop_id, follow_object);
                    return false;
                }

                // console.info('onAddTheme success', res);
                // this.setData({
                //     // [`list[${index}].shop_id`]: shop_id,
                //     // [`list[${index}].goods_id`]: goods_id,
                //     [`list[${index}].is_added`]: true,
                // });

                // 分享
                this.onShareTheme(e);
            }
        }, err => {
            console.info('onAddTheme error', err);

            wx.hideLoading();
            // 分享
            // this.onShareTheme(e);
        });
}

function onShareTheme(e) {
    const { dataset } = e.target;
    const { index } = dataset;
    const { list } = this.data;
    const { title } = list[index];

    console.info("onShareTheme", index, dataset);

    // 复制标题
    this.copyTitle(util.getTextTitle(title));

    // 分享
    this.shareIndex = index;
    logic.showshare(dataset, this.downloadStartCB, this.downloadingCB, this.onAddThemeToAlbum);
}

function onAddThemeToAlbum(dataset, callback) {
    const { index, is_added } = dataset;
    // const { addUrl, list } = this.data;
    const addUrl = addAlbumUrl;
    const { list, goods } = this.data;
    const { shop_id, goods_id } = index >= 0 ? list[index] : goods;
    const url = `${addUrl}&shop_id=${shop_id}&goods_id=${goods_id}`;

    console.info("onAddThemeToAlbum", dataset);

    if (is_added) {
        typeof callback == 'function' && callback();
        return false;
    }

    wx.showLoading({
        mask: true,
        title: '加载中...',
    });
    util.fetch(url)
        .then(res => {
            const { errcode, result } = res.data;

            wx.hideLoading();
            if (errcode == 0) {
                const { follow_object } = result;
                const key = index >= 0 ? `list[${index}].is_added` : 'goods.is_added';
                const key_shop_id = index >= 0 ? `list[${index}].share_shop_id` : 'goods.share_shop_id';
                const key_goods_id = index >= 0 ? `list[${index}].share_goods_id` : 'goods.share_goods_id';

                // 未关注
                if (follow_object) {
                    this.showGuide(shop_id, follow_object);
                    return false;
                }

                console.info('onAddThemeToAlbum success', res);
                this.setData({
                    [key]: true,
                    [key_shop_id]: result.shop_id,
                    [key_goods_id]: result.goods_id,
                });

                typeof callback == 'function' && callback();
            }

            // 分享
            // this.onShareTheme(e);
        }, err => {
            console.info('onAddThemeToAlbum error', err);

            wx.hideLoading();
            // 分享
            // this.onShareTheme(e);
        });
}

export default Object.assign({}, commonGrid, {
    iconTap,
    titleTap,
    onViewImg,
    onAddTheme,
    onShareTheme,
    onAddThemeToAlbum,
});
