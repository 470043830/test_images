const wxLog = wx.getRealtimeLogManager ? wx.getRealtimeLogManager() : null;
let deviceInfo = {};
try {
    const systemInfo = wx.getSystemInfoSync();
    deviceInfo = JSON.stringify(systemInfo);
    wxLog.info("用户系统信息", deviceInfo);
} catch (e) {
    console.log("getSystemInfoSync api not surport: ", e);
}

// const logMap = {};

export const log = (name, action, info, type) => {
    if (!info) {
        info = "empty";
    }

    // const time = formatTime();

    // const log = {
    //     name,
    //     // time,
    //     action,
    //     info,
    //     // deviceInfo,
    //     type
    // };

    // console.log("--------------日志上报 start------------");
    // console.log("log: ", log);
    // console.log("--------------日志上报 end------------");

    if (!wxLog) {
        console.log("---------基础库版本小于2.7.1--------");
    } else {
        let info1 = '';
        try {
            info1 = JSON.stringify(info && info.stack ? info.stack : info);
        } catch(e) {
        }
        wxLog.error(name, action, info);
        // wxLog[type](name, action, info1, JSON.stringify(log));
    }
};
