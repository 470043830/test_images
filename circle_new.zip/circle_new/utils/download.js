const preventFold = require('./prevent_fold');
import commonGrid from './common-grid';
import { log } from './log';

let saveTaskFiles = [];
let curTaskIndex = 0;
let singleDownloadTimer = null;
let downloadingTimer = null;

const updateDownloadLoading = (cur, total, downloadingCB) => {
    let percent = cur * 100 / total | 0;

    if (cur === total) {
        getApp().globalData.downloading = false;
    }
    typeof downloadingCB === 'function' && downloadingCB(percent, '下载进度:' + cur + '/' + total)

    // const percent = Math.round(parseFloat(cur/total) * 100);
    // wx.showLoading({
    //     title: `下载进度: ${percent}%`,
    //     mask: true,
    // });
}

const createSaveFilesTask = (title, shareType, downloadCompleteForShareFriends, shareComplete, downloadStartCB, downloadingCB) => {
    let saveTaskInterval = setInterval(() => {
        const readyToSave =
            saveTaskFiles[curTaskIndex] &&
            saveTaskFiles[curTaskIndex].downloadState &&
            !saveTaskFiles[curTaskIndex].saving;
        const savedFiles = saveTaskFiles.filter(item => item.saveState === 1 || item.saveState === 2);
        if (savedFiles.length === saveTaskFiles.length) {
            clearInterval(saveTaskInterval);
            saveTaskInterval = null;
            if (saveTaskFiles.length === 1) {
                singleDownloadTimer && clearInterval(singleDownloadTimer);
                singleDownloadTimer = null;
            }
            wx.setClipboardData({
                data: preventFold.randInsertCharacters(title),
                success: res => {
                    if (shareType !== 'friends') {
                        wx.showToast({
                            title: title?'下载成功，文字已复制':'下载成功',
                            duration: 2000,
                            icon: 'none',
                        })
                    } else {
                        wx.hideToast();
                        wx.hideLoading();
                    }
                },
                fail: () => {
                    if (shareType !== 'friends') {
                        wx.showToast({
                            title: '下载成功',
                            duration: 2000,
                            icon: 'none',
                        })
                    } else {
                        wx.hideToast();
                        wx.hideLoading();
                    }
                }
            });
            if (shareType === 'friends') {
                downloadCompleteForShareFriends();
                wx.hideToast();
                wx.hideLoading();
            }
            if (shareType === 'download') {
                shareComplete('download');
            }
            return;
        }
        if (readyToSave) {
            const curFile = saveTaskFiles[curTaskIndex];
            curFile.saving = true;
            const { index, fileType, tempFilePath = '' } = curFile;
            if (fileType === 'image') {
                wx.saveImageToPhotosAlbum({
                    filePath: tempFilePath,
                    success: res => {
                        console.log('保存到相册成功：', res);
                        log(
                            'saveImageToPhotosAlbum',
                            'saveImageToPhotosAlbum success',
                            res,
                            'info'
                        );
                        ++curTaskIndex;
                        curFile.saving = false;
                        curFile.saveState = 1;
                        updateDownloadLoading(index + 1, saveTaskFiles.length, downloadingCB);
                        clearStorage(tempFilePath);
                    },
                    fail: err => {
                        console.error('saveImageToPhotosAlbum: ', err);
                        log(
                            'saveImageToPhotosAlbum',
                            'saveImageToPhotosAlbum fail',
                            err,
                            'error'
                        );
                        ++curTaskIndex;
                        curFile.saving = false;
                        curFile.saveState = 2;
                        updateDownloadLoading(index + 1, saveTaskFiles.length, downloadingCB);
                        clearStorage(tempFilePath);
                    }
                });
            } else {
                wx.saveVideoToPhotosAlbum({
                    filePath: tempFilePath,
                    success: res => {
                        console.log('保存到相册成功：', res);
                        log(
                            'saveVideoToPhotosAlbum',
                            'saveVideoToPhotosAlbum 成功',
                            res,
                            'info'
                        );
                        ++curTaskIndex;
                        curFile.saving = false;
                        curFile.saveState = 1;
                        updateDownloadLoading(index + 1, saveTaskFiles.length, downloadingCB);
                    },
                    fail: err => {
                        console.error('saveVideoToPhotosAlbum: ', err);
                        log(
                            'saveVideoToPhotosAlbum',
                            'saveVideoToPhotosAlbum 失败',
                            err,
                            'error'
                        );
                        ++curTaskIndex;
                        curFile.saving = false;
                        curFile.saveState = 2;
                        updateDownloadLoading(index + 1, saveTaskFiles.length, downloadingCB);
                    }
                });
            }
        }
    }, 100);
}

const downloadFile = curFile => {
    if (curFile.fileType === "video") {
        const { fileSource } = curFile;
        wx.downloadFile({
            url: fileSource,
            success: res => {
                curFile.downloadState = 1;
                curFile.tempFilePath = res.tempFilePath;
            },
            fail: res => {
                curFile.downloadState = 2;
            }
        });
    } else {
        const fileName = Date.now() + "_" + parseInt(Math.random() * 100000);
        const downloadImg = (downloadTimes = 0) => {
            const { fileSource } = curFile;

            wx.downloadFile({
                url: fileSource,
                filePath: wx.env.USER_DATA_PATH + "/" + fileName + ".jpg",
                success: res => {
                    curFile.downloadState = 1;
                    curFile.tempFilePath = res.filePath;
                    console.log("curFile.tempFilePath: ", curFile.tempFilePath);
                    log(
                        "downloadFile",
                        `${fileSource}: 下载成功在第 ${downloadTimes +
                            1} 次`,
                        "",
                        "info"
                    );
                },
                fail: res => {
                    log(
                        "downloadFile",
                        `${fileSource}: 下载失败 ${downloadTimes +
                            1} 次`,
                        res,
                        "error"
                    );
                    if (downloadTimes > 4) {
                        console.warn(
                            `尝试下载 ${downloadTimes + 1} 次失败，跳过此图`
                        );
                        curFile.downloadState = 2;
                    } else if (downloadTimes === 2) {
                        curFile.fileSource = `${fileSource}?imageMogr2/auto-orient/thumbnail/!1024x1024r/quality/100/format/jpg`;
                        downloadImg(downloadTimes + 1);
                    } else if (downloadTimes === 1) {
                        // 尝试不使用临时路径下载
                        wx.downloadFile({
                            url: fileSource,
                            success: res => {
                                curFile.downloadState = 1;
                                curFile.tempFilePath = res.tempFilePath;
                                log(
                                    "downloadFile",
                                    `${fileSource}: 不使用临时文件下载成功`,
                                    "",
                                    "info"
                                );
                            },
                            fail: res => {
                                downloadImg(downloadTimes + 1);
                                log(
                                    "downloadFile",
                                    `${fileSource}: 不使用临时文件下载失败`,
                                    "",
                                    "info"
                                );
                            }
                        });
                    } else {
                        downloadImg(downloadTimes + 1);
                    }
                }
            });
        };
        downloadImg();
    }
}

const getCompatibleOptions = (themetype, video, images) => {
    let files = [];
    if (themetype !== 1) {
        for (let i = 0; i < images.length; i++) {
            files.push({
                index: i,
                fileSource: images[i],
                fileType: 'image',
            })
        }
    }

    if (themetype === 1 || themetype === 4) {
        files.push({
            index: files.length,
            fileSource: video instanceof Array ? video[0] : video,
            fileType: 'video',
        })
    }
    return files;
}

const clearDownloadingTimer = () => {
    const createTimeout = () => {
        downloadingTimer = setTimeout(() => {
            getApp().globalData.downloading = false;
            clearTimeout(downloadingTimer);
            downloadingTimer = null;
        }, 10000);
    };
    if (!!downloadingTimer) {
        clearTimeout(downloadingTimer);
        createTimeout();
    } else {
        createTimeout();
    }
};

const clearStorage = (path) => {
    if (!path) return;

    const fs = wx.getFileSystemManager();
    try {
        const stat = fs.statSync(path);
        const isDir = stat.isDirectory();
        if (isDir) {
            const paths = fs.readdirSync(path);
            for (let i = 0; i < paths.length; i++) {
                clearStorage(path + '/' + paths[i]);
            }
        } else {
            try {
                if (path.indexOf('miniprogramLog') === -1) {
                    console.log(
                        "点我查看图片大小： ",
                        path,
                        stat
                    );
                    fs.removeSavedFile(path);
                    fs.unlinkSync(path);
                } else {
                    console.warn("点我查看日志文件大小：", path, stat);
                    fs.removeSavedFile(path);
                    fs.unlinkSync(path);
                }
            } catch(e) {
                console.log('remove file: ', e);
            }

        }
    } catch(e) {
        console.log('clearStorage: ', e);
    }
};

export const saveFilesToAlbum = opts => {

    // 通过全局变量判断是否下载中
    if (getApp().globalData.downloading) {
        return;
    }
    getApp().globalData.downloading = true;

    // 异常情况下定时器清除downloading
    clearDownloadingTimer();

    let {
        title,
        files,
        themetype,
        video,
        images,
        shareType,
        downloadCompleteForShareFriends,
        shareComplete,
        downloadStartCB,
        downloadingCB
    } = opts;
    // 兼容格式
    if (opts.themetype !== undefined) {
        files = getCompatibleOptions(opts.themetype, video, images);
    } else if (opts.themeType !== undefined) {
        files = getCompatibleOptions(opts.themeType, video, images);
    }
    saveTaskFiles = files;
    downloadingCB('', '下载进度:' + 0 + '/' + files.length);
    const start = () => {
        const systemInfo = wx.getSystemInfoSync();
        // 安卓倒序保存
        if (systemInfo.system.indexOf('Android') > -1) {
            saveTaskFiles = saveTaskFiles.reverse().map((item, index) => {
                return {
                    ...item,
                    index
                };
            });
        }

        const handleDownload = () => {
            curTaskIndex = 0;
            createSaveFilesTask(
                title,
                shareType,
                downloadCompleteForShareFriends,
                shareComplete,
                downloadStartCB,
                downloadingCB
            );
            if (files.length > 0) {
                typeof downloadStartCB === 'function' && downloadStartCB();
            }

            typeof downloadingCB === 'function' &&
                downloadingCB(
                    '',
                    '下载进度:' + curTaskIndex + '/' + files.length
                );
            for (let i = 0; i < saveTaskFiles.length; i++) {
                const curFile = saveTaskFiles[i];
                downloadFile(curFile);
            }
        };

        wx.getSetting({
            success: res => {
                const scope = 'scope.writePhotosAlbum';

                if (typeof res.authSetting[scope] === 'undefined') {
                    // 未授权
                    commonGrid.authorize(scope, handleDownload);
                } else if (!res.authSetting[scope]) {
                    // 拒绝授权
                    commonGrid.openSetting(scope, handleDownload);
                } else {
                    // 已授权
                    handleDownload();
                }
            }
        });
    }

    const storagePath = wx.env.USER_DATA_PATH;
    clearStorage(storagePath);
    start();
}
