

const shareContentOfType = (type) => {
    let share_content = '';
    switch (type) {
        case 0:
            share_content = '图片';
            break;
        case 1:
            share_content = '视频';
            break;
        case 2:
            share_content = '文字';
            break;
        case 3:
            share_content = '链接';
            break;
        default:
            break;
    }
    return share_content;
}

function profileBury(buryEvent, config) {
}

module.exports = {
    shareContentOfType,
    profileBury,
};
