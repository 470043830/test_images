import { dedupArr } from './util';

export const getSku = (data = [], defaultSku, totalStock = '') => {
    const len = data.length;
    const hasData = len > 0;
    let sku = [{
        id: 'default',
        name: '默认',
        quantity: (totalStock === '' || totalStock > 0) ? 1 : 0,
        price: '',
        stock: totalStock,
        formatNum: '',
        ...defaultSku,
    }];

    if (!hasData) return sku;

    const quantity = len == 1 ? 1 : 0;
    sku = data.map(item => {
        const { formatId: id, formatName: name } = item;

        return {
            id,
            name,
            cname: name,
            quantity,
            price: '',
            stock: '',
            formatNum: '',
        };
    });

    return sku;
}

export const getSkus = ({skus = [], formats = [], colors = [], sku, totalStock = ''}) => {
    const len = skus.length;
    const hasSkus = len > 0;

    if (hasSkus) {
        skus = [...skus].map(sku => {
            let { id, cname = '', quantity = 0, stock } = sku;
            if (!cname) {
                const [ { formatName = '' } = {} ] = formats.filter(item => id.toString().indexOf(item.formatId) != -1);
                cname = formatName;
            }
            if (!quantity) {
                quantity = len == 1 && (typeof stock === 'undefined' || stock > 0) ? 1 : 0;
            }

            return {...sku, cname, quantity};
        });

        return sortSize(skus, 'cname');
    }

    const fLen = formats.length;
    const cLen = colors.length;
    const hasFormats = fLen > 0;
    const hasColors = cLen > 0;

    if (hasFormats && hasColors) {
        const quantity = fLen == 1 && cLen == 1 ? 1 : 0;
        skus = colors.map(item => {
            const { formatId: id, formatName: name } = item;
            const data = formats.map(item => {
                const { formatId, formatName } = item;

                return {
                    id: `${id};${formatId}`,
                    name: `${name} ${formatName}`,
                    cname: formatName,
                    quantity,
                    price: '',
                    stock: '',
                    formatNum: '',
                };
            });

            return data;
        }).reduce((arr, curr) => [...arr, ...curr], []);

        return skus;
    }

    if (hasFormats) return getSku(formats);

    if (hasColors) return getSku(colors);

    return getSku(undefined, sku, totalStock);
}

export const getColors = (colors = [], skus = []) => {
    if (colors.length <= 0) return colors;
    if (skus.length <= 0) return colors;

    skus = skus.map(sku => `${sku.id}`.split(';')[0]);
    skus = dedupArr(skus);
    colors = colors.filter(color => skus.some(sku => color.formatId == sku));

    return colors;
}

// 尺码排序
// let params = ["XXXXL", "S", "L绿", 'L红', 1, 2, 3, 4, 5, 6, 7, '大小']
const size = ['XXS', 'XS', 'S', 'M', 'L', 'XL', 'XXL', 'XXXL', 'XXXXL', 'XXXXXL'];

export function sortSize(params, nameId) {
    let arrSize = [],
        arrNumber = [],
        arrString = [];
    let flg;
    let includesNum = /[0-9]/;
    params.map(val => {
        if (typeof val[nameId] === 'string') {
            flg = true;
            size.map((val1, index) => {
                const name = val[nameId].toUpperCase();
                if (name.startsWith(val1)) {
                    flg = false;
                    if (!arrSize[index]) {
                        arrSize[index] = [];
                    }
                    arrSize[index].push(val);
                }
            });
            if (!flg) return;
            if (includesNum.test(val[nameId])) {
                arrNumber.push(val);
            } else {
                arrString.push(val);
            }
        } else if (typeof val[nameId] === 'number') {
            arrNumber.push(val);
        } else {
            arrString.push(val);
        }
    });

    arrSize = sort(arrSize);
    arrNumber = arrNumber.sort((a, b) => {
        return a[nameId] - b[nameId];
    });
    // arrString=arrString.sort((a,b)=>{
    //   return a.id-b.id
    // })
    // 导出顺序为尺码，数字，其他字符

    return [...arrSize, ...arrNumber, ...arrString];
}

function sort(params) {
    let arr = [];

    params.map(val => {
        val.map(val2 => {
            arr.push(val2);
        });
    });
    return arr;
}
