const util = require('./util.js');
const constant = require('./constant.js');
const clog = require('./circle-log.js');

var configLock = false;
var tempData = {
  shareChosedGid: 0,
};

/**
 * @description 获取网络数据
 * @param {*} { url, param = {} }
 * @param {*} onFinished
 */
const fetchNetData = async function ({ url, method = 'GET', param = {}, extInfo = {} }, onFinished) {
  const res = await util.fetch(url, param, method).catch(error => {
    clog.log('fetchNetData: ', error);
  });
  if (!res) {
    return { isOk: false };
  }
  const { data = {} } = res;
  const { errcode, errmsg, result, ...other } = data;

  if (errcode == 0) {
    onFinished && onFinished(true, result, extInfo);
    return { isOk: true, result, other };
  }
  //-1 获取用户信息失败! clear the user
  if (errcode == -1) {
    getApp().storageUserInfo("");
    getApp().globalData.userInfo = null;
  }

  // wx.showToast({ title: errmsg });
  onFinished && onFinished(false, { title: errmsg }, extInfo);
  return { isOk: false, errcode, errmsg, result };
};


const isMiniChecked = () => {
  // const { circleInfo = {} } = getApp().globalData;
  // const { config = {} } = circleInfo;
  const { appVersion = '100' } = getApp().getCircleConfig();
  let isMiniChecked = parseInt(constant.VERSION) <= parseInt(appVersion);

  clog.log('isMiniChecked: ', constant.VERSION, appVersion, isMiniChecked);
  return isMiniChecked
};

/**
 * jump to other miniapp
 */
const jumpToWsxcApp = (shop_id) => {
  if (!shop_id) shop_id = getApp().getMyShopId();
  const { appId, pagePath } = getApp().getCircleConfig();
  const path = pagePath + '?shop_id=' + shop_id;

  console.log('onJumpAppTap...', appId, path);
  wx.navigateToMiniProgram({
    appId: appId,
    path,
    extraData: {},
    // envVersion: 'trial',
    success(res) {
      // 打开成功
    }
  });
};



const getCircleConfigData = async function () {
  const markets = [];

  const config = {
    building: "",
    circleDesc: "南山区",
    circleId: "CID000008",
    circleName: "杭州主播线上选品平台",
    goodsCategory: "",
    id: 8,
    leimu: "[]",
    leixing: "[]",
    otherInfo: {},
    "texts": { "str001": "入驻", "str002": "商圈", "str003": "入驻申请", "str004": "已入驻该商圈", "str005": "申请成功" },
    tags: [
      { name: '男装' }, { name: '女装' }
    ],
    version: 232,
  }
  // return { config, markets };
  return new Promise(function (resolve, reject) {
    getApp().globalData.circleInfo = {
      config, markets, floors: [], buildings: []
    };
    resolve(getApp().globalData.circleInfo);
    // resolve({ config, markets });
  });
}
const getCircleConfigData222 = async function () {
  console.log("getCircleConfigData, configLock: ", configLock);

  while (configLock) {
    await sleepTime(500);
  }
  if (getApp().globalData.circleInfo.config) {
    return getApp().globalData.circleInfo;
  }

  configLock = true;
  const url = '/circle/circle_new_interface.jsp?act=getCircleConfigInfo';
  // const { isOk, result = {} } = await fetchNetData({ url, param: { circle_id: constant.circle_id } });
  const { isOk, result = {} } = await fetchNetData({ url });
  configLock = false;

  if (isOk) {
    console.log('getCircleConfigData result: ', result);
    const { config, markets, floors } = result;
    let circleName = config.circleName;
    let goodsCategory = JSON.parse(config.goodsCategory); //result.goodsCategory.split(',');
    let LeiMu = JSON.parse(config.leimu); //result.leimu.split(',');
    let LouDong = []; //SON.parse(config.building); //result.building.split(',');
    let LeiXing = JSON.parse(config.leixing); //result.leixing.split(',');
    let tags = JSON.parse(config.tags);
    let otherInfo = JSON.parse(config.otherInfo);
    let version = config.version;
    let stickNavList = [];

    let { banner, banner2, publish, texts } = otherInfo;

    //set to app
    for (let index = 0; index < goodsCategory.length; index++) {
      stickNavList.push({ title: goodsCategory[index] });
    }

    let obj = { circleName, LeiMu, tags, LeiXing, LouDong, banner, banner2, publish, texts, version, stickNavList };
    let buildings =
      markets.map((item, index) => ({ market_id: item.market_id, label: item.name, value: '' + index, floors: item.extInfo ? JSON.parse(item.extInfo).floors : [] }));
    // console.log('getCircleConfigData buildings: ', buildings);
    getApp().globalData.circleInfo = {
      config: obj, markets, floors, buildings
    };
    return getApp().globalData.circleInfo;
  }


  return {};
};



const saveFollowedShopIds = shopIds => {
  wx.setStorageSync(constant.FOLLOWED_SHOP_IDS_STORAGE, shopIds);
};

const getFollowedShopIds = () => {
  return wx.getStorageSync(constant.FOLLOWED_SHOP_IDS_STORAGE);
};


const onShopItemTap = (albumId, toAlbum) => {
  if (getApp().offline()) {
    showLoginModal();
    return;
  }
  let isCircle = '';
  !toAlbum && (isCircle = 'true');
  wx.navigateTo({
    url: `/pages/follow_detail_ks/index?isCircle=${isCircle}&shop_id=${albumId}`
  });

  // wx.showActionSheet({
  //     itemList: ['产品图册', 'Ta的发布'],
  //     success(res) {
  //         console.log(res.tapIndex);
  //         if (res.tapIndex == 0) {
  //             wx.navigateTo({
  //                 url: `/pages/follow_detail/index?shop_id=${albumId}`
  //             });
  //         } else if (res.tapIndex == 1) {
  //             wx.navigateTo({
  //                 url: `/pages/follow_detail/index?isCircle=true&shop_id=${albumId}`
  //             });
  //         }
  //     },
  //     fail(res) {
  //         console.log(res.errMsg);
  //     }
  // });
};


const handleFoldText = (title, filterText, numbers) => {
  let resultStrs = [];
  let pointer = 0;
  let normalColor = '#777';

  // console.log('handleFoldText numbers:', numbers);
  for (let index = 0; index < title.length; index++) {
    //console.log(index + ': ' + title[index]);
    if (!numbers && !filterText) break;
    if (numbers) {
      for (let j = 0; j < numbers.length; j++) {
        const number = numbers[j];
        if (title.startsWith(number, index)) {
          let normal = title.substring(pointer, index);
          resultStrs.push({ text: normal, color: normalColor });
          resultStrs.push({ text: number, color: '#586CB9', tap: 'onNumberTap' });
          index += number.length;
          pointer = index;
          break;
        }
      }
    }
    if (filterText) {
      if (title.startsWith(filterText, index)) {
        let normal = title.substring(pointer, index);
        resultStrs.push({ text: normal, color: normalColor });
        resultStrs.push({ text: filterText, color: '#3cc51f' });
        index += filterText.length;
        pointer = index;
      }
    }
  }

  if (pointer < title.length) {
    let normal = title.substr(pointer);
    resultStrs.push({ text: normal, color: normalColor });
  }
  return resultStrs;
};

const querySingleSelector = (selector) => {
  const query = wx.createSelectorQuery();

  return new Promise((resolve, reject) => {
    query.select(selector).boundingClientRect();
    query.exec((res) => {
      // console.log('querySingleSelector, res: ', res);
      if (res && res.length > 0) {
        resolve(res[0]);
      } else {
        reject(null);
      }
    });
  });
};

let uptokenCache = null;
let uptokenCacheTimer = null;
const getQiniuToken = async function () {
  const url = "/get_qiuniu_token.jsp";

  if (!uptokenCache) {
    const { isOk, other = {} } = await fetchNetData({ url });
    // console.log("getQiniuToken: ", isOk, other);
    uptokenCache = other.uptoken;
    if (uptokenCacheTimer) {
      clearTimeout(uptokenCacheTimer);
      uptokenCacheTimer = null;
    }
    uptokenCacheTimer = setTimeout(() => {
      uptokenCache = null;
    }, 180 * 1000);
  }
  return uptokenCache;
};

const uploadFile = async (filePath) => {
  const uptoken = await getQiniuToken();
  const a = parseInt(Math.random() * 10);
  const b = parseInt(Math.random() * 10);
  const c = parseInt(Math.random() * 10);
  const d = parseInt(Math.random() * 10);
  const ext = filePath.substring(filePath.lastIndexOf('.'));
  const randomName = `circle_${Date.now()}_${a}${b}${c}${d}${ext}`;

  return new Promise((resolve, reject) => {
    wx.uploadFile({
      url: 'https://upload.qiniup.com/',
      filePath,
      name: 'file',
      formData: {
        'token': uptoken,
        'key': randomName,
        'name': randomName,
      },
      success: resolve,
      fail: reject
    });
  });
};

function formatDate(date, splitChar) {
  var d = new Date(date),
    month = '' + (d.getMonth() + 1),
    day = '' + d.getDate(),
    year = d.getFullYear();

  if (month.length < 2) month = '0' + month;
  if (day.length < 2) day = '0' + day;

  return [year, month, day].join(splitChar);
}

const gotoLoginPage = (extParam) => {
  // wx.redirectTo({
  //     url: `/pages/login/index`
  // });
  // return;
  let path = 'pages/login/index?circle_id=' + constant.circle_id;
  if (extParam) {
    path += `&extParam=${extParam}`;
  }
  if (getApp().globalData.userInfo && getApp().globalData.userInfo.tokenExpired) {
    path += `&tokenExpired=true`;
  }
  console.log('path: ', path);
  wx.navigateToMiniProgram({
    appId: 'wxb278781d654e8f81',
    path,
    extraData: {
      foo: 'bar'
    },
    // envVersion: 'trial',
    success(res) {
      // 打开成功
    }
  });
};

const showLoginConfirm = (errmsg) => {
  wx.showModal({
    title: '提示',
    content: errmsg,
    success(res) {
      if (res.confirm) {
        console.log('用户点击确定');
        wx.redirectTo({
          url: '/pages/login/index'
        });
      } else if (res.cancel) {
        console.log('用户点击取消');
        wx.switchTab({
          url: '/pages/home/index'
        });
      }
    }
  });
};

const showLoginModal = function () {
  wx.redirectTo({
    url: '/pages/login/index'
  });
  // disable this for apply
  // wx.showModal({
  //     title: '提示',
  //     content: '请先登录',
  //     success(res) {
  //         if (res.confirm) {
  //             console.log('用户点击确定');
  //             wx.redirectTo({
  //                 url: '/pages/login/index'
  //             });
  //         } else if (res.cancel) {
  //             console.log('用户点击取消');
  //             wx.switchTab({
  //                 url: '/pages/home/index'
  //             });
  //         }
  //     }
  // });
};



function getGoodsTitleById(gid, array) {
  for (let index = 0; index < array.length; index++) {
    const ele = array[index];
    if (ele.goods_id == gid) {
      return ele.title;
    }
  }
  return '';
}

const getMarketById = (markets, market_id) => {
  for (let index = 0; index < markets.length; index++) {
    const element = markets[index];
    if (element.market_id == market_id) {
      return element;
    }
  }
  return {};
};

const getBuildingById = (buildings, market_id) => {
  for (let index = 0; index < buildings.length; index++) {
    const element = buildings[index];
    if (element.market_id == market_id) {
      return element;
    }
  }
  return {};
};


const sleepTime = time => {
  return new Promise((resolve) => setTimeout(resolve, time));
};


module.exports = {
  onShopItemTap,
  fetchNetData,
  showLoginModal,
  showLoginConfirm,
  saveFollowedShopIds,
  getFollowedShopIds,
  handleFoldText,
  querySingleSelector,
  getCircleConfigData,
  getMarketById,
  getBuildingById,
  isMiniChecked,
  getQiniuToken,
  uploadFile,
  formatDate,
  gotoLoginPage,
  getGoodsTitleById,
  jumpToWsxcApp,
  tempData
};
