import {
    $tdActionsheet,
    $wuxToast
} from '../components/wux';
const util = require('./util');
import { saveFilesToAlbum } from './download';
const app = getApp();
const bury = require('../utils/burypoint.js');
import commonGrid from './common-grid';
const constant = require('./constant');
const preventFold = require('./prevent_fold');

function canDownload(data) {
    const {
        themetype,
        images
    } = data;
    const isLinkTheme = themetype === 3;
    const hasImg = images.length > 0;

    return !isLinkTheme && hasImg;
}

// 获取价格规则
// 判断是否存在sku，
// 1:如果存在sku,则获取sku 字段 price 数据(sku price 价格可能是一个区间，最大值和最小值)，如果 配置了 加价规则 即 increasePriceConfig 对象中的 itemPriceConfig为1，则应该加上 increasePriceConfig对象中的itemPriceAdd字段
// 2:如果不存在sku，则获取priceArr 数组里面 permission 为0 且 value 最小的数据显示，如果 配置了 加价规则 即 increasePriceConfig 对象中的 itemPriceConfig为1，则应该加上 increasePriceConfig对象中的itemPriceAdd字段
function calcPrice(data) {

    let increasePrice = 0;

    if (!data) {
        return increasePrice;
    }
    // 判断是否配置加价规则
    if (data.increasePriceConfig && data.increasePriceConfig.itemPriceConfig == 1) {
        increasePrice = data.increasePriceConfig.itemPriceAdd;
    }

    // 判断是否存在sku
    // 存在
    let price = getShareImagePrice(data.skus, data.priceArr);
    if (price != 0) {
        return price;
    } else {
        return '';
    }
    // if (data.skus&&data.skus.length) {
    //   let arrSkuPirce = [];
    //   data.skus.forEach(item => {
    //     arrSkuPirce.push(item.price);
    //   });
    //   // console.log(arrSkuPirce);
    //   let minPrice = Math.min(...arrSkuPirce);
    //   let maxPirce = Math.max(...arrSkuPirce);
    //   if (minPrice == maxPirce) {
    //     return Number(increasePrice) + Number(minPrice);
    //   } else {
    //     return (Number(increasePrice) + Number(minPrice)) + "-" + (Number(increasePrice) + Number(maxPirce))
    //   }
    // } else { // 不存在
    //   let arrPrice = [];
    //   if (data.priceArr) {
    //     data.priceArr && data.priceArr.forEach(item => {
    //       arrPrice.push(item.value);
    //     })
    //     let minPrice = 0;
    //     if (arrPrice.length) {
    //       minPrice = Math.min(...arrPrice)
    //     }
    //     return Number(minPrice) + Number(increasePrice);
    //   } else {
    //     return "";
    //   }

    // }
}

/**
 * @description 数字升序
 * @param {*} a
 * @param {*} b
 * @returns
 */
function orderAsc(a, b) {
    return a - b;
}
/**
 * @description 获取skus价格区间
 * @param {*} [skus=[]]
 * @returns
 */
function getSkusPriceRange(skus = []) {
    var priceRange = '';
    if (skus.length > 0) {
        var prices = skus
            .reduce(function (result, curr) {
                var price = curr.price;
                if (!!price) {
                    result.push(price);
                }

                return result;
            }, [])
            .sort(orderAsc);
        var len = prices.length;
        var firstPrice = prices[0];
        var lastPrice = prices[len - 1];

        priceRange = firstPrice == lastPrice ? firstPrice : firstPrice + '~' + lastPrice;
    }

    return priceRange;
}

/**
 * @description 获取备注价格中非私密最小价格
 * @param {array} priceArr
 * @returns
 */
function getPublicMinPrice(priceArr = []) {
    var prices = priceArr
        .reduce(function (result, curr) {
            var permission = curr.permission;
            var value = curr.value;
            if (permission != 1 && !!value) {
                result.push(value);
            }

            return result;
        }, []);
    var minPrice = prices.sort(orderAsc)[0] || 0;

    return minPrice;
}

/**
* @description 获取商品添加购物车时展示价格
* @param {*} [skus=[]]
* @param {*} [priceArr=[]]
* @returns
*/
function getCartPrice(skus = [], priceArr = []) {
    var price = getSkusPriceRange(skus);

    if (!price) {
        price = getPublicMinPrice(priceArr);
    }

    return price;
}

/**
 * @description 获取公开价最小价格
 * @param {array} priceArr
 * @returns
 */
function getPublicMinPrice_1(priceArr = []) {
    var prices = priceArr
        .reduce(function (result, curr) {
            var permission = curr.permission;
            var value = curr.value;
            if (permission == 0 && !!value) {
                result.push(value);
            }

            return result;
        }, []);
    var minPrice = prices.sort(orderAsc)[0] || 0;

    return minPrice;
}

/**
* @description 获取海报分享展示价格
* @param {*} [skus=[]]
* @param {*} [priceArr=[]]
* @returns
*/
function getShareImagePrice(skus = [], priceArr = []) {
    var price = getSkusPriceRange(skus);

    if (!price) {
        price = getPublicMinPrice_1(priceArr);
    }

    return price;
}


let downloadCompleteForShareFriends = () => { };


function showshare(data, downloadStartCB, downloadingCB, onAddToAlbum, _this) {
    const bury_config = app.globalData.bury_config;
    console.log('app.globalData.pageInfo: ', app.globalData.pageInfo);
    const {
        $title,
        $screen_name
    } = app.globalData.pageInfo;
    // 全部分享参数,如需查看具体逻辑，请前往 components/share/share.js 查看对应逻辑处理，
    const setTopKeys = "settop";
    const cancelTopKeys = "canceltop";
    let shareList = ['wechart', 'friends', 'more', 'download', 'join', 'advs', 'editor', 'refresh', setTopKeys, cancelTopKeys, 'delete'];
    // 已置顶情况取消置顶
    console.log(data);
    if (data.item && data.item.isTop == 1) {
        let settopIndex = shareList.indexOf(setTopKeys);
        shareList.splice(settopIndex, 1);
    } else {
        let canceltopIndex = shareList.indexOf(cancelTopKeys);
        shareList.splice(canceltopIndex, 1);
    }

    let currentPage = util.getPagesPath().pop();

    // 添加图文页面，不显示 editor refresh settop canceltop delete
    let editorRouter = "pages/goods_edit/index";
    const browserPage = 'pages/browser/index';
    // 编辑图文页面不显示 editor
    if (currentPage.indexOf(editorRouter) > -1) {

        // 不是自己的产品都是添加情况
        if (!data.is_my_album) {
            shareList = shareList.filter(item => {
                if (item == "editor" ||
                    item == "refresh" ||
                    item == "settop" ||
                    item == "canceltop" ||
                    item == "delete") {
                    return false;
                } else {
                    return true;
                }
            });
        } else {
            // 不存在商品ID 添加
            if (!_this.goods_id) {
                shareList = shareList.filter(item => {
                    if (item == "editor" ||
                        item == "refresh" ||
                        item == "settop" ||
                        item == "canceltop" ||
                        item == "delete") {
                        return false;
                    } else {
                        return true;
                    }
                });
            } else {
                // console.log("编辑");
                shareList = shareList.filter(item => {
                    if (item == "editor") {
                        return false;
                    } else {
                        return true;
                    }
                });
            }
        }
    }
    if (currentPage.indexOf(browserPage) > -1) {
        shareList = shareList.filter(item => (
            item !== 'refresh' &&
            item !== 'settop' &&
            item !== 'canceltop' &&
            item !== 'delete'
        ));
    }

    // 相册详情页面不是自己的商品不需要显示编辑。刷新，置顶操作
    let homeRouter = "pages/goods_detail/index";
    if (currentPage.indexOf(homeRouter) > -1) {
        if (data.item && !data.item.is_my_album) {
            shareList = shareList.filter(item => {
                if (item == "editor" ||
                    item == "refresh" ||
                    item == "settop" ||
                    item == "canceltop" || item == "delete") {
                    return false;
                } else {
                    return true;
                }
            });
        }
    }

    //处理面板显示菜单
    // if (!data.item.is_my_album){
    //     shareList = ['wechart', 'friends', 'more', 'download', 'join', 'advs'];
    // }
    let template = null;
    _this && (template = _this.selectComponent('#template'));
    if (template) {
        _this.shareComponent = template.selectComponent("#share");
    } else {
        _this.shareComponent = _this.selectComponent("#share");
    }
    // TODO这里传递数据到canvas
    let {
        follow_num,
        new_goods,
        user_icon,
        shop_name
    } = wx.getStorageSync('share_shop_data');
    _this.shareComponent.setData({
        list: shareList,
        shareData: {
            shop: {
                follow_num,
                new_goods,
                user_icon,
                shop_name,
            },
            goods_list: [data.item]
        }
    });
    _this.shareComponent.show();
    _this.shareComponent.onShare = function (ev, cb, ctx) {
        const {
            title
        } = data;
        let type = ev.key;
        // console.log(data)

        switch (type) {

            case 'download':
                data.shareType = "download";
                //下载图片
                data.title = data.title || (data.item ? data.item.title : '');
                // console.log('------------title-----------'+data.title)

                downloadImgs(data, downloadStartCB, downloadingCB);

                let themetype = themetype || (data.item ? data.item.themeType : '');
                const obj = {
                    route: this.route,
                    $title,
                    share_method: '保存手机',
                    $screen_name,
                    share_content: bury.shareContentOfType(themetype),
                };
                bury.share(bury_config, obj);

                // copyTitle(data.title, () => {
                //   downloadImgs(data, downloadStartCB, downloadingCB);
                //   const {
                //     themetype
                //   } = data;
                //   const obj = {
                //     route: this.route,
                //     $title,
                //     share_method: '保存手机',
                //     $screen_name,
                //     share_content: bury.shareContentOfType(themetype),
                //   }
                //   bury.share(bury_config, obj);
                // });

                break;
            case 'wechart':
                //TODO:封面合成,分享给好友
                // wechart 直接通过小程序按钮的 open-type 开放能力调用
                break;
            case 'friends':
                //分享给朋友圈
                //TODO:更新分享时间
                data.action = 'circle';
                cb && cb(data);
                data.shareType = "friends";
                downloadCompleteForShareFriends = () => {
                    setTimeout(() => {
                        _this.shareComponent.showFriendsDialog();
                    }, 600);
                };
                //下载图片
                // copyTitle(title, () => {
                //   // 判断是否有图片
                //   if (data.images && data.images.length > 0) {
                //     data.title = data.title || (data.item?data.item.title : '');
                //     console.log('------------title-----------'+data.title)
                //     downloadImgs(data, downloadStartCB, downloadingCB);
                //   } else {
                //     _this.shareComponent.showFriendsDialog()
                //   }
                //   const obj1 = {
                //     route: this.route,
                //     $title,
                //     share_method: '保存手机',
                //     $screen_name,
                //     share_content: bury.shareContentOfType(data.themetype),
                //   }
                //   bury.share(bury_config, obj1);
                // });
                // 判断是否有图片
                if (data.images && data.images.length > 0 || data.video && data.video.length) {
                    data.title = data.title || (data.item ? data.item.title : '');
                    // console.log('------------title-----------'+data.title)
                    downloadImgs(data, downloadStartCB, downloadingCB);
                } else {
                    wx.setClipboardData({
                        data: preventFold.randInsertCharacters(data.title || (data.item ? data.item.title : '')),
                        success: res => {
                            wx.hideToast();
                            wx.hideLoading();
                        },
                        fail: () => {
                            wx.hideToast();
                            wx.hideLoading();
                        }
                    });
                    _this.shareComponent.showFriendsDialog();
                }
                themetype = data.themetype || (data.item ? data.item.themeType : '');
                const obj1 = {
                    route: this.route,
                    $title,
                    share_method: '保存手机',
                    $screen_name,
                    share_content: bury.shareContentOfType(themetype),
                };
                bury.share(bury_config, obj1);
                break;
            case 'editor':
                //编辑
                util.openGoodsEdit({
                    goods_id: data.goods_id,
                    shop_id: data.shop_id
                });
                break;
            case 'refresh':
                commonGrid.onRefreshGoods(data).then(res => {
                    util.shareComplete("refresh");
                });
                break;
            case 'settop':
            case 'canceltop':
                data.item.listidx = data.listidx;
                commonGrid.onSetTopGoods(data.item, cb);
                break;
            case 'delete':
                commonGrid.onDelGoods(data, cb, ctx);
                break;
            case 'join':
                console.log("拼图分享data 数据", data);
                if (data.item.themeType == 1 || data.item.themeType == 4) {
                    data.hasVideo = true;
                }
                data.price = calcPrice(data.item);
                //处理images
                if (data.item && data.item.imgsSrc) {
                    data.images = data.item.imgsSrc;
                }
                // util.navigateTo("/pages/img_share/index", data);
                util.navigateToShareImg(data, 0);
                break;
            case 'advs':
                if (data.item.themeType == 1 || data.item.themeType == 4) {
                    data.hasVideo = true;
                }
                data.price = calcPrice(data.item);
                //处理images
                if (data.item && data.item.imgsSrc) {
                    data.images = data.item.imgsSrc;
                }
                // // 海报分享只传递第一张图
                // if (data.images && data.images.length) {
                //   data.images.splice(1);
                // }
                // util.navigateTo("/pages/img_share/index", data);
                util.navigateToShareImg(data, 1);
                break;

            // case 'timeline':
            //     let content = '小程序暂不支持此操作，请关注【微商相册】公众号，确认即复制微信号：mmicroboss'
            //     // if (util.isIOS()) {
            //     //     content = '此功能需在app中使用。下载app请前往苹果APP store 搜索「微商相册」。'
            //     // } else {
            //     //     content = '此功能需在app中使用。下载app请前往百度搜索「微商相册」。'
            //     // }
            //     const route = this.route;
            //     const buryData = {
            //         route,
            //         $title,
            //         share_method: '复制文字',
            //         $screen_name,
            //         share_content: "文字",
            //     }
            //     bury.share(bury_config, buryData);
            //     wx.showModal({
            //         title: '提示',
            //         content: content,
            //         confirmText: '确认',
            //         confirmColor: '#3cc51f',
            //         success: function (res) {
            //             if (res.confirm) {
            //                 console.log('用户点击确定')
            //                 wx.setClipboardData({
            //                     data: 'mmicroboss',
            //                     success: function (res) {
            //                         wx.getClipboardData({
            //                             success: function (res) {
            //                                 console.log(res.data) // data
            //                             }
            //                         })
            //                     }
            //                 })
            //                 // // 跳转至app下载教程页面
            //                 // wx.navigateTo({
            //                 //     url: '/pages/app/index'
            //                 // })
            //             } else if (res.cancel) {
            //                 console.log('用户点击取消')
            //             }
            //         }
            //     })
            //     break;
            // case 'add':
            //     typeof onAddToAlbum == 'function' && onAddToAlbum(data, function () {
            //         wx.showModal({
            //             title: '提示',
            //             content: '已成功添加至您的微商相册，请前往您的「微商相册APP 」中查看',
            //             // content: '请在微商相册app中添加',
            //             cancelText: '查看教程',
            //             confirmText: '好的',
            //             success: function (res) {
            //                 if (res.confirm) {
            //                     console.log('用户点击确定')
            //                 } else if (res.cancel) {
            //                     console.log('用户点击取消')

            //                     // 跳转至app下载教程页面
            //                     wx.navigateTo({
            //                         url: '/pages/app/index'
            //                     })
            //                 }
            //             }
            //         })
            //     });
            //     break;

        }
    };

    return;

}

var downloadedSize = 0;
var donwloadTimer = 0;
var downloadedImgs = [];

export function downloadImgs(data, downloadStartCB, downloadingCB) {

    console.log('data: ', data);
    saveFilesToAlbum({
        ...data,
        downloadCompleteForShareFriends,
        shareComplete: util.shareComplete,
        downloadStartCB,
        downloadingCB,
    });

    return;

    console.log(data.images);
    console.log('type------->' + data.themetype);
    //当商品为视频加图片类型时
    if (data.themetype == 4 && data.video) {
        data.images.push(data.video);
    }
    if (data.themetype == 1 && data.video) {
        data.images = [data.video];
    }
    // console.log(data.images)

    if (data.images.length > 0) {
        typeof downloadStartCB === `function` && downloadStartCB();
        //一张图片的下载进度条，虚拟的
        if (data.images.length == 1) {
            let percent = 0;
            if (downloadedSize == 0) {
                donwloadTimer = setInterval(() => {
                    percent++;
                    if (percent >= 99 || downloadedSize != 0) {
                        clearInterval(donwloadTimer);
                    } else {
                        typeof downloadingCB === `function` && downloadingCB(percent, '下载进度:' + percent + '%');
                    }
                }, 200);
            }
        }
        downloadedSize = 0;
        donwloadTimer = 0;
        downloadedImgs = [];
        downloadQuene(data, data.images, downloadingCB, 1, data.images.length);
    }
}

function downloadQuene(data, imageList, downloadingCB, maxThread, allSize) {
    let curDowloadSize = 0;
    imageList.map((item, index) => {
        console.log(item);
        if (index >= maxThread) {
            //超过同时并发，则不立即创建下载任务，等图片下载完后再回调下载
            return;
        }
        downloadSingle(data, item, downloadingCB, allSize, () => {
            //下载剩下的图片
            curDowloadSize++;
            if (curDowloadSize >= maxThread) {
                //上一次并发图片同时下载完
                curDowloadSize = 0;
                let resData = imageList.slice(maxThread);
                console.log(resData);
                if (resData && resData.length > 0) {
                    downloadQuene(data, resData, downloadingCB, maxThread, allSize);
                }
            }

        });

    });
}

function downloadSingle(data, item, downloadingCB, allSize, nextDown) {
    wx.downloadFile({
        url: item,
        success: function (res) {
            downloadedSize++;
            downloadedImgs.push(res.tempFilePath);
            let percent = downloadedSize * 100 / allSize | 0;
            if (data.shareType !== "friends") {
                typeof downloadingCB === `function` && downloadingCB(percent, '下载进度:' + downloadedSize + '/' + allSize);
                //  typeof downloadingCB === `function` && downloadingCB(percent, '下载进度:' + percent + '%')
            } else {
                typeof downloadingCB === `function` && downloadingCB(percent, "");
            }
            if (downloadedSize == allSize) {
                if (data.shareType !== "friends") {
                    if (app.globalData.title) {
                        wx.setClipboardData({
                            data: preventFold.randInsertCharacters(app.globalData.title),
                            success: function (res) {
                                wx.showToast({
                                    title: "下载成功，文字已复制",
                                    duration: 2000,
                                    icon: "none",
                                });
                                app.globalData.title = null;
                            },
                            fail: function () {
                                wx.showToast({
                                    title: "下载成功",
                                    duration: 2000,
                                    icon: "none",
                                });
                                app.globalData.title = null;
                            }
                        });
                    } else {
                        wx.showToast({
                            title: "下载成功",
                            duration: 2000,
                            icon: "none",
                        });
                        app.globalData.title = null;
                    }

                }
                if (data.shareType === "friends") {
                    downloadCompleteForShareFriends();
                }
                if (data.shareType === "download") {
                    util.shareComplete("download");
                }

                // 保存图片
                saveImgs(downloadedImgs, data);
            }
            console.log(res.tempFilePath);

            //调用下载剩余图片
            nextDown();
        },
        fail: res => {
            typeof downloadingCB === `function` && downloadingCB(100);
            wx.showToast({
                title: "下载失败",
                //title: res.errMsg,
            });
            if (donwloadTimer != 0) {
                clearInterval(donwloadTimer);
            }
            console.log(res);
            //调用下载剩余图片
            nextDown();
        }
    });
}

function saveImgs(imgs = [], data) {
    imgs.reverse();
    const len = imgs.length;
    if (len <= 0) return;

    const { themetype, images } = data;
    let count = 0;

    saveImg(imgs[count]);

    function callback(cb) {
        count++;
        if (count >= len) return;
        typeof cb === 'function' && cb(imgs[count]);
    }
    function saveImg(img) {
        if (
            themetype == 1 ||
            (themetype == 4 && images[images.length - 1] === img)
        ) {
            //视频
            wx.saveVideoToPhotosAlbum({
                filePath: img,
                success(res) {
                    callback(saveImg);
                },
                fail(err) {
                    callback(saveImg);
                }
            });
        } else {
            wx.saveImageToPhotosAlbum({
                filePath: img,
                success(res) {
                    callback(saveImg);
                },
                fail(err) {
                    callback(saveImg);
                }
            });
        }
    }
}

function copyTitle(title, fn) {
    if (title) {
        wx.setClipboardData({
            data: title,
            success: res => {
                if (fn && typeof fn === "function") {
                    setTimeout(() => {
                        fn(res);
                    }, 800);
                }
                // $wuxToast.show({
                //     type: 'text',
                //     text: '标题已复制到剪贴板'
                // });
            },
            fail: res => {
                // $wuxToast.show({
                //     type: 'text',
                //     text: '标题复制失败，请稍后重试~'
                // });
            }
        });
    } else {
        if (fn && typeof fn === "function") {
            fn();
        }
    }
}

function getDateTime(timestamp = Date.now()) {
    const t = new Date(timestamp);
    const year = t.getFullYear();
    const month = t.getMonth() + 1;
    const day = t.getDate();
    const date_time = `${year}${month < 10 ? `0${month}` : month}${day < 10 ? `0${day}` : day}`;

    return {
        date_time,
        year,
        month,
        day
    };
}

function getDateText(timestamp = Date.now()) {
    const {
        date_time,
        year,
        month,
        day
    } = getDateTime(Math.abs(timestamp));
    const today = getDateTime().date_time;
    const yesterday = getDateTime(Date.now() - 24 * 60 * 60 * 1000).date_time;
    let date_text = `${day < 10 ? `0${day}` : day} ${month}月`;

    if (date_time == today) {
        date_text = '今天';
    } else if (date_time == yesterday) {
        date_text = '昨天';
    }

    return {
        date_text,
        date_time,
        year,
        month,
        day
    };
}

function filterData(data, template) {
    //过滤数据
    let _data = data;
    if (template == 1 || template == 2 || template == 3) {
        _data = _data.filter(item => {
            const {
                imgs,
                title,
                tags = [],
                colors = [],
                formats = [],
                goodsNum,
                noteArr = [],
                subTitle,
                priceArr = [],
                totalStock,
                themeType
            } = item;
            if (themeType != 1 && themeType != 4 && (imgs.length == 0 || title == '' && imgs.length == 1 || themeType == 3)) {
                if (imgs.length == 1 && themeType != 3) {
                    if (!!goodsNum || !!tags.length || !!noteArr.length || !!subTitle || !!priceArr.length || !!colors.length || !!formats.length || !!totalStock) {
                        return true;
                    }
                }
                return false;
            } else {
                return true;
            }
        });
    }
    return _data;
}

function getGrouplist(list, template, _this, setTop) {
    const {
        filterText,
        col,
        listIndex
    } = _this.data;
    let currentCol = _this.col ? _this.col : col;
    let data = list;
    const topObj = {
        date: {
            date_text: '置顶'
        },
    };
    const tops = [];
    const others = [];
    // console.log('lin--111111111111--------->'+template)
    // if (template == 1 || template == 2 || template == 3) {
    //   //过滤纯文字、纯图片、链接
    //   data = data.filter(item => {
    //     const {
    //       imgs,
    //       title,
    //       themeType
    //     } = item;
    //     if (imgs.length == 0 || title == '' || themeType == 3) {
    //       return false;
    //     }else{
    //       return true;
    //     }
    //   });
    // }
    data = filterData(data, template);
    // console.log(data);
    switch (template) {
        case 1:

            // let cols = [];
            // if (data.length <= 0) return cols;
            // for (let i = 0; i < currentCol; i++) {
            //   cols[i] = data.filter((item, idx) => idx % currentCol == i);
            // }

            return data;

        case 5:
            //去除置顶项单独处理
            let normalArr = [],
                topArr = [];
            if (listIndex == 0 && setTop) {
                normalArr = data.filter(function (val) {
                    return val.isTop == 0;
                });
                topArr = data.filter(function (val) {
                    return val.isTop == 1;
                });
            } else {
                normalArr = data;
            }

            normalArr = normalArr.map(item => (Object.assign({}, item, {
                date: this.getDateText(item.time_stamp)
            }, {
                showRemark: false
            })));
            let dateTimes = normalArr.map(item => item.date.date_time);
            dateTimes = util.dedupArr(dateTimes);
            let arr = [];

            dateTimes.forEach((date_time, i) => {
                arr[i] = normalArr.filter(item => item.date.date_time == date_time);
            });

            //处理置顶
            if (topArr.length > 0) {
                topArr = topArr.map(item => (Object.assign({}, item, topObj, {
                    showRemark: false
                })));
                arr.unshift(topArr);
            }

            return arr;

        case 4:
            if (listIndex == 0 && setTop) {
                data.forEach(item => {
                    item.isTop === 1 ? tops.push(item) : others.push(item);
                });
                data = [...tops, ...others];
            }
            console.log('lin--------->');
            console.log(data);
            return data.map(item => ({
                rows: constant.ROWS,
                richTitle: !!filterText ? util.getRichTitle(item.title, filterText) : undefined,
                ...item
            }));

        default:
            if (listIndex == 0 && setTop) {
                data.forEach(item => {
                    item.isTop === 1 ? tops.push(item) : others.push(item);
                });
                data = [...tops, ...others];
            }
            return data;
    }
}

function dealDelGoods(_this, goods_id) {
    let {
        list = [], template
    } = _this.data;
    if (template == 5) {
        let delGoods = false;
        let w1 = 0,
            w2 = 0;
        for (let i = 0; i < list.length; i++) {
            for (let j = 0; j < list[i].length; j++) {
                if (list[i][j].goods_id == goods_id) {
                    w1 = i;
                    w2 = j;
                    delGoods = true;
                    break;
                }

            }
            if (delGoods) {
                break;
            }
        }
        //删除商品
        list[w1].splice(w2, 1);
    } else {
        list = list.filter(item => {
            return item.goods_id !== goods_id;
        });
    }

    return list;
}

function updateGoodsFromEdit(_this) {
    // console.log('updateGoodsFromEdit111111111')
    let {
        list = [],
        template,
        listIndex,
        shop: { shop_id } = {},
    } = _this.data;
    // try {
    // const goodsEditAction = wx.getStorageSync('goods_edit');
    const goodsEditData = wx.getStorageSync('goods_edit_submit_result');
    const delGoods = wx.getStorageSync('del_goods');
    // console.log(goodsEditData);
    wx.removeStorageSync('del_goods');
    wx.removeStorageSync('goods_edit_submit_result');
    let goodsEditSubmitResult = {};
    if (goodsEditData) {
        goodsEditSubmitResult = goodsEditData;
    } else if (delGoods) {
        return dealDelGoods(_this, delGoods);
    } else {
        return null;
    }
    // console.log('updateGoodsFromEdit333333:'+template)
    //根据各模板更新数据
    let isDel = false;
    console.log('goodsEditSubmitResult--->', goodsEditSubmitResult);
    //添加上家的不进行过滤
    if (!(shop_id == goodsEditSubmitResult.shop_id) && (template == 1 || template == 2 || template == 3)) {
        //过滤纯文字、纯图片、链接
        let {
            themeType,
            imgs,
            title,
            tags = [],
            colors = [],
            formats = [],
            goodsNum,
            noteArr = [],
            subTitle,
            priceArr = [],
            totalStock
        } = goodsEditSubmitResult;
        if (themeType != 1 && themeType != 4 && (imgs.length == 0 || title == '' && imgs.length == 1 || themeType == 3)) {
            if (imgs.length == 1 && themeType != 3) {
                if (!!goodsNum || !!tags.length || !!noteArr.length || !!subTitle || !!priceArr.length || !!colors.length || !!formats.length || !!totalStock) {
                    isDel = false;
                }
            }
            isDel = true;
        }
        // if (goodsEditSubmitResult.imgs && (goodsEditSubmitResult.imgs.length == 0 ||
        //     goodsEditSubmitResult.title == '' ||
        //     goodsEditSubmitResult.themeType == 3)) {
        //   isDel = true;
        // }
    }


    if (template == 5) {
        //listIndex为0时，才处理置顶
        //  console.log('updateGoodsFromEdit555555555555')
        const {
            isTop
        } = goodsEditSubmitResult;
        if (listIndex == 0) {
            if (isTop == 1) {
                //处理置顶
                goodsEditSubmitResult.date = {
                    date_text: '置顶'
                };
                goodsEditSubmitResult.showRemark = false;
                let isNewTop = true;
                if (list.length > 0) {
                    if (list[0].length > 0) {
                        if (list[0][0].date.date_text == '置顶') {
                            isNewTop = false;
                            //已经存在置顶
                            const index = list[0].findIndex(item => item.goods_id === goodsEditSubmitResult.goods_id);
                            if (index < 0) {
                                list[0].unshift(goodsEditSubmitResult);
                            } else {
                                list[0][index] = goodsEditSubmitResult;
                                if (list[0][index].is_my_album) {
                                    list[0][index] = goodsEditSubmitResult;
                                } else {
                                    list[0][index].share_time = goodsEditSubmitResult.share_time;
                                    list[0][index].from = goodsEditSubmitResult.from;
                                }
                            }
                        }
                    }
                }
                if (isNewTop) {
                    list.unshift([goodsEditSubmitResult]);
                }
                return list;
            } else {
                //非置顶情况处理
                let hasTopGroup = false;
                let date = getDateText(goodsEditSubmitResult.time_stamp);
                goodsEditSubmitResult.date = date;
                goodsEditSubmitResult.showRemark = false;

                if (list.length > 0) {
                    if (list[0].length > 0) {
                        if (list[0][0].date.date_text == '置顶') {
                            hasTopGroup = true;
                        }
                    }
                    let findGoods = false;
                    for (let i = 0; i < list.length; i++) {
                        for (let j = 0; j < list[i].length; j++) {
                            if (list[i][j].goods_id == goodsEditSubmitResult.goods_id) {
                                //编辑商品只更新数据，不更新位置
                                if (list[i][j].is_my_album) {
                                    list[i][j] = goodsEditSubmitResult;
                                } else {
                                    list[i][j].share_time = goodsEditSubmitResult.share_time;
                                    list[i][j].from = goodsEditSubmitResult.from;
                                }
                                findGoods = true;
                                break;
                            }
                        }
                        if (findGoods) {
                            break;
                        }
                    }
                    if (!findGoods) {
                        //新增商品在今天显示
                        let findGroup = false;
                        for (let i = 0; i < list.length; i++) {

                            if (list[i][0].date.date_text == goodsEditSubmitResult.date.date_text) {
                                findGroup = true;
                                list[i].unshift(goodsEditSubmitResult);
                            }
                            if (findGroup) {
                                break;
                            }
                        }
                        // if (!hasTopGroup) {
                        //   list.unshift([goodsEditSubmitResult]);
                        // } else {
                        //   list.splice(1, 0, [goodsEditSubmitResult]);
                        // }
                    }
                } else {
                    list.unshift([goodsEditSubmitResult]);
                }

                return list;
            }
        } else {
            //只更新数据
            let findGoods = false;
            for (let i = 0; i < list.length; i++) {
                for (let j = 0; j < list[i].length; j++) {
                    if (list[i][j].goods_id == goodsEditSubmitResult.goods_id) {
                        //编辑商品只更新数据，不更新位置
                        if (list[i][j].is_my_album) {
                            let date = list[i][j].date;
                            list[i][j] = goodsEditSubmitResult;
                            list[i][j].date = date;
                        } else {
                            list[i][j].share_time = goodsEditSubmitResult.share_time;
                            list[i][j].from = goodsEditSubmitResult.from;
                        }
                        findGoods = true;
                        break;
                    }
                }
                if (findGoods) {
                    break;
                }
            }


            if (!findGoods) {
                //新增商品在今天显示
                let findGroup = false;
                let date = getDateText(goodsEditSubmitResult.time_stamp);
                goodsEditSubmitResult.date = date;
                for (let i = 0; i < list.length; i++) {

                    if (list[i][0].date.date_text == goodsEditSubmitResult.date.date_text) {
                        findGroup = true;
                        list[i].unshift(goodsEditSubmitResult);
                    }
                    if (findGroup) {
                        break;
                    }
                }
                if (!findGroup) {
                    //没找到分组就新增一个
                    list.unshift([goodsEditSubmitResult]);
                }
            }

            // if (index < 0) {
            //     if (shop_id == goodsEditSubmitResult.shop_id) {
            //         list.unshift(goodsEditSubmitResult);
            //     }
            // } else {
            //   if (list[index].is_my_album) {
            //     list[index] = goodsEditSubmitResult;
            //   } else {
            //     list[index].share_time = goodsEditSubmitResult.share_time;
            //     list[index].from = goodsEditSubmitResult.from;
            //   }
            // }
            return list;
        }


    } else if (template == 1) {
        // console.log('template11111111111111')
        //瀑布流显示处理
        if (isDel) {
            list = list.filter(item => {
                return item.goods_id !== goodsEditSubmitResult.goods_id;
            });
        } else {
            const index = list.findIndex(item => item.goods_id === goodsEditSubmitResult.goods_id);
            if (index < 0) {
                goodsEditSubmitResult.col = 0;
                list.unshift(goodsEditSubmitResult);
            } else {
                goodsEditSubmitResult.col = list[index].col;
                if (list[index].is_my_album) {
                    list[index] = goodsEditSubmitResult;
                } else {
                    list[index].share_time = goodsEditSubmitResult.share_time;
                    list[index].from = goodsEditSubmitResult.from;
                }
            }
        }
        return list;
    } else {
        // console.log('template2222222'+template)
        console.log(goodsEditSubmitResult);
        if (isDel) {
            list = list.filter(item => {
                return item.goods_id !== goodsEditSubmitResult.goods_id;
            });
        } else {
            const index = list.findIndex(item => item.goods_id === goodsEditSubmitResult.goods_id);

            if (index < 0) {
                if (shop_id == goodsEditSubmitResult.shop_id) {
                    list.unshift(goodsEditSubmitResult);
                }
            } else {
                if (list[index].is_my_album) {
                    list[index] = goodsEditSubmitResult;
                } else {
                    list[index].share_time = goodsEditSubmitResult.share_time;
                    list[index].from = goodsEditSubmitResult.from;
                }
            }
        }
        return list;
    }
    // } catch (e) {
    //   console.log('updateGoodsFromEdieeeeeeeeeeeeee')
    // }
    return null;
}


function showshare111(data, downloadStartCB, downloadingCB, onAddToAlbum) {
    const buttons = [
        {
            type: 'friend',
            img: '../../assets/images/wechat.png',
            text: '微信好友',
            share: data.is_added ? 'share' : ''
        },
        {
            type: 'timeline',
            img: '../../assets/images/wx_circle.png',
            // text: '朋友圈',
            text: '更多渠道',
        }
    ];
    const download = {
        type: 'download',
        img: '../../assets/images/album_findpic_1.png',
        text: '批量保存'
    };
    const myAlbum = {
        type: 'add',
        img: '../../assets/images/album.png',
        text: '我的相册'
    };
    canDownload(data) && buttons.unshift(download);
    !data.is_added && buttons.push(myAlbum);

    const hideSheet = $tdActionsheet.show({
        theme: 'wx',
        titleText: '分享至',
        buttons,
        buttonClicked(index, item) {
            switch (item.type) {
                case 'download':
                    //下载图片
                    downloadImgs(data, downloadStartCB, downloadingCB);
                    break;
                case 'friend':
                    if (!data.is_added) {
                        wx.showModal({
                            title: '提示',
                            content: '请添加至您的相册后，再分享给好友',
                            confirmText: '添加',
                            success: function (res) {
                                if (res.confirm) {
                                    console.log('用户点击确定');
                                    typeof onAddToAlbum == 'function' && onAddToAlbum(data, function () {
                                        $wuxToast.show({
                                            type: 'text',
                                            text: '添加成功'
                                        });

                                        data = { ...data, is_added: true };
                                        showshare(data, downloadStartCB, downloadingCB, onAddToAlbum);
                                    });
                                } else if (res.cancel) {
                                    console.log('用户点击取消');
                                }
                            }
                        });
                    }
                    break;
                case 'timeline':
                    let content = '';
                    if (util.isIOS()) {
                        content = '此功能需在app中使用。下载app请前往苹果APP store 搜索「微商相册」。';
                    } else {
                        content = '此功能需在app中使用。下载app请前往百度搜索「微商相册」。';
                    }
                    wx.showModal({
                        title: '提示',
                        content: content,
                        //      confirmText:'查看教程',
                        //    cancelText:'好的',
                        success: function (res) {
                            if (res.confirm) {
                                console.log('用户点击确定');

                                // 跳转至app下载教程页面
                                wx.navigateTo({
                                    url: '/pages/app/index'
                                });
                            } else if (res.cancel) {
                                console.log('用户点击取消');
                            }
                        }
                    });
                    break;
                case 'add':
                    typeof onAddToAlbum == 'function' && onAddToAlbum(data, function () {
                        wx.showModal({
                            title: '提示',
                            content: '已成功添加至您的微商相册，请前往您的「微商相册APP 」中查看',
                            // content: '请在微商相册app中添加',
                            cancelText: '查看教程',
                            confirmText: '好的',
                            success: function (res) {
                                if (res.confirm) {
                                    console.log('用户点击确定');
                                } else if (res.cancel) {
                                    console.log('用户点击取消');

                                    // 跳转至app下载教程页面
                                    wx.navigateTo({
                                        url: '/pages/app/index'
                                    });
                                }
                            }
                        });
                    });
                    break;

            }
            return true;
        },
    });
}

module.exports = {
    copyTitle,
    showshare,
    downloadImgs,
    getDateText,
    getGrouplist,
    getDateTime,
    updateGoodsFromEdit,
    filterData,
};
