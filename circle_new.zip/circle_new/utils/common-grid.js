import { $wuxToast } from '../components/wux';
const util = require('./util');
const logic = require('./logic');
const attentionUrl = '/album/attention_album.jsp?';
const unAttentionUrl = '/album/album_operation.jsp?act=del_album';
export const addUrl = '/album/album_theme_operation.jsp?act=hold_theme';
export const addAlbumUrl = '/album/album_theme_operation.jsp?act=circle_hold_theme';

function showGuide(shop_id, guide) {
    const { title, desc: content, leftBtnTxt: cancelText, rightBtnTxt: confirmText } = guide;

    wx.showModal({
        title,
        content,
        cancelText,
        confirmText,
        success: res => {
            if (res.confirm) {
                console.log('用户点击确定');
                // 关注
                this.tapAttention(null, shop_id);
            } else if (res.cancel) {
                console.log('用户点击取消');
            }
        }
    });
}

function tapUnAttention(ev, shop_id) {
    const url = unAttentionUrl;

    console.info('un attention');
    wx.showLoading({
        mask: true,
        title: '加载中...',
    });
    let postData = {
        albumId: shop_id || this.shop_id
    };
    util.fetchAuthInst(url, postData, res => {
        const { errcode, errmsg } = res.data;

        wx.hideLoading();
        if (errcode == 0) {
            console.log('unattention success', res);
            this.setData({
                is_attention: true
            });
            $wuxToast.show({
                type: 'text',
                text: errmsg
            });
            if (this.onAttentionSuccess) {
                this.onAttentionSuccess();
            }
        }
    }, err => {
        console.log(err);
        wx.hideLoading();
    });
}

function tapAttention(ev, shop_id) {
    // const { attentionUrl: url } = this.data;
    const url = attentionUrl;

    console.info('attention');
    wx.showLoading({
        mask: true,
        title: '加载中...',
    });
    let postData = {
        shop_id: shop_id || this.shop_id
    };
    util.fetchAuthInst(url, postData, res => {
        const { errcode, errmsg } = res.data;

        wx.hideLoading();
        if (errcode == 0) {
            console.log('attention success', res);
            this.setData({
                is_attention: true
            });
            $wuxToast.show({
                type: 'text',
                text: errmsg
            });
            if (this.onAttentionSuccess) {
                this.onAttentionSuccess();
            }
        } else {
            let title = errmsg;
            if (title.startsWith('首次查看')) {
                if (this.pageName == 'follow_detail') {
                    title = `商家已开启关注审核\r\n请点击左下角联系商家`;
                } else {
                    title = `商家已开启关注审核\r\n请点击头像进入联系商家`;
                }
            }
            wx.showToast({
                title,
                icon: 'none',
                duration: 3000
            });
        }
    }, err => {
        console.log(err);
        wx.hideLoading();
    });
}

function copyTitle(title) {
    title &&
        wx.setClipboardData({
            data: title,
            success: res => {
                // $wuxToast.show({
                //     type: 'text',
                //     text: '标题已复制到剪贴板'
                // });
            },
            fail: res => {
                // $wuxToast.show({
                //     type: 'text',
                //     text: '标题复制失败，请稍后重试~'
                // });
            }
        });
}

function onDownload(e) {
    const { dataset } = e.target;
    const { listidx, index } = dataset;
    const { list } = this.data;
    const { title } = listidx >= 0 ? list[listidx][index] : list[index];

    // 复制标题
    this.copyTitle(util.getTextTitle(title));

    console.log('onDownload222222', list[index]);
    return;

    // 下载图片
    const timer = setTimeout(() => {
        clearTimeout(timer);
        logic.downloadImgs(dataset, this.downloadStartCB, this.downloadingCB);
    }, 500);
}

function downloadStartCB() {
    console.log("downloadStartCB");

    if (this.toast) {
        this.toast.updateText('开始下载');
    } else {
        this.toast = $wuxToast.show({
            type: 'watiing',
            color: '#fff',
            text: '开始下载',
        });
    }
    this.toast.show();

    //this.toast && this.toast.setHidden()
}

function downloadingCB(progress, text) {
    console.log("task:" + progress);
    if (this.toast) {
        this.toast.updateText(text);
        if (progress == 100) {
            this.toast.setHidden();
        }
    }
}

function onCopyRemark(ev) {
    const { dataset } = ev.target;
    const { title } = dataset;

    copyTitle(title);
}

export default {
    showGuide,
    tapAttention,
    tapUnAttention,
    copyTitle,
    onDownload,
    downloadStartCB,
    downloadingCB,
    onCopyRemark,
};
