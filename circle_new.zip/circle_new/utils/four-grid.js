import { $wuxToast } from '../components/wux';
import commonGrid, { addUrl, addAlbumUrl, getGoodsUrl } from './common-grid';
const util = require('./util');
const logic = require('./logic');

const app = getApp();
const bury = require('./burypoint');

function onTap(ev) {
    const { shopId, goodsId, themeType } = ev.currentTarget.dataset;
    const bury_config = app.globalData.bury_config;
    bury.profileBury('view_product_details', bury_config);

    if (themeType === 3) {
        let content = '小程序暂不支持此操作，请关注【微商相册】公众号，确认即复制微信号：mmicroboss';
        wx.showModal({
            title: '提示',
            content: content,
            confirmText: '确认',
            confirmColor: '#3cc51f',
            success: function (res) {
                if (res.confirm) {
                    console.log('用户点击确定');

                    // 跳转至app下载教程页面
                    wx.navigateTo({
                        url: '/pages/app/index'
                    });
                } else if (res.cancel) {
                    console.log('用户点击取消');
                }
            }
        });
    } else {
        const route = '/pages/goods_detail/index';
        const options = {
            shop_id: shopId,
            goods_id: goodsId,
        };

        util.navigateTo(route, options);
    }
}

//小程序中点击商品链接，提示语优化
function onTapTow(ev, _this) {
    const { shopId, goodsId, themeType, index } = ev.currentTarget.dataset;
    const bury_config = app.globalData.bury_config;
    bury.profileBury('view_product_details', bury_config);

    if (themeType === 3) {
        wx.showModal({
            title: '提示',
            content: '小程序暂不支持此操作，请关注【微商相册】公众号，确认即复制微信号：mmicroboss',
            success: function (res) {
                if (res.confirm) {
                    wx.setClipboardData({
                        data: 'mmicroboss',
                        success: function (res) {
                            wx.getClipboardData({
                                success: function (res) {
                                    console.log(res.data); // data
                                }
                            });
                        }
                    });
                } else if (res.cancel) {
                    console.log('用户点击取消');
                }
            }
        });
    } else {
        // const that = this.data ? this : _this;
        // const { list } = that.data;
        // const route = '/pages/goods_detail/index';
        // const route = '/pages/goods_detail_circle/index';
        // const options = {
        //     shop_id: shopId,
        //     goods_id: goodsId,
        // };

        // util.navigateTo(route, options);

        // console.log('111list:', list, index);
        // return;
        wx.navigateTo({
            url: `/pages/goods_detail_circle/index?shop_id=${shopId}&goods_id=${goodsId}&from=wsxc`,
            success: function (res) {
                res.eventChannel.emit('acceptGoodsItemData', {});
            }
        });
    }
}

function imgTap(ev, _this) {
    const { listidx, index } = ev.currentTarget.dataset;
    const that = this.data ? this : _this;
    const { list } = that.data;

    let previewIndex = 0;
    for (let i = 0; i < listidx + 1; i++) {
        const perList = list[i];
        if (i === listidx) {
            for (let j = 0; j < index; j++) {
                const { themeType, imgsSrc = [] } = perList[j];
                if (themeType === 4) {
                    previewIndex += (imgsSrc.length + 1);
                } else {
                    previewIndex += imgsSrc.length;
                }
            }
        } else {
            for (let j = 0; j < perList.length; j++) {
                const { themeType, imgsSrc = [] } = perList[j];
                if (themeType === 4) {
                    previewIndex += (imgsSrc.length + 1);
                } else {
                    previewIndex += imgsSrc.length;
                }
            }
        }
    }

    const concatArr = list.reduce((pre, item) => {
        return [...pre, ...item];
    }, []);

    const { previewList } = util.getPreviewerInitData(concatArr, 0, index, true);

    that.triggerEvent('previewImgs', {
        previewList,
        previewIndex,
    });
}

function onAdd(e, _this) {
    const { index, listidx } = e.target.dataset;
    let that = this.data ? this : _this;
    const { list } = that.data;

    const { shop_id, goods_id } = list[listidx][index];
    const url = `${addUrl}&shop_id=${shop_id}&goods_id=${goods_id}`;

    console.info("onAdd", index, e);
    wx.showLoading({
        mask: true,
        title: '加载中...',
    });
    util.fetch(url)
        .then(res => {
            const { errcode, result } = res.data;

            wx.hideLoading();
            if (errcode == 0) {
                const { follow_object } = result;

                // 未关注
                if (follow_object) {
                    this.showGuide(shop_id, follow_object);
                    return false;
                }

                // 分享
                this.onShare(e, that);
            }
        }, err => {
            console.info('onAdd error', err);

            wx.hideLoading();
        });
}

function onShare(e, _this) {
    const bury_config = app.globalData.bury_config;
    let { dataset = {} } = e.currentTarget;
    const that = this.data ? this : _this;
    const { list } = that.data;
    let listidx = 0;
    let index = 0;
    let goods = {};
    if (e.type && e.type === 'onShare') {
        let findedGoodsIndex = -1;
        const { goods_id } = e.detail;
        for (let i = 0; i < list.length; i++) {
            findedGoodsIndex = list[i].findIndex(item => item.goods_id === goods_id);
            if (findedGoodsIndex > -1) {
                goods = list[i][findedGoodsIndex];
                listidx = i;
                index = findedGoodsIndex;
                break;
            }
        }
        dataset.item = goods;
        dataset = {
            ...dataset,
            ...e.detail,
            listidx,
        };
    } else {
        index = dataset.index;
        listidx = dataset.listidx;
        goods = list[listidx][index];
    }

    const { title } = goods;

    // bury.profileBury('share_product', bury_config);

    // 复制标题
    // this.copyTitle(util.getTextTitle(title));
    dataset.title = util.getTextTitle(title);
    // 分享
    // that.shareIndex = index;
    let sharedata = {
        index,
        listidx
    };
    wx.setStorageSync('share_index', sharedata);

    // this.listidx = listidx;
    logic.showshare(dataset, this.downloadStartCB.bind(this), this.downloadingCB.bind(this), this.onAddToAlbum.bind(that), _this || that);
}

function onAddToAlbum(dataset, callback, _this) {
    const { index, listidx, is_added } = dataset;
    const addUrl = addAlbumUrl;
    let that = this.data ? this : _this;
    const { list } = that.data;
    const { shop_id, goods_id } = list[listidx][index];
    const url = `${addUrl}&shop_id=${shop_id}&goods_id=${goods_id}`;

    console.info("onAddToAlbum", dataset);

    if (is_added) {
        typeof callback == 'function' && callback();
        return false;
    }

    wx.showLoading({
        mask: true,
        title: '加载中...',
    });
    util.fetch(url)
        .then(res => {
            const { errcode, result } = res.data;

            wx.hideLoading();
            if (errcode == 0) {
                const { follow_object } = result;

                // 未关注
                if (follow_object) {
                    this.showGuide(shop_id, follow_object);
                    return false;
                }

                console.info('onAddToAlbum success', res);
                that.setData({
                    [`list[${listidx}][${index}].is_added`]: true,
                    [`list[${listidx}][${index}].share_shop_id`]: result.shop_id,
                    [`list[${listidx}][${index}].share_goods_id`]: result.goods_id,
                });

                typeof callback == 'function' && callback();
            }
        }, err => {
            console.info('onAddToAlbum error', err);

            wx.hideLoading();
        });
}

function onToggleRemark(ev, _this) {
    const { index, listidx } = ev.currentTarget.dataset;
    let that = this.data ? this : _this;
    const { list } = that.data;
    const { showRemark } = list[listidx][index];
    const key = `list[${listidx}][${index}].showRemark`;

    that.setData({
        [key]: !showRemark
    });
}

function onAddCart(e, _this) {
    const bury_config = app.globalData.bury_config;
    bury.profileBury('add_to_shopping_cart', bury_config);

    let that = this.data ? this : _this;
    const { list } = that.data;

    let goods = {};
    if (e.type && e.type === 'onAddCart') {
        const concatArr = list.reduce((pre, item) => {
            return [...pre, ...item];
        }, []);
        const { goods_id } = e.detail;
        goods = concatArr.find(item => item.goods_id === goods_id);
    } else {
        const { dataset } = e.currentTarget;
        const { index, listidx } = dataset;
        goods = list[listidx][index];
    }

    const { shop_id, goods_id, colors = [], formats = [] } = goods;

    const url = `${getGoodsUrl}&shop_id=${shop_id}&goods_id=${goods_id}&is_spot_format=true&is_add_purchase=true`;

    // if (!colors.length && !formats.length) {
    wx.showLoading({
        mask: true,
        title: '加载中...',
    });
    util.fetch(url).then(res => {
        const { errcode, result } = res.data;
        wx.hideLoading();
        if (errcode == 0) {
            // this.$cartSheet.onShow(result);
            if (this.data) {
                this.$cartSheet.onShow(result);
            } else {
                console.log('triggerEvent---------->');
                _this.triggerEvent('showCartSheet', result);

            }
        }
    }, err => {
        console.info('onAddThemeToAlbum error', err);
        wx.hideLoading();
    });
    // } else {
    //     const { dataset } = e.currentTarget;
    //     const { index, listidx } = dataset;
    //     if (this.data){
    //         this.$cartSheet.onShow(list[listidx][index]);
    //     }else{
    //         console.log('triggerEvent---------->')
    //         _this.triggerEvent('showCartSheet', list[listidx][index])

    //     }

    // }
}

export default Object.assign({}, commonGrid, {
    onTap,
    imgTap,
    onAdd,
    onShare,
    onAddToAlbum,
    onToggleRemark,
    onTapTow,
    onAddCart,
});
