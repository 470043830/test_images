

function shareAppMessageCanvas(data) {

    return new Promise((resolve, reject) => {});
}

export {
    shareAppMessageCanvas
};
