import { $wuxToast } from '../components/wux';
import commonGrid, { addUrl, addAlbumUrl } from './common-grid';
const util = require('./util');
const logic = require('./logic');

function onTap(ev) {
    const {shopId, goodsId, themeType, href} = ev.currentTarget.dataset;

    if (themeType === 3) {
        let content = '';
        if (util.isIOS()) {
            content = '此图文需在app中打开。下载app请前往苹果APP store 搜索「微商相册」。';
        } else {
            content = '此图文需在app中打开。下载app请前往百度搜索「微商相册」。';
        }

        wx.showModal({
            title: '提示',
            content: content,
            success: function (res) {
                if (res.confirm) {
                    console.log('用户点击确定');

                    // 跳转至app下载教程页面
                    wx.navigateTo({
                        url: '/pages/app/index'
                    })
                } else if (res.cancel) {
                    console.log('用户点击取消');
                }
            }
        });
    } else {
        wx.navigateTo({
            url: `/pages/goods_detail/index?shop_id=${shopId}&goods_id=${goodsId}`
        });
    }
}

function imgTap(ev) {
    const { listidx, index } = ev.currentTarget.dataset;
    const { list } = this.data;
    const current = list[listidx][index].imgsSrc[0];
    const urls = this.list.map(item => item.imgsSrc)
        .reduce((prev, curr) => [...prev, ...curr]);

    wx.previewImage({current, urls});
}

function onAdd(e) {
    const { index, listidx } = e.target.dataset;
    // const { addUrl, list } = this.data;
    const { list } = this.data;
    const { shop_id, goods_id } = list[listidx][index];
    const url = `${addUrl}&shop_id=${shop_id}&goods_id=${goods_id}`;

    console.info("onAdd", index, e);
    wx.showLoading({
        mask: true,
        title: '加载中...',
    });
    util.fetch(url)
        .then(res => {
            const { errcode, result } = res.data;

            wx.hideLoading();
            if (errcode == 0) {
                // const { shop_id, goods_id, follow_object } = result;
                const { follow_object } = result;

                // 未关注
                if (follow_object) {
                    this.showGuide(shop_id, follow_object);
                    return false;
                }

                // console.info('onAdd success', res);
                // this.setData({
                //     // [`list[${listidx}][${index}].shop_id`]: shop_id,
                //     // [`list[${listidx}][${index}].goods_id`]: goods_id,
                //     [`list[${listidx}][${index}].is_added`]: true,
                // });

                // 分享
                this.onShare(e);
            }
        }, err => {
            console.info('onAdd error', err);

            wx.hideLoading();
            // 分享
            // this.onShare(e);
        });
}

function onShare(e) {
    const { dataset } = e.target;
    const { index, listidx } = dataset;
    const { list } = this.data;
    const { title } = list[listidx][index];

    console.info("onShare", index, dataset);

    // 复制标题
    this.copyTitle(util.getTextTitle(title));

    // 分享
    this.shareIndex = index;
    this.listidx = listidx;
    logic.showshare(dataset, this.downloadStartCB, this.downloadingCB, this.onAddToAlbum);
}

function onAddToAlbum(dataset, callback) {
    const { index, listidx, is_added } = dataset;
    // const { addUrl, list } = this.data;
    const addUrl = addAlbumUrl;
    const { list } = this.data;
    const { shop_id, goods_id } = list[listidx][index];
    const url = `${addUrl}&shop_id=${shop_id}&goods_id=${goods_id}`;

    console.info("onAddToAlbum", dataset);

    if (is_added) {
      typeof callback == 'function' && callback();
      return false;
    }

    wx.showLoading({
        mask: true,
        title: '加载中...',
    });
    util.fetch(url)
        .then(res => {
            const { errcode, result } = res.data;

            wx.hideLoading();
            if (errcode == 0) {
                const { follow_object } = result;

                // 未关注
                if (follow_object) {
                    this.showGuide(shop_id, follow_object);
                    return false;
                }

                console.info('onAddToAlbum success', res);
                this.setData({
                    [`list[${listidx}][${index}].share_shop_id`]: result.shop_id,
                    [`list[${listidx}][${index}].share_goods_id`]: result.goods_id,
                    [`list[${listidx}][${index}].is_added`]: true,
                });

                typeof callback == 'function' && callback();
            }

            // 分享
            // this.onShare(e);
        }, err => {
            console.info('onAddToAlbum error', err);

            wx.hideLoading();
            // 分享
            // this.onShare(e);
        });
}

function onToggleRemark(ev) {
    const { index, listidx } = ev.currentTarget.dataset;
    const { list } = this.data;
    const { showRemark } = list[listidx][index];
    const key = `list[${listidx}][${index}].showRemark`;

    this.setData({
        [key]: !showRemark
    });
}

export default Object.assign({}, commonGrid, {
    onTap,
    imgTap,
    onAdd,
    onShare,
    onAddToAlbum,
    onToggleRemark,
})
