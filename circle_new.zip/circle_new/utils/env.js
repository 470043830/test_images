//url相关

let BASE_URL = 'https://www.wsxcme.com/service'; //'https://www.tapbizz.cn/service'; //'https://www.wxlookbook.com/service'; //

// BASE_URL = "http://192.168.1.102:8080/service";
// BASE_URL = "http://106.52.207.106:20080/service";
// BASE_URL = "https://circle.wegoab.com/service";
// BASE_URL = "http://10.20.1.100:8080/service";

// BASE_URL = "https://www.wemicroboss.com/service";


let CIRCLE_ID = 'CID000009';

const isDev = 0;

if (isDev) {
    // BASE_URL = "http://192.168.1.86:8080/service";
    BASE_URL = "http://localhost:8080/service";
    // CIRCLE_ID = 'CID000001'; //'dev';
}

function getBaseUrl() {
    return BASE_URL;
}


function getCircleId() {
    return CIRCLE_ID;
}


module.exports = {
    getBaseUrl,
    getCircleId
};
