const env = require('./env');
//url相关
//let BASE_URL = 'http://localhost:8080'
// let BASE_URL = 'https://wsxc.me/service'
let BASE_URL = env.getBaseUrl();//'https://www.wsxcme.com/service'
// let BASE_URL = 'https://www.szwego.com/service'
let QINIU_IMG_URL = 'https://ol51v40vb.qnssl.com/';
// let LOGIN_URL = BASE_URL + '/miniapp/circle_decode_user_info.jsp';
let LOGIN_URL = BASE_URL + '/circle/circle_new_interface.jsp?act=decodeMiniAppUserInfo';
let VERSION = 117; //99;//105; //199;

// 相册主题标题显示最大行数
let ROWS = 6;

// 后端热数据库数据 < minPageSize，继续加载下一页
const minPageSize = 16;

// let circle_id = "CBIZ000002"; //水贝珠宝
// let circle_id = "CBIZ000001"; //南油服装
// let circle_id = "CBIZ000003"; //商圈模板
// let circle_id = "CBIZ000004"; //广州沙河商圈
// let circle_id = "CBIZ000005"; //桐乡濮院批发商圈
let circle_id = env.getCircleId();//"CBIZ000006"; //嘉兴平湖羽绒服批发商圈

const circles = {
    'CID000001': '圣名展厅',
    'CID000002': '深圳南油服装批发商圈',
    'CID000005': '觉悟者文创',
    'CID000006': '虎门商圈',
    'CBIZ000002': '水贝珠宝商圈',
    'CBIZ000003': '商圈模板',
    'CBIZ000004': '广州沙河商圈',
    'CBIZ000005': '桐乡濮院批发商圈',
    'CBIZ000006': '嘉兴平湖羽绒服批发商圈',
};

// 备注价格类型
const priceTypesObj = {
    '1': '拿货价',
    '2': '零售价',
    '3': '批发价',
    '4': '打包价',
};

const GUEST_TOKEN = 'Mzk4MDk3Q0E5RTZCN0I1MkYwMTYwNDlCQUNFNkQ5QzVFOEZCOTI1OEEwOTA2MDc0QzUzRTVCNDVDMTg1RTgzRTZBNTY1MTZDQTNFNDFCRkI2ODZGRTgxRjQxRDU3MEZD';

const USER_INFO_STORAGE = 'UserInfo_' + circle_id;
const FOLLOWED_SHOP_IDS_STORAGE = 'followed_shop_ids';

module.exports = {
    BASE_URL,
    QINIU_IMG_URL,
    VERSION,
    LOGIN_URL,
    ROWS,
    circle_id,
    circles,
    priceTypesObj,
    minPageSize,
    USER_INFO_STORAGE,
    FOLLOWED_SHOP_IDS_STORAGE,
    GUEST_TOKEN
};
