const constant = require('./constant');
const clog = require('./circle-log.js');
const qiniuUploader = require("../assets/plugins/qiniuUploader");
// const neiwangToken = 'ODE4OEFENDg5REQwQkRCMEJGRjAxNTM5MkRFNDFDQUY0NEY2QUQ4OTJCRUY4MDU4NEZEQjg4NkY1MTkyNDNEMzIwM0M5MjI1RjE5MTZGRDZFNjFBQTc3QTVCNUIyODEw';



function getTestToken() {
    let token = '';
    //朱龙威
    token = "NEQwREFGRUM4NjAyQzVGMTYyM0U0NTQ0RTA0MzA1Q0UzQ0FBMkFFNDlFRTQ3RUExN0VDQjU5QkMwNUI0MkIyQzcwODkxMUMyQzhENEQ3RTFBQkYwNUIyRTI3MTFGQTc1NDFDMTFFRjIyRkNGOTdEQUM1MzQyNUU1MjEwNjhDREI=";
    //
    token = "QTA2M0RCREY0MzAyNUYyOTJGODE0MEIzMTEwMjQ1MDZGRjNERjk0NjdBMjMyRTZCRDYxRUREQzZEMEEyMzg4QzFDNjNFNzlGRUNEN0ZDMThGODlDOUM2MTVBMjA1ODkw";
    //liutao de token
    token = "MjBFRTQzNTlDMjg4ODY4QkNFNzdENTc2OTRFRTZEODUzMTFCNkVDRkM0MzFBM0FGN0Q2Q0MyMEU5OUNDRkYyNUFDNDYwRDJCMDM1MDlEN0YzRkQyRDU1NTA1MkMwQTM2MEQ2NzE4MDU0NEMwMjkzOEE3OUZEQzg1N0U2ODhFOTc";

    //zihua
    // token = `MDVCN0YzOEEwOEYxQUYxQkRDQTdENTlDQjUwODE5QTg1MUMwNTMyOTQ1QkMxMkFFMzYxOTBCODdDNEU5NDRCMEUwODI1NTUyRUY3QzlBNTFENzlENzRENjQ4M0JBMDA4`;
    return token;
}

var currRequestTask = null; //简单保存一下task，多个同时请求会有问题

function abortCurrRequestTask() {
    if (currRequestTask) {
        currRequestTask.abort(); // 取消请求任务
        currRequestTask = null;
    }
}

function fetchPost(api, params) {
    let token = getApp().getToken();

    console.log('fetchPost, api: ', api);
    // console.log('fetch, getApp().globalData.userInfo: ', typeof getApp().globalData.userInfo);
    // if (getApp().globalData.userInfo && getApp().globalData.userInfo.token) {
    //     token = getApp().globalData.userInfo.token;
    // }
    // const { circleId } = getApp().getCircleConfig();
    //test token for neiwang
    // if (api.startsWith('https://www.w00g.cn')) {
    //     token = neiwangToken;
    // }

    // console.log('getApp().globalData.userInfo.token: ', getApp().globalData.userInfo.token);
    return new Promise((resolve, reject) => {
        let baseUrl = constant.BASE_URL;
        let data = null;

        if (api.startsWith('http')) {
            baseUrl = '';
        }
        data = Object.assign({ version: constant.VERSION, circleId: getApp().getCircleId() }, params);
        const url = `${baseUrl}${api}`;
        clog.log('fetchPost, url:', url);
        currRequestTask = wx.request({
            url,
            data,
            header: {
                'Content-Type': 'application/json',
                'Cookie': `token=${token};`,
            },
            method: 'POST',
            success: resolve,
            fail: reject
        });

    });
}



function fetch(api, params, method = 'GET') {
    let token = getApp().getToken();
    const type = {
        'GET': 'application/x-www-form-urlencoded', //'application/json',
        'POST': 'application/x-www-form-urlencoded',
    };
    // console.log('fetch, method: ', method);
    // console.log('fetch, getApp().globalData.userInfo: ', typeof getApp().globalData.userInfo);
    // if (getApp().globalData.userInfo && getApp().globalData.userInfo.token) {
    //     token = getApp().globalData.userInfo.token;
    // }
    // if (api.startsWith('https://www.w00g.cn')) {
    //     token = neiwangToken;
    // }
    // console.log('getApp().globalData.userInfo.token: ', getApp().globalData.userInfo.token);
    return new Promise((resolve, reject) => {
        let baseUrl = constant.BASE_URL;
        let data = null;

        if (api.startsWith('http')) {
            baseUrl = '';
        }
        data = Object.assign({ client_type: 'miniapp', version: constant.VERSION, circleId: getApp().getCircleId() }, params);

        if (token && api.indexOf('token=') == -1) {
            data.token = token;
        }

        // token = getTestToken();
        const url = `${baseUrl}${api}`;
        clog.log('fetch, url:', url, data);
        currRequestTask = wx.request({
            url,
            data,
            header: { 'Content-Type': type[method] },
            method,
            success: resolve,
            fail: reject
        });

    });
}


/**
 * 获取已经授权的信息
 */
function getPromission() {
    console.log('getPromission');
    wx.getSetting({
        success: (res) => {
            if (res) {
                getApp().globalData.authSetting = res.authSetting;
            }
        }
    });
}


/**
 * 设置获取用户信息授权
 */
function setInfoPromission(api, params, succ, fail) {
    console.info('setInfoPromission');
    if (getApp().globalData.authSetting && getApp().globalData.authSetting["scope.userInfo"]) {
        return;
    }
    wx.openSetting({
        success: (res) => {
            if (res) {
                console.info(res);
                getApp().globalData.authSetting = res.authSetting;
                // if (getApp().globalData.authSetting["scope.userInfo"] == true) {
                fetchAuthInst(api, params, succ, fail);
                // }else{
                //   fail()
                // }
            }

        }
    });
}


function login(sucCB, failCB, userInfo = {}) {
    if (wx.login) {
    } else {
        // 如果希望用户在最新版本的客户端上体验您的小程序，可以这样子提示
        wx.showModal({
            title: '提示',
            content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
        });
        return;
    }
    wx.login({
        success: r => {
            let code = r.code;//登录凭证
            if (code) {
                // console.log({ encryptedData: res.encryptedData, iv: res.iv, code: code });
                //3.解密用户信息 获取unionId
                console.log(constant.LOGIN_URL);
                const data = {
                    // encryptedData: res.encryptedData,
                    // iv: res.iv,
                    code: code,
                    circle_id: constant.circle_id,
                    proxy_id: getApp().globalData.proxy_id,
                    client_type: 'miniapp',
                    version: constant.VERSION,
                    ...userInfo
                };
                wx.request({
                    url: constant.LOGIN_URL,//TODO:获取token及此小程序商城ID
                    method: 'post',
                    header: {
                        'content-type': 'application/x-www-form-urlencoded'
                    },
                    data,
                    success: res => {
                        //4.解密成功后 获取自己服务器返回的结果
                        let _userInfo = res.data.result;
                        getApp().globalData.userInfo = _userInfo;
                        //保存token
                        try {
                            console.log('---------wx.setStorageSync: ', _userInfo);
                            _userInfo.originToken = _userInfo.token;
                            wx.setStorageSync(constant.USER_INFO_STORAGE, _userInfo);
                        } catch (e) {
                        }
                        typeof sucCB == "function" && sucCB(getApp().globalData.userInfo);
                        console.log(_userInfo);
                    },
                    fail: function () {
                        console.log('系统错误');
                        typeof failCB == "function" && failCB(1, '系统错误');
                    }
                });

                //2、调用获取用户信息接口
                // wx.getUserInfo({
                //     withCredentials: true,
                //     success: res => {

                //     },
                //     fail() {
                //         console.log('获取用户信息失败');
                //         typeof failCB == "function" && failCB(2, '获取用户信息失败');
                //     }
                // });
            } else {
                console.log('获取用户登录态失败！' + r.errMsg);
                typeof failCB == "function" && failCB(3, '获取用户登录态失败！' + r.errMsg);
            }
        },
        fail() {
            // callback(false)
            typeof failCB == "function" && failCB(4, '登录失败');
        }
    });
}


/**
 * 需要授权的接口
 */
function fetchAuthImpl(api, params, succ, fail, retryAuth) {
    console.log('fetchAuthImpl: ', getApp().globalData.userInfo);

    if (!getApp().globalData.userInfo) {
        try {
            getApp().globalData.userInfo = wx.getStorageSync(constant.USER_INFO_STORAGE);
        } catch (e) {
        }
    }

    if (getApp().globalData.userInfo && getApp().globalData.userInfo.token && getApp().globalData.userInfo.new_token) {
        fetch(api, params).then(res => {
            succ(res);
        }, (err) => {
            fail(err);
        });
    } else {
        //未授权
        login(() => {
            fetch(api, params).then(res => {
                succ(res);
            }, (err) => {
                fail(err);
            });
        }, (errcode, errmsg) => {
            if (retryAuth) {
                //再次Shenqing权限
                // if (errcode == 2){
                //     setInfoPromission(api, params, succ, fail)
                // }
                wx.redirectTo({
                    url: '/pages/login/index'
                });
            } else {
                //授权失败，游客访问
                fetch(api, params).then(res => {
                    succ(res);
                }, (err) => {
                    fail(err);
                });
            }

        });
    }
}

/**
 * 需要授权的接口,用户拒绝后不做其它处理，继续访问数据
 * @param api
 * @param params
 * @param succ
 * @param fail
 */
function fetchAuth(api, params, succ, fail) {
    fetchAuthImpl(api, params, succ, fail, false);
}

/**
 * 需要授权的接口,用户拒绝后再弹出授权页面
 */
function fetchAuthInst(api, params, succ, fail) {
    fetchAuthImpl(api, params, succ, fail, true);
}

//进行经纬度转换为距离的计算
function Rad(d) {
    return d * Math.PI / 180.0;//经纬度转换成三角函数中度分表形式。
}

//计算距离，参数分别为第一点的纬度，经度；第二点的纬度，经度
function getDistance(lat1, lng1, lat2, lng2) {
    var radLat1 = Rad(lat1);
    var radLat2 = Rad(lat2);
    var a = radLat1 - radLat2;
    var b = Rad(lng1) - Rad(lng2);
    var s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) +
        Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(b / 2), 2)));
    s = s * 6378.137;// EARTH_RADIUS;
    s = Math.round(s * 10000) / 10000; //输出为公里
    //s=s.toFixed(4);
    return s;
}

// 初始化七牛相关参数
function initQiniu() {
    var options = {
        region: 'ECN', //
        uptokenURL: constant.BASE_URL + '/get_qiuniu_token.jsp',
        // uptoken: 'xxxx',
        domain: 'http://lookbook-server-img.bkt.clouddn.com',
        shouldUseQiniuFileName: false
    };
    qiniuUploader.init(options);
}

function qiniuUpload(filePath, callback) {
    qiniuUploader.upload(filePath, (res) => {
        let sourceLink = constant.QINIU_IMG_URL + res.key;
        callback(sourceLink);

    }, (error) => {
        console.error('error: ' + JSON.stringify(error));
    }
    );
}

function isIOS() {
    let isIOS = false;
    try {
        var res = wx.getSystemInfoSync();
        console.log(res.system);
        if (res.system.toLowerCase().indexOf('ios') >= 0) {
            isIOS = true;
        }
    } catch (e) {
    }
    return isIOS;
}

const reg_multi = /(<xcs>(.*?)<:xcs>)/g;
const getRegSingle = regStr => {
    return new RegExp(`(((${regStr})+))`, 'gi');
};

const getTextTitle = (title = '') => {
    return title.replace(reg_multi, '$2');
};

const getRichTitle = (title = '', filterText = '') => {
    title = title.trim();
    filterText = filterText.trim();
    if (!title || !filterText) return title;

    const reg_single = getRegSingle(filterText);
    const multiMatch = reg_multi.test(title);
    const singleMatch = reg_single.test(title);
    const match = multiMatch || singleMatch;

    if (match) {
        const reg = multiMatch ? reg_multi : reg_single;
        const now = Date.now();

        title = title.replace(reg, `${now}$1${now}`)
            .split(`${now}`)
            .filter(item => item)
            .map((item, i) => {
                const match = reg.test(item);
                const word = item.replace(reg, '$2');

                return match ? `<span class="success-color">${word}</span>` : item;
            }).join('');
    }

    return title;
};

/**
 * 数组去重
 * @param {Array} arr
 * @param {String} key
 */
const dedupArr = (arr = [], key = '') => {
    const hash = {};
    const result = [];

    arr.forEach(item => {
        const len = result.length;
        const keyValue = !!key ? item[key] : item;

        if (!hash[keyValue]) {
            hash[keyValue] = true;
            // result.push(item);
            result[len] = item;
        }
    });

    return result;
};

/**
 * 页面跳转
 * @param {string} route
 * @param {object} options
 */
const navigateTo = (route = '', options = {}) => {
    const url = getPagePath(route, options);
    const pages = getPagesPath();
    const len = pages.length;
    const index = pages.lastIndexOf(url);

    console.log(`navigateTo, url: ${url}`, index, len, constant.pageDeepth);
    if (!url) return;
    if (index === -1) {
        // len < constant.pageDeepth ? wx.navigateTo({ url }) : wx.redirectTo({ url });
        wx.navigateTo({ url });
    } else {
        const delta = len - 1 - index;
        wx.navigateBack({ delta });
    }
};

/**
 * 获取小程序各页面栈完整path
 */
const getPagesPath = () => {
    return getCurrentPages().map(page => {
        const { route, options } = page;
        const path = getPagePath(route, options);

        return path;
    });
};

/**
 * 获取小程序单页面完整path
 * @param {string} route
 * @param {object} options
 */
const getPagePath = (route = '', options = {}) => {
    let path = '';

    if (!route) return path;

    route = route.charAt(0) === '/' ? route : `/${route}`;
    const query = getQuery(options);
    path = `${route}${query}`;

    return path;
};

/**
 * object转query
 * @param {object} options
 */
const getQuery = (options = {}) => {
    let query = '';
    // const keys = Object.keys(options).sort();
    const keys = Object.keys(options);
    keys.forEach(key => {
        let char = !query ? '?' : '&';
        let value = options[key];

        query += `${char}${key}=${value}`;
    });

    return query;
};

// //test
// let circle_id = 'CBIZ000001'
// function getCircleID() {
//   if (circle_id) {
//     return circle_id
//   } else {
//     let extConfig = wx.getExtConfigSync ? wx.getExtConfigSync() : {}
//     circle_id = extConfig.attr.circle_id
//   }
//   return circle_id
// }

function compareVersion(v1, v2) {
    v1 = v1.split('.');
    v2 = v2.split('.');
    const len = Math.max(v1.length, v2.length);

    while (v1.length < len) {
        v1.push('0');
    }
    while (v2.length < len) {
        v2.push('0');
    }

    for (let i = 0; i < len; i++) {
        const num1 = parseInt(v1[i]);
        const num2 = parseInt(v2[i]);

        if (num1 > num2) {
            return 1;
        } else if (num1 < num2) {
            return -1;
        }
    }

    return 0;
}

function supportNavigationStyle() {
    const version = wx.getSystemInfoSync().version;
    if (compareVersion(version, '7.0.0') >= 0) {
        // console.log("supportNavigationStyle支持")
        return true;
    } else {
        console.log("supportNavigationStyle不支持");
        return false;
    }
}

function navGoBack() {
    wx.navigateBack({
        delta: 1,
    });
}

/**
 * 判断是否游客账号
 */
function getIsGuest() {
    let userInfo = wx.getStorageSync(constant.USER_INFO_STORAGE);
    // 游客
    if (userInfo && userInfo.is_guest) {
        return true;
    } else {
        return false;
    }
}

function openGoodsEdit(data) {
    const pages = getCurrentPages();
    const { route } = pages[pages.length - 1];
    if (route === 'pages/follow_detail/index') {
        wx.setStorage({
            key: 'goods_edit',
            data: 'shop_edit',
        });
    } else {
        wx.setStorage({
            key: 'goods_edit',
            data: 'home_edit',
        });
    }
    wx.navigateTo({
        url: '/pages/goods_edit/index' + '?shop_id=' + (data && data.shop_id || '') + '&goods_id=' + (data && data.goods_id || ''),
    });
}

/**
 * 文件判断
 * @param {*} fileName
 */
function getFileTypeFromExt(fileName) {
    if (typeof fileName !== 'string') return;

    if (
        fileName.indexOf('.jpg') > -1 ||
        fileName.indexOf('.jpeg') > -1 ||
        fileName.indexOf('.png') > -1 ||
        fileName.indexOf('.bmp') > -1 ||
        fileName.indexOf('.webp') > -1
    ) {
        return 'image';
    } else {
        return 'video';
    }
}

/**
 * 获取预览控件初始值
 * @param {*} list
 * @param {*} goodsIndex
 * @param {*} itemIndex
 */
function getPreviewerInitData(list, goodsIndex, itemIndex, videoOnImage) {
    const previewList = list.reduce((pre, item, index) => {
        const { themeType, imgsSrc = [], videoURL, title, goods_id, showAddCart, is_my_album, shop_id } = item;
        if (themeType === 4) {
            return [
                ...pre,
                {
                    fileSource: videoURL,
                    title,
                    themeType,
                    goods_id,
                    fileType: 'video',
                    showAddCart,
                    is_my_album,
                    shop_id,
                },
                {
                    fileSource: imgsSrc[0],
                    title,
                    themeType,
                    goods_id,
                    fileType: 'image',
                    showAddCart,
                    is_my_album,
                    shop_id,
                },
                ...imgsSrc.slice(1).map(i => ({
                    fileSource: i,
                    title,
                    goods_id,
                    themeType,
                    fileType: 'image',
                    showAddCart,
                    is_my_album,
                    shop_id,
                }))
            ];
        } else if (themeType === 1) {
            return [
                ...pre,
                {
                    fileSource: videoURL,
                    title,
                    goods_id,
                    themeType,
                    fileType: 'video',
                    showAddCart,
                    is_my_album,
                    shop_id,
                }
            ];
        } else {
            return [...pre, ...imgsSrc.map(i => ({
                fileSource: i,
                title,
                goods_id,
                themeType,
                fileType: 'image',
                showAddCart,
                is_my_album,
                shop_id,
            }))];
        }
    }, []);
    let previewIndex = 0;
    for (let i = 0; i < goodsIndex; i++) {
        const { themeType, imgsSrc = [], videoURL } = list[i];
        if (themeType === 4 || (videoURL && imgsSrc.length > 1)) {  //liu add videoURL check
            previewIndex += (imgsSrc.length + 1);
        } else {
            previewIndex += imgsSrc.length;
        }
    }
    const { themeType } = list[goodsIndex];
    if (themeType === 4 && videoOnImage) {
        if (itemIndex === 0) {
            previewIndex += itemIndex;
        } else {
            previewIndex += (itemIndex + 1);
        }
    } else {
        previewIndex += itemIndex;
    }

    return {
        previewList,
        previewIndex,
    };
}

function navigateToBrowserPage() {
    const pages = getCurrentPages();
    const { route } = pages[pages.length - 1];
    wx.navigateTo({
        url: `/pages/browser/index?route=${encodeURIComponent(route)}`,
    });
}

module.exports = {
    fetch,
    fetchPost,
    fetchAuth,
    fetchAuthInst,
    getDistance,
    initQiniu,
    qiniuUpload,
    isIOS,
    getTextTitle,
    getRichTitle,
    dedupArr,
    navigateTo,
    compareVersion,
    navGoBack,
    abortCurrRequestTask,
    supportNavigationStyle,
    getPagesPath,
    openGoodsEdit,
    login,
    getFileTypeFromExt,
    getPreviewerInitData,
    navigateToBrowserPage,
    getIsGuest
};
