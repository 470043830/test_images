
//Lisa微相册
export const oneShop = { phone: '16666668888_', id: 'A201808301332397980078599', appid: 'tt46b83005d987afa901' };
