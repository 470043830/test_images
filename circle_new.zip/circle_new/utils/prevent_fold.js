
const { CONFIG_KEY } = require('./constant.js')

const space = 2; //字符相隔距离
const cutLength = 10; //插入间隔

//获取配置项
const isOpenPreventFold = () => {
    const config = wx.getStorageSync(CONFIG_KEY);
    const { avoid_fold = false } = config;
    return !!avoid_fold;
}

//特殊字符转换
const truncated = (str, num) => {
    return Array.from(str).slice(0, num).join('');
}

//截取插入前半部字符串
const getInsertFontStr = (str, start, newStr) => {
    return str.slice(0, start) + newStr;
 }

//截取插入后半部字符串
const getInsertLastStr = (str, start, newStr) => {
    const lastStr = str.slice(start);
    const reverseStr = lastStr.slice(0, space).split('').reverse().join('');
    return reverseStr + newStr + lastStr.slice(space);
 }

//获取新的字符串
const getDisposedStr = (text, offset, randNum, insertTimes) => {
    const front = getInsertFontStr(text, offset + randNum + insertTimes*2, '\u202e');
    const last =  getInsertLastStr(text, offset + randNum + insertTimes*2, '\u202c');
    return front + last;
}

//获取随机数
const getRandomNumber = (min, max) => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

//插入字符
export const randInsertCharacters = (text) => {
    if (!isOpenPreventFold()) return text;
    const convertText = truncated(text, text.length);
    let copyText = convertText;
    let insertTimes = 0;
    convertText.replace(/[\u4e00-\u9fa5]+/g, (result, offset) => {
        if (result.length < 5) return;
        if (result.length <= cutLength) {
            const randNum = getRandomNumber(1, result.length - space - 1);
            copyText = getDisposedStr(copyText, offset, randNum, insertTimes);
            insertTimes++;
        }else{
            const times = Math.round(result.length / cutLength);
            let remainder = result.length % cutLength;
            for (let i = 0; i < times; i++) {
                const currOffset = offset + i* cutLength;
                remainder = remainder > 4 ? remainder : remainder + cutLength;
                const cutLen = (i == times - 1) ? remainder : cutLength;
                const randNum = getRandomNumber(1, cutLen - space - 1);
                copyText = getDisposedStr(copyText, currOffset, randNum, insertTimes);
                insertTimes++;
            }
        }
    })
    return copyText;
}

module.exports = {
    randInsertCharacters,
}