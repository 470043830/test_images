const logger = wx.getLogManager({ level: 0 });

const VERSION = "1.0.106";



function log(...args) {
  console.log(...args);
  logger.log(VERSION, ...args);
}

module.exports = {
  log,
};