const shop = require('./app_shop.js');

export const shopIds = [
  shop.oneShop,
  { phone: '13666668888_', id: 'A201905291653236670027260', appid: 'tt435035eddc6e1ccc01' },
  { phone: '13666668888_', id: 'A201905291653236670027260', appid: 'ttc30ab5b75c349c8e01' },
];