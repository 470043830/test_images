// import { $wuxToast, $cartSheet } from '../components/wux';
import commonGrid, { addUrl, addAlbumUrl, getGoodsUrl } from './common-grid';

const constant = require('./constant');
const util = require('./util');
const circleUtil = require('./circle-util.js');
const logic = require('./logic');

const app = getApp();

const bury = require('./burypoint');

function iconTap111(ev) {
    const { shopId } = ev.currentTarget.dataset;

    wx.navigateTo({
        url: `/pages/follow_detail/index?shop_id=${shopId}`
    });
}


function onTitleTap(item) {
    //for mini check
    if (!circleUtil.isMiniChecked()) {
        return;
    }
    // if (item.title && item.title.length > 130){
    //     return;
    // }
    const { shop_id, goods_id, category = 0 } = item;
    console.log('onTitleTap...', item, category);

    // wx.navigateTo({
    //     url: `/pages/goods_detail/index?shop_id=${shop_id}&goods_id=${goods_id}`
    // });
    let url = `/pages/goods_detail_circle/index?shop_id=${shop_id}&goods_id=${goods_id}`;

    if (category == 0){
        url += '&from=wsxc';
    }
    console.log('url: ', url);

    wx.navigateTo({
        url,
        success: function (res) {
            res.eventChannel.emit('acceptGoodsItemData', item);
        }
    });

}

function onReportTap(e) {
    console.log('onReportTap...', e);
    wx.showToast({ title: '举报成功' });
}

function iconTap(ev) {
    const { shopId, followStatus } = ev.currentTarget.dataset;

    console.log('iconTap ', ev.currentTarget.dataset);
    let itemList = ['产品图册', 'Ta的发布'];

    circleUtil.onShopItemTap(shopId, true);
}

function titleTap(ev, _this) {
    const { dataset } = ev.currentTarget;
    const { index, rows, themeType, href } = dataset;
    let that = this.data ? this : _this;
    const { list } = that.data;
    const key = `list[${index}].rows`;

    console.info('title', dataset);
    if (themeType === 3) {
        let content = '小程序暂不支持此操作，请关注【微商相册】公众号，确认即复制微信号：mmicroboss';
        wx.showModal({
            title: '提示',
            content: content,
            confirmText: '确认',
            confirmColor: '#3cc51f',
            success: function (res) {
                if (res.confirm) {
                    console.log('用户点击确定');

                    // 跳转至app下载教程页面
                    wx.navigateTo({
                        url: '/pages/app/index'
                    });
                } else if (res.cancel) {
                    console.log('用户点击取消');
                }
            }
        });
    } else {
        // that.setData({
        //     [key]: rows ? 0 : constant.ROWS
        // });

        //console.log('this.onTitleTap=', this.onTitleTap, dataset, list);
        onTitleTap(list[index]);
        // if (this.onTitleTap) {
        //     this.onTitleTap(dataset);
        // }
    }
    return false;
}


function onViewImg(e, _this) {
    console.log("onViewImg", this.data, e.target.dataset);
    const { index, imgssrc, goodsIndex } = e.target.dataset;
    const current = imgssrc[index];
    let that = this.data ? this : _this;
    const { list } = that.data;
    // const urls = list.map(item => item.imgsSrc)
    //     .reduce((prev, curr) => [...prev, ...curr]);

    console.log("onViewImg, list[goodsIndex]: ", list[goodsIndex], goodsIndex);
    // wx.previewImage({
    //     current, // 当前显示图片的http链接
    //     urls, // 需要预览的图片http链接列表
    // });

    // console.log('list: ', list.length, list);
    const { previewList, previewIndex } = util.getPreviewerInitData(list, goodsIndex, index, true);
    // console.log('goodsIndex: ', goodsIndex);
    // console.log('index: ', index)
    // console.log('previewList: ', previewList.length, previewList);

    that.triggerEvent('previewImgs', {
        previewList,
        previewIndex,
    });

}

function onViewVideo(e, _this) {
    let that = this.data ? this : _this;

    const { index } = e.target.dataset;
    const key = `list[${index}].showVideo`;

    that.setData({
        [key]: true
    });

}

function onAddTheme(e, _this) {
    const { index } = e.target.dataset;
    let that = this.data ? this : _this;
    const { list } = that.data;
    const { shop_id, goods_id } = list[index];
    const url = `${addUrl}&shop_id=${shop_id}&goods_id=${goods_id}`;

    console.info("onAddTheme", index, e);
    wx.showLoading({
        mask: true,
        title: '加载中...',
    });
    util.fetch(url)
        .then(res => {
            const { errcode, result } = res.data;

            wx.hideLoading();
            if (errcode == 0) {
                const { follow_object } = result;

                // 未关注
                if (follow_object) {
                    this.showGuide(shop_id, follow_object);
                    return false;
                }

                // 分享
                this.onShareTheme(e, that);
            }
        }, err => {
            console.info('onAddTheme error', err);

            wx.hideLoading();
        });
}

function onShareTheme(e, _this) {
    let { dataset } = e.currentTarget;
    const that = this.data ? this : _this;
    const { list } = that.data;

    const bury_config = app.globalData.bury_config;
    //  bury.profileBury('share_product', bury_config);

    let goods = {};
    let index = -1;
    if (e.type && e.type === 'onShare') {
        if (typeof that.data.goods === 'object' && that.data.goods && that.data.goods.goods_id) {
            dataset.item = that.data.goods;
        } else {
            const { goods_id } = e.detail;
            index = list.findIndex(item => item.goods_id === goods_id);
            goods = list[index];
            dataset.item = goods;
        }
        dataset = {
            ...dataset,
            ...e.detail,
        };
    } else {
        index = dataset.index;
        goods = list[index];
    }

    const { title } = goods;

    // 复制标题
    // this.copyTitle(util.getTextTitle(title));
    // dataset.title = util.getTextTitle(title);
    // 分享
    // that.shareIndex = index;
    let sharedata = {
        index
    };
    wx.setStorageSync('share_index', sharedata);
    logic.showshare(dataset, this.downloadStartCB.bind(this), this.downloadingCB.bind(this), this.onAddThemeToAlbum.bind(that), _this || that);
}

function onAddThemeToAlbum(dataset, callback, _this) {
    const { index, is_added } = dataset;
    const addUrl = addAlbumUrl;

    let that = this.data ? this : _this;
    const { list, goods } = that.data;

    const { shop_id, goods_id } = index >= 0 ? list[index] : goods;
    const url = `${addUrl}&shop_id=${shop_id}&goods_id=${goods_id}`;

    console.info("onAddThemeToAlbum", dataset);

    if (is_added) {
        typeof callback == 'function' && callback();
        return false;
    }

    wx.showLoading({
        mask: true,
        title: '加载中...',
    });
    util.fetch(url)
        .then(res => {
            const { errcode, result } = res.data;

            wx.hideLoading();
            if (errcode == 0) {
                const { follow_object } = result;
                const key = index >= 0 ? `list[${index}].is_added` : 'goods.is_added';
                const key_shop_id = index >= 0 ? `list[${index}].share_shop_id` : 'goods.share_shop_id';
                const key_goods_id = index >= 0 ? `list[${index}].share_goods_id` : 'goods.share_goods_id';

                // 未关注
                if (follow_object) {
                    this.showGuide(shop_id, follow_object);
                    return false;
                }

                console.info('onAddThemeToAlbum success', res);
                that.setData({
                    [key]: true,
                    [key_shop_id]: result.shop_id,
                    [key_goods_id]: result.goods_id,
                });

                typeof callback == 'function' && callback();
            }
        }, err => {
            console.info('onAddThemeToAlbum error', err);

            wx.hideLoading();
        });
}

function onAddCartTheme(e, _this) {
    console.log(e);
    const that = this.data ? this : _this;
    const { list } = that.data;

    let goods = {};
    if (e.type && e.type === 'onAddCart') {
        if (typeof this.data.goods === 'object' && this.data.goods && this.data.goods.goods_id) {
            goods = this.data.goods;
        } else {
            const { goods_id } = e.detail;
            goods = list.find(item => item.goods_id === goods_id);
        }
    } else {
        const { dataset } = e.currentTarget;
        const { index } = dataset;
        goods = list[index];
    }

    const bury_config = app.globalData.bury_config;
    bury.profileBury('add_to_shopping_cart', bury_config);

    const { shop_id, goods_id, skus = [] } = goods;
    console.info("skus", skus);
    console.info("skus", goods.hasOwnProperty('skus'));

    //   if (skus.length){
    //     this.$cartSheet.onShow(goods);
    //   }else{
    const url = `${getGoodsUrl}&shop_id=${shop_id}&goods_id=${goods_id}&is_spot_format=true&is_add_purchase=true`;
    wx.showLoading({
        mask: true,
        title: '加载中...',
    });

    util.fetch(url)
        .then(res => {
            const { errcode, result } = res.data;
            console.log('点击购物车返回数据: ', res.data);
            wx.hideLoading();
            if (errcode == 0) {
                // that.$cartSheet.onShow(result);
                if (this.data) {
                    this.$cartSheet.onShow(result);
                } else {
                    console.log('triggerEvent---------->');
                    _this.triggerEvent('showCartSheet', result);

                }
                //TODO:临时先触发组件调用者来调用
            }
        }, err => {
            console.info('onAddThemeToAlbum error', err);

            wx.hideLoading();
        });
}

function onTapTag(e, _this) {
    console.log(e);
    //for mini check
    if (!circleUtil.isMiniChecked()) {
        return;
    }

    const { tagId, shop_id } = e.currentTarget.dataset;

    const route = '/pages/tag_goods_list/index';
    const options = {
        shop_id: shop_id,
        tag_id: tagId,
        from: "tags",
    };
    util.navigateTo(route, options);
}

export default Object.assign({}, commonGrid, {
    iconTap,
    titleTap,
    onReportTap,
    onViewImg,
    onViewVideo,
    onAddTheme,
    onShareTheme,
    onAddThemeToAlbum,
    onAddCartTheme,
    onTapTag,
});
