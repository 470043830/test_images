// pages/select-leimu/index.js
const app = getApp();

Page({

    /**
     * 页面的初始数据
     */
    data: {
        items: [
            {
                name: '运动',
                checked: false
            },
            {
                name: '时尚',
                checked: false
            }
        ],

        tagInputValue: ''
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        const { tagsShowText = '', platform = '' } = options;

        console.log('options tagsShowText: ', tagsShowText);
        let config_tags = getApp().getCircleCategoryList();
        console.log('config_tags: ', config_tags);
        if (platform) {
            this._limitCount = 10;
            config_tags = [
                { categoryName: "抖音", circleId: "CID000009", level: 1 },
                { categoryName: "快手", circleId: "CID000009", level: 1 },
                { categoryName: "视频号", circleId: "CID000009", level: 1 },
                { categoryName: "其他", circleId: "CID000009", level: 1 }];
        } else {
            this._limitCount = 3;
        }
        if (config_tags) {
            // console.log('config.tags: ', config_tags);
            this.initItemsChecked(config_tags, tagsShowText);
            this.setData({ items: config_tags }, () => { });
        }

        // wx.setNavigationBarTitle({
        //     title: '选择经营品类',
        // });
    },

    initItemsChecked(tags, tagsShowText) {
        if (!tagsShowText) return;
        let texts = tagsShowText.split(',');
        let allTexts = this.getTagsShowText(tags, true);

        // console.log('texts: ', texts);

        for (let index = 0; index < texts.length; index++) {
            if (allTexts.indexOf(texts[index]) == -1) {
                tags.push({
                    id: '000',
                    categoryName: texts[index],
                })
            }
        }

        for (let index = 0; index < tags.length; index++) {
            if (texts.indexOf(tags[index].categoryName) != -1) {
                tags[index].checked = true;
            }
        }

        // console.log('tags: ', tags);
    },

    onAddTagInputConfirm(e) {
        console.log('onAddTagInputConfirm: ', e.detail.value);
        if (e.detail.value) {
            const { items } = this.data;

            items.push({
                id: '000',
                name: e.detail.value,
                checked: true
            })
            this.setData({ items, tagInputValue: '' });
        }
    },

    onTagTap(e) {
        const { items } = this.data;
        const { index } = e.currentTarget.dataset;
        let count = 0;

        for (let i = 0; i < items.length; i++) {
            if (items[i].checked) count++;
        }
        if (!items[index].checked && count >= this._limitCount) {
            wx.showToast({
                icon: 'none',
                title: '最多只能选三个品类',
            });
            return;
        };
        items[index].checked = !items[index].checked;
        this.setData({ items });
    },

    getTagsShowText(tags, isAll) {
        let ret = '';
        if (tags) {
            for (let index = 0; index < tags.length; index++) {
                const element = tags[index];
                (isAll || element.checked) && (ret += (element.categoryName + ','));
            }
            ret.length > 0 && (ret = ret.substr(0, ret.length - 1));
        }
        return ret;
    },

    onConfirmTap() {

        const { items } = this.data;
        // let selectLeimuStr = '';
        // for (let index = 0; index < items.length; index++) {
        //     const element = items[index];
        //     element.checked && (selectLeimuStr += (index.toString().padStart(2, '0') + '_'));
        // }
        // selectLeimuStr.length > 0 && (selectLeimuStr = selectLeimuStr.substr(0, selectLeimuStr.length - 1));

        // console.log('selectLeimuStr: ', selectLeimuStr);
        const eventChannel = this.getOpenerEventChannel()

        if (eventChannel.emit) {
            // console.log('111111111111111');
            eventChannel.emit('acceptDataFromSelectTagPage', { tagsShowText: this.getTagsShowText(items) });
            wx.navigateBack();
        }
    },

    // onCellTap(e) {
    //     const { items } = this.data;
    //     const { index } = e.currentTarget.dataset;

    //     items[index].checked = !items[index].checked;
    //     this.setData({ items });
    //     console.log('onCellTap ', index);
    // },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
});
