

const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const constant = require('../../utils/constant');
const app = getApp();


Page(Object.assign({},  {
    data: {
        shopInfo: {},
        interfaceAct: ''
    },

    onLoad(options) {
        console.log('onLoad', options);

        const { customBar } = app.getCustomBarInfo();

        this.setData({
            customBar
        });

        //...
        this.startTitleBarObserver();
        this.fetcShopInfo(options.wxid);

    },

    async fetcShopInfo(wxid) {
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url: `/circle/circle_new_interface.jsp?act=getWxTempShopInfo&wxid=${wxid}` });

        console.log('fetcShopInfo, result: ', result);

        if (isOk) {
            this.setData({ shopInfo: result.shop_info, interfaceAct: `getWxMomentGoods&wxid=${result.shop_info.wxid}` }, () => {
                const dynamicList = this.selectComponent('#dynamic-list');

                if (!dynamicList) {
                    return;
                }
                this.setData({ dynamicList });
            });
        }
    },

    onBackTap(){
        wx.navigateBack();
    },


    async startTitleBarObserver() {
        const { customBar } = app.getCustomBarInfo();
        const top = -(customBar); //-(customBar + 45);

        this._observer = wx.createIntersectionObserver(this);
        this._observer.relativeToViewport({ top, bottom: 300 }).observe('#the-title-watcher', (res) => {
            console.log('the-title-watcher ', res.intersectionRatio);
            const showWhiteBar = res.intersectionRatio == 0;
            if (showWhiteBar != this.data.showWhiteBar) {
                // this.setData({ showWhiteBar, stickStyle: showWhiteBar ? `position:fixed; top:${customBar}px;z-index: 999;` : `` });
                this.setData({ showWhiteBar });
            }
        });
        console.log('this._observer: ', this._observer);

        // const ret = await circleUtil.querySingleSelector('#the-up-parter');
        // // console.log('ret: ', ret);
        // if (ret) {
        //     this._stickScrollTop = (ret.bottom - ret.top) - customBar;
        //     console.log('this._stickScrollTop: ', this._stickScrollTop, customBar);
        // }
    },


    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
     onPullDownRefresh: function () {
        const { dynamicList } = this.data;
        if (dynamicList) {
            dynamicList.onPullDownRefresh();
        }
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    // onReachBottom: function () {
    //     const { dynamicList } = this.data;
    //     if (dynamicList) {
    //         dynamicList.onReachBottom();
    //     }
    // },
}))
