
const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const circleData = require('../../utils/circle-data.js');
const app = getApp();

const testJson = `[{"name":"活动","list":[{"name":"活动1","img":"https://xcimg.szwego.com/circle_images/temp/category_img001.png"},{"name":"活动2","img":"https://xcimg.szwego.com/circle_images/temp/category_img002.png"}]},{"name":"百元多件","list":[{"name":"连衣裙","img":"https://xcimg.szwego.com/circle_images/temp/category_img001.png"},{"name":"连衣裙2","img":"https://xcimg.szwego.com/circle_images/temp/category_img001.png"}]},{"name":"上装","list":[{"name":"上装1","img":"https://xcimg.szwego.com/circle_images/temp/category_img001.png"},{"name":"上装2","img":"https://xcimg.szwego.com/circle_images/temp/category_img002.png"}]},{"name":"裤装","list":[{"name":"裤装1","img":"https://xcimg.szwego.com/circle_images/temp/category_img001.png"},{"name":"裤装2","img":"https://xcimg.szwego.com/circle_images/temp/category_img002.png"}]}]`;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    vtabs: [],
    activeTab: 0,
    scrollListHeight: 0,
    searchList: [],
    searchValue: '',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setScrollListHeight();
    // this.fetchAlbumTags();
    // this.fetchCategory();
    // this._tempTabIndex = 0;

    wx.showShareMenu({
      // withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    });
  },

  onShow() {
    setTimeout(async () => {
      // await circleUtil.getCircleConfigData();
      // this.setData({
      //     isMiniChecked: circleUtil.isMiniChecked()
      // });
      this.fetchTestData();
    }, 100);
  },

  // 允许当前页面可分享
  // onShareAppMessage() {

  // },

  setScrollListHeight() {
    const { windowHeight } = wx.getSystemInfoSync();

    this.setData({ scrollListHeight: windowHeight - 42 });
  },

  onVTabChange(ev) {
    // console.log('onVTabChange ', ev.detail.index);
    // this._tempTabIndex = ev.detail.index;
  },

  onSearchConfirm(e) {
    console.log('onSearchConfirm: ', e);
    const {
      inputVal, searchImg
    } = e.detail;

    // this.searchHandler(inputVal, searchImg);
    if (inputVal) {
      this.setData({
        searchValue: inputVal,
        searchList: this.getShopsBySearch(this._tempShops, inputVal)
      })
    } else {
      this.setData({
        searchValue: '',
        searchList: []
      })
    }
  },

  onItemTap(ev) {
    console.log('onItemTap', ev);
    const { shopid } = ev.currentTarget.dataset;
    circleUtil.onShopItemTap(shopid, true);

    // const tags = circleData.test_getShopTags();
    // const shops = this.getShopsByTag(circleData.test_getShops(), tags[3]);

    // const vtabs = [];
    // for (let index = 0; index < tags.length; index++) {
    //     vtabs[index] = {
    //         title: tags[index],
    //         list: this.getShopsByTag(shops, tags[index]),
    //     };
    // }
    // this.setData({
    //     vtabs
    // });

    // this.setData({ searchList: !this.data.searchList });

    // setTimeout(() => {
    //     this.setData({ activeTab: this._tempTabIndex });
    // }, 200);
  },

  getShopsBySearch(shops, searchValue) {
    let list = [];
    for (let index = 0; index < shops.length; index++) {
      const element = shops[index];
      if (element.categoryList.indexOf(searchValue) >= 0 || element.shopName.indexOf(searchValue) >= 0) {
        list.push(element);
      }
    }
    return list;
  },

  getShopsByTag(shops, tag) {
    let list = [];
    for (let index = 0; index < shops.length; index++) {
      const element = shops[index];
      if (element.categoryList.indexOf(tag) >= 0) {
        list.push(element);
      }
    }
    return list;
  },

  async fetchTestData() {
    let cateList = getApp().getCircleCategoryList();
    if (cateList.length <= 0) {
      await circleData.getCircleConfig();
      await circleData.getCircleCategoryList();
    }
    const tags = circleData.test_getShopTags();
    const shops = await circleData.test_getShops();

    if (!circleUtil.isMiniChecked()) {
      tags.pop();
    }

    this._tempShops = shops;
    console.log('tags: ', tags);
    console.log('shops: ', shops);
    console.log('shops222: ', this.getShopsByTag(shops, tags[0]));

    const vtabs = [];
    for (let index = 0; index < tags.length; index++) {
      vtabs[index] = {
        title: tags[index],
        list: this.getShopsByTag(shops, tags[index]),
      };
    }
    this.setData({
      vtabs
    });
  },

  async fetchCategory() {
    const { isOk, result = {} } = await circleUtil.fetchNetData({ url: `/circle/circle_new_interface.jsp?act=getCategory` });
    const { marketList } = this.data;

    console.log('fetchCategory, result: ', result);

    if (isOk) {
      const { json = '' } = result;
      let config = {};
      if (circleUtil.isMiniChecked()) {
        config = JSON.parse(json);
      } else {
        config = JSON.parse(json); //JSON.parse(testJson);
      }
      console.log('fetchCategory, config: ', config);
      // wx.setStorageSync("fetchCategory", config);

      const vtabs = [];
      for (let index = 0; index < config.length; index++) {
        vtabs[index] = {
          title: config[index].name,
          list: config[index].list,
          banner: config[index].banner,
        };
      }
      this.setData({
        vtabs
      });
    }
  },

  async fetchAlbumTags() {
    const ids = ['A201905221104126960117302', 'A201905221104126960117302', 'A201901072005237390193874', 'A202011061409356090046755'];

    const { isOk, result = {} } =
      await circleUtil.fetchNetData({ url: `https://www.wsxcme.com/commodity/tags?hasVideo=0&hideUnCategorized=true&albumId=${ids[0]}` });

    // wx.setStorageSync("fetchAlbumTags", result);

    const { allTags, tagGroups } = result;
    const config = [];
    const tag_list = [];
    const tag_list_temp = {}; //for ingnore repeat tag
    for (let index = 0; index < tagGroups.length; index++) {
      const groupName = tagGroups[index].groupName;
      const childrenTag = tagGroups[index].childrenTag;
      const list = [];

      for (let j = 0; j < childrenTag.length; j++) {
        const tag = this.getChildrenTag(allTags, childrenTag[j]);
        const tagName = tag.tagName.replace('.', '');
        list.push({ id: tag.tagId, name: tagName, img: tag.tagImage });
        if (!tag_list_temp[tagName]) {
          tag_list_temp[tagName] = 1;
          tag_list.push({ id: tag.tagId, name: tagName });
        }

      }

      // vtabs[index] = {
      //     title: tagGroups[index].groupName,
      //     list: list
      // };
      console.log("groupName: ", groupName);
      if (groupName != '未分组' && list.length > 0) {
        config[index] = {
          name: tagGroups[index].groupName,
          list: list
        };
      }

    }
    config[0].banner = "https://xcimg.szwego.com/o_1fdhfv8dn1drq174o1fiifpq1enn12.png?imageMogr2/auto-orient/thumbnail/!310x310r/quality/100/format/jpg";
    wx.setStorageSync("config list", config);
    wx.setStorageSync("tag list", tag_list);
    // this.setData({
    //     vtabs
    // });
  },

  getChildrenTag(allTags, tagId) {
    console.log('getChildrenTag, tagId: ', tagId);
    for (let index = 0; index < allTags.length; index++) {
      if (allTags[index].tagId == tagId) {
        return allTags[index];
      }
    }
    return null;
  },

  onBoxItemTap(e) {
    const { item } = e.currentTarget.dataset;
    console.log('onBoxItemTap...', item);
    // wx.navigateTo({
    //     url: `/pages/category-goods/index?search=${item.name}`
    // });
    wx.navigateTo({
      url: `/pages/hm-shops/index?search=${item.name}`
    });
  },

  onSearchBarTap() {
    console.log('onSearchBarTap...');
    wx.navigateTo({
      url: `/pages/search-page/index`
    });
  },
});
