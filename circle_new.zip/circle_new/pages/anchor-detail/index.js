const circleData = require('../../utils/circle-data.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    anchorInfo: {},
    isShowNumber: false,
    actionStatus: false,
    qrcode: 'https://xcimg.szwego.com/o_1gr2jesad13kv1jm1ser38d1fns0.png',
    wechat: '13216169746',
    phone: '13216169746',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    const { shopId = '' } = options;
    console.log('anchor-detail onload, shopId:', shopId);

    //...
    this.startGetAnchorInfo(shopId);
  },

  async startGetAnchorInfo(albumId) {
    let anchorInfo = await circleData.getAnchorCircleApply({ albumId });
    console.log('anchorInfo: ', anchorInfo);

    anchorInfo.addr = '';
    if (anchorInfo.region) anchorInfo.addr = anchorInfo.region;
    // if (anchorInfo.detailAddress) anchorInfo.addr += ' ' + anchorInfo.detailAddress;

    const { anchorStatus = 0, merchantStatus = 0 } = getApp().getCircleStatus();
    const isShowNumber = merchantStatus == 3 || getApp().getCircleAdminValue() == 0 || 0;

    this.setData({ anchorInfo, isShowNumber });
  },

  onAddrNavTap(e) {
    const {
      latitude, // 纬度，范围为-90~90，负数表示南纬
      longitude,
      addr,
    } = this.data.anchorInfo;
    console.log('onAddrNavTap...', latitude, longitude);
    wx.openLocation({
      latitude: Number(latitude), // 纬度，范围为-90~90，负数表示南纬
      longitude: Number(longitude), // 经度，范围为-180~180，负数表示西经
      scale: 16, // 缩放比例
      name: addr,
      address: "..."
    });
  },

  onCopyTap(e) {
    console.log(e);
    const { id } = e.currentTarget;
    const text = this.data.anchorInfo[id];
    wx.setClipboardData({
      data: text,
      success(res) {
        wx.getClipboardData({
          success(res) {
            console.log('clip: ', res.data); // data
          }
        });
      }
    });
  },

  onPreviewQrcode() {
    console.log('onPreviewQrcode...');
    const { anchorInfo } = this.data;

    wx.previewImage({
      current: anchorInfo.wechatQrcode,
      urls: [anchorInfo.wechatQrcode]
    });
  },

  onContactTap() {
    this.setData({
      actionStatus: true
    })
  },

  onPreviewImgTap() {
    wx.previewImage({
      current: this.data.qrcode, // 当前显示图片的 http 链接
      urls: [this.data.qrcode] // 需要预览的图片 http 链接列表
    })
  },

  onCopyWechat(e) {
    wx.setClipboardData({
      data: this.data.wechat,
      success(res) {
        wx.getClipboardData({
          success(res) {
            console.log(res.data); // data
          }
        });
      }
    });
  },

  onCopyPhone(e) {
    wx.setClipboardData({
      data: this.data.phone,
      success(res) {
        wx.getClipboardData({
          success(res) {
            console.log(res.data); // data
          }
        });
      }
    });
  },

  onMakeCall() {
    wx.makePhoneCall({
      phoneNumber: this.data.phone
    });
  },

  oncustomevent_ashide() {
    console.log('oncustomevent_ashide...');
    this.setData({
      actionStatus: false
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})