// pages/customer-radar/index.js
const circleUtil = require('../../utils/circle-util.js');

const template_1907 = "xtzpmSJaTikuwe6dDSDuMYiMpv0QSuFDSbRpkaxI0WU";

Page({

    /**
     * 页面的初始数据
     */
    data: {
        windowHeight: 600,
        messageCount: 0,
        customerList: [],
        isFromScanCode: false
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        // const { windowHeight } = wx.getSystemInfoSync();
        // console.log("windowHeight ", windowHeight);
        // this.setData({ windowHeight });
        // const images = [];
        // for (let index = 0; index < 5; index++) {
        //     images.push("https://xcimg.szwego.com/KK27JzV7Cy0oCsUbw68uh9eh8GPooa4S0hnZ0s-K-nGZdz2We6FT6d0Y3IgeLNkV.jpg");
        // }
        // this.setData({ images });

    },

    onShow(options) {
        console.log('radar, scene: ', getApp().globalData.entry_scene);
        const isFromScanCode = (getApp().globalData.entry_scene == 1047);
        this.setData({
            isFromScanCode
        });
        if (getApp().offline()) {
            circleUtil.showLoginModal();
            return;
        }

        this.getSubscribeCount();
        this.fetchCustomerList();
    },

    async fetchCustomerList() {
        const customerList = [];
        // const shopItem = {
        //     avatar: 'https://xcimg.szwego.com/HDvYvAZR9bL2s80SiHQSVfvBzeIIY0FTTG1xUCg7AT3AOYuY0nDXRdVD2pM2s1lJ.jpg',
        //     shopId: 'A2017060911234097505',
        //     shopName: '欧伊沁女装工厂直销',
        //     saveCount: 1,
        //     visitCount: 2,
        // };
        // for (let index = 0; index < 3; index++) {
        //     customerList.push(shopItem);
        // }
        const { albumId } = getApp().globalData.userInfo;
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url: `/circle/circle_new_interface.jsp?act=getMyRecords&shop_id=${albumId}` });

        if (isOk) {
            const { list = [] } = result;
            this.setData({ customerList: list });
        }

    },

    async getSubscribeCount() {
        const { albumId } = getApp().globalData.userInfo;
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url: `/circle/circle_new_interface.jsp?act=getSubscribeCount&shop_id=${albumId}` });

        if (isOk) {
            const { count = 0 } = result;
            this.setData({ messageCount: count });
        }
    },

    async incSubscribeCount() {
        const { albumId } = getApp().globalData.userInfo;
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url: `/circle/circle_new_interface.jsp?act=incSubscribeCount&shop_id=${albumId}` });

        if (isOk) {
            setTimeout(() => {
                this.getSubscribeCount();
            }, 100);
        }
    },

    recvSubscribeMessage() {
        const { albumId } = getApp().globalData.userInfo;
        circleUtil.fetchNetData({ url: `/circle/circle_new_interface.jsp?act=subscribeSendClickTest&shop_id=${albumId}` });
    },

    async onAddMsgTap() {
        const ret = await this.addSubscribeMessage();
        console.log('onAddMsgTap, ret: ', ret);
        if (ret == 'accept') {
            this.incSubscribeCount();
        }
    },

    addSubscribeMessage() {
        //订阅消息
        const templateId = template_1907; //'RicDQlVCFdOsG7RIyu4fcuIbrs5BKbBvcnux3LnF3CI';
        console.log('触发订阅消息: ', templateId);

        // wx.requestSubscribeMessage({
        //     tmplIds: [templateId],
        //     success: (res) => {
        //         console.log('触发订阅消息成功: ', res);
        //         this.incSubscribeCount();
        //         // const { messageCount } = this.data;
        //         // this.setData({ messageCount: messageCount + 1 });
        //     },
        //     fail(res) {
        //         console.log('触发订阅消息失败: ', res);
        //     }
        // });

        return new Promise((resolve, reject) => {
            wx.requestSubscribeMessage({
                tmplIds: [templateId],
                success: (res) => {
                    console.log('触发订阅消息成功: ', res[templateId]);
                    resolve(res[templateId]);
                },
                fail: (res) => {
                    console.log('触发订阅消息失败: ', res);
                    reject('reject');
                }
            });

        });
    },

    oabindload(e) {
        console.log('oabindload: ', e);
    },

    oabinderror(e) {
        console.log('oabinderror: ', e);
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },



    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
});
