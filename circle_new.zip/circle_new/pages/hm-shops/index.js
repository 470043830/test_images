import { $tdSearchbar, $tdUploader, $wuxToast } from '../../components/wux';
import nineGrid from '../../utils/nine-grid';


const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const constant = require('../../utils/constant');
const app = getApp();


Page({
    data: {
        list: []
    },

    onLoad(options) {
        console.log('onLoad', options);


        wx.setNavigationBarTitle({
            title: options.search,    //页面标题
        });

        //
        this.getShopsAndGoods(options.search);

    },

    onItemTap(ev) {
        console.log('onItemTap', ev);
        const { shopid } = ev.currentTarget.dataset;
        circleUtil.onShopItemTap(shopid, true);
    },

    async getShopsAndGoods(search_value) {
        console.log('getShopsAndGoods');
        let param = {
            search_value
        };
        const url = '/circle/circle_new_interface.jsp?act=getShopsAndGoods';

        // this.setData({ loading: true });
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url, param });

        if (isOk) {
            console.log('result: ', result);
            const { list = [] } = result;
            for (let index = 0; index < list.length; index++) {
                const element = list[index];
                if (element.tagNames.length > 3) {
                    element.tagNames = element.tagNames.slice(0, 3);
                }

            }
            this.setData({ list, noShopData: list.length <= 0 })
        }
    },


    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {
        const { dynamicList } = this.data;
        if (dynamicList) {
            dynamicList.onPullDownRefresh();
        }
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
        const { dynamicList } = this.data;
        if (dynamicList) {
            dynamicList.onReachBottom();
        }
    },

});
