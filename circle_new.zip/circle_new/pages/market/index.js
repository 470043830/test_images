import {$tdSearchbar, $tdUploader, $wuxToast} from '../../components/wux';
import nineGrid from '../../utils/nine-grid';

const util = require('../../utils/util.js');
const logic = require('../../utils/logic.js');
const constant = require('../../utils/constant');
const app = getApp();

function getData() {
    return {
        // getUrl: [
        //     '/data/dynamic_2.json?',
        //     '/data/dynamic_1.json?',
        // ],
        getUrl: [
            '/circle/miniapp_circle_main.jsp?act=get_market_store',
            '/circle/miniapp_circle_themes_list.jsp?act=get_circle_themes_plaza',
        ],
        addUrl: '/album/album_theme_operation.jsp?act=hold_theme',

        loading: false,
        loadingNoData: false, // 无数据
        loadingEnd: false, // 到底了
        filterText: '',
        filterImg: '',
        latestTime: '',
        listIndex: 0,
        page_index: 1,
        list: [],
        floorId: '',
        navs: [{ label: '档口' }, { label: '商户动态' }],
        priceTypesObj: constant.priceTypesObj,
    };
}

Page(Object.assign({}, nineGrid, {
    data: getData(),

    onLoad(options) {
      const { market_id, floor_idx } = options;

        console.log('onLoad', options);
        this.market_id = market_id;
        this.floor_idx = floor_idx&&floor_idx+'楼'
        this.floor_idx && this.setData({ filterText: this.floor_idx })
        this.searchbar = $tdSearchbar.init({
            style: 'border: none',
            inputVal: this.floor_idx,
            // image: true,
            searchHandler(text, img) {
                const { listIndex } = this.page.data;

                console.info(`text: ${text}`, `img: ${img}`);
                this.setData(Object.assign({}, getData(), {
                    listIndex,
                    filterText: text,
                    filterImg: img,
                }));
                this.page.fetchData();
            }
        });

        wx.showLoading({
            mask: false,
            title: '加载中...',
        });
        this.fetchData('', () => {
            const { market_name: title } = this.data;

            title && wx.setNavigationBarTitle({title});
            wx.hideLoading();
        });
    },

    navTap(ev) {
        const { index } = ev.target.dataset;
        const { listIndex, filterText, filterImg } = this.data;

        if (index == listIndex) {
            return false;
        }

        console.info('nav', index);
        wx.showLoading({
            mask: true,
            title: '加载中...',
        });
        this.setData(Object.assign({}, getData(), {
            listIndex: index,
            filterText,
            filterImg,
        }));
        this.fetchData('', () => {
            wx.hideLoading();
        });
    },

    onTapFloor(ev) {
        const { dataset } = ev.target;
        const { floorId } = dataset;
        // const id = `floor_${floorId}`;

        console.info(ev);
        this.setData({floorId});
    },

    onShareAppMessage(res) {
        if (res.from === 'button') {
            // 来自页面内转发按钮
            console.log(res.target);
        }

        const { list, share_title } = this.data;
        const length = list.length;
        let path = '';
        let title = '';
        let imageUrl = '';

        console.log("test:" + length);
        if (this.shareIndex >= 0 && this.shareIndex < length) {
            const goods = list[this.shareIndex];
            const { shop_id, goods_id, imgsSrc, share_shop_id, share_goods_id } = goods;

            title = goods.title;
            path = `pages/goods_detail/index?goods_id=${share_goods_id || goods_id}&shop_id=${share_shop_id || shop_id}`;
            imageUrl = imgsSrc[0] || '';
        } else {
            title = share_title || '';
            path = `pages/market/index?market_id=${this.market_id}`
        }
        this.shareIndex = -1;

        return {
            title: title,
            path: path,
            imageUrl,
            success: function (res) {
                // 转发成功
            },
            fail: function (res) {
                // 转发失败
            }
        };
    },

    getTimestamp() {
        const { list, latestTime } = this.data;
        const len = list.length;

        if (len > 0) {
            return {
                top: latestTime,
                bottom: list[len - 1].time_stamp
            };
        } else {
            return {
                top: '',
                bottom: ''
            };
        }
    },

    getUrl(type) {
        const { listIndex, page_index, getUrl, filterText, filterImg } = this.data;
        const { top, bottom } = this.getTimestamp();
        let url = `${getUrl[listIndex]}&market_id=${this.market_id}&search_img=${filterImg}`;

        if (listIndex == 0) {

            url = `${url}&page_index=${page_index}`;

        } else if (listIndex == 1) {

            switch (type) {
                case 'top':
                    url = `${url}&slip_type=0&time_stamp=${top || ''}`;
                    break;

                case 'bottom':
                    url = `${url}&slip_type=1&time_stamp=${bottom || ''}`;
                    break;
            }

        }

        return url;
    },

    fetchShop(callback) {
        const url = this.getUrl();

        console.info(url);
        this.setData({loading: true});
        let param = {
          search_value: this.data.filterText
        }
        util.fetchAuthInst(url, param, res => {
            const { errcode, result } = res.data;
            let obj = {};

            console.log(res);
            if (errcode == 0) {
                const { shop_list, ...others } = result;
                const { list } = this.data;

                obj = {...this.data, ...others};
                // obj.list = [...list, ...shop_list];
                obj.list = this.getShopList(list, shop_list);
                // 无数据
                obj.list.length <= 0 && (obj.loadingNoData = true);
                // 到底了
                shop_list.length <= 0 && (obj.loadingEnd = true);
            }
            obj.loading = false;

            this.setData(obj);
            typeof callback == 'function' && callback();

            // 清除失效token，触发重新获取
            app.clearToken(res.data, () => {
                this.onPullDownRefresh();
            });
        }, err => {
            console.log(err);
            this.setData({ loading: false });
            typeof callback == 'function' && callback();
        });
    },

    getShopList(list, shop_list) {
        list = [...list];
        shop_list = [...shop_list];
        const len = list.length;
        const sLen = shop_list.length;
        let arr = [];

        arr = [...list, ...shop_list];

        if (len > 0 && sLen > 0) {
            const lastFloor = list[len -1][0].floor;
            const firstFloor = shop_list[0][0].floor;

            if (firstFloor === lastFloor) {
                const [ last ] = list.splice(len - 1, 1);
                const [ first ] = shop_list.splice(0, 1);

                arr = [...list, [...last, ...first], ...shop_list];
            }
        }

        return arr;
    },

    fetchGoods(type, callback) {
        const url = this.getUrl(type);

        console.info(url);
        this.setData({loading: true});
        let param = {
          search_value: this.data.filterText
        }
        util.fetchAuthInst(url, param, res => {
          const { errcode, result, errmsg } = res.data;
            let obj = {};

            console.log(res);
            if (errcode == 0) {
                const { goods_list, ...others } = result;
                const { list, filterText } = this.data;

                obj = {...this.data, ...others};
                if (type == 'top') {
                    obj.list = this.getNoRepeatData(goods_list, list);
                } else {
                    obj.list = [...list, ...goods_list];
                    // 到底了
                    goods_list.length <= 0 && (obj.loadingEnd = true);
                }
                obj.list = obj.list.map(item => ({rows: constant.ROWS, richTitle: !!filterText ? util.getRichTitle(item.title, filterText) : undefined, ...item}));
                // 无数据
                if (obj.list.length <= 0) {
                    obj.loadingNoData = true;
                } else {
                    obj.loadingNoData = false;
                }
                obj.latestTime = this.getLatestTime(obj.list);
            }else{
              $wuxToast.show({
                type: 'text',
                text: errmsg
              });
            }
            obj.loading = false;

            this.setData(obj);
            typeof callback == 'function' && callback();

            // 清除失效token，触发重新获取
            app.clearToken(res.data, () => {
                this.onPullDownRefresh();
            });
        }, err => {
            console.log(err);
            this.setData({ loading: false });
            typeof callback == 'function' && callback();
        });
    },

    fetchData(type, callback) {
        const { listIndex } = this.data;

        switch (listIndex) {
            case 0:
                this.fetchShop(callback);
                break;

            case 1:
                this.fetchGoods(type, callback);
                break;
        }
    },

    getNoRepeatData(newData, oldData) {
        const data = [...newData, ...oldData];
        const len = data.length;
        const hash = {};
        const result = [];

        for (let i = 0; i < len; i++) {
            let goods = data[i];
            let goods_id = goods.goods_id;

            if (!hash[goods_id]) {
                hash[goods_id] = true;
                result.push(goods);
            }
        }

        // console.info(result);
        return result;
    },

    getLatestTime(data) {
        return data.map(item => item.time_stamp).filter(item => item)[0] || '';
    },

    onReachBottom() {
        const { listIndex, page_index, loading, loadingNoData, loadingEnd } = this.data;

        if (loading || loadingNoData || loadingEnd) {
            return false;
        }

        console.log("onReachBottom");
        if (listIndex == 0) {
            this.setData({
                page_index: page_index + 1
            });
        }

        this.fetchData('bottom');
    },

    onPullDownRefresh() {
        wx.hideLoading();
        const { listIndex, loading } = this.data;

        if (loading) {
            return false;
        }

        console.log("onPullDownRefresh");
        if (listIndex == 0) {
            this.setData(getData());
            this.searchbar.hideInput();
        }

        this.fetchData('top', () => {
            console.log("stopPullDownRefresh");
            wx.stopPullDownRefresh();
        });
    },

}))
