const app = getApp();
const constant = require('../../utils/constant');
const util = require('../../utils/util');
const circleData = require('../../utils/circle-data.js');
const { circle_id, circles } = constant;

Page({
  data: {
    canIUseGetUserProfile: false,
    circle_name: circles[circle_id],
  },

  onLoad(options) {
    if (wx.getUserProfile) {
      this.setData({
        canIUseGetUserProfile: true
      });
    }

    const { pagePath, pageParam = '' } = options;
    this._pagePath = pagePath;
    this._pageParam = pageParam;
    this._pageParam = this._pageParam.replace(/:/g, '=');
    this._pageParam = this._pageParam.replace(/,/g, '&');

    console.log('this._pagePath: ', this._pagePath);
    console.log('this._pageParam: ', this._pageParam);
  },

  onShow() {

  },

  onBtnTap() {
    if (circleData.isNeiWang) {
      wx.getClipboardData({
        success(res) {
          console.log('getClipboardData: ', res.data);
          let clip = res.data;
          clip.length > 100 && wx.showModal({
            title: '提示',
            content: res.data,
            success(res) {
              if (res.confirm) {
                wx.setStorageSync(constant.USER_INFO_STORAGE, { token: '' + clip, neiwang: 'for test' });
                wx.reLaunch({ url: '/pages/home/index?login=1' });
              } else if (res.cancel) {
              }
            }
          });
        }
      });
      return;
    }

    //go to miniapp to login in prod
    wx.navigateToMiniProgram({
      appId: 'wxb278781d654e8f81',
      path: 'pages/login/index?circle_id=' + constant.circle_id,
      extraData: {
        foo: 'bar'
      },
      // envVersion: 'trial',
      success(res) {
        // 打开成功
      }
    })
  },

  onLoginOk(info) {
    wx.hideLoading();

    console.log('info: ', info);
    if (this._pagePath) {
      const url = `/pages/${this._pagePath}/index?${this._pageParam}`;
      console.log('url: ', url);
      wx.reLaunch({ url });
    } else {
      // 授权成功：默认返回首页
      const options = wx.getStorageSync('homeOptions');
      // const url = `/pages/index/index${this.getParams(options)}`;
      const url = `/pages/home/index${this.getParams(options)}`;

      console.log('url: ', url);
      wx.removeStorageSync('homeOptions');
      wx.reLaunch({ url });
    }

  },
  getUserProfile(e) {
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认
    // 开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '用于完善用户资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        });
        wx.showLoading({
          mask: true,
          title: '登录中...',
        });
        util.login(
          this.onLoginOk,
          () => { console.log('login failed!'); },
          res.userInfo
        );
      }
    });
  },
  getUserInfo(e) {
    const { errMsg } = e.detail;

    if (errMsg === 'getUserInfo:ok') {

      wx.showLoading({
        mask: true,
        title: '登录中...',
      });
      util.login(
        this.onLoginOk,
        () => { console.log('login failed!'); }
      );

    }
  },

  getParams(options = {}) {
    let params = '';
    Object.keys(options).forEach(key => {
      let char = !params ? '?' : '&';
      let value = options[key];

      params += `${char}${key}=${value}`;
    });

    return params;
  },
});
