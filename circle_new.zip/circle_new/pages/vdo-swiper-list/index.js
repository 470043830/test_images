// pages/vdo-swiper-list/index.js
const circleUtil = require('../../utils/circle-util.js');

const app = getApp();

Page({

    /**
     * 页面的初始数据
     */
    data: {
        indicatorDots: false,
        vertical: true,
        circular: false,
        interval: 2000,
        duration: 200,
        previousMargin: 0,
        nextMargin: 0,
        controls: false,
        showPlayBtn: false,
        showProgress: false,
        autoplay: true,
        swiperCurrent: 0,
        swiperIndex: 0,
        videoSwipers: [],

        objectFit: "contain",
        closeTop: 20,
    },



    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        const { current } = options;
        const { statusBarHeight } = app.getCustomBarInfo();

        console.log("current: ", current);
        const eventChannel = this.getOpenerEventChannel();
        console.log("eventChannel: ", eventChannel);

        // 监听acceptDataFromOpenerPage事件，获取上一页面通过eventChannel传送到当前页面的数据
        if (eventChannel && eventChannel.on) {
            eventChannel.on('homeVideoList', (data) => {
                console.log('homeVideoList:', data);
                let videoSwipers = [];
                // let videoSwipers = data;
                for (let index = 0; index < data.length; index++) {
                    videoSwipers.push({ playStatus: 0, ...data[index] });
                }
                this.setData({ videoSwipers, closeTop: statusBarHeight, swiperCurrent: current, swiperIndex: current }, () => {
                    this.videoPlay(current);
                });
            });
        } else {
            // wx.reLaunch({ url: '/pages/vdo-swiper-list/index' });
        }

        this.videoContexts = [];
    },

    onCloseBtn() {
        wx.navigateBack();
    },


    getVideoContext(index) {
        if (!this.videoContexts[index]) {
            this.videoContexts[index] = wx.createVideoContext('video-index-' + index);
        }
        return this.videoContexts[index];
        // return wx.createVideoContext('video-index-' + index);
    },


    videoPlay(index) {
        const { videoSwipers } = this.data;

        this.getVideoContext(index).play();
        videoSwipers[index].playStatus = 1;

        let obj = {};
        obj[`videoSwipers[${index}]`] = { ...videoSwipers[index], playStatus: 1 };
        this.setData(obj);
    },

    videoPause(index) {
        const { videoSwipers } = this.data;
        if (videoSwipers[index].playStatus != 1) return;
        videoSwipers[index].playStatus = 2;

        this.getVideoContext(index).pause();

        let obj = {};
        obj[`videoSwipers[${index}]`] = { ...videoSwipers[index], playStatus: 2 };
        this.setData(obj);
    },

    videoPauseAll() {
        for (let index = 0; index < this.videoContexts.length; index++) {
            this.videoPause(index);
        }
    },

    onSwiperChange(event) {
        const { current } = event.detail;


        this.videoPauseAll();
        this.videoPlay(current);

        this.setData({
            swiperIndex: current
        });
    },

    onVideoTap() {
        const { videoSwipers } = this.data;
        const { swiperIndex } = this.data;
        console.log('onVideoTap...', swiperIndex);

        if (videoSwipers[swiperIndex].playStatus == 1) {
            this.videoPause(swiperIndex);
        } else {
            this.videoPlay(swiperIndex);
        }

    },

    bindtimeupdate() {

    },

    bindplay(e) {
        console.log('bindplay...', e);

    },

    binderror(e) {
        console.log('binderror...', e);
    },

    onUserAvatarTap(e) {
        console.log('onUserAvatarTap...', e);
        const { videoSwipers } = this.data;
        const { index } = e.currentTarget.dataset;
        // const shopId = "A202005081156220500000644";

        this._leavePage = true;
        this.videoPause(index);
        circleUtil.onShopItemTap(videoSwipers[index].info.shopId, true);
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
        if (this._leavePage) {
            this._leavePage = false;
            const { swiperIndex } = this.data;
            console.log('video list onShow...', swiperIndex);
            this.videoPlay(swiperIndex);
        }
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {
    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
});
