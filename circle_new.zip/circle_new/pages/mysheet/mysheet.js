// pages/mysheet/mysheet.js
const circleUtil = require('../../utils/circle-util.js');


const access_token = "44_Dvqd4DcloTPBWuFzLgIe2IlADsYL35OyPZpA7lO7ABWF5-W24CTanE_VliqwXMDyWivcZgYF21GbtPKnkq4n62SmCnIt8EhpCmKhYgOfigG8zGXG5aoK_iqMJOWu51PumqutO3w3Dz1du8P0IXRbAEAETN";

const component_access_token = `43_HFsSC5iO3U4l_X9hEktAKPf8psmvM_LpGL3ywfGg0AM_UEyjRlTXCwlbWHgaWds9V1YaszV_NH9ZS-lPanFTxRIZoksqlqAwOWb5RPSVf6PKxC1FvmDvTTzrNIfDXWyLgggf1-opR7eylzkwBVLdAAAOIY`;

Page({

    /**
     * 页面的初始数据
     */
    data: {
        actionStatus: false,
        cardInfo: {
            avatar: 'dasdasdas',
            name: '雕刻时光时尚女装批发店',
            addr: '荔秀服饰文化街区-102栋-50012',
            wechat: 'ddasdas',
            phone: '121212121'
        },
        textInfo: {
            texts: []
        },
        contentImgWidth: 0,
        contentImgHeight: 0,
        imgSrc: '',

    },

    onLoad () {
        this.setData({
            icon: '/assets/wode/Group 52.svg',
            icon1: '/assets/wode/tongzhizhongxin.svg',
            icon_red: '/assets/wode/Oval 4.svg',
            icon_arrow: '/assets/wode/jiantou.svg'
        });
    },

    product_get_list() {
        const url = "https://api.weixin.qq.com/product/spu/get_list?access_token=44__aB56aSE9wCDNz6-Y5bPHbXCzcsLxkS4aR55MitirZNl_vGvWvNHF96BHKnOhraNhd98-3gA2wxZecXi3jUD4qA6etoXTTRQXaIoTwwGJWQwJSgN_0pQUGKBmLEatCvl9xldT4jsi9SX9p2FFNMhAGDTBA";

        wx.request({
            url, //仅为示例，并非真实的接口地址
            method: 'POST',
            data: {
                status: 5,
                page: 1,
                page_size: 10
            },
            header: {
                'content-type': 'application/json' // 默认值
            },
            success(res) {
                console.log(res.data);
            }
        });
    },

    check_audit_status() {
        const info =
        {
            "authorizer_access_token": "43_-J4UuD-tSN9gzurKCTcDg3A_usHHJiC39ea7ZRs9kOLdOUrekwYUWgS5BDPIMjnl2MPf3Ym7L6A-fTnUUAjyNDRci8nIKZDcn_oUNz9mBs6g5OeuExcrLtn7JkF7OF407ek4cZSJC6mFhuTMBITaALDFMX", "expires_in": 7200, "authorizer_refresh_token": "refreshtoken@@@v4E755AAWdLwuGpqvWjZaqwxm22d5GgRhYmQApStFPQ"
        };
        // const url = `https://api.weixin.qq.com/product/register/check_audit_status?access_token=${info.authorizer_access_token}`;
        const url = `https://api.weixin.qq.com/product/register/check_audit_status?access_token=${component_access_token}`;

        wx.request({
            url, //仅为示例，并非真实的接口地址
            method: 'POST',
            data: {
                "wx_name": "liutao_weixin"
            },
            success(res) {
                console.log(res.data);
            }
        });

        const ret = `{"errcode":0,"data":{"merchant_info_status":2,"acct_verify_status":1,"basic_info_status":1,"pay_sign_status":1,"pay_audit_detail":[],"audit_reject_reasons":"","account_validation":{},"legal_validation_url":"","sign_url":"","register_status":0,"registered_appid":"wxb18ab686cb168e32"}}`;
        console.log("", JSON.parse(ret));
    },

    api_authorizer_token() {
        const url = `https://api.weixin.qq.com/cgi-bin/component/api_authorizer_token?component_access_token=${component_access_token}`;

        const authorizer = { "authorizer_appid": "wxb18ab686cb168e32", "refresh_token": "refreshtoken@@@v4E755AAWdLwuGpqvWjZaqwxm22d5GgRhYmQApStFPQ", "auth_time": 1617955349 };

        wx.request({
            url, //仅为示例，并非真实的接口地址
            method: 'POST',
            data: {
                "component_appid": "wx2f3765c83ab2f80f",
                "authorizer_appid": authorizer["authorizer_appid"],
                "authorizer_refresh_token": authorizer["refresh_token"]
            },
            // header: {
            //     'content-type': 'application/json' // 默认值
            // },
            success(res) {
                console.log(res.data);
            }
        });

        const ret = { "authorizer_info": { "nick_name": "", "service_type_info": { "id": 10 }, "verify_type_info": { "id": -1 }, "user_name": "gh_143c9acf43de", "alias": "", "qrcode_url": "http:\/\/mmbiz.qpic.cn\/mmbiz_jpg\/Yg7PsUHOh9YLUsC9GC0Qj9ExKRTKj6Bic4PrDwDmYK0p1olQN4ibJNf9rlm7wzv0YPTpZr7LtuO6vwKAzOiaq5DYg\/0", "business_info": { "open_pay": 0, "open_shake": 0, "open_scan": 0, "open_card": 0, "open_store": 0 }, "idc": 1, "principal_name": "个人", "signature": "", "MiniProgramInfo": { "network": { "RequestDomain": [], "WsRequestDomain": [], "UploadDomain": [], "DownloadDomain": [], "BizDomain": [], "UDPDomain": [] }, "categories": [], "visit_status": 0 } }, "authorization_info": { "authorizer_appid": "wxb18ab686cb168e32", "authorizer_refresh_token": "refreshtoken@@@v4E755AAWdLwuGpqvWjZaqwxm22d5GgRhYmQApStFPQ", "func_info": [{ "funcscope_category": { "id": 73 }, "confirm_info": { "need_confirm": 0, "already_confirm": 0, "can_confirm": 0 } }] } };


        const qrcode_url = `http://mmbiz.qpic.cn/mmbiz_jpg/Yg7PsUHOh9YLUsC9GC0Qj9ExKRTKj6Bic4PrDwDmYK0p1olQN4ibJNf9rlm7wzv0YPTpZr7LtuO6vwKAzOiaq5DYg/0`;
    },

    api_get_authorizer_list() {
        const url = `https://api.weixin.qq.com/cgi-bin/component/api_get_authorizer_list?component_access_token=${component_access_token}`;

        wx.request({
            url, //仅为示例，并非真实的接口地址
            method: 'POST',
            data: {
                "component_appid": "wx2f3765c83ab2f80f",
                "offset": 0,
                "count": 100
            },
            // header: {
            //     'content-type': 'application/json' // 默认值
            // },
            success(res) {
                console.log(res.data);
            }
        });
    },

    getRandId() {
        return new Date().getTime() + (Math.random() + "").substr(2);
    },

    getRandProductId() {
        return "out_product_id_" + this.getRandId();
    },

    getRandSkuId() {
        return "out_sku_id_" + this.getRandId();
    },

    getTestThumbImg() {
        return 'https://xcimg.szwego.com/o_1eib3kven1q6t196p154r1s3p1p5gv.jpg?imageMogr2/auto-orient/thumbnail/!310x310r/quality/100/format/jpg';
    },

    async addProduct() {
        const out_product_id = this.getRandProductId();

        const skus = [
            {
                out_product_id,
                out_sku_id: this.getRandSkuId(),
                "thumb_img": this.getTestThumbImg(),
                "sale_price": 12,
                "stock_num": 10,
                "sku_attrs":
                    [
                        {
                            "attr_key": "尺码",
                            "attr_value": "S"
                        }
                    ]
            }
        ];
        const product_info = {
            out_product_id,
            attrs: [],
            brand_id: 2100000000,
            cats: [{ level: 0, cat_id: 6033 }, { level: 0, cat_id: 6093 }, { level: 0, cat_id: 6096 }],
            express_info: { weight: 0, template_id: 15269433 },
            head_img: [
                "https://store.mp.video.tencent-cloud.com/161/20304/snscosdownload/SZ/reserved/606e80c30000b8b600000000629f9d09000000a000004f50",
                "https://xcimg.szwego.com/o_1ep19hurg18vfbd112e21okv1h16v.jpg?imageMogr2/auto-orient/thumbnail/!310x310r/quality/100/format/jpg"
            ],
            "desc_info":
            {
                "imgs":
                    [
                        "https://xcimg.szwego.com/o_1f12opqjj1a9s1hse7c0o2rgcor.jpg?imageMogr2/auto-orient/thumbnail/!310x310r/quality/100/format/jpg"
                    ]
            },
            model: "nice增强版",
            // skus: [{ out_sku_id: out_sku_id, sku_attrs: [] }],
            skus,
            sub_title: "SPU接口测试2",
            title: "最新测试口罩2"
        };

        await this.wxMiniShopInterface("spu/add", product_info);
    },

    async getProductList() {
        const post_data = {
            "status": 5,
            "page": 1,
            "page_size": 10,
            "need_edit_spu": 0      // 默认0:获取线上数据, 1:获取草稿数据
        };
        const { isOk, result = {} } = await this.wxMiniShopInterface("spu/get_list", post_data); //await circleUtil.fetchNetData({ url });
    },

    async getProduct() {
        const post_data = {
            "product_id": 29440749,
            // "out_product_id": "51514515",
            // "need_edit_spu": 1      // 默认0:获取线上数据, 1:获取草稿数据
        };
        const { isOk, result = {} } = await this.wxMiniShopInterface("spu/get", post_data); // await circleUtil.fetchNetData({ url });
    },

    async spuList() {  //上架
        const post_data = {
            "product_id": 29440749
        };
        const { isOk, result = {} } = await this.wxMiniShopInterface("spu/listing", post_data);
    },

    async getSku() {
        const post_data = {
            "sku_id": 33029193,
            "need_edit_sku": 0      // 默认0:获取线上数据, 1:获取草稿数据
        };
        const { isOk, result = {} } = await this.wxMiniShopInterface("sku/get", post_data);
    },

    async getSkuList() {
        const post_data = {
            "product_id": 29440749,
            "need_edit_sku": 1,     //	默认0:获取线上数据, 1:获取草稿数据
            "need_real_stock": 1    // 默认0:获取草稿库存, 1:获取线上真实库存
        };
        const { isOk, result = {} } = await this.wxMiniShopInterface("sku/get_list", post_data);
        console.log('result: ', result);
        return result;
    },


    async delSkus() {
        const { ret: { skus } } = await this.getSkuList();

        console.log('skus: ', skus);

        for (let index = 0; index < skus.length; index++) {
            const sku = skus[index];

            const post_data = {
                product_id: sku.product_id,
                sku_id: sku.sku_id
            };
            const { isOk, result = {} } = await this.wxMiniShopInterface("sku/del", post_data);
        }

    },

    async batchAddSku() {
        const colors = ['红色', '白色', '黑色'];
        const sizes = ['S', 'M', 'L'];
        const skus = [];
        const product_id = 29440749;

        for (let i = 0; i < colors.length; i++) {
            for (let j = 0; j < sizes.length; j++) {
                const item = {
                    product_id,
                    out_sku_id: this.getRandSkuId(),
                    thumb_img: this.getTestThumbImg(),
                    sale_price: 10 + i * 10,
                    market_price: 50,
                    stock_num: j * 2,
                    sku_attrs:
                        [
                            {
                                "attr_key": "尺码",
                                "attr_value": sizes[j]
                            },
                            {
                                "attr_key": "颜色",
                                "attr_value": colors[i]
                            }
                        ]
                };
                skus.push(item);
            }
        }

        const func = encodeURIComponent("sku/batch_add");
        const url = `/circle/circle_new_interface.jsp?act=wxShopInterface&wx_name=iamleesong&func=${func}`;
        const param = {};
        param.param = JSON.stringify({ skus });
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url, method: 'POST', param });
    },


    /**
     * @description 微信小商店接口
     * @param {*} name
     * @param {*} post_data
     * @returns
     */
    async wxMiniShopInterface(name, post_data) {
        const url = `/circle/circle_new_interface.jsp?act=wxShopInterface&func=${encodeURIComponent(name)}`;
        const param = {
            post_data: JSON.stringify(post_data)
        };
        const ret = await circleUtil.fetchNetData({ url, method: 'POST', param });
        return ret;
    },



    async apiGetAuthorizerInfo() {
        const info =
        {
            wx_name: "liutao_weixin",

            merchantinfo: {
                "appid": "wxb18ab686cb168e3222",
                "subject_type": "2",
                id_card_info:
                {
                    portrait_pic_file:
                    {
                        media_id: "5tXYcTIO90bogf8701Qm4LSjpXFC0QKILtbiuirOtPmg7Hh4qukzRFFC2Kj6QXtW",
                        pay_media_id: "ANgIotyXuXUjkTLd_v40mOypqYUppRh0LDDcah63EBbfB4gICk65a61YYc5IvXL7_3kWCRdsEix8bff6Fs5X_140B-HoHgL6gyPEcj9kaMQ"
                    },
                    nation_pic_file:
                    {
                        media_id: "3-8BWcqB1b8nBI7yMsK4AJK2PCLFoUuf4KlRcTjwwl-VZB598BCBONDMsrD0jEYP",
                        pay_media_id: "ANgIotyXuXUjkTLd_v40mBfWTP0FN2GCALPGoaRez-TKwZCe87YTSG4SnIMw6Rbr-dWj4Jj44m2BKyXzh8KmyDqhtHv5yFir_FgjexeW5kk"
                    },
                    id_card_name: "刘滔", //encodeURIComponent("刘滔"),
                    id_card_number: "430681198512058618",
                    start_date: "2016-08-25",
                    end_date: "2036-08-25"
                },

                busi_license:
                {
                    "license_type": 1,
                    "pic_file":
                    {
                        media_id: "Z85q-UYMPqlmcTO-3uZM5vO6z7Asq-eJC1PwVo_6v-XAZibvgTe4Il3Q4lrtKXHN",
                        pay_media_id: "ANgIotyXuXUjkTLd_v40mIlqn1Weymqic5M-TAjUyIH3_MZCkDd4c9HdAKBEccNFFtXx5bH_6m-ZuWLxxhUrVW_LHdcARHCtIzH3_KgdEfs"
                    },
                    "registration_num": "91440300306174257H",
                    "merchant_name": "深圳市微购科技有限公司",
                    "legal_representative": "刘滔",
                    "registered_addrs": "深圳市南山区粤海街道滨海社区高新南九道99号A8音乐大厦1305",
                    "start_date": "2014-07-10",
                    "end_date": "长期"
                },

                "super_administrator_info":
                {
                    "type": "65",
                    "name": "刘滔",
                    "id_card_number": "430681198512058618",
                    "phone": "17322312136",
                    "mail": "470043830@qq.com"
                },
                "merchant_shortname": "深圳市微购科技有限公司",

            },


        };

        // const url = `/circle/circle_new_interface.jsp?act=apiGetAuthorizerInfo`;
        // const url = `/circle/circle_new_interface.jsp?act=apiAuthorizerToken`;
        const url = `/circle/circle_new_interface.jsp?act=submitMerchantInfo`;
        info.merchantinfo = JSON.stringify(info.merchantinfo);
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url, method: 'POST', param: info });
    },

    async registerShop() {
        // const url = `https://api.weixin.qq.com/product/register/register_shop?component_access_token=${component_access_token}`;

        // wx.request({
        //     url, //仅为示例，并非真实的接口地址
        //     method: 'POST',
        //     data: {
        //         "wx_name": "liutao_weixin",
        //         "id_card_name": "刘滔",
        //         "id_card_number": "430681198512058618",
        //         // "channel_id": "4",
        //         "api_openstore_type": 2
        //     },
        //     // header: {
        //     //     'content-type': 'application/json' // 默认值
        //     // },
        //     success(res) {
        //         console.log(res.data);
        //     }
        // });

        const url = `/circle/circle_new_interface.jsp?act=registerShop`;
        const param = {
            "wx_name": 'iamleesong', //'youngsea5', //"liutao_weixin",
            "id_card_name": "李松",
            "id_card_number": "430602198511061115", //"430602198705220524", //"430681198512058618",
            // "channel_id": "4",
            "api_openstore_type": 2
        };
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url, method: 'POST', param });


        //act=checkMerchantAuditStatus&wx_name=iamleesong
        const lisong = {
            account_validation: {},
            acct_verify_status: 5,
            audit_reject_reasons: "",
            basic_info_status: 3,
            legal_validation_url: "",
            merchant_info_status: 5,
            pay_audit_detail: [],
            pay_sign_status: 1,
            register_status: 0,
            registered_appid: "wx0b6c2e7a3a700dde",
            sign_url: "https://pay.weixin.qq.com/public/apply4ec_sign/s?applymentId=2000002183742817&sign=9767aab3c685b307cc5d461da9829dc6",
        };
    },

    async omImgLoad(e) {
        const { width, height } = e.detail;
        const { imgSrc } = this.data;

        console.log('width, height: ', width, height);
        const rat = height / width;
        const contentImgWidth = width > 300 ? 300 : width;
        const contentImgHeight = contentImgWidth * rat;
        this.setData({
            contentImgWidth,
            contentImgHeight
        });
        const { data = '' } = await circleUtil.uploadFile(imgSrc); //
        const { key, w, h, size } = JSON.parse(data);
        console.log("uploadRet: ", key, w, h, size);

        return;


        // const url = `https://api.weixin.qq.com/product/img/upload?access_token=${access_token}&height=${height}&width=${width}`;
        const param = {
            wx_name: "liutao_weixin",
            img: `https://xcimg.szwego.com/${key}`,
            width,
            height,
        };
        const { isOk, result = {} } = await circleUtil.fetchNetData(
            {
                url: "/circle/circle_new_interface.jsp?act=imgUpload", method: 'POST', param
            }
        );
        if (isOk) {
            const { errcode, pic_file = {} } = JSON.parse(result);
            console.log("pic_file: ", pic_file);
        }
        return;

        wx.uploadFile({
            url,
            filePath: imgSrc,
            name: 'file',
            formData: {
                'user': 'test'
            },
            success(res) {
                const { errcode, pic_file } = JSON.parse(res.data);
                //do something
                console.log('success, errcode, pic_file: ', errcode, pic_file);

                if (errcode == 0) {

                }
            }
        });
    },

    // 打开ActionSheet组件
    openMysheet: function () {
        // this.setData({
        //     actionStatus: true
        // });

        // wx.navigateTo({
        //     url: `plugin-private://wx34345ae5855f892d/pages/productDetail/productDetail?productId=28022775`,
        // });
        // return;
        // this.spuList();
        // return;
        // this.batchAddSku();
        // return;
        // this.delSkus();
        // return;
        // this.getSku();
        // return;
        // this.getSkuList();
        // return;
        // this.getProduct();
        // return;
        // this.getProductList();
        // return;
        // this.addProduct();
        // return;
        // this.product_get_list();
        // return;
        // this.apiGetAuthorizerInfo();
        // return;
        // this.registerShop();
        // return;
        // this.check_audit_status();
        // return;
        // this.api_authorizer_token();
        // return;
        // this.api_get_authorizer_list();
        // return;



        wx.chooseImage({
            count: 1,
            sizeType: ['compressed'],

            success: res => {
                const tempFilePaths = res.tempFilePaths;

                this.setData({
                    imgSrc: tempFilePaths[0]
                });
            }
        });
    },

    handleBtn: function () {
        wx.showToast({
            title: '我是普通按钮',
            icon: 'none'
        });


    },

    onBtnTap() {
        const AUTHORIZE_APP_ID = 'wxec9780f4c30ce2cb';
        const appId = 'wx5c0115b4375c2831';
        const code = '21211';

        wx.navigateToMiniProgram({
            appId: AUTHORIZE_APP_ID,
            path: '/pages/login/index',
            extraData: {
                appId,
                domain: 'www.szwego.com',
                authSrc: 'ewmp',
                version: '1012',
                shopIcon: 'shopIcon',
                shopName: 'shopName',
                code,
            },
            // envVersion: 'trial',
            success: (res) => {
                // 打开成功
                console.log('跳转授权小程序成功 res = ', res);
            },
            fail: (res) => {
                Taro.hideLoading();
                // 打开失败
                console.log('跳转授权小程序失败 res = ', res);
            },
        });

        // wx.navigateToMiniProgram({
        //     appId: 'wx4aedf8c9edf9fd72', //'wx5b589968eff47164', //
        //     path: 'wxa/pages/home/index',
        //     // envVersion: 'trial',
        //     success(res) {
        //         // 打开成功
        //     }
        // });
        return;


        let title = '关注身边生活,主要负责人手机：17661699483，主要联系人手机：17661699483，值班室固话：19787867561, xxx: 17853272609, yyy: 17853272609';

        title = `关注身边生活,主要负责人手机：17661699483，主要联系人手机：17853272609，值班室固话：19787867561，，，，关注身边生活,主要负责人手机：17661699483，主要联系人手机：17853272609，值班室固话：19787867561，，，，关注身边生活,主要负责人手机：17661699483，主要联系人手机：17853272609，值班室固话：19787867561，，，关注身边生活,主要负责人手机：17661699483，主要联系人手机：17853272609，值班室固话：19787867561`;

        // title ="保留空白符序列，但是正常地进行换行。"
        let texts = circleUtil.handleFoldText(title, '主要');
        console.log('resultStrs: ', texts);
        this.setData({
            textInfo: {
                texts: [], title
            }
        });
        return;
        let numbers = title.match(/1(3|4|5|7|8|9|6)\d{9}/g);
        console.log('title: ', title);
        console.log('numbers: ', numbers);
        let hilight_word = this.hilightWord(title, '身边');
        console.log('hilight_word: ', hilight_word);
        this.setData({
            foldtextParam: {
                title, numbers
            }
        });

        let resultStrs = [];
        let pointer = 0;
        let filterText = '身边';
        for (let index = 0; index < title.length; index++) {
            // const element = title[index];
            // console.log(index + ': ' + element);
            for (let j = 0; j < numbers.length; j++) {
                const number = numbers[j];

                if (title.startsWith(number, index)) {
                    let normal = title.substring(pointer, index);
                    resultStrs.push({ normal });
                    resultStrs.push({ number });
                    index += number.length;
                    pointer = index;
                    // console.log('handle: ', title.substr(pointer));
                    break;
                }
            }
            if (title.startsWith(filterText, index)) {
                let normal = title.substring(pointer, index);
                resultStrs.push({ normal });
                resultStrs.push({ filterText });
                index += filterText.length;
                pointer = index;
            }
        }

        if (pointer < title.length) {
            let tail = title.substr(pointer);
            resultStrs.push({ tail });
        }

    },


    hilightWord(str, keyword) {
        const idx = str.indexOf(keyword);
        let t = [];

        if (idx !== -1) {
            if (idx == 0) {
                t = this.hilightWord(str.substr(keyword.length), keyword);
                t.unshift({ isKeyword: true, value: keyword });
                return t;
            } else if (idx > 0) {
                t = this.hilightWord(str.substr(idx), keyword);
                t.unshift({ isKeyword: false, value: str.substring(0, idx) });
                return t;
            }
        }
        return [{ isKeyword: false, value: str }];
    },

    onActionHide: function () {
        console.log('ActionSheet关闭了');
    }
});
