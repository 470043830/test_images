// pages/supply-market/index.js
const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const app = getApp();

Page({

    currTabIndex: '0',
    /**
     * 页面的初始数据
     */
    data: {
        banner_local: [
            {
                src: 'http://xcimg.szwego.com/circle_images/banners/Group%2032%20banner%20wuye.png'
            }
        ],
        list: [],
        filterText: '',
        myAlbumId: ''
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        const { customBar } = app.getCustomBarInfo();

        let myAlbumId = '';
        if (getApp().globalData.userInfo){
            myAlbumId = getApp().globalData.userInfo.albumId;
        }
        this.setData({
            customBar,
            myAlbumId,
        });
        this.fetchConfigData();

        console.log("app.globalData: ", app.globalData)
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    onShow() {
        // const { list } = this.data;
        // if (list.length > 0){
        //     this.getGoodsListData('top');
        // }
        this.fetchCommentData();
        setTimeout(async () => {
            await circleUtil.getCircleConfigData();
            this.setData({
                isMiniChecked: circleUtil.isMiniChecked()
            });
        }, 10);
    },

    previewImgs(e) {
        this.setData({
            showPreviewer: true,
            ...e.detail,
        }, () => {
            this.data.showPreviewer && util.navigateToBrowserPage();
        });
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {
        console.log("onPullDownRefresh...");
        setTimeout(async() => {
            const { list } = this.data;
            if (list.length > 0) {
                await this.getGoodsListData('init');
            }
            wx.stopPullDownRefresh();
        }, 1000);
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },

    fetchCommentData() {
        const { list = [] } = this.data;
        if (list.length > 0) {
            let param = { ids: [] };
            for (let index = 0; index < list.length && index < 16; index++) {  //max is 16
                const element = list[index];
                param.ids.push(element.goods_id);
            }

            util.fetch('/circle/circle_new_interface.jsp?act=getGoodsExtInfoList', param, 'POST').then(res => {
                const { errcode, result } = res.data;
                let newData = {};

                if (errcode == 0) {
                    let extInfoList = result.list;
                    console.log('extInfoList: ', extInfoList);
                    for (let index = 0; index < extInfoList.length; index++) {
                        const ele = extInfoList[index];
                        const gIndex = this.getGoodsIndexInList(ele.goodsId);
                        if (gIndex >= 0 && (list[gIndex].commentCount != ele.commentCount || list[gIndex].shareCount != ele.shareCount)) {
                            list[gIndex].commentCount = ele.commentCount;
                            list[gIndex].shareCount = ele.shareCount;
                            newData["list[" + gIndex + "]"] = list[gIndex];
                        }
                    }
                }
                console.log('newData: ', newData);
                this.setData(newData);
            }, (err) => {
            });
        }
    },


    async fetchConfigData() {
        const obj = await circleUtil.getCircleConfigData();
        const { config = {}, markets = [] } = obj;

        console.log('config: ', config);
        this.setData(config);

        //...
        this.getGoodsListData('');
    },

    onTopTabEvent(e) {
        console.log('onTopTabEvent', e.detail, this.currTabIndex);
        //return;
        if (this.currTabIndex != e.detail.key) {
            this.currTabIndex = e.detail.key;
            console.log('currTabIndex ', this.currTabIndex);

            this.setData({
                loadingEnd: false,
                loadingNoData: false,
                //list: []
            });
            this.data.list = [];
            //...
            util.abortCurrRequestTask();
            this.getGoodsListData('');
        }
    },

    onPublishBtn() {
        if (app.offline()) {
            circleUtil.showLoginModal();
            return;
        }
        wx.showActionSheet({
            itemList: ['求购', '拼单', '二手', '招聘', '出租/转让'],
            success: res => {
                console.log(res.tapIndex);
                const category = res.tapIndex + 1;
                wx.setStorage({
                    key: 'goods_edit',
                    data: 'home_add',
                });
                const { list } = this.data;
                wx.navigateTo({
                    url: '/pages/goods_edit/index?category=' + category,
                    events: {
                        // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
                        acceptDataFromOpenedPage: data => {
                            // console.log('acceptDataFromOpenedPage ', data);
                            if (list) {
                                list.unshift(data);
                                this.setData({ list });
                            }
                        },
                    },
                });
            },
            fail(res) {
                console.log(res.errMsg);
            }
        });

    },


    /**
     * @description
     * @param {*} type
     */
    async getGoodsListData(type) {
        console.log('getGoodsListData, type=', type);
        const url = this.getUrl(type);

        this.setData({ loading: true });
        let param = {
            search_value: this.data.filterText
        };
        let extInfo = { type };
        const { isOk, result } = await circleUtil.fetchNetData({ url, param, extInfo });

        console.log('getGoodsListData: ', isOk, result);
        let obj = {};

        if (type == 'top') {
            wx.stopPullDownRefresh();
        }
        if (!isOk) {
            obj.loading = false;
            this.setData(obj);
            return;
        };

        const { goods_list, ...others } = result;
        const { list } = this.data;

        obj = { ...this.data, ...others };
        if (type == 'top') {
            obj.list = this.getNoRepeatData(goods_list, list);
        } else if (type == 'init'){
            obj.list = goods_list;
            // 到底了
            goods_list.length <= 0 && (obj.loadingEnd = true);
        } else {
            obj.list = [...list, ...goods_list];
            // 到底了
            goods_list.length <= 0 && (obj.loadingEnd = true);
        }

        // 无数据
        if (obj.list.length <= 0) {
            obj.loadingNoData = true;
        } else {
            obj.loadingNoData = false;
        }
        obj.latestTime = this.getLatestTime(obj.list);
        obj.loading = false;

        this.setData(obj);
    },

    getLatestTime(data) {
        return data.map(item => item.time_stamp).filter(item => item)[0] || '';
    },

    getTimestamp() {
        const { list, latestTime } = this.data;
        const len = list.length;

        if (len > 0) {
            return {
                top: latestTime,
                bottom: list[len - 1].time_stamp
            };
        } else {
            return {
                top: '',
                bottom: ''
            };
        }
    },

    getUrl(type) {
        const { top, bottom } = this.getTimestamp();
        let url = `/circle/circle_new_interface.jsp?act=getGoodsListByPage`;
        let category = this.currTabIndex;

        switch (type) {
            case 'init':
                url = `${url}&slip_type=0&time_stamp=0`;
                break;
            case 'top':
                url = `${url}&slip_type=0&time_stamp=${top || ''}`;
                break;
            case 'bottom':
                url = `${url}&slip_type=1&time_stamp=${bottom || ''}`;
                break;
        }
        url += `&category=${category}`;
        return url;
    },

    getGoodsIndexInList(goodsId) {
        const { list } = this.data;
        for (let index = 0; index < list.length; index++) {
            if (list[index].goods_id == goodsId) {
                return index;
            }
        }
        return -1;
    },
});
