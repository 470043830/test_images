import { $wuxToast } from '../../components/wux';
import nineGrid from '../../utils/nine-grid';

const util = require('../../utils/util.js');
const logic = require('../../utils/logic.js');
const constant = require('../../utils/constant');
const app = getApp();

Page(Object.assign({}, nineGrid, {
    data: {
        //getUrl: '/data/goods_detail.json?',
        getUrl: '/album/get_album_themes_list.jsp?act=single_item',
        circleGoodsUrl: '/circle/circle_new_interface.jsp?act=getGoods',
        addUrl: '/album/album_theme_operation.jsp?act=hold_theme',
        addCommentUrl: '/circle/circle_new_interface.jsp?act=addComment',
        fetchCommentUrl: '/circle/circle_new_interface.jsp?act=getCommentsByGoodsId',
        loading: false,
        goods: null,
        priceTypesObj: constant.priceTypesObj,
        showWechat: false,
        autoplay: false, // 视频自动播放
        isCircleGoods: false,
        mixThemeSwiperSrc: [],
        comments: [],
        inputComment: '',
        categoryTitle: '',
    },

    onLoad(options) {
        const { shop_id, goods_id } = options;

        console.info('onLoad', options);
        this.shop_id = shop_id || '';
        this.goods_id = goods_id || '';

        // 隐藏本页面的转发按钮
        // wx.hideShareMenu();
        if (!this.goods_id.startsWith('I')) {
            this.setData({ isCircleGoods: true });
        }

        wx.getNetworkType({
            success: (res) => {
                let isWifi = res.networkType == 'wifi';
                //wifi环境下静音自动播放
                this.setData({
                    autoplay: isWifi,
                    muted: isWifi
                });
            }
        });

        wx.showLoading({
            mask: false,
            title: '加载中...',
        });
        this.fetchData(() => {
            wx.hideLoading();
        });
    },



    onShareAppMessage(res) {
        if (res.from === 'button') {
            // 来自页面内转发按钮
            console.log(res.target);
        }

        const { title, shop_id, goods_id, imgsSrc, share_shop_id, share_goods_id } = this.data.goods;
        const path = `pages/goods_detail/index?goods_id=${share_goods_id || goods_id}&shop_id=${share_shop_id || shop_id}`;
        const imageUrl = imgsSrc[0] || '';

        return {
            title,
            path,
            imageUrl,
            success: function (res) {
                // 转发成功
            },
            fail: function (res) {
                // 转发失败
            }
        };
    },

    getUrl() {
        const { getUrl, circleGoodsUrl, isCircleGoods } = this.data;

        if (isCircleGoods) {
            return `${circleGoodsUrl}&goods_id=${this.goods_id}`;
        }
        return `${getUrl}&shop_id=${this.shop_id}&goods_id=${this.goods_id}`;
    },

    fetchData(callback) {
        const url = this.getUrl();

        console.info(url);
        this.setData({ loading: true });
        util.fetchAuthInst(url, null, res => {
            const { errcode, result } = res.data;
            let obj = {};

            console.log(res);
            if (errcode == 0) {
                obj.goods = result;
                const { shop_id, images, imgsSrc, videoURL, themeType, is_my_album, category=0 } = obj.goods || {};
                obj.mixThemeSwiperSrc = themeType === 4 ? [videoURL, ...(images || imgsSrc)] : [videoURL];
                obj.categoryTitle = app.globalData.circleInfo.navList[category].title;
            }
            obj.loading = false;

            this.setData(obj);
            typeof callback == 'function' && callback();

            // 清除失效token，触发重新获取
            app.clearToken(res.data, () => {
                this.onPullDownRefresh();
            });

            //fetchComments
            this.fetchComments();
        }, err => {
            console.log(err);
            this.setData({ loading: false });
            typeof callback == 'function' && callback();
        });
    },

    fetchComments(callback) {
        const { fetchCommentUrl } = this.data;
        const url = `${fetchCommentUrl}&goods_id=${this.goods_id}`;
        util.fetchAuthInst(url, null, res => {
            const { errcode, result } = res.data;
            console.log('fetchComments: ', res.data);

            if (errcode == 0) {
                this.setData({ comments: result.comments });
            }
            typeof callback == 'function' && callback();
        }, err => {
            console.log(err);
            typeof callback == 'function' && callback();
        });
    },

    onPullDownRefresh() {
        wx.hideLoading();
        const { loading } = this.data;

        if (loading) {
            return false;
        }

        console.log("onPullDownRefresh");
        this.fetchData(() => {
            console.log("stopPullDownRefresh");
            wx.stopPullDownRefresh();
        });
    },

    iconTap(ev) {
        const { shop_id, is_my_album } = this.data.goods;
        const url = `/pages/follow_detail/index?shop_id=${shop_id}`;
        // const pages = getCurrentPages().map(item => item.route);
        // const len = pages.length;

        // if (len < 2) {
        //     wx.redirectTo({ url });
        //     return
        // }
        // if (is_my_album) {
        //     wx.navigateBack();
        // } else {
        //     const prevPage = pages[len - 2];

        //     if (url.match(prevPage)) {
        //         wx.navigateBack();
        //     } else {
        //         // 防止页面路径超过五层，无法再打开页面
        //         wx.redirectTo({url});
        //     }
        // }

        const len = getCurrentPages().length;

        if (len < 2) {
            wx.redirectTo({ url });
        } else {
            is_my_album ? wx.navigateBack() : wx.redirectTo({ url });
        }
    },

    onViewImg(e) {
        //const { index, imgssrc } = e.target.dataset;
        const { index } = e.currentTarget.dataset;
        const { imgsSrc: imgssrc } = this.data.goods;

        console.info(index, e);
        wx.previewImage({
            current: imgssrc[index], // 当前显示图片的http链接
            urls: imgssrc // 需要预览的图片http链接列表
        });
    },

    onTapTag(e) {
        const { tagId } = e.currentTarget.dataset;
        const route = '/pages/tag_goods_list/index';
        const options = {
            shop_id: this.shop_id,
            tag_id: tagId,
        };

        util.navigateTo(route, options);
    },

    sendCommentReq(content) {
        const { addCommentUrl } = this.data;
        const url = `${addCommentUrl}&goods_id=${this.goods_id}&title=${content}&shop_id=${this.shop_id}`;
        util.fetchAuthInst(url, null, res => {
            const { errcode, result } = res.data;
            console.log('addCommentUrl: ', res.data);
            //...
            wx.showToast({
                title: '留言成功',
                duration: 1500
            });
            wx.pageScrollTo({
                scrollTop: 0,
                duration: 300
            });
            this.fetchComments();

            //订阅消息
            wx.requestSubscribeMessage({
                tmplIds: ['RicDQlVCFdOsG7RIyu4fcuIbrs5BKbBvcnux3LnF3CI'],
                success(res) { }
            })
        }, err => {
            console.log(err);
        });
    },

    onInput(e) {
        console.log('onInput ', e.detail.value);
        this._inputValue = e.detail.value;

        this.setData({ inputComment: e.detail.value });
    },

    onInputConfirm(e) {
        console.log('onInputConfirm ', e);
        this.sendCommentReq(e.detail.value);

        //reset
        let inputComment = '';
        this.setData({ inputComment });
    },

    onCommentTap() {
        if (this._inputValue) {
            this.sendCommentReq(this._inputValue);

            //reset
            this._inputValue = '';
            this.setData({ inputComment: this._inputValue });
        }
        return;
        const itemList = ['快捷留言 AAA', '快捷留言 BBB'];
        wx.showActionSheet({
            itemList,
            success: res => {
                const { tapIndex } = res;
                console.log('', itemList[tapIndex], this.goods_id);
                this.sendCommentReq(itemList[tapIndex]);

                // const { addCommentUrl } = this.data;
                // const url = `${addCommentUrl}&goods_id=${this.goods_id}&title=${itemList[tapIndex]}`;
                // util.fetchAuthInst(url, null, res => {
                //     const { errcode, result } = res.data;
                //     console.log('addCommentUrl: ', res.data);
                //     //...
                //     wx.showToast({
                //         title: '留言成功',
                //         duration: 1500
                //     });
                //     this.fetchComments();
                // }, err => {
                //     console.log(err);
                // });

            },
            fail: res => {
                console.log(res);
            }
        });
    },

    tapContact() {
        wx.showActionSheet({
            itemList: ['微信', '电话'],
            success: res => {
                const { tapIndex } = res;

                switch (tapIndex) {
                    case 0:
                        this.tapWechat();
                        break;

                    case 1:
                        this.tapCall();
                        break;
                }
            },
            fail: res => {
                console.log(res);
            }
        });
    },

    //微信
    tapWechat() {
        const { wechat_id, wechat_qrcode } = this.data.goods.shop || {};

        if (wechat_id || wechat_qrcode) {
            this.setData({
                showWechat: true
            });
        } else {
            wx.showToast({
                icon: 'none',
                title: '该商家没有设置微信信息~',
            });
        }
    },

    viewQrcode(e) {
        const { src } = e.target.dataset;

        console.log(src);
        wx.previewImage({
            current: src,
            urls: [src]
        });
    },

    copyWechat(e) {
        const { title } = e.target.dataset;

        this.copyTitle(title);
    },

    hideWechat() {
        this.setData({
            showWechat: false
        });
    },

    //电话
    tapCall() {
        const { phone_number: phoneNumber } = this.data.goods.shop || {};

        if (phoneNumber) {
            wx.makePhoneCall({
                phoneNumber,
                fail: res => {
                    const { errMsg } = res;

                    console.info(res);
                    !errMsg.match(/cancel/) &&
                        wx.showToast({
                            icon: 'none',
                            title: '呼叫失败，请稍后重试~',
                        });
                }
            });
        } else {
            wx.showToast({
                icon: 'none',
                title: '该商家没有设置电话号码~',
            });
        }
    },

    onDownload(e) {
        const { dataset } = e.currentTarget;
        const { title } = this.data.goods;

        // 复制标题
        this.copyTitle(util.getTextTitle(title));

        // console.log('onDownload11111111');
        // return;

        // 下载图片
        const timer = setTimeout(() => {
            clearTimeout(timer);
            logic.downloadImgs(dataset, this.downloadStartCB, this.downloadingCB);
        }, 500);
    },

    onAdd(e) {
        const { addUrl } = this.data;
        const url = `${addUrl}&shop_id=${this.shop_id}&goods_id=${this.goods_id}`;

        console.info("onAdd", e);
        wx.showLoading({
            mask: true,
            title: '加载中...',
        });
        util.fetch(url)
            .then(res => {
                const { errcode, result } = res.data;

                wx.hideLoading();
                if (errcode == 0) {
                    // const { shop_id, goods_id, follow_object } = result;
                    const { follow_object } = result;

                    // 未关注
                    if (follow_object) {
                        this.showGuide(this.shop_id, follow_object);
                        return false;
                    }

                    // console.info('onAdd success', res);
                    // this.setData({
                    //     'goods.shop_id': shop_id,
                    //     'goods.goods_id': goods_id,
                    //     'goods.is_added': true,
                    // });

                    // 分享
                    this.onShare(e);
                }
            }, err => {
                console.info('onAdd error', err);

                wx.hideLoading();
                // 分享
                // this.onShare(e);
            });
    },

    onShare(e) {
        const { title } = this.data.goods;

        // 复制标题
        this.copyTitle(title);

        // 分享
        logic.showshare(e.target.dataset, this.downloadStartCB, this.downloadingCB, this.onAddThemeToAlbum);
    },

}));
