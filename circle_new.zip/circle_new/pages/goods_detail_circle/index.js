// pages/goods_detail_circle/index.js
import nineGrid from '../../utils/nine-grid.js';

const constant = require('../../utils/constant');

const util = require('../../utils/util.js');

const circleUtil = require('../../utils/circle-util.js');
const circleData = require('../../utils/circle-data.js');

const wsxcGoodsUrl = '/album/get_album_themes_list.jsp?act=single_item';
const circleGoodsUrl = '/circle/circle_new_interface.jsp?act=getGoods';
const fetchCommentUrl = '/circle/circle_new_interface.jsp?act=getCommentsByGoodsId';
const addCommentUrl = '/circle/circle_new_interface.jsp?act=addComment';
Page({
  /**
   * 页面的初始数据
   */
  data: {
    item: {},
    comments: [],
    inputComment: '',
    priceTypesObj: constant.priceTypesObj,
    previewList: [// {
      //     fileSource: "https://xcimg.szwego.com/20210704/a1625368924006_7136.mp4",
      //     title: '1111111111',
      //     themeType: 4,
      //     goods_id: '111111111',
      //     fileType: 'video',
      //     showAddCart: false,
      //     is_my_album: false,
      //     shop_id: 'A201906031621498020000323',
      // },
      // {
      //     fileSource: "https://xcimg.szwego.com/20210704/a1625368923988_6636.jpg?imageMogr2/auto-orient/thumbnail/!160x160r/quality/100/format/jpg",
      //     title: '2222',
      //     themeType: 4,
      //     goods_id: '111111111',
      //     fileType: 'image',
      //     showAddCart: false,
      //     is_my_album: false,
      //     shop_id: 'A201906031621498020000323',
      // }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    if (getApp().offline()) {
      console.log('offline...');
      getApp().globalData.triggerPagePath = '';
      circleUtil.showLoginConfirm('登录已过期，请重新登录。');
      return;
    }

    const {
      goods_id,
      shop_id,
      from = 'wsxc', //'circle'
    } = options;
    console.info('onLoad', options);
    this._fromWsxc = from == 'wsxc';
    this.setData({
      fromWsxc: this._fromWsxc
    });

    if (!this._fromWsxc) {
      wx.setNavigationBarTitle({
        title: '详情'
      });
    }

    const eventChannel = null; //this.getOpenerEventChannel();
    console.info('eventChannel: ', eventChannel);

    if (eventChannel && eventChannel.on) {
      eventChannel.on('acceptGoodsItemData', item => {
        console.log('acceptGoodsItemData: ', item);

        if (item.goods_id && item.user_icon.startsWith('http')) {
          this.setData({
            item
          });
          setTimeout(() => {
            this.fetchComments(item.goods_id);
          }, 10);
        } else {
          //need to get net data
          this.fetchItemData(goods_id, shop_id);
        }
      });
    } else {
      //need to get net data
      this.fetchItemData(goods_id, shop_id);
    }
  },

  onShow() {
    const isShowPublish = circleUtil.isMiniChecked();
    this.setData({
      isShowPublish
    });
  },

  onUnload: function () { },

  onInput(e) {
    console.log('onInput ', e.detail.value);
    this._inputValue = e.detail.value;
    this.setData({
      inputComment: e.detail.value
    });
  },

  onInputConfirm(e) {
    console.log('onInputConfirm ', e);
    this.sendCommentReq(e.detail.value); //reset

    let inputComment = '';
    this.setData({
      inputComment
    });
  },

  onCommentTap() {
    if (this._inputValue) {
      this.sendCommentReq(this._inputValue); //reset

      this._inputValue = '';
      this.setData({
        inputComment: this._inputValue
      });
    }
  },

  iconTap(e) {
    nineGrid.iconTap(e, this);
  },

  titleTap(ev) {// const { dataset } = ev.currentTarget;
    // console.log('titleTap ', dataset)
    // // nineGrid.titleTap(e, this);
    // if (dataset.href){
    //     const url111 = "/pages/webview/index?url=" + dataset.href;
    //     wx.navigateTo({ url: url111 });
    // }
  },

  getPreviewList() {
    const {
      item = {}
    } = this.data;
    const {
      themeType,
      imgsSrc = [],
      videoURL,
      title,
      goods_id,
      shop_id
    } = item;
    let previewList = [];
    let startIndex = 0;
    console.log('getPreviewList, themeType: ', themeType, imgsSrc, videoURL); // 4: video+image, 0: image, 1: video

    if (videoURL) {
      previewList.push({
        fileSource: videoURL,
        fileType: 'video',
        title,
        themeType,
        goods_id,
        shop_id
      });
      startIndex = 1; // here is very funny
    }

    for (let index = startIndex; index < imgsSrc.length; index++) {
      const element = imgsSrc[index];
      previewList.push({
        fileSource: element,
        fileType: 'image',
        title,
        themeType,
        goods_id,
        shop_id
      });
    }

    console.log('previewList: ', previewList);
    return previewList;
  },

  onViewImg(e) {
    const {
      item
    } = this.data;
    const {
      index,
      imgssrc
    } = e.target.dataset;
    let previewList = this.getPreviewList();
    let previewIndex = item.themeType == 4 ? index : index;
    this.setData({
      previewList,
      showPreviewer: true,
      previewIndex
    }, () => {
      util.navigateToBrowserPage();
    });
    return; //以下是使用系统预览组件的版本

    const current = imgssrc[index];
    console.log('onViewImg: ', index, current, imgssrc, item);
    const sources = [];

    for (let index = 0; index < imgssrc.length; index++) {
      const element = imgssrc[index];

      if (item.videoURL && index == 0) {
        sources.push({
          url: item.videoURL,
          type: 'video',
          poster: element
        });
      } else {
        sources.push({
          url: element
        });
      }
    }

    if (wx.previewMedia) {
      wx.previewMedia({
        current: index,
        // 当前显示图片的http链接
        sources // 需要预览的图片http链接列表

      });
    } else {
      wx.previewImage({
        current,
        // 当前显示图片的http链接
        urls: imgssrc // 需要预览的图片http链接列表

      });
    }
  },

  onShareBtn() {
    console.log('onShareBtn...');
  },

  onShareAppMessage(shareOption) {
    console.log('onShareAppMessage: ', shareOption);
    const {
      item
    } = this.data;
    const imageUrl = item.imgsSrc && item.imgsSrc[0]; //'/assets/image/tt_logo2.png';
    const path = `/pages/goods_detail_circle/index?shop_id=${item.shop_id}&goods_id=${item.goods_id}`;

    console.log('path: ', path);
    return {
      // channel: "video",
      title: item.title,
      path,
      imageUrl,
      success: () => {
        console.log("分享成功");
      },
    };
  },

  async fetchItemData(goods_id, shop_id) {
    let url = `${circleGoodsUrl}&goods_id=${goods_id}`;

    if (this._fromWsxc) {
      // if (goods_id.startsWith('_')) {
      //   url = `/commodity/view?&targetAlbumId=${shop_id}&itemId=${goods_id}`;
      // } else {
      //   url = '/service' + `${wsxcGoodsUrl}&goods_id=${goods_id}&shop_id=${shop_id}`;
      // }
      url = `/commodity/view?&targetAlbumId=${shop_id}&itemId=${goods_id}`;
    }
    if (circleData.testDomain) {
      url = circleData.testDomain + url;
    }

    const {
      isOk,
      errcode, errmsg,
      result = {}
    } = await circleUtil.fetchNetData({
      url
    });
    console.log('fetchItemData: ', isOk, result);

    if (isOk) {
      this.setData({
        item: result.commodity
      });
      // if (goods_id.startsWith('_')) {
      //   this.setData({
      //     item: result.commodity
      //   });
      // } else {
      //   this.setData({
      //     item: result
      //   }, () => this.fetchComments(result.goods_id));
      // }
    } else {
      wx.showModal({
        title: '提示',
        content: errmsg,
        showCancel: false, //true,
        // confirmText: '确定',
        // confirmColor: '#3CC51F',
        success: (result) => {
          if (result.confirm) {
            wx.navigateBack();
          }
        },
      });
    }
  },

  async fetchComments(goods_id) {
    if (this._fromWsxc) {
      return;
    }

    const url = `${fetchCommentUrl}&goods_id=${goods_id}`;
    const {
      isOk,
      result = {}
    } = await circleUtil.fetchNetData({
      url
    });
    console.log('fetchComments: ', isOk, result);

    if (isOk) {
      this.setData({
        comments: result.comments
      });
    }
  },

  sendCommentReq(content) {
    const {
      item
    } = this.data;
    const url = `${addCommentUrl}&goods_id=${item.goods_id}&title=${content}&shop_id=${item.shop_id}`;
    util.fetchAuthInst(url, null, res => {
      const {
        errcode,
        result
      } = res.data;
      console.log('addCommentUrl: ', res.data); //...

      wx.showToast({
        title: '留言成功',
        duration: 1500
      });
      wx.pageScrollTo({
        scrollTop: 0,
        duration: 300
      });
      this.fetchComments(item.goods_id); //订阅消息

      const templateId = 'RicDQlVCFdOsG7RIyu4fcuIbrs5BKbBvcnux3LnF3CI';
      console.log('触发订阅消息: ', templateId);
      wx.requestSubscribeMessage({
        tmplIds: [templateId],

        success(res) {
          console.log('触发订阅消息成功: ', res);
          setTimeout(() => {
            const {
              openId
            } = getApp().globalData.userInfo;
            circleUtil.fetchNetData({
              url: `/circle/circle_new_interface.jsp?act=getAccessToken&openId=${openId}`
            });
          }, 6000);
        },

        fail(res) {
          console.log('触发订阅消息失败: ', res);
        }

      });
    }, err => {
      console.log(err);
    });
  },

  async updateSaveRecord(shop_id) {
    const action_type = "save";
    const url = `/circle/circle_new_interface.jsp?act=updateVisitRecord&shop_id=${shop_id}&action_type=${action_type}`;
    const {
      isOk,
      result = {}
    } = await circleUtil.fetchNetData({
      url
    });

    if (isOk) { }
  },

  async onZhuanCunTap() {
    const {
      item = {}
    } = this.data;

    if (item.is_added) {
      return;
    }

    const {
      userInfo = {}
    } = getApp().globalData;
    const {
      goods_id,
      shop_id
    } = item;
    const url = `/album/album_theme_operation.jsp?act=circle_hold_theme&shop_id=${shop_id}&goods_id=${goods_id}`;
    console.log("onZhuanCunTap...", item);
    this.updateSaveRecord(shop_id);
    const {
      isOk,
      result = {}
    } = await circleUtil.fetchNetData({
      url
    });
    console.log("result: ", result);
    item.is_added = true;
    this.setData({
      item
    });

    if (isOk) {
      wx.showModal({
        title: '提示',
        content: '已成功添加至您的产品图册',
        confirmText: "去查看",

        success(res) {
          if (res.confirm) {
            const url = '/pages/follow_detail/index?shop_id=' + userInfo.albumId;
            wx.navigateTo({
              url
            });
          } else if (res.cancel) {
            console.log('用户点击取消');
          }
        }

      });
    }
  }

});
