// pages/circle-contact-tip/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    actionStatus: false,
    shopIcon: 'https://xcimg.szwego.com/PiajxSqBRaEKp39kYtY5xwmJE6uSbyAWdgYzkRXh6Cb5vdjanoJwDDxvIvfTibMdAHbW3KO3Tq17qmRSUsK0GmWw',
    shopName: '222',
    qrcode: 'https://ol51v40vb.qnssl.com/tmp_2fd6bdd1c20b29c28468a621a81d764d0555d2ca6b51b0b6.jpg',
    wechat: 'ManihongDaWang',
    phone: '121212121',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    const { icon = '', name = '', phone, wx, qr } = options;

    this.setData({
      shopIcon: icon,
      shopName: name,
      qrcode: qr,
      wechat: wx,
      phone: phone,
    })
  },

  onBtnTap() {
    this.setData({
      actionStatus: true
    })
  },

  onCopyWechat(e) {
    wx.setClipboardData({
      data: this.data.wechat,
      success(res) {
        wx.getClipboardData({
          success(res) {
            console.log(res.data); // data
          }
        });
      }
    });
  },

  onCopyPhone(e) {
    wx.setClipboardData({
      data: this.data.phone,
      success(res) {
        wx.getClipboardData({
          success(res) {
            console.log(res.data); // data
          }
        });
      }
    });
  },

  onMakeCall() {
    wx.makePhoneCall({
      phoneNumber: this.data.phone
    });
  },

  onSaveImageTap() {
    console.log('onSaveImageTap...');
    wx.downloadFile({
      url: this.data.qrcode, //仅为示例，并非真实的资源
      success(res) {
        // 只要服务器有响应数据，就会把响应内容写入文件并进入 success 回调，业务需要自行判断是否下载到了想要的内容
        if (res.statusCode === 200) {
          wx.saveImageToPhotosAlbum({
            filePath: res.tempFilePath,
            success(res) {
              wx.showToast({
                title: '保存成功！',
              });
            }
          })
        }
      }
    });
  },

  onPreviewImgTap() {
    wx.previewImage({
      current: this.data.qrcode, // 当前显示图片的 http 链接
      urls: [this.data.qrcode] // 需要预览的图片 http 链接列表
    })
  },

  oncustomevent_ashide() {
    console.log('oncustomevent_ashide...');
    this.setData({
      actionStatus: false
    });
  },

  catchtest222() {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})