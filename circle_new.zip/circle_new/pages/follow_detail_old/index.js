import { $tdSearchbar, $wuxToast, $tdTags } from '../../components/wux';
import fourGrid from '../../utils/four-grid';
import nineGrid from '../../utils/nine-grid';

const util = require('../../utils/util.js');
const constant = require('../../utils/constant');
const app = getApp();
function getData() {
    return {
        // getUrl: [
        //     '/data/follow_detail.json?',
        //     '/data/follow_detail.json?',
        //     '/data/follow_detail.json?',
        //     '/data/follow_detail.json?',
        // ],
        // addUrl: '/data/ok.json?',
        getUrl: [
            '/album/get_album_themes_list.jsp?act=single_album',
            '/album/get_album_themes_list.jsp?act=single_album&query_type=new',
            '/album/get_album_themes_list.jsp?act=single_album&query_type=recommend',
            '/album/get_album_themes_list.jsp?act=single_album&query_type=video',
        ],
        addUrl: '/album/album_theme_operation.jsp?act=hold_theme',
        attentionUrl: '/album/attention_album.jsp?',
        loading: true, // 列表加载中
        loadingNoData: false, // 列表加载完成 & 无数据
        loadingEnd: false, // 列表加载完成 & 到底了
        cur_page: 1,
        filterText: '',
        filterImg: '',
        filterTag: [],
        listIndex: 0,
        list: [],
        showWechat: false,
        showTag: false,
        navs: [{ label: '动态' }, { label: '首发' }, { label: '人气' }, { label: '小视频' }],
        priceTypesObj: constant.priceTypesObj,
    };
}

Page(Object.assign({}, fourGrid, nineGrid, {
    data: getData(),
    pageName: 'follow_detail',

    onLoad(options) {
        const { shop_id } = options;

        console.info('onLoad', options);
        this.shop_id = shop_id || '';
        this.list = [];

        $tdSearchbar.init({
            style: 'border: none',
            image: true,
            searchHandler(text, img) {
                const { listIndex, filterTag } = this.page.data;

                console.log('-------------------------------------------listIndex: ', listIndex);
                console.info(`text: ${text}`, `img: ${img}`);
                console.info(this);

                this.page.list = [];
                this.setData(Object.assign({}, getData(), {
                    listIndex,
                    filterText: text,
                    filterImg: img,
                    filterTag
                }));
                this.page.fetchData();
            }
        });

        this.tags = $tdTags.init({
            onClear: () => {
                this.clearTags();
            },
            onOk: (ev) => {
                this.okTags(ev);
            }
        });

        wx.showLoading({
            mask: false,
            title: '加载中...',
        });
        this.fetchData('', () => {
            const { shop_name: title } = this.data.shop || {};

            wx.hideLoading();
            title && wx.setNavigationBarTitle({ title });
        });
    },

    onUnload(){
        console.log('onUnload...')
    },

    navTap(ev) {
        const { index } = ev.target.dataset;
        const { listIndex, filterText, filterImg, filterTag } = this.data;

        if (index == listIndex) {
            return false;
        }

        console.info('nav', index);
        this.list = [];
        wx.showLoading({
            mask: true,
            title: '加载中...',
        });
        this.setData(Object.assign({}, getData(), {
            listIndex: index,
            filterText,
            filterImg,
            filterTag
        }));
        this.fetchData('', () => {
            wx.hideLoading();
        });
    },

    /**
     * @description 关注成功后刷新列表
     */
    onAttentionSuccess(){
        setTimeout(() => {
            this.fetchData('', () => {
                wx.hideLoading();
            });
        }, 0);
    },

    onShareAppMessage(res) {
        if (res.from === 'button') {
            // 来自页面内转发按钮
            console.log(res.target);
        }

        const { shop, list, share_title } = this.data;
        let path = '';
        let title = '';
        let imageUrl = '';

        console.log(this.data);
        console.log(`index: ${this.shareIndex} list: ${this.listidx}`);
        if (this.shareIndex > -1) {
            const goods = this.listidx > -1 ? list[this.listidx][this.shareIndex] : list[this.shareIndex];
            const { shop_id, goods_id, imgsSrc, share_shop_id, share_goods_id } = goods;

            title = util.getTextTitle(goods.title);
            path = `pages/goods_detail/index?goods_id=${share_goods_id || goods_id}&shop_id=${share_shop_id || shop_id}`;
            imageUrl = imgsSrc[0] || '';
        } else {
            title = share_title || '';
            path = `pages/follow_detail/index?shop_id=${shop.shop_id}`;
        }
        console.log(title);
        this.shareIndex = -1;
        this.listidx = -1;
        return {
            title: title,
            path: path,
            imageUrl,
            success: function (res) {
                // 转发成功
            },
            fail: function (res) {
                // 转发失败
            }
        };
    },

    getTimestamp() {
        const len = this.list.length;

        if (len > 0) {
            return {
                top: this.list[0].time_stamp,
                bottom: this.list[len - 1].time_stamp
            };
        } else {
            return {
                top: '',
                bottom: ''
            };
        }
    },

    getUrl(type) {
        const { listIndex, getUrl, cur_page, filterText, filterImg, filterTag } = this.data;

        // this.shop_id = 'A202012141408421580517268';
        let url = `${getUrl[listIndex]}&shop_id=${this.shop_id}&search_img=${filterImg}&tag=${JSON.stringify(filterTag)}&page_index=${cur_page}`;

        // if (!!filterText) return `${url}&page_index=${cur_page}`;
        const { top, bottom } = this.getTimestamp();

        switch (type) {
            case 'top':
                url = `${url}&slip_type=0&time_stamp=${top || ''}`;
                break;

            case 'bottom':
                url = `${url}&slip_type=1&time_stamp=${bottom || ''}`;
                break;
        }

        return url;
    },

    getSubListDiff(list0, list1, listIndex) {
        let ret = {};

        for (let index = list0.length; index < list1.length; index++) {
            //const ele0 = list0[index];
            const ele1 = list1[index];

            //if (ele0.goods_id != ele1.goods_id){
            ret["list[" + listIndex + "][" + index + "]"] = ele1;
            //}
        }
        // console.log('getSubListDiff: ', ret);
        return ret;
    },

    getDiffData(newObj) {
        const { list: oldList } = this.data;
        const { list: newList, loadingNoData, groups, loading, loadingEnd } = newObj;

        console.log('getDiffData: ', oldList, newList);

        if (oldList.length == 0){
            return newObj;
        }

        let ret = {};
        for (let index = 0; index < newList.length; index++) {
            const list0 = index < oldList.length ? oldList[index] : [];
            const list1 = newList[index];

            if (list1.length != list0.length) {
                Object.assign(ret, this.getSubListDiff(list0, list1, index));
            }

        }
        Object.assign(ret, { loadingNoData, groups, loading, loadingEnd });
        console.log('getDiffData, ret: ', ret);
        return ret;
    },

    fetchData(type, callback) {
        const url = this.getUrl(type);

        console.info(url);
        this.setData({ loading: true });
        // if(type == 'bottom')
        //     return;
        let param = {
            search_value: this.data.filterText
        };
        util.fetchAuthInst(url, param, res => {
            const { errcode, result, errmsg, total_page } = res.data;
            let obj = {};

            console.info(res);
            if (errcode == 0) {
                const { goods_list, ...others } = result;
                const { cur_page, filterText } = this.data;

                obj = { ...this.data, ...others };

                if (type == 'top') {
                    // 去重
                    this.list = this.getNoRepeatList(goods_list, this.list);
                } else {
                    this.list = [...this.list, ...goods_list];

                    // if (!!filterText) {
                    //     if (cur_page >= total_page) {
                    //         obj.loadingEnd = true;
                    //     } else {
                    //         obj.cur_page = cur_page + 1;
                    //     }
                    // } else {
                    // 到底了
                    obj.loadingEnd = false;
                    goods_list.length <= 0 && (obj.loadingEnd = true);
                    // }
                }
                // 分组
                obj.list = this.getGrouplist(this.list);
                // 无数据
                if (this.list.length <= 0) {
                    obj.loadingNoData = true;
                } else {
                    obj.loadingNoData = false;
                }
                obj.groups = this.getGroups(obj);
                obj.loading = false;

                console.info('obj: ', obj);
                this.setData(this.getDiffData(obj));
                // this.setData(obj);
                console.log('this.list: ', this.list);  //数据源list
                console.log('// onReachBottom', this.data.list, this.data.list.length, constant.minPageSize);
                this.list.length < constant.minPageSize && this.onReachBottom();
                // this.data.list.length < constant.minPageSize && this.onReachBottom();
            } else {
                $wuxToast.show({
                    type: 'text',
                    text: errmsg
                });
                obj.loading = false;
                this.setData(obj);
            }

            typeof callback == 'function' && callback();

            // 清除失效token，触发重新获取
            console.log('// 清除失效token，触发重新获取', res.data);
            app.clearToken(res.data, () => {
                console.log('// 清除失效token，触发重新获取 onPullDownRefresh');
                this.onPullDownRefresh();
            });
        }, err => {
            console.log(err);
            this.setData({ loading: false });
            typeof callback == 'function' && callback();
        });
    },

    getGroups(data) {
        const { all_tags = [], groups = [] } = data;

        return groups.map(group => {
            let { tags = [] } = group;
            tags = tags.map(tagId => all_tags.filter(items => tagId == items.tagId)[0]);

            return { ...group, tags };
        });
    },

    getNoRepeatList(newList, oldList) {
        const list = [...newList, ...oldList];
        const len = list.length;
        const hash = {};
        const result = [];

        list.forEach(item => {
            const { goods_id } = item;

            if (!hash[goods_id]) {
                result.push(item);
                hash[goods_id] = true;
            }
        });

        return result;
    },

    getGrouplist(list) {
        const { listIndex, filterText } = this.data;
        let data = list;
        const topObj = {
            date: {
                date_text: '置顶'
            },
        };

        console.log('listIndex: ', listIndex);
        // if (!!filterText) return data.map(item => ({rows: constant.ROWS, richTitle: util.getRichTitle(item.title, filterText), ...item}));
        switch (listIndex) {
            case 0:
            /* // 小程序不支持发布
            // const post = this.getPostItem();
            const post = [];
            const hasPost = post.length > 0;
            // 筛选置顶
            const topArr = data.filter(item => item.isTop === 1)
                .map(item => (Object.assign({}, item, topObj)));
            topArr.sort((a, b) => b.time_stamp - a.time_stamp);
            const hasTop = topArr.length > 0;
            // 筛选非置顶
            data = data.filter(item => item.isTop !== 1); */

            case 1:
                data = data.map(item => (Object.assign({}, item, { date: this.getDateText(item.time_stamp) }, { showRemark: false })));
                let dateTimes = data.map(item => item.date.date_time);
                // console.log('111 dateTimes: ', dateTimes);
                dateTimes = this.getNoRepeatArr(dateTimes);
                console.log('222 dateTimes: ', dateTimes);
                let arr = [];

                dateTimes.forEach((date_time, i) => {
                    arr[i] = data.filter(item => item.date.date_time == date_time);
                });

                // if (listIndex == 0) {
                //     // 合并置顶
                //     arr = hasTop ? [topArr, ...arr] : arr;
                //     // 合并发布
                //     arr = hasPost ? [post, ...arr] : arr;
                // }

                return arr;
                break;

            default:
                return data.map(item => ({ rows: constant.ROWS, richTitle: !!filterText ? util.getRichTitle(item.title, filterText) : undefined, ...item }));
                break;
        }
    },

    getPostItem() {
        const post = this.shop_id ? [] : [{
            type: 'post',
            time_stamp: Date.now(),
            onPost: 'onPost'
        }];

        return post;
    },

    onPost(ev) {
        console.info('发布图文', ev);
    },

    getDateText(timestamp = Date.now()) {
        const { date_time, year, month, day } = this.getDateTime(timestamp);
        const today = this.getDateTime().date_time;
        const yesterday = this.getDateTime(Date.now() - 24 * 60 * 60 * 1000).date_time;
        let date_text = `${day < 10 ? `0${day}` : day} ${month}月`;

        if (date_time == today) {
            date_text = '今天';
        } else if (date_time == yesterday) {
            date_text = '昨天';
        }

        return {
            date_text,
            date_time,
            year,
            month,
            day
        };
    },

    getDateTime(timestamp = Date.now()) {
        const t = new Date(timestamp);
        const year = t.getFullYear();
        const month = t.getMonth() + 1;
        const day = t.getDate();
        const date_time = `${year}${month < 10 ? `0${month}` : month}${day < 10 ? `0${day}` : day}`;

        return {
            date_time,
            year,
            month,
            day
        };
    },

    getNoRepeatArr(arr) {
        const hash = {};
        const newArr = [];

        arr.forEach(item => {
            if (!hash[item]) {
                newArr.push(item);
                hash[item] = true;
            }
        });

        return newArr;
    },

    onReachBottom() {
        const { loading, loadingNoData, loadingEnd } = this.data;

        console.info('onReachBottom ', loading, loadingNoData, loadingEnd);
        if (loading || loadingNoData || loadingEnd) {
            return false;
        }

        console.info('onReachBottom');
        this.fetchData('bottom');
    },

    onPullDownRefresh() {
        wx.hideLoading();
        const { loading, filterText } = this.data;

        // if (loading || !!filterText) {
        if (loading) {
            return false;
        }

        console.info('onPullDownRefresh');
        this.fetchData('top', () => {
            console.log('stopPullDownRefresh');
            wx.stopPullDownRefresh();
        });
    },

    tapContact(ev) {
        wx.showActionSheet({
            itemList: ['微信', '电话'],
            success: res => {
                const { tapIndex } = res;

                console.log(res, tapIndex, typeof tapIndex);
                switch (tapIndex) {
                    case 0:
                        this.tapWechat(ev);
                        break;

                    case 1:
                        this.tapCall(ev);
                        break;
                }
            },
            fail: res => {
                console.log(res);
            }
        });
    },

    tapWechat(ev) {
        const { wechat_id, wechat_icon, wechat_qrcode } = this.data.shop;

        if (wechat_id || wechat_icon || wechat_qrcode) {
            this.setData({
                showWechat: true
            });
        } else {
            // $wuxToast.show({
            //     type: 'text',
            //     text: '该商家没有设置微信信息~'
            // });
            wx.showToast({
                icon: 'none',
                title: '该商家没有设置微信信息~',
            });
        }
    },

    viewQrcode(ev) {
        const { src } = ev.target.dataset;

        console.log(src);
        wx.previewImage({
            current: src,
            urls: [src]
        });
    },

    copyWechat(ev) {
        const { wechat_id } = this.data.shop;

        this.copyTitle(wechat_id);
    },

    hideWechat(ev) {
        this.setData({
            showWechat: false
        });
    },

    tapCall(ev) {
        const { phone_number: phoneNumber } = this.data.shop;

        if (phoneNumber) {
            wx.makePhoneCall({
                phoneNumber,
                fail: res => {
                    const { errMsg } = res;

                    console.info(res);
                    !errMsg.match(/cancel/) &&
                        $wuxToast.show({
                            type: 'text',
                            text: '呼叫失败，请稍后重试~'
                        });
                }
            });
        } else {
            // $wuxToast.show({
            //     type: 'text',
            //     text: '该商家没有设置电话号码~'
            // });
            wx.showToast({
                icon: 'none',
                title: '该商家没有设置电话号码~',
            });
        }
    },

    tapQrcode(ev) {
        const { shop_id } = this.data.shop;

        wx.navigateTo({
            url: `/pages/album_qrcode/index?shop_id=${shop_id}`
        });
    },

    tapTags(ev) {
        const { all_tags: tags = [], groups, filterTag } = this.data;

        this.tags.onShow({
            tags,
            groups,
            filterTag,
        });
    },

    tapTag(ev) {
        const { tagId } = ev.target.dataset;
        const { listIndex, filterText, filterImg, filterTag } = this.data;

        if (tagId == filterTag) {
            return false;
        }
        this.list = [];
        this.setData(Object.assign({}, getData(), {
            listIndex,
            filterText,
            filterImg,
            filterTag: tagId
        }));
        this.fetchData();
    },

    hideTags(ev) {
        this.setData({
            showTag: false
        });
    },

    clearTags() {
        const { listIndex, filterText, filterImg, filterTag } = this.data;

        console.log('clear');
        this.list = [];
        this.setData(Object.assign({}, getData(), {
            listIndex,
            filterText,
            filterImg,
            filterTag: []
        }));
        this.fetchData();
    },

    okTags(ev) {
        const { filterTag } = ev.detail;
        const { listIndex, filterText, filterImg } = this.data;

        console.log('ok', ev);
        this.list = [];
        this.setData(Object.assign({}, getData(), {
            listIndex,
            filterText,
            filterImg,
            filterTag
        }));
        this.fetchData();
    }

}));
