import {$wuxToast, $ellipsis, $cartSheet} from '../../components/wux';
import launchAppError from '../../components/launch-app/launch-app';
import nineGrid from '../../utils/nine-grid';
const bury = require('../../utils/burypoint.js')
const util = require('../../utils/util.js');
const logic = require('../../utils/logic.js');
const constant = require('../../utils/constant');
import commonGrid from '../../utils/common-grid.js';
import { shareAppMessageCanvas } from "../../utils/canvas-composite-img";
const app = getApp();
let shareFriendsImgPath = '';

Page(Object.assign({}, nineGrid, {
    data: {
      /**这里用来区分，用户是否从分享页面进来，以此切换不同的图片  true 代表用户从分享进来*/
        iconState: false,
        getUrl: '/album/get_album_themes_list.jsp?act=single_item',
        addUrl: '/album/album_theme_operation.jsp?act=hold_theme',
        shopCartUrl: '/shoppingCart/shopping_card_index.jsp?act=check_shopping_cart',
        loading: false,
        goods: null,
        priceTypesObj: constant.priceTypesObj,
        type: 'new',
        showWechat: false,
        autoplay: false, // 视频自动播放
        // isWifi: false,
        muted: false,
        showCart: false,
        openApp: false,
        mixThemeSwiperSrc: [],
        showPreviewer: false,
        previewList: [],
        previewIndex: 0,
        isIPhoneX: app.globalData.isIpx,
        statusBarHeight:null,

    },

    onLoad(options) {

        setTimeout(res => {
          /**这里用来区分，用户是否从分享页面进来，以此切换不同的图片  true 代表用户从分享进来*/

          let state = options.is_icon || false;
          console.log("我打印的数据", options)
          this.setData({
            iconState: state
          })
        })
        app.globalData.from = '';
        app.globalData.pageInfo = {$title: '详情', $screen_name: 'goods_detail'};
        const { shop_id, goods_id, scene = '' } = options;
        const { globalData } = app;
        const { appInitOptions: { scene: entryScene } = {} } = globalData;

        let isopenApp = false;
        if (entryScene == 1036 || entryScene == 1069) {
            isopenApp = true;
        }
        var that = this
        wx.getNetworkType({
          success: function (res) {
            let isWifi = res.networkType == 'wifi';
            //wifi环境下静音自动播放
            that.setData({
              autoplay:isWifi,
              muted: isWifi
            })
          }
        });
        wx.getSystemInfo({
          success: res => {
            this.setData({
              statusBarHeight: res.statusBarHeight,
            })
          }
        });
        this.setData({
            openApp: isopenApp
        })
        console.info('onLoad', options);
        this.shop_id = shop_id || '';
        this.goods_id = goods_id || decodeURIComponent(scene);

        // 隐藏本页面的转发按钮
        // wx.hideShareMenu();
        $ellipsis.init();
        this.$cartSheet = $cartSheet.init({
            onAddCart() {
                this.setData({
                    showCart: true
                })
            }
        });
        wx.showLoading({
            mask: false,
            title: '加载中...',
        });
        app.getUserInfo(userInfo => {
            this.fetchData(() => {
                wx.hideLoading();
                const { shop_id, images, imgsSrc, videoUrl, themeType, is_my_album } = this.data.goods || {};
                this.setData({
                    mixThemeSwiperSrc: themeType === 4 ? [videoUrl, ...(images || imgsSrc)] : [videoUrl],
                })
                this.shop_id = shop_id || '';

                let tempKey = Date.now();
                this.setData({
                    canvasW: 1,
                    canvasH: 1,
                    canvasId: "J_canvas_share" + tempKey,
                    clipCanvas: {
                        key: "clipCanvas",
                        idName:"clipCanvasShare" + tempKey,
                        width: 200,
                        height: 200,
                        value: []
                    },
                },() => {
                    if (true) {
                        shareAppMessageCanvas({
                            goods_list: [this.data.goods],
                            component: this,
                            canvasId: this.data.canvasId,
                            from: 'button', // 根据分享类型判断拼图样式
                        }).then((res) => {
                            shareFriendsImgPath = res;
                        },(e) => {
                            console.log("画图失败",e)
                        });
                    } else {
                        wx.hideShareMenu();
                    }
                })
            });
        }, () => {
            wx.hideLoading();
        }, shop_id)
      this.queryHeight();
    },

    queryHeight(){
      var query = wx.createSelectorQuery();
      //选择id
      var that = this;
      query.select('.nav-id').boundingClientRect(function (rect) {
        that.setData({
          domHeight: rect.height  + 'px'
        })

      }).exec();
    },
    goBack(){
        const page = getCurrentPages();
        if (page.length === 1) {
            wx.reLaunch({
                url: '/pages/home/index',
                success(){
                    //小红点获取
                    app.startRedPoint();
                }
            });
        } else {
            wx.navigateBack({
                delta: 1
            })
        }
    },
    onShow(e) {
        // bury.pageShow(bury_config, this.route);
        const { shopCartUrl, goods } = this.data;
        const url = shopCartUrl;
        util.fetch(url)
            .then(res => {
            const { errcode, result } = res.data;
            const { showCart } = result;
            if (errcode == 0) {
                this.setData({
                showCart
                })
            }
            }, res => {

            });

        const { pendingEvent } = app.globalData;
        // pendingEvent type: updateData
        if (pendingEvent && pendingEvent.updateData) {
            const { data } = pendingEvent.updateData;
            this.setData({
                goods: data.item ? data.item : data,
            });
        }
        if (!goods) return;
        if (!goods.is_my_album && !!app.globalData.from) {
            const { goods } = this.data;
            goods.from = app.globalData.from;
            this.setData({
                goods,
            })
            app.globalData.from = '';
        }
    },
    onShareAppMessage(res) {
        const bury_config = app.globalData.bury_config;

        const { title, shop_id, goods_id, imgsSrc, share_shop_id, share_goods_id, themeType } = this.data.goods;
        const path = `pages/goods_detail/index?goods_id=${share_goods_id || goods_id}&shop_id=${share_shop_id || shop_id}&is_icon=${true}`;

        let imageUrl = "";
        // bury.pageShare(bury_config, this.route);
        const obj = {
            route: this.route,
            $title: '详情',
            share_method: '微信小程序',
            $screen_name: 'goods_detail',
            share_content: bury.shareContentOfType(themeType),
        }
        bury.share(bury_config, obj);
        if (res.from === 'button') {
            // 来自页面内转发按钮
            const { share_goods_id: id = '', tempFilePath = '' } = wx.getStorageSync('share_goods_canvas');
            imageUrl = (id.length && id == goods_id) ? tempFilePath : imgsSrc[0];
        } else {
            imageUrl = shareFriendsImgPath || imgsSrc[0]
        }

        return {
            title,
            path,
            imageUrl,
            success: function (res) {
                // 转发成功
            },
            fail: function (res) {
                // 转发失败
            }
        };
    },

    launchAppError,

    getUrl() {
        const { getUrl } = this.data;

        return `${getUrl}&shop_id=${this.shop_id}&goods_id=${this.goods_id}`;
    },

    fetchData(callback) {
        const url = this.getUrl();

        console.info(url);
        this.setData({loading: true});
        util.fetch(url)
            .then(res => {
                const {errcode, errmsg, result} = res.data;
                let obj = {};

                console.log(res);
                if (errcode == 0) {
                    obj.goods = result;

                    this.goods_id = result.goods_id;
                    this.shop_id = result.shop_id;

                    obj.loading = false;

                    this.setData(obj);
                    typeof callback == 'function' && callback();
                } else if (errcode == 300) {
                    obj = result;
                    obj.errMsg = errmsg;
                    obj.loading = false;

                    this.setData(obj);
                    wx.hideLoading();
                } else {
                    wx.hideLoading();

                    wx.showModal({
                        title: '温馨提示',
                        content: errmsg,
                        showCancel: false,
                        success(res) {
                            if (res.confirm) {
                                wx.hideLoading();
                            }
                        }
                    });

                    this.setData({
                        loading: false
                    })
                }

                // 清除失效token，触发重新获取
                app.clearToken(res.data, () => {
                    this.onPullDownRefresh();
                });
            }, () => {
                this.setData({loading: false});
                typeof callback == 'function' && callback();
            });
    },

    onPullDownRefresh() {
        wx.hideLoading();
        const { loading } = this.data;

        if (loading) {
            return false;
        }

        console.log("onPullDownRefresh");
        this.fetchData(() => {
            console.log("stopPullDownRefresh");
            const { shop_id, images, imgsSrc, videoUrl, themeType } = this.data.goods || {};
            this.setData({
                mixThemeSwiperSrc: themeType === 4 ? [videoUrl, ...(images || imgsSrc)] : [videoUrl],
            })
            wx.stopPullDownRefresh();
        });
    },

    iconTap(ev) {
        const route = '/pages/follow_detail/index';
        const options = {
            shop_id: this.shop_id,
        };

        util.navigateTo(route, options);
    },

    onViewImg(e) {
        const { goods } = this.data;
        const { index } = e.currentTarget.dataset;
        const { imgsSrc: imgssrc } = this.data.goods;

        const videoContext = wx.createVideoContext('video_goods_detail', this);
        videoContext && videoContext.stop();

        const { previewList, previewIndex } = util.getPreviewerInitData([goods], 0, index);

        this.setData({
            showPreviewer: true,
            previewList,
            previewIndex,
        }, () => {
            this.data.showPreviewer && util.navigateToBrowserPage();
        });

        // console.info(index, e);
        // wx.previewImage({
        //     current: imgssrc[index], // 当前显示图片的http链接
        //     urls: imgssrc // 需要预览的图片http链接列表
        // });
    },

    wxPreview(e) {
        const { index } = e.currentTarget.dataset;
        const { imgsSrc: imgssrc } = this.data.goods;
        wx.previewImage({
            current: imgssrc[index], // 当前显示图片的http链接
            urls: imgssrc // 需要预览的图片http链接列表
        });
    },

    previewImgs(e) {
        this.setData({
            showPreviewer: true,
            ...e.detail,
        })
    },

    onTapTag(e) {
        const { tagId } = e.currentTarget.dataset;
        const route = '/pages/tag_goods_list/index';
        const options = {
            shop_id: this.shop_id,
            from:"tags",
            tag_id: tagId,
        };

        util.navigateTo(route, options);
    },

    tapContact() {
        wx.showActionSheet({
            itemList: ['微信', '电话'],
            success: res => {
                const { tapIndex } = res;

                switch (tapIndex) {
                    case 0:
                        this.tapWechat();
                        break;

                    case 1:
                        this.tapCall();
                        break;
                }
            },
            fail: res => {
                console.log(res);
            }
        });
    },

    tapWechat() {
        const { wechat_id, wechat_qrcode } = this.data.goods.shop || {};

        if (wechat_id || wechat_qrcode) {
            this.setData({
                showWechat: true
            });
        } else {
            wx.showToast({
                icon: 'none',
                title: '该好友没有设置微信信息~',
            });
        }
    },

    viewQrcode(e) {
        const { src } = e.target.dataset;

        console.log(src);
        wx.previewImage({
            current: src,
            urls: [src]
        })
    },

    copyWechat(e) {
        const { title } = e.target.dataset;

        this.copyTitle(title);
    },

    hideWechat() {
        this.setData({
            showWechat: false
        });
    },

    tapCall() {
        const { phone_number: phoneNumber } = this.data.goods.shop || {};

        if (phoneNumber) {
            wx.makePhoneCall({
                phoneNumber,
                fail: res => {
                    const { errMsg } = res;

                    console.info(res);
                    !errMsg.match(/cancel/) &&
                    wx.showToast({
                        icon: 'none',
                        title: '呼叫失败，请稍后重试~',
                    });
                }
            });
        } else {
            wx.showToast({
                icon: 'none',
                title: '该好友没有设置电话号码~',
            });
        }
    },

    onDownload(e) {
        const { dataset } = e.currentTarget;
        const { title } = this.data.goods;
        // 复制标题
        // this.copyTitle(util.getTextTitle(title));
        // 下载图片
        app.globalData.title = title;
        // const timer = setTimeout(() => {
        //     clearTimeout(timer);
        //     logic.downloadImgs({...dataset, title: util.getTextTitle(title)}, this.downloadStartCB, this.downloadingCB);
        // }, 500);
        logic.downloadImgs({...dataset, title: util.getTextTitle(title)}, this.downloadStartCB, this.downloadingCB);
    },

    onAdd(e) {
        let {goods_id, shop_id} = e.currentTarget.dataset;
        util.openGoodsEdit({
          goods_id:this.goods_id,
          shop_id:this.shop_id
        });
        // const { addUrl } = this.data;
        // const url = `${addUrl}&shop_id=${this.shop_id}&goods_id=${this.goods_id}`;

        // console.info("onAdd", e);
        // wx.showLoading({
        //     mask: true,
        //     title: '加载中...',
        // });
        // util.fetch(url)
        //     .then(res => {
        //         const { errcode, result } = res.data;

        //         wx.hideLoading();
        //         if (errcode == 0) {
        //             const { follow_object } = result;

        //             // 未关注
        //             if (follow_object) {
        //                 this.showGuide(this.shop_id, follow_object);
        //                 return false;
        //             }

        //             // 分享
        //             this.onShare(e);
        //         }
        //     }, () => {
        //         console.info('onAdd error');

        //         wx.hideLoading();
        //     });
    },

    onShare(e) {
        const { title,themeType,videoURL,imgsSrc } = this.data.goods;
        // 复制标题
        // this.copyTitle(title);
        let data = e.target.dataset;
         app.globalData.title = title;
       // data.title = title;
        // 分享
        const images = themeType === 1 ? (videoURL ? [videoURL] : []) : imgsSrc;
        data.images = images;
        console.log("分享数据",data)
        logic.showshare(data, this.downloadStartCB, this.downloadingCB, this.onAddThemeToAlbum, this)
    },

    onToShop() {
        this.iconTap();
    },

    onRichTextLongTap(e) {
        if (!e.currentTarget.dataset.title) {
            return;
        }
        wx.setClipboardData({
            data: e.currentTarget.dataset.title,
            success: () => {
                wx.showToast({
                    title: '已复制',
                    icon: 'success',
                    duration: 1000,
                    mask: true
                })
            }
        })
    },
    handleToShopCarDetail() {
      wx.navigateTo({
        url: '/pages/my_shopping_cart/index',
      })
    },

    onAddCart(e) {
        const { goods } = e.target.dataset;
        const { shop_id, goods_id } = goods;
        const getGoodsUrl = '/album/get_album_themes_list.jsp?act=single_item';
        const url = `${getGoodsUrl}&shop_id=${shop_id}&goods_id=${goods_id}&is_spot_format=true&is_add_purchase=true`;

        wx.showLoading({
            mask: true,
            title: '加载中...',
        });
        util.fetch(url).then(res => {
            const { errcode, result } = res.data;
            wx.hideLoading();
            if (errcode == 0) {
                // this.$cartSheet.onShow(result);
                if (this.data){
                    this.$cartSheet.onShow(result);
                }
            }
        }, err => {
            console.info('onAddThemeToAlbum error', err);
            wx.hideLoading();
        });
    },

  showOperationToast(data) {
    let { errcode, errmsg } = data
    wx.showToast({
      title: errmsg,
      icon: errcode == 0 ? 'success' : 'none',
      duration: 1000,
      mask: true
    })
  },

  onDelGoods(e) {
    let param = {
        goods_id:this.data.goods.goods_id
      }
    let that = this;
    commonGrid.onDelGoods(param, (data)=>{
        this.delGoods(data);
      });
  },

  delGoods(data){
    let {goods_id} = data;
    wx.navigateBack({
        delta: 1
    })
    //TODO:删除上一页商品
  },

  onRefreshGoods(e) {
    let param = {
      goods_id: this.data.goods.goods_id
    }
    commonGrid.onRefreshGoods(param);
  },

  onSetTopGoods(e) {
    let { goods_id, isTop} = this.data.goods;
    let param = {
      goods_id,
      isTop
    }
    let that = this;
    commonGrid.onSetTopGoods(param, data=>{
      this.setTopGoods(data);
    })

  },
  setTopGoods(data){
    let {isTop, goods_id} = data;
    isTop = isTop == 1 ? 0 : 1;
    this.data.goods.isTop = isTop;
    this.setData({ goods:this.data.goods });
  },

    onEditGoods(e) {
        let {goods_id, shop_id} = this.data.goods;
        let param ={
            goods_id,
            shop_id
        }
        commonGrid.onEditGoods(param);
    },

    updateData(e){
        let data = e.detail;
        if (data.action === 'del') {
            this.delGoods(data);
        } else if (data.action === 'top') {
            this.setTopGoods(e.detail);
        } else if (data.action === 'circle') {
            this._requestShare();
        }
    },

    _requestShare() {
        const { goods } = this.data;
        util.updateShareTime(goods, res => {
            this.setData({
                goods: { ...goods, ...res },
            });
            const app = getApp();
            app.globalData.willUpdateGoods = { ...goods, ...res };
        });
    }
}))
