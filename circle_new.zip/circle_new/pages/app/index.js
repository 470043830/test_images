const util = require('../../utils/util.js');

Page({
    data: {
        getUrl: '/album/get_album_help.jsp?act=get_miniapp_download_help',
        imgWidth: '100%',
        pic: [],
    },

    onLoad(options) {
        console.info('onLoad', options);
        this.fetchData();
    },

    fetchData() {
        const { getUrl: url } = this.data;
        const postData = {
            system_type: util.isIOS() ? 'ios' : 'android'
        };

        console.info(url);
        wx.showLoading({
            mask: false,
            title: '加载中...',
        });
        util.fetchAuthInst(url, postData, res => {
            const { errcode, result } = res.data;
            let obj = {};

            console.log(res);
            wx.hideLoading();
            if (errcode == 0) {
                obj = Object.assign({}, this.data, result);
                this.setData(obj);
            }
        }, err => {
            console.log(err);
            wx.hideLoading();
        });
    },

    bindload(ev) {
        const { detail } = ev;
        const { width } = detail;

        console.info(detail);
        this.setData({
            imgWidth: `${width}px`
        });
    },

    previewImage(ev) {
        const { src } = ev.target.dataset;
        const { pic } = this.data;

        console.log(src, pic);
        wx.previewImage({
            current: src,
            urls: pic
        });
    },

})
