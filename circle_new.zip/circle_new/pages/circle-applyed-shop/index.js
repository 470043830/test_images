// pages/circle-applyed-shop/index.js
const circleData = require('../../utils/circle-data.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    shop: {
      // name: '悠路铭衫 VIP',
      // avatar: 'https://xcimg.szwego.com/4NzwLSYEzicS43qlGPbA11ibzQTZyibxWYsWdJy85I3hGvyr1pRxh6nqMudaWOq7sqQ6Jt79hopLnESib3IfD4yAibw',
      // phone: '13510588888',
      // wechat: 'WXmicai',
      // qrcode: 'https://xcimg.szwego.com/20210905/i1630845239_9912_0.jpg',
      // region: '浙江省杭州市13行',
      // addr: '13行大厦1308',
      // category: '男装、女装、童装',
    },
    isHot: false,
    listType: '0',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    wx.hideShareMenu({
      menus: ['shareAppMessage', 'shareTimeline']
    })
    console.log('onLoad options: ', options);

    const { albumId = '', isHot = '', type = '0' } = options;
    this._listType = type;
    this.setData({ listType: type });

    if (type == '1') { //zhubo
      this.getAnchorCircleApply(albumId, isHot);
    } else {
      this.getCircleApply(albumId, isHot);
    }
  },

  async getCircleApply(albumId, isHot) {
    const applyInfo = await circleData.getCircleApply({ albumId });
    if (applyInfo.shopId) {
      this.setData({
        isHot,
        shop: {
          id: applyInfo.shopId,
          name: applyInfo.shopName,
          avatar: applyInfo.shopIcon,
          wechat: applyInfo.wechatId,
          phone: applyInfo.phoneNumber,
          qrcode: applyInfo.wechatQrcode,
          region: applyInfo.region,
          addr: applyInfo.detailAddress,
          category: applyInfo.category,
          createTime: applyInfo.createTime,
        }
      })
    }
  },

  async getAnchorCircleApply(albumId, isHot) {
    const applyInfo = await circleData.getAnchorCircleApply({ albumId });
    if (applyInfo.shopId) {
      this.setData({
        isHot,
        shop: {
          id: applyInfo.shopId,
          name: applyInfo.shopName,
          avatar: applyInfo.shopIcon,
          wechat: applyInfo.wechatId,
          phone: applyInfo.phoneNumber,
          qrcode: applyInfo.wechatQrcode,
          region: applyInfo.region,
          addr: applyInfo.detailAddress,
          category: applyInfo.category,
          createTime: applyInfo.createTime,
          age: applyInfo.age,
          remark: applyInfo.remark,
          platform: applyInfo.platform,
          priceDesc: applyInfo.priceDesc,
        }
      })
    }
  },



  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  onHotTap() {
    const that = this;
    const { shop, isHot } = this.data;
    if (isHot) {
      wx.showModal({
        title: '提示',
        content: `是否取消推荐 ${shop.name} ？`,
        async success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
            // const result = await circleData.recommendMerchant(shop.id, 1);
            let result = 0;
            if (that._listType == '1') {
              result = await circleData.recommendAnchor(shop.id, 1);
            } else {
              result = await circleData.recommendMerchant(shop.id, 1);
            }
            if (result) {
              wx.showToast({
                title: '已取消推荐！',
                icon: 'none',
                duration: 1500,
                mask: false,
              });
              that.setData({
                isHot: false
              });
            }
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      wx.showModal({
        title: '提示',
        content: `确认推荐 ${shop.name} ？`,
        async success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
            // const result = await circleData.recommendMerchant(shop.id, 0);
            let result = 0;
            if (that._listType == '1') {
              result = await circleData.recommendAnchor(shop.id, 0);
            } else {
              result = await circleData.recommendMerchant(shop.id, 0);
            }
            if (result) {
              wx.showToast({
                title: '推荐成功！',
                icon: 'none',
                duration: 1500,
                mask: false,
              });
              that.setData({
                isHot: true
              });
            }
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      });
    }

  },

  onRemoveTap() {
    const that = this;
    const { shop } = this.data;
    wx.showModal({
      title: '提示',
      content: `确认移除 ${shop.name} ？移除后将不在平台展示，请谨慎操作！`,
      async success(res) {
        if (res.confirm) {
          console.log('用户点击确定')
          // const result = await circleData.delMerchant(shop.id, 1);
          // const result = await circleData.delMerchant('A202209021631150820001551', 0);
          let result = 0;
          if (that._listType == '1') {
            result = await circleData.deleteAnchor(shop.id, 1);
          } else {
            result = await circleData.delMerchant(shop.id, 1);
          }
          if (result) {
            wx.navigateBack();
          }
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },

  onCopyTap(e) {
    console.log('onCopyTap, e: ', e);
    const { copy } = e.currentTarget.dataset;
    wx.setClipboardData({
      data: copy,
      success: () => {
        wx.showToast({
          title: '已复制',
          icon: 'success',
          duration: 1000,
          mask: true
        });
      }
    })
  },

  onQrcodeTap() {
    const { shop } = this.data;
    wx.previewImage({
      current: shop.qrcode,
      urls: [shop.qrcode]
    });
  },



})