// pages/circle-applyed-list/index.js
const circleData = require('../../utils/circle-data.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    items: [
      //   {
      //   name: '悠路铭衫 VIP',
      //   avatar: 'https://xcimg.szwego.com/4NzwLSYEzicS43qlGPbA11ibzQTZyibxWYsWdJy85I3hGvyr1pRxh6nqMudaWOq7sqQ6Jt79hopLnESib3IfD4yAibw',
      //   addr: '贵航大厦1楼123号',
      //   goods: '6',
      //   isHot: true,
      // }, {
      //   name: 'YI SHILING',
      //   avatar: 'https://xcimg.szwego.com/4NzwLSYEzicS43qlGPbA11ibzQTZyibxWYsWdJy85I3hGvyr1pRxh6nqMudaWOq7sqQ6Jt79hopLnESib3IfD4yAibw',
      //   addr: '飞马城-二期204栋...',
      //   goods: '2000',
      //   isHot: false,
      // }
    ],
    listType: '0',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    const { type = '0' } = options;
    this._listType = type;
    console.log('this._listType: ', this._listType);
    if (type == '1') {
      wx.setNavigationBarTitle({
        title: '已入驻主播',    //页面标题
      });
    }
    wx.hideShareMenu({
      menus: ['shareAppMessage', 'shareTimeline']
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.startGetNetData();
  },

  onCellTap(e) {
    console.log('onCellTap, albumid:', e.currentTarget.dataset);
    const { item } = e.currentTarget.dataset;
    let url = `/pages/circle-applyed-shop/index?albumId=${item.albumId}&type=${this._listType}`;
    if (item.isHot) url += '&isHot=1';
    wx.navigateTo({ url });
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  async startGetNetData() {
    let list = null;
    if (this._listType == '1') {
      list = await circleData.queryAnchorApplyList();
    } else {
      list = await circleData.queryMerchantsList();
    }
    console.log('list: ', list);
    const items = list.map(item => (
      {
        albumId: item.shopId,
        name: item.shopName,
        avatar: item.shopIcon,
        // addr: item.detailAddress,
        goods: item.newItemCount,
        isHot: item.isRecommend === 0 || item.isRecommend === true,
        // isHot: item.isRecommend == 1?false:(),
      }
    ));
    console.log('items: ', items);
    this.setData({ items, listType: this._listType })
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    this.startGetNetData();
    setTimeout(() => {
      wx.stopPullDownRefresh();
    }, 300);
  },


  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  onHotTap(e) {
    const that = this;
    const { items } = this.data;
    const { index } = e.currentTarget.dataset;
    const shop = items[index];
    if (shop.isHot) {
      wx.showModal({
        title: '提示',
        content: `是否取消推荐 ${shop.name} ？`,
        async success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
            let result = 0;
            if (that._listType == '1') {
              result = await circleData.recommendAnchor(shop.albumId, 1);
            } else {
              result = await circleData.recommendMerchant(shop.albumId, 1);
            }
            if (result) {
              wx.showToast({
                title: '已取消推荐！',
                icon: 'none',
                duration: 1500,
                mask: false,
              });
              shop.isHot = false;
              that.setData({
                isHot: false, items
              });
            }
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      wx.showModal({
        title: '提示',
        content: `确认推荐 ${shop.name} ？`,
        async success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
            // const result = await circleData.recommendMerchant(shop.albumId, 0);
            let result = 0;
            if (that._listType == '1') {
              result = await circleData.recommendAnchor(shop.albumId, 0);
            } else {
              result = await circleData.recommendMerchant(shop.albumId, 0);
            }
            if (result) {
              wx.showToast({
                title: '推荐成功！',
                icon: 'none',
                duration: 1500,
                mask: false,
              });
              shop.isHot = true;
              that.setData({
                isHot: true, items
              });
            }
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      });
    }

  },

  onRemoveTap(e) {
    const that = this;
    const { items } = this.data;
    const { index } = e.currentTarget.dataset;
    const shop = items[index];
    wx.showModal({
      title: '提示',
      content: `确认移除 ${shop.name} ？移除后将不在平台展示，请谨慎操作！`,
      async success(res) {
        if (res.confirm) {
          console.log('用户点击确定', shop.albumId);
          // const result = await circleData.delMerchant(shop.albumId, 1);
          // const result = await circleData.delMerchant('A201905291653236670027260', 0);
          let result = 0;
          if (that._listType == '1') {
            result = await circleData.deleteAnchor(shop.albumId, 1);
          } else {
            result = await circleData.delMerchant(shop.albumId, 1);
          }
          if (result) {
            // that.startGetNetData();
            items.splice(index, 1);
            that.setData({ items });
          }
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },

})