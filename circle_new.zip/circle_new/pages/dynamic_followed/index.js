// pages/test001/index.js
import { $tdSearchbar } from '../../components/wux';



Page({

    /**
     * 页面的初始数据
     */
    data: {
        dynamicList: {}
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        const dynamicList = this.selectComponent('#dynamic-list');

        if (!dynamicList) {
            return;
        }
        this.setData({ dynamicList });

        $tdSearchbar.init({
            style: 'border: none',
            image: false,
            searchHandler(text, img) {
                dynamicList.searchHandler(text, img);
            }
        });
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {
        const { dynamicList } = this.data;
        if (dynamicList) {
            dynamicList.onPullDownRefresh();
        }
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
        const { dynamicList } = this.data;
        if (dynamicList) {
            dynamicList.onReachBottom();
        }
    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
});
