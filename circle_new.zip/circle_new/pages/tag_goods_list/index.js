import { $tdSearchbar, $ellipsis, $cartSheet } from '../../components/wux';
import launchAppError from '../../components/launch-app/launch-app';
import {
    shareAppMessageCanvas
} from "../../utils/canvas-composite-img";
import fourGrid from '../../utils/four-grid';
import nineGrid from '../../utils/nine-grid';
const bury = require('../../utils/burypoint.js')
const util = require('../../utils/util.js');
const logic = require('../../utils/logic.js');
const constant = require('../../utils/constant');
const app = getApp();
const waterfullId = 1; //瀑布流的id
let shareFriendsImgPath = "";
let queryStringOptions = {};
let shopInfo = null;
function getCol(width) {
    return width >= 600 ? 3 : 2;
}
function getData() {
    return {
        isIOS: util.isIOS(),
        getUrl: '/album/get_album_themes_list.jsp?act=get_alone_page', // [标签独立页面接口,日期独立页面接口]
        shopCartUrl: '/shoppingCart/shopping_card_index.jsp?act=check_shopping_cart',
        col: 2,
        gap: 15,
        itemW: '48%', // 列宽
        loading: false,
        loadingNoData: false, // 无数据
        loadingEnd: false, // 到底了
        search_value: '',
        filterImg: '',
        search_img: '',
        cur_page: 1,
        filterText: '',
        filterTag: [],
        list: [],
        showCart:false,
        loadingNum: 0,
        listIndex: 0,
        date:"",  // 日期独立页面日期参数
        curQueryType:0,  // navs 当前选中的导航
        from:"",  // 页面跳转来源，date日期独立页面 和tags标签独立页面两种类型
        // navs: [],
        priceTypesObj: constant.priceTypesObj,
        selectShow: false,
        //0:瀑布流；1：商城模板；2：商城单图列表；3：微信朋友圈动态；4：微信朋友圈列表
        // canvasW: 1,
        // canvasH: 1,
        // canvasId: "J_canvas_share",
        // clipCanvas:{
        //     key:"clipCanvas",
        //     idName:"clipCanvas",
        //     width: 200,
        //     height: 200,
        //     value:[]
        // },
        showPreviewer:false,
        previewList:[],
        previewIndex:0,
        hasBackRouter:true,
        vipConfrimShow:false,
        supportNavigationStyle:true
    };
}

// function getCol(width) {
//     return width >= 600 ? 3 : 2;
// }

Page(Object.assign({}, fourGrid, nineGrid,{
    data: getData(),

    launchAppError,

    onShareAppMessage(res) {
        const bury_config = app.globalData.bury_config;

        let { share,list } = this.data;
        let share_content = '小程序个人主页';
        let shareTitle = '';
        let path = util.urlAddQueryString("pages/tag_goods_list/index",queryStringOptions);
        let sharedata = wx.getStorageSync('share_index');
        let shareIndex;
        let listidx;
        let imageUrl = "";
        if(sharedata && sharedata != ""){
            shareIndex = sharedata.index;
            listidx = sharedata.listidx;
            console.log("shareIndex",shareIndex);
        }

        let imgsSrc = [];
        let goods_id = '';
        if (shareIndex > -1) {
            const goods = listidx > -1 ? list[listidx][shareIndex] : list[shareIndex];
            const {
                shop_id,
                share_shop_id,
                share_goods_id,
                themeType
            } = goods;
            imgsSrc = goods.imgsSrc;
            goods_id = goods.goods_id;
            share_content = ""; //bury.shareContentOfType(themeType);
            shareTitle = util.getTextTitle(goods.title);
          path = `pages/goods_detail/index?goods_id=${share_goods_id || goods_id}&shop_id=${share_shop_id || shop_id}&is_icon=${true}`;
        } else {
            shareTitle = share.miniappTitle || '';
        }

        if(sharedata && sharedata != ""){
            sharedata.listidx = -1;
            sharedata.index = -1;
            wx.setStorageSync('share_index', sharedata);
        }

        const obj = {
            route: this.route,
            $title: '商品标签列表',
            share_method: '微信小程序',
            $screen_name: 'tag_goods_list',
            share_content: share_content,
        }
        // bury.share(bury_config, obj);

        if(res.from === "menu"){
            imageUrl = shareFriendsImgPath;
        }else{
            // 来自页面内转发按钮
            const { share_goods_id: id = '', tempFilePath = '' } = wx.getStorageSync('share_goods_canvas');
            imageUrl = (id.length && id == goods_id) ? tempFilePath : imgsSrc[0];
        }
        console.log(shareTitle,path,imageUrl);
        return {
            title: shareTitle,
            path, // 默认当前页面 path
            imageUrl:imageUrl,
            success: function (res) {
                // 转发成功

            },
            fail: function (res) {
                // 转发失败
            }
        }
    },
    onUnload(){
        shareFriendsImgPath = "";
    },
    onLoad(options) {

        // 判断是否支持自定义导航
        this.setData({
            supportNavigationStyle:util.supportNavigationStyle()
        })
        if(getCurrentPages().length <= 1){
            this.setData({
                hasBackRouter:false
            });
        }
        const { shop_id, tag_id, group_id, timestamp, from='' } = options;
        this.localTemplateId = 0;//临时模板ID
        this.setData({
            from,
        })
        if(from === "date" && timestamp){
            this.setData({
                date:util.getCurrentTime('-',':','DATE',Math.abs(timestamp))
            })
        }
        app.globalData.pageInfo = {$title: '标签商品列表', $screen_name: 'tag_goods_list'};
        queryStringOptions = options;
        console.info('onLoad', options);
        this.shop_id = shop_id || '';
        this.tag_id = tag_id || '';
        this.group_id = group_id || '';
        this.list = [];
        this.setData(Object.assign({}, this.data));
        $ellipsis.init()
        if (options.scene) {
            let scene = decodeURIComponent(options.scene);

            // 时间独立页分享
            if (scene.indexOf('_') === 6) {
                const dateStr = scene.substr(0, 6);
                this.date = 20 + dateStr.slice(0, 2) + '-' + dateStr.slice(2, 4) + '-' + dateStr.slice(4, 6);
                this.shop_id = scene.substr(7);
                this.setData({
                    from: 'date',
                    date: this.date,
                })
            } else {
                let reg = /^A/; //含有shopid
                const isHasShopid = reg.test(scene); //传
                if (isHasShopid){
                    let sceneSplit = scene.split(';');
                    this.shop_id = sceneSplit[0];
                    scene = sceneSplit[1];
                }
                reg = /^g/; //分组
                const isGroup = reg.test(scene);
                if (isGroup) {
                    this.group_id = scene.substr(1);
                } else {
                    this.tag_id = "["+scene+"]";
                }
            }
        }
        this.getItemW();
        this.$cartSheet = $cartSheet.init({
          onAddCart() {
            this.setData({
              showCart: true
            })
          }
        });
        $tdSearchbar.init({
            image: !util.getIsGuest(),
            onAddImg(upload) {
                const {
                    login_user: { // 登录用户
                        vip_status, // vip状态
                        photo_search_check: login_photo_search_check, // Boolean：搜图开关
                    } = {},
                    shop: { photo_search_check } = {}, // Boolean：当前店铺是否开启搜图开关
                    isMyAlbum,
                } = this.page.data;

                // vip_status: 0为非会员 1会员 2试用期 3会员过期
                switch (vip_status) {
                    case 0:
                    case 3:
                        this.setData({
                            vipConfrimShow:true
                        })
                        break;

                    case 1:
                        if (login_photo_search_check && photo_search_check) {
                            upload();
                        } else {
                            this.setData({
                                vipConfrimShow:true
                            })
                        }
                        break;

                    case 2:
                        if (!isMyAlbum && !photo_search_check) {
                            this.setData({
                                vipConfrimShow:true
                            })
                        } else {
                            upload();
                        }
                        break;

                    default:
                        break;
                }
            },
            searchHandler(text, img) {
                console.log(text + '---' + img);
                const {
                    photoSearchCheck
                } = this.page.data;

                // 搜索时停止递归renderList
                this.page.stopRenderList = true;
                this.page.list = [];
                this.setData({
                    loadingNoData: false,
                    loadingEnd: false,
                    search_value: text,
                    search_img: img,
                    list: [],
                    canvasId:null,
                    photoSearchCheck
                }, () => {
                    this.page.stopRenderList = false;
                    this.page.fetchData('',data => {
                        if(data.goods_list){
                            this.page.initShareAppMessageToCanvas(data);
                        }
                    });
                });
            }
        })

        wx.getSystemInfo({
            success: res => {
                console.log("onShow:" + res.windowHeight)
                this.setData({
                    statusBarHeight: res.statusBarHeight,
                })
            }
        });
        this.initData();
    },
    initShareAppMessageToCanvas(data){
        // 前6个商品，低于6个大于4个，拼4个图。大于2个低于4个，拼 2个图。如果少于2个，则默认按老的分享方式。
        function queryGoods(goodsList = []){
            let goodsData = [];
            if(goodsList && goodsList instanceof Array){
                goodsList.some((item,index) => {
                    if(goodsData.length < 6){
                        if(item.themeType == 1 && item.imgs && item.imgs.length > 0){
                            goodsData.push(item);
                        }else if(item.themeType == 4){
                            if(item.imgs && item.imgs.length > 0){
                                goodsData.push(item);
                            }else{
                                if(item.videoThumbImg && item.videoThumbImg != ""){
                                    goodsData.push(item);
                                }
                            }
                        } else {
                            if(item.imgs && item.imgs.length > 0){
                                goodsData.push(item);
                            }
                        }
                    }else{
                        return true;
                    }
                })
            }
            console.log("goodsData",goodsData)
            return goodsData;
        }
        let goodsData = queryGoods(data.goods_list);
        if(goodsData.length === 5){
            goodsData.splice(4,1)
        } else if(goodsData.length === 3){
            goodsData.splice(2,1)
        }
        if(goodsData.length >= 2){
            // 每次都重新生成canvas-ID，不然画图失败
            let tempKey = Date.now();
            this.setData({
                canvasW: 1,
                canvasH: 1,
                canvasId: "J_canvas_share" + tempKey,
                clipCanvas: {
                    key: "clipCanvas",
                    idName:"clipCanvasShare" + tempKey,
                    width: 200,
                    height: 200,
                    value: []
                },
            },() => {
                shareAppMessageCanvas({
                    goods_list:goodsData,...shopInfo,
                    component:this,
                    canvasId:this.data.canvasId,
                    from:"menu"
                }).then((res) => {
                    console.log("后台画图完成", res);
                    shareFriendsImgPath = res;
                });
            })

        }

    },
    initData(){
        wx.showLoading({
            mask: false,
            title: '加载中...',
        });

        this.fetchData('init', (data) => {
            const { title, list } = this.data;
            wx.hideLoading();
            if(this.data.from == "date"){
                let dateTitle = dateStrTransform(this.data.date);
                this.data.date && this.setData({
                    navigationBarTitle:dateTitle
                })
            } else {
                title && this.setData({
                    navigationBarTitle:title
                })
            }
            // console.log("this.data",this.data);
            // 2020-03-04  替换为 2020年03月04日
            function dateStrTransform(date){
                let result = "";
                if(date && typeof date === "string"){
                    result = date.replace(/-/g,function($1,$2){
                        if($2 === 4){
                            return "年";
                        } else if($2 === 7){
                            return "月";
                        }
                    })
                    result += "日";
                }
                return result;
            }
            // 进入页面预生成canvas 图片，因为onShareAppMessage 函数不支持异步调用，
            // 商品店铺图片大于6个才调用该方法
            shopInfo = data.shop;
            this.setData({
                shop:data.shop,
                isMyAlbum:data.isMyAlbum,
                photoSearchCheck:data.photo_search_check
            })
            this.setDialogInfo();
            if(data.goods_list){
                this.initShareAppMessageToCanvas(data);
            }
            // list.length < constant.minPageSize && this.onReachBottom();
        });
    },

    updateVip() {
        const { login_user = {} } = this.data;
        const { vip_status, photo_search_check } = app.globalData;

        if (typeof vip_status === 'undefined') return;
        if (typeof photo_search_check === 'undefined') return;

        this.setData({
            login_user: {
                ...login_user,
                vip_status,
                photo_search_check,
            },
        });
    },

    onShow (e) {
        // bury.pageShow(bury_config, this.route);
        this.updateVip();
        let list = logic.updateGoodsFromEdit(this)

        list&&this.setData({
            list
        })

        const { shopCartUrl } = this.data;
        const url = shopCartUrl;
        util.fetch(url)
            .then(res => {
                const { errcode, result } = res.data;
                const { showCart } = result;
                if (errcode == 0) {
                    this.setData({
                        showCart
                })
            }
        }, res => {

        });
    },


   /**
    * 根据ID获取模板对象
   */
    getTemplateById(id, template_list){

        if (!template_list){
        return null;
        }
        let obj = template_list.filter(item=>{return item.id == id});


        return obj[0] || template_list[0];
    },

    saveTemplate(id){
        let saveTemplateUrl = '/album/album_config_operation.jsp?act=set_album_template';
        let param = {
        template:id
        };
        util.fetch(saveTemplateUrl, param).then(res=>{
        let {errcode, errmsg} = res.data;
        if (errcode == 0){
            // wx.showToast({
            //   title: errmsg,
            //   icon: "none",
            // })
        }else{
            wx.showToast({
            title: errmsg||'异常',
            icon: "none",
            })
        }
        });
    },
    goBack() {
        util.navGoBack();
    },
    getItemW() {
        const { template, gap } = this.data;

        // if (template != 1) return;

        const { windowWidth } = wx.getSystemInfoSync();
        const col = getCol(windowWidth);
        const gapW = (col + 1) * gap;
        const itemW = `${((windowWidth - gapW) / col) | 0}px`;
        this.itemW = itemW;
        this.col = col;
        this.setData({ col, itemW });
    },

    getTimestamp() {
        const { list = [] } = this;
        const len = list.length;

        if (len > 0) {
            return {
                top: list[0].time_stamp,
                bottom: list[len - 1].time_stamp
            };
        } else {
            return {
                top: '',
                bottom: ''
            };
        }
    },

    getUrl(type) {
        const { getUrl } = this.data;
        const { top, bottom } = this.getTimestamp();
        // let url = getUrl[0];
        // if(this.data.from === "date"){
        //     url = getUrl[1];
        // }
        let url = getUrl;

        switch (type) {
            case 'top':
                url = `${url}&slip_type=0&time_stamp=${top}`;
                break;

            case 'bottom':
                url = `${url}&slip_type=1&time_stamp=${bottom}`;
                break;
        }

        return url;
    },

    fetchData(type, callback) {
        const url = this.getUrl(type);
        const params = {
            shop_id: this.shop_id,
            tag_id: this.tag_id,
            group_id: this.group_id,
            search_value: this.data.search_value,
            search_img: this.data.search_img,
            start_date:this.data.date,
            end_date:this.data.date,
            query_type:this.data.curQueryType
        };
        if(queryStringOptions.from == "date"){
            params["page"] = "goods_list";
        }
        const bury_config = app.globalData.bury_config;
        const isSearch = !!(this.data.search_value || this.data.search_img);
        const searchType = isSearch && this.data.search_value ? '文字搜索' : '图搜';
        this.setData({loadingNum: 0});
        const {top = ''} = this.getTimestamp(type);

        console.log(" this.data.search_value", this.data.search_value);
        if(type != "init"){
            this.setData({
                loading: true
            });
        }
        // return;
        util.fetch(url, params)
            .then(res => {
                const { errcode, errmsg, result } = res.data;
                let obj = {};
                const isSuccess = errcode == 0;
                if (errcode == 0) {

                    const { goods_list = [], ...others } = result;
                    try {
                        const { is_vip } = result.shop;
                        if (result.shop &&
                            result.shop.hasOwnProperty('is_vip') &&
                            app.globalData.userInfo.shop_id === this.shop_id
                        ) {
                            app.globalData.is_vip = is_vip;
                            // bury.registerProperties({ is_vip });
                        }
                    } catch(e) {
                        console.log('e: ', e);
                    }
                    const { listIndex } = this.data;

                    obj = { ...this.data, ...others };
                    if (type == 'top') {
                        // 去重
                        this.list = util.dedupArr([...goods_list, ...this.list], 'goods_id');
                    } else {
                        if (type === '') {
                            this.list = [];
                        }
                        this.list = [...this.list, ...goods_list];

                        // if (!!filterText) {
                        //     if (cur_page >= total_page) {
                        //         obj.loadingEnd = true;
                        //     } else {
                        //         obj.cur_page = cur_page + 1;
                        //     }
                        // } else {
                        // 到底了
                        goods_list.length <= 0 && (obj.loadingEnd = true);
                        // }
                    }

                    //tab为全部时初始化临时模板ID
                    if (this.localTemplateId == 0 && listIndex == 0){
                        this.localTemplateId = obj.template;
                    }

                    //初始化各tab使用模板
                    obj.template = this.initTabTemplate(listIndex, this.localTemplateId);

                    //设置当前显示模板
                    obj.curTempObj = this.getTemplateById(obj.template, obj.template_list);
                    //----------------------------
                    // 分组
                    console.log("lin--------------template:"+obj.template,obj.curTempObj )
                    if (obj.template!=waterfullId) {
                        obj.list = logic.getGrouplist(util.dedupArr(this.list, 'goods_id'), obj.template, this, false);
                        obj.loading = false;
                    } else {
                        if (this.stopRenderList){
                            obj.list = []
                        }
                    }

                    // 无数据
                    if (this.list.length <= 0) {
                        obj.loadingNoData = true;
                    } else {
                        obj.loadingNoData = false;
                    }

                    console.info(obj.list);
                    console.log("this.itemW",this.itemW)
                    obj.itemW = this.itemW ? this.itemW : itemW;
                    obj.col = this.col ? this.col : col;


                    //设置tab显示
                  if (obj.hasVideo === undefined){
                    obj.hasVideo = this.data.hasVideo || false;
                  }

                  if (obj.hasVideo){
                    obj.navs = [{ label: '全部', idx: 0,queryType:'' }, { label: '上新', idx: 1,queryType:'new' }, { label: '小视频', idx: 2,queryType:'video'}, { label: '图集', idx: 3,queryType:'img'}]
                  }else{
                    obj.navs = [{ label: '全部', idx: 0,queryType:''}, { label: '上新', idx: 1,queryType:'new'}, { label: '图集', idx: 3,queryType:'img' }]
                  }

                  //处理
                  console.log(obj);
                    this.setData(obj, () => {
                        let goodsList = goods_list;
                        if (obj.template === waterfullId) {
                            console.log("renderList first")
                            this.stopRenderList = false;
                            //过滤数据
                            goodsList = logic.filterData(goodsList, waterfullId);

                             //过滤跟现有数据相同的
                             let that = this;
                             goodsList = goodsList.filter(item=>{
                                 let found = false;
                                 for (let i = 0; i < that.data.list.length; i++){
                                     if (item.goods_id==that.data.list[i].goods_id){
                                         found = true;
                                     }
                                 }
                                 return found?false:true;
                             })

                             //如果是top,则刷新所有数据
                            if (type=='top'&&goodsList.length>0){
                                goodsList = [...goodsList,...this.data.list];
                               // console.log('刷新所有数据:')
                                //console.log(goodsList);
                                this.setData({
                                    list: []
                                },()=>{
                                    this.renderList(goodsList, 0, () => {
                                        if (this.data.template != waterfullId) {
                                          return;
                                        }
                                        let loadingNumTemp = this.data.loadingNum;
                                        this.setData({
                                            loading: false,
                                            loadingNum: 0
                                        }, () => {
                                            if (loadingNumTemp > 0) {
                                                this.onReachBottom()
                                            }
                                        });

                                    });
                                })
                            }else{
                                this.renderList(goodsList, 0, () => {
                                    if (this.data.template != waterfullId) {
                                      return;
                                    }
                                    let loadingNumTemp = this.data.loadingNum;
                                    this.setData({
                                        loading: false,
                                        loadingNum: 0
                                    }, () => {
                                        if (loadingNumTemp > 0) {
                                            this.onReachBottom()
                                        }
                                    });

                                });
                            }
                        }else{
                            //处理过滤商品后无法加载下一页的问题
                            goodsList = logic.filterData(goodsList, waterfullId);
                        }
                        res.statusCode == 200 && (this.list.length < constant.minPageSize|| obj.template==100&&this.list.length<24 || goodsList.length <= 2) && this.onReachBottom();
                    });
                    typeof callback == 'function' && callback(result);
                } else {
                    // errcode: error
                    // wx.showToast({
                    //     icon: 'none',
                    //     title: errmsg,
                    // });
                    wx.showModal({
                        title: '温馨提示',
                        content: errmsg,
                        showCancel: false,
                        success(res) {
                            if (res.confirm) {
                                wx.hideLoading();
                            }
                        }
                    });

                    this.setData({
                        loading: false
                    })
                }

                if (isSearch && !top) {
                    const obj = {
                        route: this.route,
                        $title: '标签列表',
                        search_method: searchType,
                        key_word: this.data.search_value ? this.data.search_value : this.data.search_img,
                        has_result: isSuccess,
                    }
                    // bury.search(bury_config, obj)
                }

            }, () => {
                // error
                this.setData({loading: false});
                if (isSearch && !top) {
                    const obj = {
                        route: this.route,
                        $title: '标签列表',
                        search_method: searchType,
                        key_word: this.data.search_value ? this.data.search_value : this.data.search_img,
                        has_result: false,
                    }
                    // bury.search(bury_config, obj)
                }
            });
    },
    // getGrouplist(list, template) {
    //     const { filterText, col } = this.data;
    //     let currentCol = this.col ? this.col : col;
    //     let data = list;
    //     const topObj = {
    //         date: {
    //             date_text: '置顶'
    //         },
    //     };
    //     console.log('lin------------>getGrouplist template:'+template)
    //     // if (!!filterText) return data.map(item => ({rows: constant.ROWS, richTitle: util.getRichTitle(item.title, filterText), ...item}));
    //     switch (template) {
    //         case 1:
    //             /* // 小程序不支持发布
    //             // const post = this.getPostItem();
    //             const post = [];
    //             const hasPost = post.length > 0;
    //             // 筛选置顶
    //             const topArr = data.filter(item => item.isTop === 1)
    //                 .map(item => (Object.assign({}, item, topObj)));
    //             topArr.sort((a, b) => b.time_stamp - a.time_stamp);
    //             const hasTop = topArr.length > 0;
    //             // 筛选非置顶
    //             data = data.filter(item => item.isTop !== 1); */
    //             const tops = [];
    //             const others = [];
    //             // 多图 || 一图（有文字 || 视频）
    //             data = data.filter(item => {
    //                 const { imgs, title, themeType } = item;
    //                 const len = imgs.length;
    //                 const moreImg = len > 1;
    //                 const hasTitle = !!title;
    //                 const isVideo = themeType === 1;
    //                 const oneImg = len === 1 && (hasTitle || isVideo);

    //                 return moreImg || oneImg;
    //             });
    //             data.forEach(item => {
    //                 item.isTop === 1 ? tops.push(item) : others.push(item);
    //             });
    //             data = [...tops, ...others];
    //             let cols = [];
    //             if (data.length <= 0) return cols;
    //             for (let i = 0; i < currentCol; i++) {
    //                 cols[i] = data.filter((item, idx) => idx % currentCol == i);
    //             }

    //             return cols;

    //             break;

    //         case 5:
    //             data = data.map(item => (Object.assign({}, item, { date: this.getDateText(item.time_stamp) }, { showRemark: false })));
    //             let dateTimes = data.map(item => item.date.date_time);
    //             dateTimes = util.dedupArr(dateTimes);
    //             let arr = [];

    //             dateTimes.forEach((date_time, i) => {
    //                 arr[i] = data.filter(item => item.date.date_time == date_time);
    //             });

    //             // if (listIndex == 0) {
    //             //     // 合并置顶
    //             //     arr = hasTop ? [topArr, ...arr] : arr;
    //             //     // 合并发布
    //             //     arr = hasPost ? [post, ...arr] : arr;
    //             // }

    //             return arr;
    //             break;

    //         case 4:
    //             return data.map(item => ({ rows: constant.ROWS, richTitle: !!filterText ? util.getRichTitle(item.title, filterText) : undefined, ...item }));
    //             break;

    //         default:
    //             return data;
    //             break;
    //     }
    // },
    /**
     * 初始化各个tab使用的模板
     * @param {tab} listindex
     * @param {显示模板id} template
     */
    initTabTemplate(listindex, template){
        return 4;
        let _template = template;
        switch (listindex){
            case 0:
                break;
            case 1:
                _template = 5;
                break;
            case 2:
                _template = 4;
                break;
            case 3:
                _template = 100;
                break;
        }
        console.log("_template----------------"+_template)
        return _template;
    },
    goVipPage(e){
        const {
            type
        } = e.target.dataset;
        if(type){
            wx.navigateTo({
                url: '../vip/index', //vip
            });
        }

        this.closeVipConfrim();
    },
    closeVipConfrim(){
        this.setData({
            vipConfrimShow:false
        })
    },
    renderList(goodsList, i, finish) {
        let { col, list, template } = this.data;

        const key = `list[${list.length}]`;
        // console.log(key)
        if (this.stopRenderList && i != 0){
        //   console.log("renderList 1111")
          this.setData({ list: [] })
          return;
        } else{
          this.stopRenderList = false;
        }

        if (template != waterfullId){
            return;
        }
        // console.log("renderList aaaa"+goodsList.length+","+i)
        if (goodsList.length > i) {
            if (i < col) {
                const item = {...goodsList[i], col: i};
            //   console.log("renderList 3333")
                this.setData({
                    [key]: item,
                }, () => {
                    this.renderList(goodsList, ++i, finish);
                });
            } else {
                if (this.data.listIndex !=0){
                    return;
                }
              this.selectComponent('#waterfall').getClientRect(res => {
                //   console.log("boundingClientRect------->")
                //   console.log(res)
                  const heights = res.map(item => item.height);
                  const min = Math.min(...heights);
                  const idx = heights.indexOf(min);
                  const item = {...goodsList[i], col: idx};
                  if (this.data.template != waterfullId || this.data.listIndex !=0){
                      return;
                  }
                  this.setData({
                      [key]: item,
                  }, () => {
                      this.renderList(goodsList, ++i, finish);
                  });
              });

            }
        } else {
        //   console.log("renderList 555")

            finish();
        }
    },

    getList(list) {
        const { col } = this.data;
        const cols = [];

        if (list.length <= 0) return cols;

        for (let i = 0; i < col; i++) {
            cols[i] = list.filter((item, idx) => idx % col == i);
        }

        return cols;
    },

    onReachBottom() {
        const { loading, loadingNoData, loadingEnd } = this.data;

        if (loading){
            //处理IOS下滑到最后无法加载的问题
            this.setData({
                loadingNum: this.data.loadingNum+1
            });
        }

        if (loading || loadingNoData || loadingEnd) return;

        console.log("onReachBottom");
        this.fetchData('bottom');
    },

    onPullDownRefresh() {
        wx.hideLoading();
        const { loading, search_value, search_img, template } = this.data;

        if (loading || !!search_value || !!search_img) return;

        this.setData({
            canvasId: null,
        })
        console.log("onPullDownRefresh");
        if (template != waterfullId){
            this.fetchData('top', (data) => {
                console.log("stopPullDownRefresh");
                wx.stopPullDownRefresh();

                this.setDialogInfo();
                if(data.goods_list){
                    this.initShareAppMessageToCanvas(data);
                }
            });
        }else{
            wx.stopPullDownRefresh();
        }

    },

    onTap: fourGrid.onTap,

    showCartSheetListener(e) {
        console.log(e)
        this.$cartSheet.onShow(e.detail);
    },
    onTapTag(ev) {
        const { tagId } = ev.target.dataset;
        const route = '/pages/tag_goods_list/index';
        const options = {
            shop_id: this.shop_id,
            from:"tags",
            tag_id: tagId,
        };

        util.navigateTo(route, options);
    },
    // getDateText(timestamp = Date.now()) {
    //     const { date_time, year, month, day } = this.getDateTime(Math.abs(timestamp));
    //     const today = this.getDateTime().date_time;
    //     const yesterday = this.getDateTime(Date.now() - 24 * 60 * 60 * 1000).date_time;
    //     let date_text = `${day < 10 ? `0${day}` : day} ${month}月`;

    //     if (date_time == today) {
    //         date_text = '今天';
    //     } else if (date_time == yesterday) {
    //         date_text = '昨天';
    //     }

    //     return {
    //         date_text,
    //         date_time,
    //         year,
    //         month,
    //         day
    //     };
    // },

    // getDateTime(timestamp = Date.now()) {
    //     const t = new Date(timestamp);
    //     const year = t.getFullYear();
    //     const month = t.getMonth() + 1;
    //     const day = t.getDate();
    //     const date_time = `${year}${month < 10 ? `0${month}` : month}${day < 10 ? `0${day}` : day}`;

    //     return {
    //         date_time,
    //         year,
    //         month,
    //         day
    //     };
    // },

    handleToShopCarDetail() {
      wx.navigateTo({
        url: '/pages/my_shopping_cart/index',
      })
    },
    navTap(ev){
        const { index,item } = ev.target.dataset;
        const { listIndex} = this.data;
        console.log(item);
        if (index == listIndex) {
            return false;
        }

        this.setData({
            curQueryType:item.queryType,
            listIndex:index,
            loading:false
        })
        console.info('nav', index);
        this.refreshData(index);
    },
    previewAddCart: fourGrid.onAddCart,
    onAddCart: nineGrid.onAddCartTheme,
    onAddCartTheme: nineGrid.onAddCartTheme,
    /**重新获取列表数据 */
    refreshData(index){
        const { loading, listIndex,filterImg, filterText, search_value, search_img, filterTag ,curQueryType,date,supportNavigationStyle, hasBackRouter, photoSearchCheck} = this.data;
        this.list = [];
        console.log(this.data.date,"this.data.date;");

        this.setData(Object.assign({}, getData(), {
          hasBackRouter,
          listIndex: index,
          filterText,
          filterImg,
          search_value,
          search_img,
          filterTag,
          list: [],
          date,
          loading,supportNavigationStyle,
          curQueryType:curQueryType,
          photoSearchCheck
        }));
        this.setData({
            loading:false
        })
        wx.showLoading({
            mask: true,
            title: '加载中...',
        });
        this.setData({
            canvasId: null,
        })
        this.fetchData('init', (data) => {
            wx.hideLoading();
            if(data.goods_list){
                this.initShareAppMessageToCanvas(data);
            }
        });
    },
    previewImgs(e) {
        this.setData({
            showPreviewer: true,
            ...e.detail,
        }, () => {
            this.data.showPreviewer && util.navigateToBrowserPage();
        });
    },
    setDialogInfo(){
        const {
            login_user: { // 登录用户
                vip_status, // vip状态
                photo_search_check: login_photo_search_check, // Boolean：搜图开关
            } = {},
            shop: { photo_search_check } = {}, // Boolean：当前店铺是否开启搜图开关
            isMyAlbum,
        } = this.data;

        // vip_status: 0为非会员 1会员 2试用期 3会员过期
        switch (vip_status) {
            case 0:
            case 3:
                const dialogInfo = util.isIOS()
                    ? {
                          title: "温馨提示",
                          body: "由于相关规范，iOS暂不支持此功能，如有疑问，请联系客服",
                          button: "联系客服",
                          type: 1
                      }
                    : {
                          title: "会员特权",
                          body: "以图搜图是会员功能哟，马上开通吧",
                          button: "去开通",
                          type: 1
                      };
                this.setData({
                    dialogInfo
                });
                break;

            case 1:
                if (!login_photo_search_check) {
                    this.setData({
                        dialogInfo:{
                            title:"温馨提示",
                            body:"您的相册尚未开启以图搜图功能，请打开APP的【我】-【设置】进行开启。",
                            button:"知道了",
                            type:0
                        }
                    });
                } else if (!photo_search_check) {
                    this.setData({
                        dialogInfo:{
                            title:"温馨提示",
                            body:"此相册尚未开启以图搜图功能，请提醒您的好友打开APP的【我】-【设置】进行开启。",
                            button:"知道了",
                            type:0
                        }
                    });
                }
                break;

            case 2:
                if (!isMyAlbum && !photo_search_check) {
                    this.setData({
                        dialogInfo:{
                            title:"温馨提示",
                            body:"此相册尚未开启以图搜图功能，请提醒您的好友打开APP的【我】-【设置】进行开启。",
                            button:"知道了",
                            type:0
                        }
                    })
                }
                break;

            default:
                break;
        }
    },
}))
