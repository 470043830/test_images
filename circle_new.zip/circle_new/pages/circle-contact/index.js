
const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const constant = require('../../utils/constant');
const app = getApp();



Page({

    /**
     * 页面的初始数据
     */
    data: {
        pageType: '',
        postState: -1,
        multiArray: [
            ['楼栋1', '楼栋2', '楼栋3'],
            ['1F', '2F', '3F']
        ],
        buyerArray: ['批发贸易', '品牌连锁', '网商', '实体店'],
        buyerArrayIndex: -1,
        priceArray: ['50以内', '50～100', '100～200', '200～500', '500～1000', '1000～2000', '2000～5000', '5000以上'],
        priceArrayIndex: -1,
        userInfo: {},
        tagsShowText: '',
        customTitle: '111',
        webview1Url: 'http://mp.weixin.qq.com/s?__biz=MzIzMzEwMTQwOQ==&mid=502021391&idx=1&sn=f98eb0cddc9ced0e6d6b684665982ded&chksm=70925c0147e5d517dd8d65b383b4ff2fb8a11ca164a22abcd74fc39adce3929a9f262102af12#rd',
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        if (app.offline()) {
            circleUtil.gotoLoginPage();
            return;
        }
        setTimeout(async () => {
            await circleUtil.getCircleConfigData();
            // this.setData({
            //     isMiniChecked: circleUtil.isMiniChecked()
            // });
            //...
            if (!circleUtil.isMiniChecked()) {
                return;
            }
            const { pageType = '' } = options;
            this.setData({ pageType });
            if (pageType == 'factory') {  //供货商入驻留资
                this.setData({
                    customTitle: '我是织里厂家'
                });
                this.getOneCustomer();
            } else if (pageType == 'buyer') {  //采购商
                this.setData({
                    customTitle: '我是采购商'
                });
                this.getUserInfo();
            } else if (pageType == 'finder') {  //找厂家
                // wx.setNavigationBarTitle({
                //     title: '我要找厂家',    //页面标题
                // });
                this.setData({
                    customTitle: '我要找厂家'
                });
                const {
                    platform
                } = wx.getSystemInfoSync();
                const isIOS = (platform == 'ios');
                this.setData({ isIOS });
                this.getUserInfo();
            }
        }, 10);
    },

    onShow() {

    },

    async getOneCustomer() {
        this.setData({ postState: 0 });
        this.getUserInfo();
        return;

        const url = `/circle/circle_new_interface.jsp?act=getOneCustomer`;
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url });
        console.log('getOneCustomer: ', isOk, result);
        if (isOk) {
            if (result.albumId) {
                this.setData({ postState: 1 });
            } else {
                this.setData({ postState: 0 });
                this.getUserInfo();
            }
        }
    },

    async getUserInfo() {
        wx.login({
            success: (res) => {
                if (res.code) {
                    this._loginCode = res.code;
                    console.log("this._loginCode: ", this._loginCode);
                } else {
                    console.log('登录失败！' + res.errMsg);
                }
            }
        });

        wx.showLoading({
            title: '加载中...'
        });
        await this.initBuildingPicker();
        const {
            isOk,
            result = {}
        } = await circleUtil.fetchNetData({
            url: `/circle/circle_new_interface.jsp?act=getPersonalInfo`
        });
        console.log('getUserInfo: ', isOk, result);
        wx.hideLoading();

        if (isOk) {
            const { booth } = result.circle;
            this.setData({
                loadingPage: false,
                userInfo: { ...result.base, booth_id: booth },
                multiIndex: [0, 0]
            });
        }
    },

    async initBuildingPicker() {
        let {
            multiArray
        } = this.data;

        let circleInfo = await circleUtil.getCircleConfigData();

        const { markets = [], buildings = [] } = circleInfo;
        console.log('circleInfo: ', circleInfo);
        if (markets.length > 0) {
            multiArray[0] = buildings.map(item => item.label);
            multiArray[1] = buildings[0].floors;
            this.setData({
                multiArray
            });
        }

    },

    bindKeyInput: function (e) {
        console.log('bindKeyInput: ', e);
        this.data.userInfo[e.currentTarget.id] = e.detail.value;
    },

    bindMultiPickerChange: function (e) {
        console.log('picker发送选择改变，携带值为', e.detail.value);
        this.setData({
            multiIndex: e.detail.value
        });
    },
    bindMultiPickerColumnChange: function (e) {
        const {
            circleInfo
        } = app.globalData;
        const {
            multiArray
        } = this.data;

        // console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
        if (e.detail.column == 0) {
            let fIndex = parseInt(e.detail.value);
            multiArray[1] = circleInfo.buildings[fIndex].floors;
            this.setData({
                multiArray
            });
        }
        if (e.detail.column == 1 && multiArray[0].length == 1) {
            this.setData({
                multiIndex: [0, e.detail.value]
            });
        }
        return;
    },

    async onPhoneNumber(e) {
        console.log("onPhoneNumber: ", e);
        const { encryptedData, iv } = e.detail;
        if (!encryptedData || !iv) {
            return;
        }
        const method = 'POST';
        const param = {
            encryptedData: encryptedData,
            iv: iv,
            code: this._loginCode,
            circle_id: constant.circle_id,
            client_type: 'miniapp',
        };
        console.log("onPhoneNumber param: ", param);
        const url = '/circle/circle_new_interface.jsp?act=decodeMiniAppPhoneNumber';
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url, method, param });
        console.log('onPhoneNumber fetchNetData: ', isOk, result);

        if (isOk) {
            const { userInfo } = this.data;
            const { phoneNumber = '' } = result;
            userInfo.phone_number = phoneNumber;
            console.log('userInfo: ', userInfo);
            this.setData({ userInfo });
        }

    },


    onTextareaInput(e) {
        const {
            value,
        } = e.detail;
        // console.log('value ', value, value.length);
        this.setData({
            inputCount: `${value.length}/140`
        });
        this.data.userInfo.finder_desc = e.detail.value;
    },

    onFinderBottomBtn() {
        const {
            userInfo,
        } = this.data;
        const param = {
            shop_name: userInfo.shop_name,
            avatar: userInfo.user_icon,
            phone_number: userInfo.phone_number,
            finder_desc: userInfo.finder_desc,
        };
        if (!param.phone_number) {
            wx.showToast({
                title: '请输入联系电话',
            });
            return;
        }
        if (!param.finder_desc) {
            wx.showToast({
                title: '请输入品牌名称',
            });
            return;
        }
        setTimeout(async () => {
            const url = `/circle/circle_new_interface.jsp?act=saveFinderInfo`;
            const { isOk, result = {} } = await circleUtil.fetchNetData({ url, param });

            if (isOk) {
                const url111 = "/pages/webview/index?url=" + encodeURIComponent(this.data.webview1Url);
                url111 && wx.redirectTo({ url: url111 });
            } else {
                wx.showToast({
                    title: '提交失败!',
                });
                // const url111 = "/pages/webview/index?url=" + encodeURIComponent(this.data.webview1Url);
                // url111 && wx.redirectTo({ url: url111 });
            }
        }, 10);
    },

    onBottomBtn() {

        const {
            userInfo,
            multiArray,
            multiIndex,
            streetShowText,
            buildIndex = 0,
            floorIndex = 0
        } = this.data;

        const param = {
            shop_name: userInfo.shop_name,
            avatar: userInfo.user_icon,
            phone_number: userInfo.phone_number,
            booth_id: userInfo.booth_id,
            ext_info: this._sceneInfo,
        };

        if (!param.booth_id) {
            wx.showToast({
                title: '请填写店名',
            });
            return;
        }

        setTimeout(async () => {
            // const loufloor = multiArray[0][multiIndex[0]] + '/' + multiArray[1][multiIndex[1]];
            // console.log('loufloor: ', loufloor);
            // const name_booth = `${loufloor} ${userInfo.booth_id}`;
            const name_booth = JSON.stringify({
                street: streetShowText,
                booth_id: userInfo.booth_id,
                buildIndex, floorIndex
            });
            const param = {
                name: name_booth,
                phone: userInfo.phone_number
            };
            // const url = `/circle/circle_new_interface.jsp?act=saveCustomerPhone&name=${name_booth}&phone=${userInfo.phone_number}&booth=${userInfo.booth_id}`;
            const url = `/circle/circle_new_interface.jsp?act=saveCustomerPhone`;
            const { isOk, result = {} } = await circleUtil.fetchNetData({ url, param });

            if (isOk) {
                // wx.redirectTo({
                //     url: `/pages/circle-contact/index?pageType=factory`
                // });

                wx.navigateBack({
                    complete: () => {
                        setTimeout(() => {
                            wx.showToast({
                                title: '信息填写成功',
                            });
                        }, 100);
                    }
                });
            }
        }, 10);

    },

    onBuyerPostTap() {
        const {
            userInfo,
            tagsShowText,
            buyerArrayIndex,
            priceArrayIndex,
            buyerArray,
            priceArray,
        } = this.data;

        const param = {
            shop_name: userInfo.shop_name,
            avatar: userInfo.user_icon,
            phone_number: userInfo.phone_number,
            wechat_id: userInfo.wechat_id,
            tagNames: tagsShowText,
            buyerType: buyerArray[buyerArrayIndex],
            price: 0, //priceArray[priceArrayIndex],
        };

        console.log('onBuyerPostTap, param: ', param);

        if (!param.phone_number) {
            wx.showToast({
                title: '请填写联系电话',
            });
            return;
        }

        if (buyerArrayIndex < 0) {
            wx.showToast({
                title: '请选择采购商类型',
            });
            return;
        }

        // if (priceArrayIndex < 0) {
        //     wx.showToast({
        //         title: '请选择意向拿货价',
        //     });
        //     return;
        // }



        setTimeout(async () => {
            const url = `/circle/circle_new_interface.jsp?act=saveBuyerInfo`;
            const { isOk, result = {} } = await circleUtil.fetchNetData({ url, param });

            if (isOk) {
                // wx.navigateBack({
                //     complete: () => {
                //         setTimeout(() => {
                //             wx.showToast({
                //                 title: '信息填写成功',
                //             });
                //         }, 100);
                //     }
                // });
                wx.showToast({
                    title: '信息填写成功',
                });
                setTimeout(() => {
                    const url111 = "/pages/webview/index?url=" + encodeURIComponent('https://mp.weixin.qq.com/s/eMV76IAiur7ABB89SMOP3g');
                    url111 && wx.redirectTo({ url: url111 });
                }, 1000);

            }
        }, 10);

    },


    onBtn1Tap() {
        wx.navigateBack();
    },

    onBtn2Tap() {
        const url111 = "/pages/webview/index?url=" + encodeURIComponent(this.data.webview1Url);
        url111 && wx.navigateTo({ url: url111 });
    },


    bindbuyerPickerChange(e) {
        console.log('picker发送选择改变，携带值为', e.detail.value);
        this.setData({
            buyerArrayIndex: e.detail.value
        });
    },

    bindPricePickerChange(e) {
        console.log('picker发送选择改变，携带值为', e.detail.value);
        this.setData({
            priceArrayIndex: e.detail.value
        });
    },

    onSelectTagsClick() {
        const thisPage = this;
        wx.navigateTo({
            url: '/pages/select-tags/index?tagsShowText=' + this.data.tagsShowText,
            events: {
                // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
                acceptDataFromSelectTagPage(data) {
                    console.log(data.tagsShowText);
                    thisPage.setData({ tagsShowText: data.tagsShowText });
                }
            },
        });
    },

    onSelectStreetClick() {
        const thisPage = this;
        wx.navigateTo({
            url: '/pages/select-street/index?streetShowText=' + this.data.streetShowText,
            events: {
                // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
                acceptDataFromSelectStreetPage(data) {
                    console.log(data.streetShowText);
                    thisPage.setData({ streetShowText: data.streetShowText, buildIndex: data.buildIndex, floorIndex: data.floorIndex });
                }
            },
        });
    },


});
