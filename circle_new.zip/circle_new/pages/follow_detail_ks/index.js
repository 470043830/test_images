// import { $tdSearchbar } from '../../components/wux';

const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const circleData = require('../../utils/circle-data.js');
const app_cfg = require('../../utils/app_cfg.js');
const app_switch = require('../../utils/app_switch.js');

// import logic from '../../utils/logic';

// let shareFriendsImgPath = "";
// let shopInfo = null;
const getCircleAlbumUrl = `/circle/circle_new_interface.jsp?act=single_album`;
// const app = getApp();
const waterfullId = 1; //瀑布流的id
const app = getApp();

Page({
  data: {
    isIOS: util.isIOS(),
    col: 2,
    gap: 15,
    itemW: '48%',
    // 列宽
    addUrl: '/album/album_theme_operation.jsp?act=hold_theme',
    attentionUrl: '/album/att_album_mini.jsp?',
    tagsUrl: '/album/album_theme_tag_operation.jsp?act=get_tags_except&has_video=0&hide_uncategorized=true',
    // tagsUrl: 'https://www.wsxcme.com/commodity/tags?hasVideo=0&hideUnCategorized=true',
    // shopCartUrl: '/shoppingCart/shopping_card_index.jsp?act=check_shopping_cart',
    setTopUrl: '/album/album_operation.jsp?act=set_top',
    followUrl: '/album/att_album_mini.jsp',
    cancelFollowUrl: '/album/album_operation.jsp?act=del_album',
    loading: true,
    // 列表加载中
    loadingNoData: false,
    // 列表加载完成 & 无数据
    loadingEnd: false,
    // 列表加载完成 & 到底了
    cur_page: 1,
    filterText: '',
    filterImg: '',
    filterTag: [],
    listIndex: 0,
    list: [],
    showWechat: false,
    showTag: false,
    showCart: false,
    openApp: false,
    videoPlaceholder: true,
    autoplay: true,
    navBgWhite: false,
    loadingNum: 0,
    showAddCart: false,
    // pxopen: true,
    selectShow: false,
    //0:瀑布流；1：商城模板；2：商城单图列表；3：微信朋友圈动态；4：微信朋友圈列表
    tagSelectSheetShow: false,
    windowWidth: 0,
    shop_id: '',
    showPreviewer: false,
    previewList: [],
    previewIndex: 0,
    vipConfrimShow: false,
    showPopoverMask: false,
    photoSearchCheck: 0,
    // 是否开启了搜图, 0：都开启，1：自己没开启，2：别人没开启
    hasBackRouter: true,
    isScroll: true,
    supportNavigationStyle: false, //true,
    updateSticky: false,
    shop: {
      shop_name: '',
    },
    applyInfo: {},

    topDomHeight: 210,
    isMyAlbum: true,
    actionStatus: false,
    cardInfo: {},

    placeholder: '搜索',
    inputShowed: false,
    inputVal: "",
    searchImg: "",

    isIpx: false, //getApp().globalData.isIpx,
    isShowBottomTab: false,
    switchListIcons: ['template_wxlist.png', 'template_shangchen.png'],
    listType: app_switch.listType,

    hasBackRouter: true,
  },

  onUnload() {
    console.log('test001 onUnload ');
    if (this.delayRenderTimer > 0) {
      clearTimeout(this.delayRenderTimer);
      this.delayRenderTimer = 0;
    }
  },

  onLoad(options) {
    console.log('test001 onLoad ', options, app_cfg.getCurrAppId());

    if (getCurrentPages().length <= 1) {
      this.setData({
        hasBackRouter: false
      });
    }

    //for test
    // setTimeout(() => {
    //   app_cfg.setStorageShopId();
    // }, 3000);

    this.delayRenderTimer = 0;

    // let aaabbb = getApp().getStorageUserInfo();
    // console.log('aaabbb ', aaabbb);
    // this.setData({
    //   albumId: aaabbb.albumId
    // });
    // return;

    const {
      shop_id = '',
    } = options;

    this.localTemplateId = 0; //临时模板ID
    this.shop_id = shop_id || app_cfg.getStorageShopId() || app_cfg.getCurrShopId();
    let isShowBottomTab = true; //false;
    if (this.shop_id != app_cfg.defaultShopId) {
      isShowBottomTab = true;
    }
    this.setData({
      isShowBottomTab,
      shop_id: this.shop_id
    }); //

    if (getApp().offline()) {
      circleUtil.showLoginModal();
      return;
    }

    wx.showLoading({
      mask: false,
      title: '加载中...'
    });
    this.list = [];
    this.listOrigin = []; // 用来获取正确的时间戳

    return;
    getApp().getUserInfo(userInfo => {

      // this.fetchTagsAndGroups();
      this.fetchAlbumTags();
      // this.fetchCircleShopInfo();
      this.fetchInitShopInfo();

      //for test
      // this.fetchDataTest();
    }, () => {
      wx.hideLoading();
    }, this.shop_id);

  },

  onShow() {
    wx.getSystemInfo({
      success: res => {

        const {
          model = '',
          screenHeight = 0,
          windowWidth,
          windowHeight,
          statusBarHeight,
        } = res;
        const isIPhone = model.toLowerCase().indexOf('iphone') != -1;
        const maxH = windowHeight > screenHeight ? windowHeight : screenHeight;
        const isIpx = isIPhone && maxH >= 812;
        console.log("follow_detail_ks onShow:", maxH, isIPhone, isIpx);

        this.setData({
          windowHeight,
          windowWidth,
          statusBarHeight,
          isIpx,
        }, () => {
          this.compatibleStyle();
        });
      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    //  页面初次渲染完成后，使用选择器选择组件实例节点，返回匹配到组件实例对象   
    this.listComponent = this.selectComponent('#ks-combined-list');

    getApp().getUserInfo(userInfo => {
      this.fetchAlbumTags();
      this.fetchCircleShopInfo();
      // this.fetchInitShopInfo();
      // this.listComponent.getListData('init', this.shop_id);
      this.listComponent.getListData({ urlType: 'single', type: 'init', shopId: this.shop_id, callback: null });
    }, () => {
      wx.hideLoading();
    }, this.shop_id);
  },

  onShopDataGetted(e) {
    console.log('onShopDataGetted ', e.detail.shop);
    this.setData({
      ...e.detail
    }, () => {
      const { isMyAlbum, is_attention, shop } = this.data;
      if (!isMyAlbum && !is_attention) {
        this.onSetFollow({
          currentTarget: {
            dataset: {
              shop,
              isattention: is_attention
            }
          }
        });
      }
    });
    // this.setData({
    //   shop: e.detail.shop,
    //   banner: e.detail.banner,
    // })
  },

  /**
   * 切换列表样式
   */
  onSwitchListTap() {
    const { listType } = this.data;

    console.log('onSwitchListTap...');
    this.setData({
      listType: (listType + 1) % 2
    });
  },

  onPageScroll(e) {
    let query = wx.createSelectorQuery();
    query.select('#J_avatar').boundingClientRect((rect) => {
      let top = rect.top;
      // 44 导航栏高度
      if (top <= this.data.statusBarHeight + 44) {

        if (!this.data.navBgWhite) {
          this.setData({
            navBgWhite: true,
            topDomHeight: 40 + this.data.statusBarHeight + 44 + 127 + 20
          });
        }

      } else {
        if (this.data.navBgWhite) {
          this.setData({
            navBgWhite: false
          });
          this.compatibleStyle();
        }
      }
    }).exec();
  },

  goBack() {
    util.navGoBack();
  },

  /***兼容各个手机样式高度显示一样 */
  compatibleStyle() {
    this.setData({
      topDomHeight: 40 + this.data.statusBarHeight + 44 + 127 + 20
    });
    return;

    // this.setData({
    //   topDomHeight: 40 + this.data.statusBarHeight + 44 + 127 + 20
    // });

    //tt minapp 暂不支持自定义标题栏
    this.setData({
      // topDomHeight: 40 + this.data.statusBarHeight + 127 + 20,
      topDomHeight: 40 + this.data.statusBarHeight + 107 + 20
    });
  },

  getTimeList(list = []) {
    return list.map(item => item.time_stamp).filter(item => item);
  },

  getTimestamp(type) {
    const {
      filterText,
      template,
      listIndex
    } = this.data;
    const timeList = this.getTimeList(this.listOrigin);
    let tList = [];

    if (listIndex == 0) {
      if (type == 'top' || !!filterText) {
        tList = timeList;
      } else {
        tList = this.listOrigin.filter(item => item.isTop !== 1);
        tList = this.getTimeList(tList);
      }
    } else {
      tList = timeList;
    }

    if (!!filterText) {
      const len = tList.length;

      if (len > 0) {
        const first = tList[0];
        const last = tList[len - 1];
        first < 0 && last > 0 && (tList = tList.filter(item => item > 0));
      }
    }

    tList.sort((a, b) => b - a);
    const len = tList.length;
    const max = tList[0] || '';
    const min = tList[len - 1] || 1; // 全部为置顶时，list为空[]，min=1停止加载

    return {
      top: max,
      bottom: min
    };
  },

  getSearchDate(type) {
    console.log('getSearchDate, type: ', type);

    return '';
    //liu disabled

    if (type == 'bottom') {
      const d = new Date(Date.now() - 24 * 3600000 * 7);
      const yy = d.getFullYear();
      const mm = d.getMonth() + 1 + '';
      const dd = d.getDate() + '';
      return `&start_date=${yy}-${mm.padStart(2, '0')}-${dd.padStart(2, '0')}`; // return 'start_date=2021-03-11&end_date=2021-03-12';
    } else {
      return '';
    }
  },

  getUrl(type) {
    const {
      listIndex = 0,
      cur_page = 1,
      filterImg = '',
      filterTag = [],
      isCirclePersonal = false,
    } = this.data;
    console.log('isCirclePersonal: ', isCirclePersonal);
    const baseUrl = [`/album/get_album_themes_list.jsp?act=single_album${this.getSearchDate(type)}`, getCircleAlbumUrl];
    let getUrl = [];
    let url = '';

    if (!isCirclePersonal) {
      getUrl = [`${baseUrl[0]}`, `${baseUrl[0]}&query_type=new`, `${baseUrl[0]}&query_type=video`, `${baseUrl[0]}&query_type=img`];
      url = `${getUrl[listIndex]}&shop_id=${this.shop_id}&search_img=${filterImg}&tag=${encodeURIComponent(JSON.stringify(filterTag))}&page_index=${cur_page}`;
      // url = `${getUrl[listIndex]}&shop_id=${this.shop_id}&search_img=${filterImg}&page_index=${cur_page}`;
    } else {
      getUrl = [`${baseUrl[1]}`];
      url = `${getUrl[0]}&shop_id=${this.shop_id}&category=${this.currTabIndex}`; // if (this.wxid){
    }

    const {
      top,
      bottom
    } = this.getTimestamp(type);

    switch (type) {
      case 'top':
        url = `${url}&slip_type=0&time_stamp=${top}`;
        break;

      case 'bottom':
        url = `${url}&slip_type=1&time_stamp=${bottom}`;
        break;
    }

    console.log('getUrl----------------url: ', url);
    // url = `/album/personal/all?&albumId=A2018010521093602411&searchValue=&searchImg=&startDate=&endDate=&sourceId=&requestDataType=`;
    return url;
  },

  async getMarketBooth() {
    return "测试地址000";
    const {
      building,
      booth,
      isBusiness,
      floor
    } = this.data;
    if (!isBusiness) return '';
    const obj = await circleUtil.getCircleConfigData();
    const {
      markets = [],
      buildings = []
    } = obj;
    // console.log("onAvatarTap 111", markets, building, buildings);
    // const { name } = circleUtil.getMarketById(markets, building); //circleInfo.LouDong[parseInt(building)];

    const {
      label,
      floors
    } = circleUtil.getBuildingById(buildings, building); // const addr = market.name + '-' + floor.split('|')[1] + '-' + booth;
    // const addr = name + '-' + booth;

    const addr = label + ' ' + floors[floor] + ' ' + booth;
    return addr;
  },

  //liu add 1119
  async fetchInitShopInfo() {


    this.fetchData('init', data => {
      console.log('callback ', typeof data.shop, data.shop);
      const {
        shop_name: title
      } = data.shop || {};
      //liu add
      // title && wx.setNavigationBarTitle({
      //   title: title
      // });

      this.setData({
        shop: data.shop,
        isMyAlbum: data.isMyAlbum,
        photoSearchCheck: data.photo_search_check
      });
      shopInfo = data.shop;
      this.setDialogInfo(); //...
    });
  },


  async fetchCircleShopInfo() {
    let info = await circleData.getCircleShopInfo(this.shop_id);
    console.log('fetchCircleShopInfo, info: ', info);
    this.setData(info);
    return;

    const url = `${getCircleAlbumUrl}&shop_id=${this.shop_id}&exclude_list=1`;
    const {
      isOk,
      result = {}
    } = await circleUtil.fetchNetData({
      url
    });
    console.log('fetchCircleShopInfo: ', isOk, result);

    if (isOk) {
      const {
        booth = '',
        building,
        floor,
        leimu,
        leixing,
        tagNames,
        shop,
        isMyAlbum,
        isBusiness,
        is_attention,
        mediaInfo,
        plusAppId
      } = result;
      const mediaInfoObj = mediaInfo ? JSON.parse(mediaInfo) : [];
      this.setData({
        booth,
        building,
        floor,
        leimu,
        leixing,
        tagNames,
        shop,
        is_attention,
        isBusiness,
        mediaInfoObj,
        plusAppId
      }, async () => {
        const marketBooth = await this.getMarketBooth();
        this.setData({
          marketBooth
        });
      }); //...自动关注

      //......
      return;

      if (!isMyAlbum && !is_attention) {
        this.onSetFollow({
          currentTarget: {
            dataset: {
              shop,
              isattention: is_attention
            }
          }
        });
        return;
      }

      //liu add
      // shop.shop_name && wx.setNavigationBarTitle({
      //   title: shop.shop_name
      // });

      this.fetchData('init', data => {
        const {
          shop_name: title
        } = this.data.shop || {}; // wx.hideLoading();

        // console.log('shop_name: ', shop_name, title)
        // title && wx.setNavigationBarTitle({
        //   title
        // }); // this.list.length < constant.minPageSize && this.onReachBottom();

        this.setData({
          isMyAlbum: data.isMyAlbum,
          photoSearchCheck: data.photo_search_check
        });
        shopInfo = data.shop;

        if (data.goods_list) {
          // this.initShareAppMessageToCanvas(data);
        }

        this.setDialogInfo(); //...
        // this.insertVisitMsg(shop_id);
      });
    }
  },

  fetchTagsAndGroups() {
    const {
      tagsUrl: url
    } = this.data;
    const params = {
      shop_id: this.shop_id
    };
    util.fetch(url, params).then(res => {
      const {
        errcode,
        result
      } = res.data;

      if (errcode == 0) {
        const {
          all_tags = [],
          groups = []
        } = result;
        // console.log('all_tags: ', all_tags);
        // console.log('groups: ', groups);
        this.setData({
          all_tags,
          groups
        });
      }
    });
  },

  async fetchAlbumTags() {
    const {
      isOk,
      result = {}
    } = await circleUtil.fetchNetData({
      url: `https://www.wsxcme.com/commodity/tags?hasVideo=0&hideUnCategorized=true&albumId=${this.shop_id}`
    }); // wx.setStorageSync("fetchAlbumTags", result);

    const {
      allTags = [],
      tagGroups = [],
    } = result;

    const all_tags = [];
    const groups = [];

    //convert for old formate
    for (let index = 0; index < allTags.length; index++) {
      const itm = allTags[index];

      all_tags.push({
        count: itm.itemCount,
        order: itm.order,
        tagId: itm.tagId,
        tagName: itm.tagName,
        tag_img: itm.customIcon || itm.tagImage,
      });
    }

    for (let index = 0; index < tagGroups.length; index++) {
      const itm = tagGroups[index];

      groups.push({
        groupId: itm.groupId,
        groupName: itm.groupName,
        count: itm.tagCount,
        tags: itm.childrenTag,
        order: itm.order,
      });
    }


    this.setData({
      all_tags,
      groups,
    });
  },

  fetchDataTest() {
    const url = `/album/personal/all?&albumId=A2018010521093602411&searchValue=&searchImg=&startDate=&endDate=&sourceId=&slipType=1&timestamp=1666522722392&requestDataType=`;
    const param = {};
    util.fetch(url, param).then(res => {
      const {
        errcode,
        result,
        total_page,
        errmsg
      } = res.data;
      console.log('res.data: ', res.data);
    });
  },

  sortGoodsByTime(goods_list) {
    let list;

    for (let index = 0; index < goods_list.length; index++) {
      const element = goods_list[index];

    }

    return list;
  },


  fetchData(type, callback) {
    const {
      filterText = '',
      filterImg = '',
    } = this.data;
    const isSearch = !!(filterText || filterImg);
    const searchType = isSearch && filterText ? '文字搜索' : '图搜';
    const url = this.getUrl(type);
    const {
      top = ''
    } = this.getTimestamp(type); // 初始化首次加载不需要显示loading

    if (type != "init") {
      this.setData({
        loading: true
      });
    }

    this.setData({
      loadingNum: 0
    });
    let param = {
      search_value: this.data.filterText
    };
    util.fetch(url, param).then(res => {
      const {
        errcode,
        result,
        total_page,
        errmsg
      } = res.data;
      // console.log('res.data: ', res.data);
      let obj = {};
      const isSuccess = errcode == 0;
      wx.hideLoading();

      if (errcode == 0) {
        result.template = 4; //2;商城模板  //4;  //-----------------------先默认设为朋友圈动态模板

        let {
          goods_list = [],
          shop = { tips: 'shop is null!!!' },
          ...others
        } = result;

        //liu add for sort
        goods_list = goods_list.sort((a, b) => {
          return b.time_stamp - a.time_stamp;
        });
        console.log('goods_list.length: ', goods_list.length);
        try {
          console.log('shop: ', shop);
          const {
            is_vip = false
          } = shop;


          if (shop && shop.hasOwnProperty('is_vip') && getApp().globalData.userInfo.shop_id === this.shop_id) {
            getApp().globalData.is_vip = is_vip;
            // bury.registerProperties({
            //     is_vip
            // });
          }
        } catch (e) {
          console.log('e: ', e);
        }

        const {
          listIndex
        } = this.data;
        obj = {
          ...this.data,
          ...others
        }; // console.info('服务器返回的数据---》', goods_list);
        // console.info('备份的数据---》', this.list);

        //liu add 1119
        if (type == 'init') {
          obj.shop = shop;
          //liu add
          if (shop.shop_name == '壹号 相册-105栋7777') {
            shop.shop_name = '壹号 相册';
          }
          // shop.shop_name && wx.setNavigationBarTitle({
          //   title: shop.shop_name
          // });
        }

        if (type == 'top') {
          // 去重
          this.list = util.dedupArr([...goods_list, ...this.list], 'goods_id');
          this.listOrigin = this.list; // console.info('下拉去重后的数据---》', this.list);
        } else {
          if (type === '') {
            this.list = [];
          } // this.list = [...this.list, ...goods_list];


          this.listOrigin = [...this.list, ...goods_list];
          this.list = util.dedupArr([...this.list, ...goods_list], 'goods_id'); // console.log('正常处理的数据---》', this.list);

          goods_list.length <= 0 && (obj.loadingEnd = true);

          //set the max len
          if (this.list.length >= 32 * 4) {
            obj.loadingEnd = true;
          }
        } //...


        // console.log('this.list: ', this.list);

        if (this.localTemplateId == 0 && listIndex == 0) {
          this.localTemplateId = obj.template;
        }

        console.log('this.localTemplateId: ', this.localTemplateId); //初始化各tab使用模板

        obj.template = this.initTabTemplate(listIndex, this.localTemplateId); //设置当前显示模板

        if (listIndex === 0) {
          obj.curTempObj = this.getTemplateById(obj.template, obj.template_list);
        } //----------------------------
        //保存关注度及商品到缓存，用于后面进行商品分享


        if (obj.shop) {
          let {
            follow_num,
            new_goods,
            user_icon,
            shop_name
          } = obj.shop;
          let shareShopData = {
            follow_num,
            new_goods,
            user_icon,
            shop_name
          };
          console.log(shareShopData);
          wx.setStorage({
            key: 'share_shop_data',
            data: shareShopData
          });
        }

        obj.guest = util.getIsGuest(); // 分组

        // liu add for disbale here
        // if (obj.template != waterfullId) {
        //   obj.list = logic.getGrouplist(util.dedupArr(this.list, 'goods_id'), obj.template, this, true);
        //   obj.loading = false;
        // } else {
        //   if (this.stopRenderList) {
        //     console.log('设置空-----》');
        //     obj.list = [];
        //   }
        // } // 无数据
        obj.loading = false;


        if (this.list.length <= 0) {
          obj.loadingNoData = true;
        } else {
          obj.loadingNoData = false;
        }

        // console.info('这次要设置的数据---》', obj.list);
        obj.itemW = this.itemW ? this.itemW : this.data.itemW;
        obj.col = this.col ? this.col : this.data.col; //设置tab显示
        // navs: [{ label: '首页', idx: 0 }, { label: '上新', idx: 1 }, { label: '小视频', idx: 2 }, { label: '图集', idx: 3 }]

        obj.navs = [{
          label: '全部',
          idx: 0
        }, {
          label: '上新',
          idx: 1
        }];

        // console.log('111111111111----->', obj);

        //liu mark here.... init for visibale fast
        // console.log('obj ', obj);
        if (type == 'init' && this.list.length > 10) {
          console.log('init > slice ...');
          obj.list = this.list.slice(0, 9);
          this.setData(obj, () => {
            obj.list = this.list;
            this.delayRenderTimer = setTimeout(() => {
              this.setData(obj, () => { });
            }, 200);

          });
        } else {
          obj.list = this.list;
          this.setData(obj, () => { });
          typeof callback == 'function' && callback(result);
        }


      } else {
        wx.showModal({
          title: '温馨提示',
          content: errmsg || "服务器错误",
          showCancel: false,

          success(res) {
            if (res.confirm) {
            }
          }

        });
        this.setData({
          loading: false
        });
      } // 清除失效token，触发重新获取
      // getApp().clearToken(res.data, () => {
      //     this.onPullDownRefresh();
      // });


      if (isSearch && !top) {
        const obj = {
          route: this.route,
          $title: '个人主页',
          search_method: searchType,
          key_word: filterText ? filterText : filterImg,
          has_result: isSuccess
        }; // bury.search(bury_config, obj)
      }
    }, () => {
      this.setData({
        loading: false
      });
      typeof callback == 'function' && callback();

      if (isSearch && !top) {
        const obj = {
          route: this.route,
          $title: '个人主页',
          search_method: searchType,
          key_word: filterText ? filterText : filterImg,
          has_result: false
        }; // bury.search(bury_config, obj)
      }
    });
  },


  /**
 * 初始化各个tab使用的模板
 * @param {tab} listindex
 * @param {显示模板id} template
 */
  initTabTemplate(listindex, template) {
    let _template = template;

    switch (listindex) {
      case 0:
        break;

      case 1:
        _template = 5;
        break;

      case 2:
        _template = 4;
        break;

      case 3:
        _template = 100;
        break;
    }

    console.log("_template----------------" + _template);
    return _template;
  },

  /**
 * 根据ID获取模板对象
 */
  getTemplateById(id, template_list) {
    if (!template_list) {
      return null;
    }

    let obj = template_list.filter(item => {
      return item.id == id;
    });
    return obj[0] || template_list[0];
  },

  onSearchConfirm(e) {
    console.log('onSearchConfirm: ', e);
    const {
      inputVal, searchImg
    } = e.detail;

    this.searchHandler(inputVal, searchImg);
  },

  /*
  bindConfirm(e) {
    console.log('bindConfirm: ', e);
    this.setData({
      inputVal: e.detail.value
    }, () => {
      this.search();
    });
  },

  bindInput(e) {
    let iptVal = e.detail.value;
    console.log('bindInput: ', iptVal);
    // this.setData({ iptVal });

    // this.setData({
    //   inputVal: e.detail.value
    // }, () => {
    //   this.search();
    // });
  },

  clearInput() {
    console.log('clearInput...',);
    this.setData({
      inputVal: "",
      searchImg: ""
    }, () => {
      this.search();
    });
  },

  search() {
    // const searchData = this.getComponentData();
    // typeof options.searchHandler === `function` && options.searchHandler(searchData.inputVal.trim(), searchData.searchImg);

    const {
      inputVal,
      searchImg,
    } = this.data;

    this.searchHandler(inputVal, searchImg);
    this.setData({
      inputShowed: false
    });
  },*/

  searchHandler(text, img) {
    const {
      listIndex,
      filterTag,
      isMyAlbum,
      supportNavigationStyle,
      photoSearchCheck,
      shop,
    } = this.data;
    console.log(`text: ${text}`, `img: ${img}`);
    // console.info(this); // 搜索时停止递归renderList

    console.log("searchHandler set stopRenderList true");


    this.stopRenderList = true;
    this.list = [];
    this.setData({
      listIndex,
      filterText: text,
      filterImg: img,
      filterTag,
      isMyAlbum,
      supportNavigationStyle,
      photoSearchCheck,

      cur_page: 1,
      list: [],
    }, () => {
      // console.log("searchHandler set stopRenderList false");
      // this.page.stopRenderList = false;
      this.setData({
        canvasId: null
      });

      // this.listComponent.getListData('search', this.shop_id);
      // this.fetchData('', data => { });
    });
  },

  uploadFile() {
    const upload = () => {
      util.initQiniu(); // 微信 API 选文件

      wx.chooseImage({
        count: 1,
        success: res => {
          let filePath = res.tempFilePaths[0]; // 交给七牛上传

          util.qiniuUpload(filePath, this.callback);
        }
      });
    };

    // if (typeof options.onAddImg === 'function') {
    //   options.onAddImg(upload);
    // } else {
    //   upload();
    // }

    //...liu add
    // upload();
  },

  async onAvatarTap() {
    const {
      shop,
      isBusiness,
      mediaInfoObj = {},
      applyInfo = {},
    } = this.data;
    console.log("onAvatarTap mediaInfoObj: ", mediaInfoObj); // if (!isBusiness) return;

    const addr = applyInfo.region + applyInfo.detailAddress; //await this.getMarketBooth(); //name + '-' + booth;

    if (!addr && !applyInfo.wechatId && !applyInfo.wechatQrcode && !applyInfo.phoneNumber) {
      return;
    }

    console.log("onAvatarTap 333");
    this.setData({
      actionStatus: true,
      cardInfo: {
        name: shop.shop_name,
        avatar: applyInfo.shopIcon || shop.user_icon, //shop.user_icon,
        wechat_id: applyInfo.wechatId, //shop.wechat_id,
        wechat_qrcode: applyInfo.wechatQrcode, //shop.wechat_qrcode,
        //'http://xcimg.szwego.com/circle_images/qrcode/wechatqrcode111.jpg',//
        phone: applyInfo.phoneNumber, //shop.phone_number,
        desc: shop.shop_desc,
        mediaInfoObj: mediaInfoObj.length > 0 ? mediaInfoObj : this.getOtherMediaInfo(),
        tagNames: applyInfo.category,
        addr,
        latitude: applyInfo.latitude,
        longitude: applyInfo.longitude,
      }
    });
    // this.data.actionStatus = false;
  },

  getOtherMediaInfo() {
    const {
      list
    } = this.data;
    const ret = [];
    const maxItemCount = 3; // 1???

    for (let index = 0; index < list.length && index < maxItemCount; index++) {
      const element = list[index];

      for (let j = 0; j < element.imgs.length; j++) {
        if (element.videoURL && j == 0) {
          ret.push({
            src: element.imgs[j],
            type: 'video',
            video: element.videoURL
          });
          continue;
        }

        ret.push({
          src: element.imgs[j],
          type: 'image'
        });
      }

      if (ret.length >= 9) break;
    }

    return ret;
  },

  oncustomevent_ashide() {
    console.log('oncustomevent_ashide...');
    // this.data.actionStatus = false;
    this.setData({
      actionStatus: false
    });
  },

  onPullDownRefresh() {
    console.log('onPullDownRefresh...');
    wx.hideLoading();
    this.listComponent.getListData({
      urlType: 'single', type: 'top', shopId: this.shop_id, callback: () => {
        console.log('stopPullDownRefresh');
        wx.stopPullDownRefresh();
        this.setDialogInfo();
      }
    });
    // this.listComponent.getListData('top', this.shop_id, () => {
    //   console.log('stopPullDownRefresh');
    //   wx.stopPullDownRefresh();
    //   this.setDialogInfo();
    // });
    return;
    const {
      loading,
      filterText,
      template
    } = this.data; // if (loading || !!filterText) {

    if (loading) {
      return false;
    }
    console.info('onPullDownRefresh');

    if (template != waterfullId) {
      this.fetchData('top', data => {
        console.log('stopPullDownRefresh');
        wx.stopPullDownRefresh();
        this.setDialogInfo();
      });
    } else {
      wx.stopPullDownRefresh();
    }
  },

  onReachBottom(lastTimeStamp) {
    // this.listComponent.getListData('bottom', this.shop_id);
    this.listComponent.getListData({
      urlType: 'single', type: 'bottom', shopId: this.shop_id, callback: null
    });
    return;

    const {
      loading,
      loadingNoData,
      loadingEnd
    } = this.data;

    if (loading) {
      //处理IOS下滑到最后无法加载的问题
      this.setData({
        loadingNum: this.data.loadingNum + 1
      });
    }

    if (loading || loadingNoData || loadingEnd) {
      return false;
    }

    console.info('onReachBottom');
    this.fetchData('bottom');

  },

  onViewImgHandler(e) {
    console.log('onViewImgHandler...');
    const {
      listIndex,
      index
    } = e.detail;
    // const {
    //   previewList,
    //   previewIndex
    // } = util.getPreviewerInitData([this.data.list[listIndex]], 0, index);
    const {
      previewList,
      previewIndex
    } = util.getPreviewerInitData([this.listComponent.data.list[listIndex]], 0, index);
    this.setData({
      showPreviewer: true,
      previewList,
      previewIndex
    }, () => {
      this.data.showPreviewer && util.navigateToBrowserPage();
    });
  },

  showTagSelectSheet(e) {
    const {
      all_tags = [],
      groups = [],
      tagSelectSheetShow = false
    } = this.data;
    console.log('showTagSelectSheet  ', tagSelectSheetShow);
    this.setData({
      tagSelectSheetShow: true,
      all_tags,
      groups,
      ...e.detail,
      // isScroll: tagSelectSheetShow // 禁用滚动
    });
  },

  tapContact(ev) {
    // const bury_config = app.globalData.bury_config; // bury.profileBury('contact_ta', bury_config);

    // liu add for tt
    // this.tapCall(ev);
    // return;
    // const {
    //   phone_number: phoneNumber
    // } = this.data.shop;
    const {
      phoneNumber
    } = this.data.applyInfo;

    let itemList = ['微信'];
    if (phoneNumber) {
      itemList = ['微信', '电话'];
    }
    // let itemList = ['电话'];

    wx.showActionSheet({
      itemList,
      success: res => {
        const {
          tapIndex
        } = res;
        console.log(res, tapIndex, typeof tapIndex);

        switch (tapIndex) {
          case 0:
            this.tapWechat(ev);
            // this.tapCall(ev);
            break;

          case 1:
            this.tapCall(ev);
            break;
        }
      },
      fail: res => {
        console.log(res);
      }
    });
  },

  copyWechat(ev) {
    // const {
    //   wechat_id
    // } = this.data.shop;
    const {
      wechatId: wechat_id
    } = this.data.applyInfo;
    // this.copyTitle(wechat_id);
    console.log('copyWechat ', wechat_id);

    wechat_id && wx.setClipboardData({
      data: wechat_id,
      success: res => {
        // wx.showToast({
        //   type: 'text',
        //   text: '标题已复制到剪贴板'
        // });
      },
      fail: res => {// wx.showToast({
        //     type: 'text',
        //     text: '标题复制失败，请稍后重试~'
        // });
      }
    });
  },

  hideWechat(ev) {
    this.setData({
      showWechat: false
    });
  },

  tapWechat(ev) {
    // const {
    //   wechat_id,
    //   wechat_icon,
    //   wechat_qrcode
    // } = this.data.shop;
    const {
      wechatId,
      wechatIcon,
      wechatQrcode
    } = this.data.applyInfo;

    if (wechatId || wechatIcon || wechatQrcode) {
      this.setData({
        showWechat: true
      });
    } else {
      wx.showToast({
        icon: 'none',
        title: '未设置微信号'
      });
    }
  },

  tapCall(ev) {
    // const {
    //   phone_number: phoneNumber
    // } = this.data.shop;
    const {
      phoneNumber
    } = this.data.applyInfo;

    if (phoneNumber) {
      wx.makePhoneCall({
        phoneNumber,
        //: '18083020058',
        fail: res => {
          const {
            errMsg
          } = res;
          console.info(res);
          !errMsg.match(/cancel/) && wx.showToast({
            type: 'text',
            text: '呼叫失败，请稍后重试~'
          });
        }
      });
    } else {
      wx.showToast({
        type: 'text',
        icon: 'none',
        title: '未设置电话号码'
      });
    }
  },

  onPlusAppTap() {
    const { shop_id, plusAppId } = this.data;

    circleUtil.jumpToWsxcApp(shop_id);
    return;

    console.log('onPlusAppTap...', shop_id, plusAppId);
    wx.navigateToMiniProgram({
      appId: plusAppId, //'wx82768f631dd021fd', //'wx107b8fbd08e99afd', //'wx5b589968eff47164', //
      path: 'pages/follow_detail/index?shop_id=' + shop_id,
      // path: `/package-album/pages/vip/index`,
      extraData: {
        foo: 'bar'
      },
      // envVersion: 'trial',
      success(res) {
        // 打开成功
      }
    });
  },


  /**
   * 分享设置
   * @param {*} res 
   */
  onShareAppMessage(res) {
    console.log('onShareAppMessage...', res);

    const {
      shop,
      share,
      shop_id='',
    } = this.data;

    let path = '';
    let title = share.miniappTitle;
    let imageUrl = shop.user_icon || '/assets/image/tt_logo2.png';

    if (res.from === 'button') {
      // 来自页面内转发按钮
      // await this.sleepAwa(100);
      let shareChosedGid = circleUtil.tempData.shareChosedGid;
      circleUtil.tempData.shareChosedGid = '';
      if (shareChosedGid) {
        title = util.getTextTitle(circleUtil.getGoodsTitleById(shareChosedGid, this.list));
        path = `/pages/goods_detail_circle/index?shop_id=${shop.shop_id}&goods_id=${shareChosedGid}`;
      } else {
        path = `pages/follow_detail_ks/index?shop_id=${shop.shop_id}`;
      }

    } else {
      path = `pages/follow_detail_ks/index?shop_id=${shop.shop_id||shop_id}`;
    }

    console.log('title: ', title);
    console.log('path: ', path);
    console.log('imageUrl: ', imageUrl);

    return {
      title: title,
      path: path,
      imageUrl: imageUrl,
      // channel: "video", //拍抖音
      success: function (res) {// 转发成功
      },
      fail: function (res) {// 转发失败
      }
    };
  },


  onSetFollow(ev) {
    const {
      dataset
    } = ev.currentTarget;
    const {
      isattention,
      shop
    } = dataset;
    console.info('onSetFollow, isattention: ', isattention);

    if (isattention) {
      wx.showModal({
        title: '温馨提示',
        content: '是否取消关注好友相册',
        showCancel: true,
        confirmText: '确定',
        success: res => {
          if (res.confirm) {
            requestSetFollow.call(this, {
              url: this.data.cancelFollowUrl,
              data: {
                albumId: shop.shop_id || shop.id
              }
            });
          } else {
            console.log("取消");
          }
        },
        fail: res => { }
      });
    } else {
      requestSetFollow.call(this, {
        url: this.data.followUrl,
        data: {
          shop_id: shop.shop_id || shop.id
        }
      });
    }

    function requestSetFollow(param) {
      util.fetch(param.url, param.data, 'POST').then(res => {
        const {
          errcode,
          errmsg
        } = res.data;

        if (errcode == 0) {
          app.globalData.updateHomeData = true;
          this.setData({
            is_attention: !isattention
          });
          wx.showToast({
            title: errmsg
          }); // 取消关注的时候更新上一个页面数据

          if (isattention) {
            //直接更新数据
            const pages = getCurrentPages();
            const followListPage = pages.find(i => i.route === 'pages/follow/index');

            if (followListPage) {
              followListPage.data.list.splice(followListPage.data.list.findIndex(item => item.shop_id === param.data.albumId), 1);
            }

            wx.setStorage({
              key: 'refresh_follow_list',
              data: 1
            });
          } else {
            wx.removeStorageSync('refresh_follow_list');
          } //new add


          if (errmsg == "关注成功") {
            //拉取列表
            this.setData({
              loadingEnd: false
            }, () => this.fetchData(''));
          }
        } else {
          wx.showToast({
            icon: 'none',
            title: errmsg
          });
          this.setData({
            loadingEnd: true
          });
        }
      }, errmsg => {
        wx.showToast({
          icon: 'none',
          title: errmsg
        });
      });
    }
  },

  setDialogInfo() {
    const {
      login_user: {
        // 登录用户
        vip_status,
        // vip状态
        photo_search_check: login_photo_search_check // Boolean：搜图开关

      } = {},
      shop: {
        photo_search_check
      } = {},
      // Boolean：当前店铺是否开启搜图开关
      isMyAlbum
    } = this.data; // vip_status: 0为非会员 1会员 2试用期 3会员过期

    switch (vip_status) {
      case 0:
      case 3:
        const dialogInfo = util.isIOS() ? {
          title: "温馨提示",
          body: "由于相关规范，iOS暂不支持此功能，如有疑问，请联系客服",
          button: "联系客服",
          type: 1
        } : {
          title: "会员特权",
          body: "以图搜图是会员功能哟，马上开通吧",
          button: "去开通",
          type: 1
        };
        this.setData({
          dialogInfo
        });
        break;

      case 1:
        if (!login_photo_search_check) {
          this.setData({
            dialogInfo: {
              title: "温馨提示",
              body: "您的相册尚未开启以图搜图功能，请打开APP的【我】-【设置】进行开启。",
              button: "知道了",
              type: 0
            }
          });
        } else if (!photo_search_check) {
          this.setData({
            dialogInfo: {
              title: "温馨提示",
              body: "此相册尚未开启以图搜图功能，请提醒您的好友打开APP的【我】-【设置】进行开启。",
              button: "知道了",
              type: 0
            }
          });
        }

        break;

      case 2:
        if (!isMyAlbum && !photo_search_check) {
          this.setData({
            dialogInfo: {
              title: "温馨提示",
              body: "此相册尚未开启以图搜图功能，请提醒您的好友打开APP的【我】-【设置】进行开启。",
              button: "知道了",
              type: 0
            }
          });
        }

        break;

      default:
        break;
    }
  },
});
