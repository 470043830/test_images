import { $tdSearchbar, $tdUploader, $wuxToast } from '../../components/wux';
import nineGrid from '../../utils/nine-grid';


const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const constant = require('../../utils/constant');
const app = getApp();
function getData() {
    return {
        // getUrl: /data/dynamic_1.json?,
        // getUrl: '/circle/miniapp_circle_search.jsp?',
        getUrl: '/circle/miniapp_circle_themes_list.jsp?act=get_circle_themes_plaza',
        addUrl: '/album/album_theme_operation.jsp?act=hold_theme',
        filterText: '',
        filterImg: '',
        allTags: [],
        searchBooths: [],
        priceTypesObj: constant.priceTypesObj,
    };
}

Page(Object.assign({}, nineGrid, {
    data: getData(),

    onLoad(options) {
        console.log('onLoad', options);

        const dynamicList = this.selectComponent('#dynamic-list');

        if (!dynamicList) {
            return;
        }
        this.setData({ dynamicList });


        // wx.setNavigationBarTitle({
        //     title: options.search,    //页面标题
        // });

        // dynamicList.searchHandler(options.search, '');

    },


    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
     onPullDownRefresh: function () {
        const { dynamicList } = this.data;
        if (dynamicList) {
            dynamicList.onPullDownRefresh();
        }
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
        const { dynamicList } = this.data;
        if (dynamicList) {
            dynamicList.onReachBottom();
        }
    },
}))
