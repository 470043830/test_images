// pages/select-leimu/index.js
const app = getApp();

Page({

    /**
     * 页面的初始数据
     */
    data: {
        buildIndex: 0,
        floorIndex: 0,
        currStreet: '',
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        const { streetShowText = '' } = options;
        const { circleInfo } = app.globalData;
        const { config = {}, buildings = [] } = circleInfo;

        console.log('options buildings: ', buildings);
        if (config.tags) {
            // console.log('config.tags: ', config.tags);
            this.initStreets(buildings, streetShowText)
        }

        // wx.setNavigationBarTitle({
        //     title: '选择经营品类',
        // });
    },

    initStreets(buildings, currStreet){
        let buildIndex = 0;
        let floorIndex = 0;
        for (let i = 0; i < buildings.length; i++) {
            const build = buildings[i];
            // console.log('build: ', build.floors);
            for (let j = 0; j < build.floors.length; j++) {
                if (build.floors[j] == currStreet){
                    floorIndex = j;
                    buildIndex = i;
                    break;
                }
            }
        }
        this.setData({ buildings, currStreet, buildIndex, floorIndex }, () => { });
    },


    onStreetTap(e) {
        const { buildings } = this.data;
        const { build, index } = e.currentTarget.dataset;

        const buildIndex = build;
        const floorIndex = index;
        const currStreet = buildings[build].floors[index];
        const currMarketId = buildings[build].market_id;

        console.log('onStreetTap: ', build, index, currStreet, currMarketId);
        this.setData({ currMarketId, currStreet, buildIndex, floorIndex });
    },


    onConfirmTap() {

        const { buildIndex, floorIndex, currStreet, currMarketId } = this.data;
        // let selectLeimuStr = '';
        // for (let index = 0; index < items.length; index++) {
        //     const element = items[index];
        //     element.checked && (selectLeimuStr += (index.toString().padStart(2, '0') + '_'));
        // }
        // selectLeimuStr.length > 0 && (selectLeimuStr = selectLeimuStr.substr(0, selectLeimuStr.length - 1));

        // console.log('selectLeimuStr: ', selectLeimuStr);
        const eventChannel = this.getOpenerEventChannel();

        if (eventChannel.emit) {
            eventChannel.emit('acceptDataFromSelectStreetPage', { streetShowText: currStreet, buildIndex, floorIndex, market_id: currMarketId });
            wx.navigateBack();
        }
    },
});
