// pages/select-leimu/index.js
const app = getApp();

Page({

    /**
     * 页面的初始数据
     */
    data: {
        items: [
            {
                name: '商铺经营类目1',
                checked: false
            },
            {
                name: '商铺经营类目2',
                checked: false
            }, {
                name: '商铺经营类目3',
                checked: false
            }, {
                name: '商铺经营类目4',
                checked: false
            }
        ]
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        const { circleInfo } = app.globalData;
        const { config } = circleInfo;

        if (config.LeiMu) {
            console.log('config.LeiMu: ', config.LeiMu);
            this.setData({ items: config.LeiMu });
        }
    },

    onConfirmTap() {

        // const { items } = this.data;
        // let selectLeimuStr = '';
        // for (let index = 0; index < items.length; index++) {
        //     const element = items[index];
        //     element.checked && (selectLeimuStr += (index.toString().padStart(2, '0') + '_'));
        // }
        // selectLeimuStr.length > 0 && (selectLeimuStr = selectLeimuStr.substr(0, selectLeimuStr.length - 1));

        // console.log('selectLeimuStr: ', selectLeimuStr);
        wx.navigateBack();
    },

    onCellTap(e) {
        const { items } = this.data;
        const { index } = e.currentTarget.dataset;

        items[index].checked = !items[index].checked;
        this.setData({ items });
        console.log('onCellTap ', index);
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
});
