// pages/my/index.js
const util = require('../../utils/util.js');
const constant = require('../../utils/constant');
const circleUtil = require('../../utils/circle-util.js');
const circleData = require('../../utils/circle-data.js');

const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    icons: {
      data: '/assets/my/Group 52.svg',
      notify: '/assets/my/tongzhizhongxin.svg',
      arrow: '/assets/my/jiantou.svg',
      good: '/assets/my/shangpingguanli.svg',
      tuiguang: '/assets/my/Group 109.svg',
      supply: '/assets/my/supply.svg',
      apply: '/assets/my/apply.svg',
    },
    isMiniChecked: false,
    state: -1,
    customBar: 0,
    user: {},
    otherInfo: {
      fansCount: 0,
      followCount: 0,
      total_goods: 0
    },
    ruzhuStr: '',
    isAdmin: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    const { customBar, headerBar, statusBarHeight } = getApp().getCustomBarInfo();

    console.log("customBar: ", customBar, headerBar, statusBarHeight);
    this.setData({
      customBar, headerBar, statusBarHeight,
      avatar: '/assets/my/avatar.svg',
    });

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    console.log('my onShow...');
    setTimeout(async () => {
      const { config } = await circleUtil.getCircleConfigData();
      this.setData({
        isMiniChecked: circleUtil.isMiniChecked()
      });
      if (circleUtil.isMiniChecked()) {
        this.setData({
          ruzhuStr: config.texts.str001
        });
      }
      if (app.offline()) return;
      //...
      const { state } = this.data;
      if (state < 1) {
        //...
        wx.showLoading({ title: '加载中...' });
        this.getMyShopInfo();
        // this.fetchFollowedShops();
      } else {
        this.getMyShopInfo();
      }

    }, 10);
  },

  onHeadBarTap() {
    if (app.offline()) {
      // circleUtil.gotoLoginPage('my');
      wx.redirectTo({
        url: '/pages/login/index'
      });
      return;
    }
    if (!this.data.isApplyed || !circleUtil.isMiniChecked()) {
      return;
    }
    const { anchorStatus } = this.data;
    wx.navigateTo({
      url: `/pages/apply-page/index?anchorStatus=${anchorStatus}`,
    });
    return;


    const { user } = this.data;
    if (user.isBusiness) {
      wx.navigateTo({
        url: `/pages/merchant-info/index`,
      });
    } else {
      wx.navigateTo({
        url: `/pages/personal-info/index`,
      });
    }

  },

  joinCircleTap() {
    wx.navigateTo({ url: '/pages/personal-info/index?scene=10001' });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },



  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },


  async getMyShopInfo() {
    // const user = await circleData.getCircleApply();
    // console.log('getMyShopInfo applyInfo: ', user);
    // if (!user.shopId) {
    //   this.setData({ state: 0 });
    //   return;
    // }
    let user = null;
    // let isApplyed = false;
    const applyInfo = await circleData.getCircleApply();
    wx.hideLoading();

    if (!applyInfo.shopId) {
      const userInfo = await circleData.getMyUserInfo();
      if (!userInfo.user) return;
      user = userInfo.user;
      user.shopName = user.shop_name;
      user.shopId = user.shop_id;
      user.shopIcon = user.user_icon;
    } else {
      user = { ...applyInfo, ...user };
      // isApplyed = true;
    }

    this.setData({ user, state: 1 });

    let isApplyed = false;
    //admin switch
    let { anchorStatus, merchantStatus } = await circleData.getCircleStatus();
    // anchorStatus = 3; //for test
    if (anchorStatus >= 2 || merchantStatus >= 2) {
      isApplyed = true;
    }
    let adminRet = await circleData.getAdminStatus();
    // adminRet = 0; //for test
    this.setData({ isAdmin: adminRet == 0, isApplyed, anchorStatus });

    // const { isOk, result = {} } = await circleUtil.fetchNetData({ url: `/circle/circle_new_interface.jsp?act=getMyShopInfo` });
    // if (isOk) {
    //   let otherInfo = {};
    //   otherInfo.fansCount = result.fansCount;
    //   otherInfo.followCount = result.followCount;
    //   otherInfo.total_goods = result.total_goods;
    //   this.setData({ otherInfo });
    //   if (result.shopId == "A201905291653236670027260") {
    //     this.setData({ isApplyed: true });  //for test
    //   }
    // }

    const album = await circleData.getMyShopInfo(user.shopId);
    console.log('getMyShopInfo: ', album);

    if (album.isMy) {
      let otherInfo = {};
      otherInfo.fansCount = album.popularity;
      otherInfo.followCount = 0; //album.popularity;
      otherInfo.total_goods = album.totalItemCount;
      this.setData({ otherInfo });
    }



    return;
    // console.log('app.globalData.userInfo: ', app.globalData.userInfo);
    // wx.setClipboardData({
    //     data: app.globalData.userInfo.token,
    //     success (res) {
    //       wx.getClipboardData({
    //         success (res) {
    //           console.log(res.data) // data
    //         }
    //       })
    //     }
    //   })
    //..登过一次管理员账号的情况
    if (result.admin) {
      app.globalData.userInfo.admin = true;
      app.storageUserInfo(app.globalData.userInfo);
    }
    result.admin = app.globalData.userInfo.admin;


    this.setData({ user, state: 1 }, () => {
      // this.getShopInfo(result.shopId);
    });
  },

  // async getShopInfo(shop_id) {
  //     const url = `/circle/circle_new_interface.jsp?act=single_album&shop_id=${shop_id}&exclude_list=1`;
  //     const { isOk, errcode, result = {} } = await circleUtil.fetchNetData({ url });
  //     console.log('getShopInfo: ', errcode, isOk, result);

  //     if (!isOk) {
  //         return;
  //     }

  //     this.setData({ shopInfo: result.shop })
  // },

  async fetchFollowedShops() {
    if (app.offline()) {
      return;
    }
    const { isOk, result = {} } = await circleUtil.fetchNetData({ url: `/circle/circle_new_interface.jsp?act=getFollowedShops` });
    const { marketList } = this.data;

    // wx.hideLoading();
    console.log('fetchFollowedShops, result: ', result);
    // console.log('marketList: ', marketList);

    if (isOk) {
      const { shop_list } = result;
      for (let index = 0; index < shop_list.length; index++) {
        const shop = shop_list[index];
        shop.address = this.getShopAddress(marketList, shop); //shop.floor.split('|')[1] + shop.booth;
      }
      this.setData({ followed_booths: shop_list });
    }
  },

  boothsTap(ev) {
    if (!circleUtil.isMiniChecked() && app.offline()) {
      return;
    }
    const { dataset } = ev.currentTarget;
    const { shopId } = dataset;
    const url = `/pages/follow_detail/index?shop_id=${shopId}`;

    console.info('boothsTap: ', dataset, url);
    circleUtil.onShopItemTap(shopId, true);
  },


  getShopAddress(marketList, shop) {
    let address = '圣名 ';

    address += shop.booth;
    return address;
  },

  onLoginTap() {
    wx.navigateTo({
      url: '/pages/login/index',
    });
  },

  onNotifyTap() {
    console.log('onNotifyTap...');
    wx.navigateTo({
      url: '/pages/new-comments/index',
    });
  },

  onRadarTap() {
    console.log('onRadarTap...');
    wx.navigateTo({ url: '/pages/customer-radar/index' });
  },

  onBoothApply() {
    console.log('onBoothApply...');
    // this.getApplyInfo();
    wx.navigateTo({ url: '/pages/personal-info/index?scene=10001' });
  },

  onAppledListTap() {
    // wx.navigateTo({ url: '/pages/circle-applyed-list/index' });
    wx.navigateTo({ url: '/pages/circle-admin/index' });
  },

  /**
   * @description 商品管理
   */
  onPlusAppTap() {
    const { user } = this.data;

    // wx.openEmbeddedMiniProgram({
    //   appId: "wxe5f52902cf4de896",
    //   path: 'page/component/index',
    //   extraData: {},
    //   // envVersion: 'trial',
    //   success(res) {
    //     // 打开成功
    //   }
    // });
    // return;

    circleUtil.jumpToWsxcApp(user.shopId);
    return;

    // const { user } = this.data;
    // const url = '/pages/follow_detail/index?shop_id=' + user.shopId;

    // console.log('onPlusAppTap...', url);

    // if (user.shopId == 'A201905291653236670027260') {
    //     wx.navigateTo({
    //         url
    //     });
    //     return;
    // }


    wx.navigateToMiniProgram({
      appId: 'wx82768f631dd021fd', //'wx107b8fbd08e99afd', //'wx5b589968eff47164', //
      path: 'pages/follow_detail/index?shop_id=' + user.shopId,
      // path: `/package-album/pages/vip/index`,
      extraData: {
        foo: 'bar'
      },
      // envVersion: 'trial',
      success(res) {
        // 打开成功
      }
    });
  },

  /**
   * @description 我发布的供求
   */
  onSupplyTap() {
    const { user, isApplyed } = this.data;
    if (!isApplyed) {
      wx.switchTab({ url: '/pages/circle-apply/index' });
      return;
    }
    const url = '/pages/follow_detail_ks/index?isCircle=&shop_id=' + user.shopId;

    console.log('onSupplyTap...', url);
    wx.navigateTo({
      url
    });
  },

  onWegoLinkTap() {
    const url = "/pages/webview/index?url=" + encodeURIComponent('https://mp.weixin.qq.com/s/n2S8PKfyQxytRYhuE-f3LQ');

    wx.navigateTo({ url });
  },


  onKefuTap(ev) {
    const url = "/pages/webview/index?url=" + encodeURIComponent('http://mp.weixin.qq.com/s?__biz=MzIzMzEwMTQwOQ==&mid=502021395&idx=1&sn=1c02dea8cd5952d635d15a6c9b41debf&chksm=70925c1d47e5d50b4c083ef3d53b231f8f2c8e743f8c10024cdbeaf021ee9493ad39dbd33199#rd');

    // wx.navigateTo({ url });
  },
});
