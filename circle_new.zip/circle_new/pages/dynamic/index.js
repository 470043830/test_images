import {$tdSearchbar, $tdUploader, $wuxToast} from '../../components/wux';
import nineGrid from '../../utils/nine-grid';

const util = require('../../utils/util.js');
const constant = require('../../utils/constant');
const app = getApp();
function getData() {
    return {
        // getUrl: [
        //     '/data/dynamic_1.json?tab=0',
        //     '/data/dynamic_1.json?tab=1',
        // ],
        tabbar: {},
        getUrl: [
            '/circle/miniapp_circle_themes_list.jsp?act=get_circle_themes_attention',
            '/circle/miniapp_circle_themes_list.jsp?act=get_circle_themes_plaza',
        ],
        addUrl: '/album/album_theme_operation.jsp?act=hold_theme',
        loading: false,
        loadingNoData: false, // 无数据
        loadingEnd: false, // 到底了
        filterText: '',
        filterImg: '',
        latestTime: '',
        listIndex: 0,
        list: [],
        navs: [{ label: '已关注' }, { label: '广场' }],
        priceTypesObj: constant.priceTypesObj,
    };
}

Page(Object.assign({}, nineGrid, {
    data: getData(),

    onLoad(options) {
        console.log('onLoad', options);
        app.editTabbar();

        // 隐藏本页面的转发按钮
        wx.hideShareMenu();

        $tdSearchbar.init({
            style: 'border: none',
            image: true,
            searchHandler(text, img) {
                const { listIndex } = this.page.data;

                console.info(`text: ${text}`, `img: ${img}`);
                this.setData(Object.assign({}, getData(), {
                    listIndex,
                    filterText: text,
                    filterImg: img,
                }));
                this.page.fetchData();
            }
        });

        if (this.isGuestLogin()){
            return;
        }

        wx.showLoading({
            mask: false,
            title: '加载中...',
        });
        this.fetchData('', () => {
            wx.hideLoading();
        });
    },

    isGuestLogin(){
        let info = wx.getStorageSync(USER_INFO_STORAGE);

        //游客弹窗提示登录
        if (info && info.isGuest) {
            //return true;
        }
        return false;
    },

    onShow(){
        if (this.isGuestLogin()) {
            wx.showModal({
                title: '提示',
                content: '请先登录',
                success(res) {
                    if (res.confirm) {
                        console.log('用户点击确定');
                        wx.redirectTo({
                            url: '/pages/login/index'
                        });
                    } else if (res.cancel) {
                        console.log('用户点击取消');
                        wx.switchTab({
                            url: '/pages/index/index'
                        });
                    }
                }
            });
        }

    },

    navTap(ev) {
        const { index } = ev.target.dataset;
        const { listIndex, filterText, filterImg } = this.data;

        if (index == listIndex) {
            return false;
        }

        console.info('nav', index);
        wx.showLoading({
            mask: true,
            title: '加载中...',
        });
        this.setData(Object.assign({}, getData(), {
            listIndex: index,
            filterText,
            filterImg,
        }));
        this.fetchData('', () => {
            wx.hideLoading();
        });
    },

    onShareAppMessage(res) {
        if (res.from === 'button') {
            // 来自页面内转发按钮
            console.log(res.target);
        }

        const { list } = this.data;
        const length = list.length;
        let path = '';
        let title = '';
        let imageUrl = '';

        console.log("test:" + length);
        if (this.shareIndex >= 0 && this.shareIndex < length) {
            const goods = list[this.shareIndex];
            const { shop_id, goods_id, imgsSrc, share_shop_id, share_goods_id } = goods;

            title = goods.title;
            path = `pages/goods_detail/index?goods_id=${share_goods_id || goods_id}&shop_id=${share_shop_id || shop_id}`;
            imageUrl = imgsSrc[0] || '';
        }
        this.shareIndex = -1;

        return {
            title: title,
            path: path,
            imageUrl,
            success: function (res) {
                // 转发成功
            },
            fail: function (res) {
                // 转发失败
            }
        };
    },

    getTimestamp() {
        const { list, latestTime } = this.data;
        const len = list.length;

        if (len > 0) {
            return {
                top: latestTime,
                bottom: list[len - 1].time_stamp
            };
        } else {
            return {
                top: '',
                bottom: ''
            };
        }
    },

    getUrl(type) {
        const { listIndex, getUrl, filterText, filterImg } = this.data;
        const { top, bottom } = this.getTimestamp();
        let url = `${getUrl[listIndex]}&search_img=${filterImg}`;

        switch (type) {
            case 'top':
                url = `${url}&slip_type=0&time_stamp=${top || ''}`;
                break;

            case 'bottom':
                url = `${url}&slip_type=1&time_stamp=${bottom || ''}`;
                break;
        }

        return url;
    },

    fetchData(type, callback) {
        const url = this.getUrl(type);

        console.info(url);
        this.setData({loading: true});
        let param={
          search_value: this.data.filterText
        }
        util.fetchAuthInst(url, param, res => {
          const { errcode, result, errmsg } = res.data;
            let obj = {};

            console.log(res);
            if (errcode == 0) {
                const { goods_list, ...others } = result;
                const { list, filterText } = this.data;

                obj = {...this.data, ...others};
                if (type == 'top') {
                    obj.list = this.getNoRepeatData(goods_list, list);
                } else {
                    obj.list = [...list, ...goods_list];
                    // 到底了
                    goods_list.length <= 0 && (obj.loadingEnd = true);
                }
                obj.list = obj.list.map(item => ({rows: constant.ROWS, richTitle: !!filterText ? util.getRichTitle(item.title, filterText) : undefined, ...item}));
                // 无数据
                if (obj.list.length <= 0) {
                    obj.loadingNoData = true;
                } else {
                    obj.loadingNoData = false;
                }
                obj.latestTime = this.getLatestTime(obj.list);
                obj.loading = false;

                this.setData(obj);
                this.data.list.length < constant.minPageSize && this.onReachBottom();
            }else {
              $wuxToast.show({
                type: 'text',
                text: errmsg
              });

              obj.loading = false;

              this.setData(obj);
            }
            typeof callback == 'function' && callback();

            // 清除失效token，触发重新获取
            app.clearToken(res.data, () => {
                this.onPullDownRefresh();
            });
        }, err => {
            console.log(err);
            this.setData({ loading: false });
            typeof callback == 'function' && callback();
        });
    },

    getNoRepeatData(newData, oldData) {
        const data = [...newData, ...oldData];
        const len = data.length;
        const hash = {};
        const result = [];

        for (let i = 0; i < len; i++) {
            let goods = data[i];
            let goods_id = goods.goods_id;

            if (!hash[goods_id]) {
                hash[goods_id] = true;
                result.push(goods);
            }
        }

        // console.info(result);
        return result;
    },

    getLatestTime(data) {
        return data.map(item => item.time_stamp).filter(item => item)[0] || '';
    },

    onReachBottom() {
        const { loading, loadingNoData, loadingEnd } = this.data;

        if (loading || loadingNoData || loadingEnd) {
            return false;
        }

        console.log("onReachBottom");
        this.fetchData('bottom');
    },

    onPullDownRefresh() {
        wx.hideLoading();
        const { loading } = this.data;

        if (loading) {
            return false;
        }

        console.log("onPullDownRefresh");
        this.fetchData('top', () => {
            console.log("stopPullDownRefresh");
            wx.stopPullDownRefresh();
        });
    },

}))
