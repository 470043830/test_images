
const constant = require('../../utils/constant');
const circleUtil = require('../../utils/circle-util.js');

Page({
    data: {
        focus: false,
        inputValue: '',
        shop_list: []
    },

    onLoad() {
        this.getShopList();
    },

    bindKeyInput: function (e) {
        this.setData({
            inputValue: e.detail.value
        });
    },
    bindReplaceInput: function (e) {
        var value = e.detail.value;
        var pos = e.detail.cursor;
        var left;
        if (pos !== -1) {
            // 光标在中间
            left = e.detail.value.slice(0, pos);
            // 计算光标的位置
            pos = left.replace(/11/g, '2').length;
        }

        // 直接返回对象，可以对输入进行过滤处理，同时可以控制光标的位置
        return {
            value: value.replace(/11/g, '2'),
            cursor: pos
        };

        // 或者直接返回字符串,光标在最后边
        // return value.replace(/11/g,'2'),
    },
    bindHideKeyboard: function (e) {
        if (e.detail.value === '123') {
            // 收起键盘
            wx.hideKeyboard();
        }
    },

    onItemTap(e) {
        const { shop_list } = this.data;
        const { index } = e.currentTarget.dataset;
        this.getAlbumUserInfo(shop_list[index].shopId);
    },

    onLoginTap() {
        // wx.reLaunch({ url: '/pages/home/index' });
        const { inputValue } = this.data;
        this.getAlbumUserInfo(inputValue);
    },

    async getShopList() {
        wx.showLoading({ title: '加载中...' });
        const url = `/circle/circle_new_interface.jsp?act=getAllShops`;
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url });
        console.log('getShopList: ', isOk, result);
        wx.hideLoading();

        if (isOk) {
            const { shop_list } = result;

            this.setData({ shop_list });
        }
    },

    async getAlbumUserInfo(inputValue) {
        let _userInfo = getApp().globalData.userInfo;
        console.log('getAlbumUserInfo, inputValue: ', inputValue);
        if (inputValue == 'reset') {
            _userInfo.token = _userInfo.originToken;
            wx.reLaunch({ url: '/pages/wxme/index' });
            return;
        }
        wx.showLoading({ title: '加载中...' });
        const url = `/circle/circle_new_interface.jsp?act=getAlbumUserInfo&albumId=${inputValue}`;
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url });
        console.log('getAlbumUserInfo: ', isOk, result);
        wx.hideLoading();

        if (isOk) {
            // this.setData({
            //     applyList: result
            // });
            const { userToken, albumId } = result;
            if (userToken) {
                _userInfo.token = result.userToken;
                _userInfo.albumId = albumId;
                wx.setStorageSync(constant.USER_INFO_STORAGE, _userInfo);
                wx.reLaunch({ url: '/pages/wxme/index' });
            } else {

            }

        }
    },
});
