// pages/file-uploader/index.js
const util = require('../../utils/util');

Page({

    /**
     * 页面的初始数据
     */
    data: {

    },

    onBtnTap() {
        console.log('onBtnTap...');
        // 微信 API 选文件
        wx.chooseImage({
            count: 1,
            success: res => {
                let filePath = res.tempFilePaths[0];
                // 交给七牛上传
                util.qiniuUpload(filePath, res => {
                    wx.showToast({title:'upload ok!'});
                    console.log('file-uploader, res: ', res);
                });
            }
        })
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        util.initQiniu();
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
});
