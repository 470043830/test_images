import { $wuxToast } from '../../components/wux';

const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');

Page({
    data: {
        getUrl: '/data/ok.json',
        postUrl: '/circle/miniapp_circle_main.jsp?act=join',
        phone_number: '',
        wechat_id: '',
        isInit: false,
        posted: false, // 是否提交过
        showSuccess: false,

        leimuIndex: 0,
        leixingIndex: 0,
        multiIndex: [0, 0],
        pickLeimuArray: ['类目A', '类目B', '类目C'],
        multiArray: [['楼栋1', '楼栋2', '楼栋3', '楼栋4'], ['一层', '二层', '三层', '四层']],
        pickLeixingArray: ['类型1', '类型2', '类型3'],

        oobbjj: {
            dasdas: 1
        }
    },

    onLoad(options) {
        console.info('onLoad', options);

        this.fetchData();
    },

    bindPickerChange: function (e) {
        console.log('picker发送选择改变，携带值为', e.detail.value);
        this.setData({
            leimuIndex: parseInt(e.detail.value)
        });
    },

    async applyIntoCircle() {
        wx.showLoading({ title: '加载中...' });
        const { leimuIndex, leixingIndex, multiIndex } = this.data;
        const leimu = (leimuIndex + 1);
        const param = {
            leimu: leimu.toString().padStart(2, '0'),
            leixing: leixingIndex + 1,
            building: multiIndex[0] + 1,
            floor: multiIndex[1] + 1
        };
        await circleUtil.fetchNetData({ url: '/circle/circle_new_interface.jsp?act=applyIntoCircle', param }, this.onMyApplyInfoFetched);
        wx.hideLoading();
    },

    async getApplyInfo() {
        wx.showLoading({ title: '加载中...' });
        await circleUtil.fetchNetData({ url: '/circle/circle_new_interface.jsp?act=getMyApplyInfo' }, this.onMyApplyInfoFetched);
        wx.hideLoading();
    },

    onMyApplyInfoFetched(isOk, result = {}) {
        this.setData({ isInit: true });
        if (!isOk) {
            return;
        }
        const { status = -1 } = result;

        console.log('onMyApplyInfoFetched, status: ', status);
        //this.setData({ user: result, showView: true });
        if (status == 0) {
            this.setData({ posted: true });
        } else if (status == 1) {
            this.setData({ showSuccess: true });
        }
    },

    fetchData(callback) {
        const { getUrl: url } = this.data;

        console.info(url);
        this.getApplyInfo();

        // wx.showLoading({
        //     mask: true,
        //     title: '加载中...',
        // });

        // util.fetchAuth(url, null, res => {
        //     const { errcode, result } = res.data;
        //     let obj = {};

        //     console.log(res);
        //     wx.hideLoading();
        //     if (errcode == 0) {
        //         obj = Object.assign({}, this.data, result);
        //         this.setData(obj);
        //     }
        // }, err => {
        //     console.log(err);
        //     wx.hideLoading();
        // });
    },

    bindinput(ev) {
        const { target, detail } = ev;
        const { id } = target;
        let { value, cursor } = detail;
        value = value.trim();
        cursor = value.length;

        console.info(`id: '${id}'`, `value: '${value}'`, `cursor: ${cursor}`);
        this.setData({
            [id]: value
        });

        // return { value, cursor };
    },

    submitTap() {
        const { postUrl: url, phone_number, wechat_id } = this.data;
        const obj = { phone_number, wechat_id };

        if (!this.validate()) {
            //return false;
        }

        this.applyIntoCircle();
        //this.postData(url, obj);
    },

    postData(url, params) {
        console.info(url);
        wx.showLoading({
            mask: true,
            title: '正在保存...',
        });

        util.fetchAuthInst(url, params, res => {
            const { errcode, errmsg } = res.data;

            console.log(res);
            wx.hideLoading();
            if (errcode == 0) {
                this.setData({
                    showSuccess: true,
                });
            } else {
                $wuxToast.show({
                    type: 'text',
                    text: errmsg,
                });
            }
        }, err => {
            consoel.log(err);
            wx.hideLoading();
            $wuxToast.show({
                type: 'text',
                text: '保存失败，请稍后重试~',
            });
        });
    },

    validate() {
        // const reg_phone = /^(\d{3,4}-)?(\d{7,8})$|^1\d{10}$/;
        const reg_phone = /^1\d{10}$/;
        const reg_wechat = /^[A-z][A-z0-9_-]{5,19}$|^1\d{10}$|^[1-9]\d{4,9}$/;
        const { phone_number, wechat_id } = this.data;

        if (phone_number.length <= 0) {
            $wuxToast.show({
                type: 'text',
                text: '请输入电话号码~',
            });
            return false;
        }
        if (!reg_phone.test(phone_number)) {
            $wuxToast.show({
                type: 'text',
                text: '请输入正确的电话号码~',
            });
            return false;
        }

        if (wechat_id.length > 0 && !reg_wechat.test(wechat_id)) {
            $wuxToast.show({
                type: 'text',
                text: '请输入正确的微信号~',
            });
            return false;
        }

        return true;
    },


    bindMultiPickerChange: function (e) {
        console.log('picker发送选择改变，携带值为', e.detail.value);
        this.setData({
            multiIndex: e.detail.value
        });
    },
    bindMultiPickerColumnChange: function (e) {
        console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
        return;
    }

});
