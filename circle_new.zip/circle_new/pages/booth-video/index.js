import { $tdSearchbar, $tdUploader, $wuxToast } from '../../components/wux';
import nineGrid from '../../utils/nine-grid';

const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const constant = require('../../utils/constant');
const app = getApp();


Page({
    data: {
        showCustomBar: true,
    },

    onLoad(options) {
    },

    onShow() {
        if (getApp().offline()) {
            // circleUtil.showLoginModal();
            return;
        }
    },

    onUnload() {
    },

    showTabBar() {
        if (typeof this.getTabBar === 'function' && this.getTabBar()) {
            this.getTabBar().setData({
                selected: 1
            });
        }
    },

    onPullDownRefresh() {
        setTimeout(() => {
            wx.stopPullDownRefresh();
        }, 300);
    },






});
