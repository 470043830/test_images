import { $tdSearchbar, $tdUploader, $wuxToast } from '../../components/wux';
import nineGrid from '../../utils/nine-grid';

const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const constant = require('../../utils/constant');
const app = getApp();
const circleConfigInfoUrl = '/circle/circle_new_interface.jsp?act=getCircleConfigInfo';
const circleVideosUrl = '/circle/circle_new_interface.jsp?act=findAllVideos';

Page(Object.assign({}, nineGrid, {
    data: {
        tabs: [
            {
                title: '  ',
                checked: true
            }, {
                title: '   ',
                checked: false
            }],
        isMiniChecked: false,
    },

    onLoad(options) {
        console.log('onLoad', options);
        this.fetchNewShops();

        // this.addActivity();
    },

    onShow() {
        setTimeout(async () => {
            await circleUtil.getCircleConfigData();
            this.setData({
                isMiniChecked: circleUtil.isMiniChecked(),
            });
            this.showTabs();
        }, 10);
    },

    onUnload() {
        if (this._observer) this._observer.disconnect();
    },

    showTabs(){
        if (circleUtil.isMiniChecked()){
            this.setData({
                tabs: [
                    {
                        title: '视频',
                        checked: true
                    }, {
                        title: '活动预约',
                        checked: false
                    }],
            });
        }
    },

    onTabTap(ev) {
        const { tabs } = this.data;
        const { index } = ev.currentTarget.dataset;

        if (tabs[index].checked) {
            return;
        }
        tabs[0].checked = false;
        tabs[1].checked = false;
        tabs[index].checked = true;
        console.log("onTabChanged ", ev.currentTarget);
        this.setData({ tabs });
    },

    onBannerTap() {
        const url111 = "/pages/webview/index?url=" + "http://www.fanzhentang.com/index.php/index/Video/detail/id/138/videoid/18";

        url111 && wx.navigateTo({ url: url111 });
    },


    async fetchNewShops() {
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url: `/circle/circle_new_interface.jsp?act=getNewShops` });
        const { marketList } = this.data;

        // wx.hideLoading();
        console.log('fetchNewShops, result: ', result);
        // console.log('marketList: ', marketList);

        if (isOk) {
            const { shop_list } = result;
            for (let index = 0; index < shop_list.length; index++) {
                const shop = shop_list[index];
                shop.address = '梵真堂 ' + shop.booth;
            }
            this.setData({ new_booths: shop_list });
        }
    },


    async addActivity() {
        const param = {
            img: "https://xcimg.szwego.com/circle_images/fzt/huodong001.png",
            title: "7.26--大型史诗电影《觉悟者.六祖惠能》《觉悟者.六祖惠能》《觉悟者.六祖惠能》缘起赠礼活...",
            // start: new Date("2021/08/19 00:00:00").getTime(),
            // end: new Date("2021/08/19 23:59:00").getTime(),
            start: new Date("2021/07/19 00:00:00").getTime(),
            end: new Date("2021/07/19 23:59:00").getTime(),
            addr: "广西容县",
        };
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url: `/circle/circle_new_interface.jsp?act=addActivity`, param });

        // wx.hideLoading();
        console.log('addActivity, result: ', result);
        // console.log('marketList: ', marketList);

        if (isOk) {
        }
    },

}));
