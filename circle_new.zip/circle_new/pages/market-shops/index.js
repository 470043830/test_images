import { $tdSearchbar, $tdUploader } from '../../components/wux';
import nineGrid from '../../utils/nine-grid';

const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const constant = require('../../utils/constant');
const app = getApp();
function getData() {
    return {
        tabbar: {},
        getUrl: [
            //'/circle/miniapp_circle_themes_list.jsp?act=get_circle_themes_attention',
            '/circle/circle_new_interface.jsp?act=getShops',
            '/circle/circle_new_interface.jsp?act=get_circle_themes_plaza',
            // '/circle/miniapp_circle_themes_list.jsp?act=get_circle_themes_plaza',
        ],
        // addUrl: '/album/album_theme_operation.jsp?act=hold_theme',
        loading: false,
        loadingNoData: false, // 无数据
        loadingEnd: false, // 到底了
        noShopData: false, // 无商户数据
        filterText: '',
        filterImg: '',
        latestTime: '',
        listIndex: 0,
        list: [],
        shopList: [],
        navs: [{ label: '商户' }, { label: '动态' }],
        priceTypesObj: constant.priceTypesObj,

    };
}

Page(Object.assign({}, nineGrid, {
    data: {
        ...getData(),
        dynamicIndex: 1, //在只有动态的时候为0
        scrollListHeight: 0,
        floorList: [],
        banner: [], //[{ "src": "https://xcimg.szwego.com/m1611196700632_4932.jpg" }],
        vtabs: [],
        activeTab: 0,
        market_id: null,
    },
    shopIdList: '',

    onLoad(options) {
        const { market_id = null, leimu = null, floorIndex=0 } = options;
        console.log('onLoad', options);

        this.setData({ market_id });

        if (options.title) {
            wx.setNavigationBarTitle({ title: options.title });
        }

        //...
        this.setUrlCondition(options);
        this.setLeiMuBanner(leimu);
        this.setMarketBanner(market_id, floorIndex);

        // 隐藏本页面的转发按钮
        wx.hideShareMenu();

        $tdSearchbar.init({
            style: 'border: none',
            image: false, //true,
            searchHandler(text, img) {
                const { listIndex } = this.page.data;

                console.info(`text: ${text}`, `img: ${img}`);
                this.setData(Object.assign({}, getData(), {
                    listIndex,
                    filterText: text,
                    filterImg: img,
                }));
                this.page.fetchData();
            }
        });

        //...
        this.setScrollListHeight();

        //...
        if (!getApp().offline()) {
            this.startShowLoadingTimer();
        }
        //...get net data
        this.fetchData('', () => this.stopShowLoadingTimer());
    },

    onShow() {
        const isShowPublish = circleUtil.isMiniChecked();
        if (isShowPublish && getApp().offline()) {
            circleUtil.showLoginModal();
            return;
        }
    },

    startShowLoadingTimer() {
        this.stopShowLoadingTimer();
        this._delayLoadingTimer = setTimeout(() => {
            wx.showLoading({
                mask: true,
                title: '加载中...',
            });
        }, 600);
    },

    stopShowLoadingTimer() {
        if (this._delayLoadingTimer) {
            clearTimeout(this._delayLoadingTimer);
            this._delayLoadingTimer = null;
            wx.hideLoading();
        }
    },

    setMarketBanner(market_id, floorIndex) {
        const { circleInfo } = app.globalData;
        const { markets, floors=[] } = circleInfo;

        console.log('setMarketBanner, circleInfo: ', circleInfo);
        if(floors.length> 0){
            const banner = [{ src: floors[floorIndex].banner }];
            this.setData({ banner });
            return;
        }
        if (market_id) {
            for (let index = 0; index < markets.length; index++) {
                const element = markets[index];
                if (element.market_id == market_id) {
                    const banner = [{ src: element.banner }];
                    console.log('setMarketBanner, banner: ', banner);
                    this.setData({ banner });
                    break;
                }
            }
        }
    },

    setLeiMuBanner(leimu) {
        const { circleInfo } = app.globalData;
        const { config } = circleInfo;

        if (config.LeiMu && leimu) {
            const banner = [];
            let leimuItem = config.LeiMu[parseInt(leimu) - 1];
            for (let index = 0; index < leimuItem.banner.length; index++) {
                banner.push({ src: leimuItem.banner[index] });
            }
            this.setData({ banner });
            return;
        }
    },

    setScrollListHeight() {
        const query = wx.createSelectorQuery();
        const { windowHeight } = wx.getSystemInfoSync();
        query.select('#the-postion-line').boundingClientRect();
        query.exec(res => {
            console.log('setScrollListHeight: ', res);
            if (res[0]) {
                let scrollListHeight = windowHeight - res[0].top - 10;
                if (app.globalData.isIphoneX) scrollListHeight -= 20;
                console.log('query res:', res[0].top, windowHeight, scrollListHeight);
                this.setData({ scrollListHeight });
            } else {
                if (!this._queryTimerId) {
                    this._queryTimerId = setTimeout(() => {
                        this.setScrollListHeight();
                    }, 100);
                }
            }

        });
    },

    /**
     * 设置页面的打开参数
     * @param {} options
     */
    setUrlCondition(options) {
        this.appendUrl = ``;
        if (options.from == 'followedDynamicTap') {
            this.shopIdList = '';
            // this.shopIdList = circleUtil.getFollowedShopIds();
            this.setData({
                listIndex: 0,
                dynamicIndex: 0,
                navs: [], //[{ label: '动态' }],
                getUrl: ['/circle/circle_new_interface.jsp?act=get_circle_themes_attention'],
            });
        } else {
            options.leimu && (this.appendUrl += `&leimu=${options.leimu}`);
            options.leixing && (this.appendUrl += `&leixing=${options.leixing}`);
            // options.building && (this.appendUrl += `&building=${options.building}`);
            options.market_id && (this.appendUrl += `&building=${options.market_id}`);
            // options.floor && (this.appendUrl += `&floor=${options.floor}`);
            options.floorIndex && (this.appendUrl += `&floor=${options.floorIndex}`);
        }
        console.log('this.appendUrl: ', this.appendUrl);

    },

    previewImgs(e) {
        this.setData({
            showPreviewer: true,
            ...e.detail,
        }, () => {
            this.data.showPreviewer && util.navigateToBrowserPage();
        });
    },


    navTap(ev) {
        const { index } = ev.target.dataset;
        const { listIndex, filterText, filterImg } = this.data;

        if (index == listIndex) {
            return false;
        }

        console.info('nav', index);
        this.setData(Object.assign({}, getData(), {
            listIndex: index,
            filterText,
            filterImg,
        }));
        //...
        util.abortCurrRequestTask();
        this.fetchData('');
    },

    onShareAppMessage(res) {
        if (res.from === 'button') {
            // 来自页面内转发按钮
            console.log(res.target);
        }

        const { list } = this.data;
        const length = list.length;
        let path = '';
        let title = '';
        let imageUrl = '';

        console.log("test:" + length);
        if (this.shareIndex >= 0 && this.shareIndex < length) {
            const goods = list[this.shareIndex];
            const { shop_id, goods_id, imgsSrc, share_shop_id, share_goods_id } = goods;

            title = goods.title;
            path = `pages/goods_detail/index?goods_id=${share_goods_id || goods_id}&shop_id=${share_shop_id || shop_id}`;
            imageUrl = imgsSrc[0] || '';
        }
        this.shareIndex = -1;

        return {
            title: title,
            path: path,
            imageUrl,
            success: function (res) {
                // 转发成功
            },
            fail: function (res) {
                // 转发失败
            }
        };
    },

    getTimestamp() {
        const { list, latestTime } = this.data;
        const len = list.length;

        if (len > 0) {
            return {
                top: latestTime,
                bottom: list[len - 1].time_stamp
            };
        } else {
            return {
                top: '',
                bottom: ''
            };
        }
    },

    handleGoodsList(type, result, obj) {
        const { goods_list, ...others } = result;
        const { list, filterText } = this.data;

        obj = { ...this.data, ...others };

        if (!goods_list) {
            obj.loadingNoData = true;
            obj.loading = false;
            this.setData(obj);
            return;
        }

        if (!circleUtil.isMiniChecked()) {
            for (let index = 0; index < goods_list.length; index++) {
                const item = goods_list[index];
                if (item.videoURL) {
                    item.videoURL = "";
                    item.videoUrl = "";
                    item.themeType = 0;
                }
            }
        }

        if (type == 'top') {
            obj.list = this.getNoRepeatData(goods_list, list);
        } else {
            obj.list = [...list, ...goods_list];
            // 到底了
            goods_list.length <= 0 && (obj.loadingEnd = true);
        }
        obj.list = obj.list.map(item => ({ rows: constant.ROWS, richTitle: !!filterText ? util.getRichTitle(item.title, filterText) : undefined, ...item }));
        // 无数据
        if (obj.list.length <= 0) {
            obj.loadingNoData = true;
        } else {
            obj.loadingNoData = false;
        }
        obj.latestTime = this.getLatestTime(obj.list);
        obj.loading = false;

        this.setData(obj);
        this.data.list.length < constant.minPageSize && this.onReachBottom();
    },

    getMarketInfoById(market_id){
        const { circleInfo } = app.globalData;
        for (let index = 0; index < circleInfo.markets.length; index++) {
            const element = circleInfo.markets[index];
            if (element.market_id == market_id){
                return element;
            }
        }
        return null;
    },

    handleShopList(type, result, obj) {
        const { market_id } = this.data;
        const { shop_list, ...others } = result;
        let vtabs = [];
        obj.shopList = shop_list;
        obj.loading = false;

        this.shopIdList = '';

        const { circleInfo } = app.globalData;
        const marketInfo = this.getMarketInfoById(market_id);
        const floorObj = JSON.parse(marketInfo.extInfo);

        console.log('marketInfo: ', marketInfo);
        console.log('circleInfo: ', circleInfo);
        console.log('shop_list: ', shop_list);
        if (!shop_list) {
            obj.noShopData = true;
            this.setData(obj);
            return;
        }

        for (let index = 0; index < obj.shopList.length; index++) {
            const ele = obj.shopList[index];
            const { building, floor, booth } = ele;
            const floorInfo = floor.split('|');

            // const loudong = circleInfo.LouDong[parseInt(building) - 1];
            // ele.addr = loudong.floor[parseInt(floor)] + '-' + booth;
            // ele.addr = floorInfo[1] + '-' + booth;
            ele.addr = booth;

            // console.log('ele.addr: ', ele);
            // console.log('floorInfo: ', floorInfo);


            this.shopIdList += ele.shopId;
            this.shopIdList += ',';

            // let floorNum = Number(floor) - 1;
            let floorNum = floor; //Number(floorInfo[0]) - 1;
            console.log('floorNum: ', floorNum);
            if (!vtabs[floorNum]) {
                vtabs[floorNum] = {
                    title: floorObj.floors[floorNum], //floorInfo[1],
                    list: []
                };
            }
            vtabs[floorNum].list.push(ele);
        }
        obj.vtabs = vtabs.filter(Boolean);
        console.log('obj.vtabs: ', obj.vtabs);
        console.log('this.shopIdList: ', this.shopIdList);

        // 无数据
        if (obj.shopList.length <= 0) {
            obj.noShopData = true;
        } else {
            obj.noShopData = false;
        }

        this.setData(obj);
    },

    getUrl(type) {
        const { listIndex, getUrl, filterText, filterImg } = this.data;
        const { top, bottom } = this.getTimestamp();
        let url = `${getUrl[listIndex]}&search_img=${filterImg}`;

        switch (type) {
            case 'top':
                url = `${url}&slip_type=0&time_stamp=${top || ''}`;
                break;

            case 'bottom':
                url = `${url}&slip_type=1&time_stamp=${bottom || ''}`;
                break;
        }

        url += this.appendUrl;
        // if (listIndex == 1) {
        //     url += `&market_id=${this.shopIdList}`;
        // }
        // this.currFloor > 0 && (url += `&floor=${this.currFloor}`);
        return url;
    },

    /**
     * 获取网络数据（商品动态列表采用POST方式）
     * @param {*} type
     * @param {*} callback
     */
    async fetchNetData(type, callback) {
        const { listIndex, filterText, dynamicIndex } = this.data;
        console.log('start fetchNetData: ', type, filterText);

        const url = this.getUrl(type);
        const param = {
            search_value: filterText,
            // shop_ids: listIndex == dynamicIndex ? this.shopIdList : ''
        };
        const method = listIndex == dynamicIndex ? 'POST' : 'GET';
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url, method, param });
        console.log('on fetchNetData: ', isOk, result);
        //wx.hideLoading();
        let obj = {};
        if (isOk) {
            if (listIndex == dynamicIndex) {
                this.handleGoodsList(type, result, obj);
            } else {
                this.handleShopList(type, result, obj);
            }
        } else {
            obj.loading = false;
            this.setData(obj);
        }
        typeof callback == 'function' && callback();
    },

    fetchData(type, callback) {
        const isShowPublish = circleUtil.isMiniChecked();
        if (getApp().offline()) {
            if (isShowPublish) {
                circleUtil.showLoginModal();
            } else {
                const obj = {};
                obj.noShopData = true;
                this.setData(obj);
            }
            return;
        }

        const url = this.getUrl(type);

        console.info(url);
        this.setData({ loading: true });
        this.fetchNetData(type, callback);
        return;


        let param = {
            search_value: this.data.filterText
        };
        util.fetchAuthInst(url, param, res => {
            const { errcode, result, errmsg } = res.data;
            let obj = {};

            console.log(res);
            if (errcode == 0) {
                if (this.data.listIndex == 0) {
                    this.handleShopList(type, result, obj);
                } else {
                    this.handleGoodsList(type, result, obj);
                }

            } else {
                wx.showToast({
                    text: errmsg
                });

                obj.loading = false;

                this.setData(obj);
            }
            typeof callback == 'function' && callback();

            // 清除失效token，触发重新获取
            app.clearToken(res.data, () => {
                this.onPullDownRefresh();
            });
        }, err => {
            console.log(err);
            this.setData({ loading: false });
            typeof callback == 'function' && callback();
        });
    },


    getNoRepeatData(newData, oldData) {
        const data = [...newData, ...oldData];
        const len = data.length;
        const hash = {};
        const result = [];

        for (let i = 0; i < len; i++) {
            let goods = data[i];
            let goods_id = goods.goods_id;

            if (!hash[goods_id]) {
                hash[goods_id] = true;
                result.push(goods);
            }
        }

        // console.info(result);
        return result;
    },

    getLatestTime(data) {
        return data.map(item => item.time_stamp).filter(item => item)[0] || '';
    },

    onReachBottom() {
        const { loading, loadingNoData, loadingEnd } = this.data;

        if (loading || loadingNoData || loadingEnd) {
            return false;
        }

        console.log("onReachBottom");
        this.fetchData('bottom');
    },

    onPullDownRefresh() {
        wx.hideLoading();
        const { loading } = this.data;

        if (loading) {
            return false;
        }

        console.log("onPullDownRefresh");
        this.fetchData('top', () => {
            console.log("stopPullDownRefresh");
            wx.stopPullDownRefresh();
        });
    },

    onVTabChange(e) {
        const index = e.detail.index;
        console.log('change', index);
    },

    joinCircleTap2() {
        // wx.navigateTo({ url: '/pages/contact-info/index?scene=10001' });
        wx.navigateTo({ url: '/pages/personal-info/index?scene=10001' });
    },

}));
