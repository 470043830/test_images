// pages/test001/index.js
import { $tdSearchbar } from '../../components/wux';

const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const app = getApp();

Page({

    /**
     * 页面的初始数据
     */
    data: {
        themeTag: 0,
        dynamicList: {}
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        const dynamicList = this.selectComponent('#dynamic-list');

        if (!dynamicList) {
            return;
        }
        this.setData({ dynamicList });

        $tdSearchbar.init({
            style: 'border: none',
            image: false,
            searchHandler(text, img) {
                dynamicList.searchHandler(text, img);
            }
        });

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        // this.fetchVipShops();
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    boothsTap(ev) {
        if (!circleUtil.isMiniChecked() && app.offline()) {
            return;
        }
        const { dataset } = ev.currentTarget;
        const { shopId } = dataset;
        const url = `/pages/follow_detail/index?shop_id=${shopId}`;

        console.info('boothsTap: ', dataset, url);
        circleUtil.onShopItemTap(shopId, true);
    },

    onThemeTagChanged(e) {
        const { index } = e.detail;
        console.log('onThemeTagChanged...', index);
        this.setData({
            themeTag: index
        });
    },


    async fetchVipShops() {
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url: `/circle/circle_new_interface.jsp?act=getVipShops` });
        const { marketList } = this.data;

        console.log('fetchVipShops, result: ', result);

        if (isOk) {
            const { shop_list } = result;
            for (let index = 0; index < shop_list.length; index++) {
                const shop = shop_list[index];
                shop.address = '圣名' + shop.booth;
            }
            this.setData({ vip_booths: shop_list });
        }
    },



    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {
        const { dynamicList } = this.data;
        if (dynamicList) {
            dynamicList.onPullDownRefresh();
        }
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
        const { dynamicList } = this.data;
        if (dynamicList) {
            dynamicList.onReachBottom();
        }
    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
});
