import {
    $fileUploader,
} from '../../components/wux';
const util = require('../../utils/util.js');
const logic = require('../../utils/logic');
const circleUtil = require('../../utils/circle-util');

import commonGrid from '../../utils/common-grid.js';

const getUrl = '/album/get_album_themes_list.jsp?act=single_item';
const saveUrl = '/album/album_theme_operation.jsp?act=save_theme';
const addCircleGoodsUrl = '/circle/circle_new_interface.jsp?act=addGoods';

function getDefaultPostData() {
    return {
        id: '',
        title: '', // 小程序可编辑
        main_imgs: [], // 小程序可编辑
        videoImg: '', // 小程序可编辑，视频封面图
        videoUrl: '', // 小程序可编辑，小程序资源
        themeType: 4,
    };
};
const app = getApp();

Page({
    data: {
        isIOS: util.isIOS(),
        showLoading: true,
        showDownloadConfirm: false,
        edittingGoods: getDefaultPostData(),
        vipConfirm: false,
        is_my_album: false,
        statusBarHeight: 20,
        albumItemBean: {},
        playing: false,
        editting: false,
        supportNavigationStyle: true,
        isScroll: false,
        hideHandleBar: false,
        showShareFriendConfirm: false,
        errMsg: '',
        isShowFabu: false,
        category: -1,
        isShowPublish: false,
    },

    onLoad(options) {
        // if (app.offline()) {
        //     wx.redirectTo({
        //         url: '/pages/login/index'
        //     });
        //     return;
        // }

        // 判断是否支持自定义导航
        wx.hideShareMenu();

        const { statusBarHeight } = app.getCustomBarInfo();

        this.setData({
            statusBarHeight,
            supportNavigationStyle: util.supportNavigationStyle()
        });
        this.initFileUploader({
            videoURL: '',
            themeType: 2,
            files: [],
        });
        this.setData({
            isShowFabu: true,
            category: options.category,
            showLoading: false,
        });
        console.log('新增商品/编辑商品 onLoad, options: ', options, statusBarHeight);
        // this._category = 1; //options.category;
    },

    onShow() {
        // console.log('getTabBar: ', this.getTabBar().showTab(false));
        // wx.hideTabBar();

        // const { category } = this.data;
        // if (category < 0) {
        //     this.initFileUploader({
        //         videoURL: '',
        //         themeType: 2,
        //         files: [],
        //     });

        //     setTimeout(() => {
        //         this.showSelectSheet();
        //     }, 200);
        // }

        const isShowPublish = circleUtil.isMiniChecked();
        this.setData({ isShowPublish });

    },

    onUnload() {
        try {
            wx.removeStorageSync('image_tempfiles');
            wx.removeStorageSync('video_tempfiles');
        } catch (e) { };
    },

    showSelectSheet() {
        wx.showActionSheet({
            // itemList: ['商品', '求购', '拼单', '二手', '招聘', '出租/转让'],
            itemList: ['求购', '拼单', '二手', '招聘', '出租/转让'],
            success: res => {
                console.log(res.tapIndex);
                this.setData({ category: res.tapIndex + 1, isShowFabu: true });
            },
            fail: res => {
                console.log(res.errMsg);
                // this.goBack();
                this.setData({ category: 1, isShowFabu: true });
            }
        });
    },

    onBackTap() {
        this.goBack(false);
    },

    goBack(isSendContent) {
        // util.navGoBack();
        const { category } = this.data;
        console.log('goBack, isSendContent: ', isSendContent);
        wx.navigateBack({
            success: res => {
                if (isSendContent) {
                    setTimeout(() => {
                        // console.log('startPullDownRefresh...');
                        // wx.startPullDownRefresh();

                        // wx.switchTab({
                        //     url: '/pages/home/index',
                        //     complete: e => {
                        //         wx.startPullDownRefresh();
                        //     }
                        // });

                        //暂时屏蔽 特殊跳转处理
                        // app.globalData.discoveryCategory = category;
                        // app.globalData.discoveryIndex = 1;
                        // console.log('app.globalData.discoveryIndex=', app.globalData.discoveryIndex);
                        // wx.switchTab({
                        //     url: '/pages/discovery/index'
                        // });
                    }, 200);
                }
            }
        });
        return;

        // this.setData({ category: -1, isShowFabu: false, edittingGoods: getDefaultPostData() });
        if (isSendContent) {
            // app.globalData.fromGoodsEdit = true;
            wx.navigateBack({
                success: res => {
                    wx.switchTab({
                        url: '/pages/discovery/index',
                        success: res => {
                            setTimeout(() => {
                                console.log('startPullDownRefresh...');
                                wx.startPullDownRefresh();
                            }, 200);
                        }
                    });
                }
            });

        } else {
            // wx.switchTab({
            //     url: app.globalData.currTabPageUrl
            // });
            wx.navigateBack();
        }

    },

    initFileUploader(props) {
        console.log('props: ', props);
        const windowWidth = wx.getSystemInfoSync().windowWidth;
        this.fileUploaderContext = $fileUploader.init({
            ...props,
            windowWidth,
            imageWidth: (windowWidth - 30 - 30) / 3,
            playVideo: (playing) => {
                console.log('playing: ', playing);
                this.setData({
                    playing
                });
            },
        });
    },

    fetchGoodsDetail(data) {
        util.fetch(getUrl, data).then(res => {
            const {
                errcode,
                errmsg,
                result = {},
            } = res.data;
            if (errcode === 0) {
                let {
                    videoURL,
                    themeType,
                    videoThumbImg,
                    imgsSrc,
                    imgs,
                    priceArr,
                    skuPriceType,
                    skus,
                    increasePriceConfig,
                    formats,
                    colors,
                    is_my_album,
                } = result;
                if (!is_my_album) {

                }
                this.setData({
                    edittingGoods: {
                        ...result,
                        priceArr,
                        skus,
                        formats,
                        colors,
                    },
                }, () => {
                    let files = [];
                    if (themeType === 4) {
                        files = [{
                            name: videoURL,
                            cdnSource: videoThumbImg,
                            status: 'uploaded'
                        },
                        ...imgsSrc.map((img, index) => ({
                            name: imgs[index],
                            cdnSource: img,
                            status: 'uploaded'
                        }))
                        ];
                    } else {
                        files = imgsSrc.map((img, index) => ({
                            name: themeType === 1 ? videoURL : imgs[index],
                            cdnSource: img,
                            status: 'uploaded'
                        }));
                    }
                    this.initFileUploader({
                        videoURL,
                        themeType,
                        files,
                    });
                    wx.hideLoading();
                    this.setData({
                        showLoading: false,
                    });
                });
            } else if (errcode === 300) {
                wx.hideLoading();
                this.setData({
                    showLoading: false,
                    errMsg: errmsg,
                    ...result,
                });
            } else {
                wx.hideLoading();
                wx.showToast({
                    icon: 'none',
                    title: errmsg,
                });
            }
        });
    },

    getFormats(formats = []) {
        return formats.map(format => {
            const { formatId } = format;

            return { ...format, formatId: -1 * formatId };
        });
    },

    getSkus(skus = []) {
        return skus.map(sku => {
            let { id } = sku;
            const [colorID, formatID] = id.split(';');
            id = !!formatID ? `-${colorID};-${formatID}` : `-${colorID}`;

            return { ...sku, id };
        });
    },

    hideDownloadConfrim(e) {
        const {
            copy = '0'
        } = e.currentTarget.dataset;
        this._showDownloadConfirm(false);
        if (copy === '1') {
            util.copyTitle("mmicroboss");
        }
    },

    showMoreGoodsProps() {
        wx.showModal({
            title: '温馨提示',
            content: '小程序暂时不支持此操作，请关注【微商相册】公众号下载APP，确认即复制微信号：mmicroboss',
            showCancel: true,
            success: function (res) {
                if (res.confirm) {
                    util.copyTitle("mmicroboss");
                } else if (res.cancel) {
                    console.log('用户点击取消');
                }
            }
        });
        // this._showDownloadConfirm(true);
    },

    _showDownloadConfirm(show) {
        this.setData({
            showDownloadConfirm: show,
            isScroll: !show
        });
    },

    handleOkVipConfrim() {
        this.setData({
            vipConfirm: false,
        });
        wx.navigateTo({
            url: '/pages/vip/index'
        });
    },

    closeConfirm() {
        this.setData({
            vipConfirm: false,
        });
    },

    handleChangeTextarea(e) {
        this.setData({
            ['edittingGoods.title']: e.detail.value,
        });
    },

    saveGoodsAct() {
        this.saveGoods();
    },

    updateShareGoods(data) {
        //分享到朋友圈,更新商品分享时间
        // console.log('lin---------->更新分享时间：')
        console.log(data);

        if (data.is_my_album) {
            this.saveGoods('circle', 2, data);
        } else {
            util.updateShareTime(data, res => {
                console.log('lin---------->更新分享时间res：');
                console.log(res);
                let item = res.item_data;
                item.shop_id = data.shop_id;
                item.goods_id = data.goods_id;
                wx.setStorage({
                    key: 'goods_edit_submit_result',
                    data: item,
                });
            }, true);
        }

        // /service/album/share_operation.jsp?act=miniapp_item_share
        // setTimeout(() => {
        //     this.saveGoods('circle', 2, data);
        // }, 2000)
    },
    shareGoodsAct() {
        this.saveGoods('shareGoods');
    },

    watchFilesUploaded() {
        return new Promise((resolve, reject) => {
            this.timer = setInterval(() => {
                const {
                    files
                } = this.fileUploaderContext.getComponentData();
                const unUploadedFiles = files.filter(item => item.status === 'before_upload');
                if (unUploadedFiles.length === 0) {
                    clearInterval(this.timer);
                    this.timer = null;
                    resolve(true);
                }
            }, 200);
        });
    },

    async saveGoods(type, sharePlat, argsData) {
        console.log('saveGoods...');
        const postDataStructure = getDefaultPostData();
        const {
            edittingGoods
        } = this.data;
        console.log('edittingGoods: ' + edittingGoods);

        type !== 'circle' && wx.showLoading({
            title: '正在保存...',
            mask: true,
        });

        await this.watchFilesUploaded();

        const {
            is_my_album,
            goods_id
        } = edittingGoods;
        const {
            files,
            themeType,
            videoURL
        } = this.fileUploaderContext.getComponentData();
        console.log('files: ', files);
        const obj = {
            ...edittingGoods
        };
        if (themeType === 0) {
            obj.main_imgs = JSON.stringify(files.map(file => file.cdnSource));
            obj.themeType = 0;
        } else if (themeType === 1) {
            obj.videoImg = files[0].cdnSource;
            obj.videoUrl = videoURL;
        } else if (themeType === 2) {
            // ...
        } else if (themeType === 4) {
            obj.videoImg = files[0].cdnSource;
            obj.videoUrl = videoURL;
            obj.main_imgs = JSON.stringify(files.slice(1).map(file => file.cdnSource));
        }
        console.log('saveGoods: ', obj);

        //...
        if (!obj.title && obj.main_imgs.length == 0 && !obj.videoUrl) {
            wx.hideLoading();
            wx.showToast({ title: '发布内容为空', icon: 'none' });
            return;
        }

        let postData = {};
        if (!is_my_album && goods_id) {
            postData = {
                ...postData,
                source_type: 100,
                album_id: this.shop_id,
                item_id: this.goods_id,
            };
        } else if (is_my_album && goods_id) {
            postData = {
                ...postData,
                album_id: this.shop_id,
            };
        }
        obj.themeType = themeType;
        Object.keys(postDataStructure).map(key => {
            if (obj.hasOwnProperty(key)) {
                if (typeof obj[key] === 'object') {
                    postData[key] = JSON.stringify(obj[key]);
                } else {
                    postData[key] = obj[key];
                }
            } else {
                if (typeof postDataStructure[key] === 'object') {
                    postData[key] = JSON.stringify(postDataStructure[key]);
                } else {
                    postData[key] = postDataStructure[key];
                }
            }
        });
        postData = {
            ...postData,
            id: is_my_album ? goods_id : '',
        };
        if (sharePlat) {
            postData.share_type = sharePlat;
        }

        if (typeof (obj.is_my_album) != 'undefined') {
            this.setData({
                is_my_album: obj.is_my_album
            });
        }

        //new add
        postData.category = this.data.category;
        console.log('postData: ', postData);

        //发布到商圈url
        let addGoodsUrl = addCircleGoodsUrl;
        if (this.data.category == 0) {
            addGoodsUrl = saveUrl;  //发布到相册url
        }

        util.fetch(addGoodsUrl, postData, 'POST')
            .then(
                res => {
                    const {
                        errcode,
                        errmsg,
                        item_data = {},
                        result = {},
                        albumItemBean
                    } = res.data;
                    if (errcode === 0) {
                        const {
                            vip_object,
                            item_data: circle_item_data
                        } = result;
                        const { from = {} } = item_data;
                        console.log('circle_item_data: ', circle_item_data);
                        if (circle_item_data) {
                            const eventChannel = this.getOpenerEventChannel();
                            eventChannel && eventChannel.emit('acceptDataFromOpenedPage', circle_item_data);
                        }
                        if (vip_object) {
                            console.log('vip_object: ', vip_object);
                            wx.hideLoading();
                            // this.setData({
                            //     vipConfirm: true,
                            // });
                            wx.showModal({
                                title: '会员特权',
                                content: '抱歉,只有会员才可以发布商品,请开通会员',
                                showCancel: true,
                                confirmText: '去开通',
                                success: function (res) {
                                    if (res.confirm) {
                                        wx.navigateToMiniProgram({
                                            appId: 'wx82768f631dd021fd', 
                                            path: `/package-album/pages/vip/index`,
                                            // envVersion: 'trial',
                                            success(res) {
                                                // 打开成功
                                            }
                                        });
                                    } else if (res.cancel) {
                                        console.log('用户点击取消');
                                    }
                                }
                            });
                        } else {
                            if (type === 'shareGoods') {
                                wx.hideLoading();
                                let {
                                    edittingGoods
                                } = this.data;
                                if (!edittingGoods.goods_id) {
                                    edittingGoods.goods_id = item_data.goods_id;
                                    edittingGoods.is_my_album = true;
                                }
                                //console.log("shareGoods hideHandleBar : " + this.data.hideHandleBar)
                                this.setData({
                                    edittingGoods: edittingGoods,
                                    temp_data: albumItemBean || item_data,
                                    hideHandleBar: true,
                                }, () => {
                                    // this.shareGoods();
                                    this.shareGoods(item_data, albumItemBean);
                                });
                            } else {
                                type !== 'circle' && wx.showToast({
                                    title: errmsg,
                                });
                                // 分享朋友圈情况出现视频弹框点击ok按钮才自动返回。所以这里单独特殊处理
                                if (!argsData) {
                                    // 处理缓存数据
                                    // wx.navigateBack();
                                    console.log('goBack 2222222222');
                                    this.goBack(true);
                                } else {
                                    if (argsData.shareType != "friends") {
                                        // wx.navigateBack();
                                        this.goBack();
                                    }
                                }
                                // app.globalData.updateHomeData = true;
                            }
                            wx.setStorage({
                                key: 'goods_edit_submit_result',
                                data: item_data,
                            });
                        }
                        app.globalData.from = from;//用于返回详情页分享
                    } else {
                        if (errcode == 1 && type === 'circle') {
                            //处理分享后此图文不存在的情况(主从延时问题)，延时1秒后重试
                            // let that = this;
                            setTimeout(() => {
                                this.updateShareGoods(argsData);
                            }, 1500);
                        } else {
                            wx.hideLoading();
                            wx.showToast({
                                icon: 'none',
                                title: errmsg,
                            });
                        }

                    }
                },
                err => {
                    console.log('err: ', err);
                    wx.hideLoading();
                    wx.showToast({
                        icon: 'none',
                        title: '网络有点堵~',
                    });
                }
            );
    },

    updateData(e) {
        console.log('lin------------2222222222>updateData');
        let data = e.detail;
        console.log(data);
        if (data.action == 'del') {
            wx.removeStorageSync('goods_edit_submit_result');
        } else if (data.action == 'top') {

        } else if (data.action == 'circle') {
            //TODO：
            this.setData({
                showShareFriendConfirm: true,
            });
            this.updateShareGoods(data);
        }
    },

    onShareClose(e) {
        //console.log("onShareClose : " + JSON.stringify(e))
        let hideHandleBar = e.detail;
        console.log("onShareClose hideHandleBar1 : " + hideHandleBar);
        this.setData({
            hideHandleBar: hideHandleBar,
        });
        //console.log("onShareClose hideHandleBar2 : " + this.data.hideHandleBar)

    },

    onToShop() {
        const route = '/pages/follow_detail/index';
        const options = {
            shop_id: this.data.shop_id,
        };

        util.navigateTo(route, options);
    },

    shareGoods(edittingGoods, data) {
        // share_type=2
        const goods = edittingGoods;
        // console.log(data)

        let {
            shop_id,
            goods_id,
            themeType,
            is_my_album,
            videoURL,
            imgsSrc,
            title
        } = goods;
        if (data) {
            if (!videoURL) {
                videoURL = data.videoURL || '';
            }
            if (!imgsSrc) {
                imgsSrc = data.imgsSrc || '';
            }
            if (!title) {
                title = data.title || '';
            }
        }

        const images = imgsSrc;
        const obj = {
            index: 0,
            goods_id,
            images,
            is_added: !is_my_album, // 判断是否是自己的商品
            // item: goods,
            item: data || goods,
            shop_id,
            themetype: themeType,
            title,
            video: videoURL,
            is_my_album: this.data.is_my_album
        };
        //  console.log(obj)
        // logic.showshare(this.data.albumItemBean, () => {}, () => {}, () => {}, this);
        logic.showshare(obj, commonGrid.downloadStartCB.bind(this), commonGrid.downloadingCB.bind(this), () => { }, this);
        // app.globalData.updateHomeData = true;
    },
    setEditting() {
        this.setData({
            editting: !this.data.editting,
        });
    },
    onShareAppMessage(res) {
        let imageUrl = '';
        const goods = this.data.temp_data;
        const {
            shop_id,
            goods_id,
            themeType,
            is_my_album,
            videoURL,
            imgsSrc,
            title
        } = goods;
        const images = imgsSrc;
        console.log('share----------->' + images);
        if (res.from === 'button') {
            // 来自页面内转发按钮
            const { share_goods_id = '', tempFilePath = '' } = wx.getStorageSync('share_goods_canvas');
            imageUrl = (share_goods_id.length && share_goods_id == goods_id) ? tempFilePath : images ? images[0] : '';
        }
        setTimeout(() => {
            util.shareComplete("wechart");
        }, 500);
        const path = `pages/goods_detail/index?goods_id=${goods_id}&shop_id=${shop_id}&is_icon=${true}`;
        return {
            title: title,
            path: path,
            imageUrl,
            success: function (res) {
                console.log("发送成功");

            },
            fail: function (res) {
                console.log("转发失败");
                // 转发失败
            }
        };
    },
});
