const util = require('../../utils/util.js');

Page({
    data: {
        getUrl: '/account/get_my_attention_code.jsp?',
        imgWidth: '100%',
        follow_qrcode: '',
    },

    onLoad(options) {
        const { shop_id } = options;

        console.info('onLoad', options);
        this.shop_id = shop_id || '';

        this.fetchData();
    },

    fetchData() {
        const { getUrl } = this.data;
        const url = `${getUrl}&shop_id=${this.shop_id}`;

        console.info(url);
        wx.showLoading({
            mask: false,
            title: '加载中...',
        });
        util.fetchAuthInst(url, null, res => {
            const { errcode, result } = res.data;
            let obj = {};

            console.log(res);
            wx.hideLoading();
            if (errcode == 0) {
                obj = Object.assign({}, this.data, result);
                this.setData(obj);
            }
        }, err => {
            console.log(err);
            wx.hideLoading();
        });
    },

    bindload(ev) {
        const { detail } = ev;
        const { width } = detail;

        console.info(detail);
        this.setData({
            imgWidth: `${width}px`
        });
    },

    previewImage() {
        const { follow_qrcode } = this.data;

        console.log(follow_qrcode);
        wx.previewImage({
            current: follow_qrcode,
            urls: [follow_qrcode]
        });
    },

})
