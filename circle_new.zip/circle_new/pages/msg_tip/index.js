// pages/msg_tip/index.js
const circleUtil = require('../../utils/circle-util.js');
const app = getApp();

Page({

    /**
     * 页面的初始数据
     */
    data: {
        status: 0,
        imgSrc: '/assets/icons/waiting-check.svg',
        tipText: `操作成功`,
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        const { status } = options;

        this.initText(status);
    },

    async initText(status) {
        console.log("initText, status=" + status);
        let {
            circleInfo
        } = app.globalData;
        if (!circleInfo.LouDong) {
            circleInfo = await circleUtil.getCircleConfigData();
        }
        if (circleUtil.isMiniChecked()) {
            if (status > 0) {
                this.setData({
                    status,
                    imgSrc: '/assets/icons/checked.svg',
                    tipText: circleInfo.config.texts.str004
                });
            } else {
                this.setData({
                    tipText: circleInfo.config.texts.str005
                });
            }

        }

    },

    onBtnTap() {
        // wx.navigateBack({
        //     delta: 3,
        //     success: res => {

        //     }
        // });

        // wx.switchTab({
        //     url: '/pages/wxme/index'
        // });

        wx.reLaunch({ url: '/pages/home/index' });

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {
        //   wx.navigateBack({
        //       delta: 2,
        //       success: res => {

        //       }
        //   });
    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
});
