// pages/circle-apply/index.js
const constant = require('../../utils/constant');
const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const circleData = require('../../utils/circle-data.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    blurValue: 7,
    topPaddig: 100,
    price: 998,
    ruzhuText: '',
    address: '',
    latitude: '',
    longitude: '',
    tagsShowText: '',
    whichPage: 1,
    texts: [
      `管理者：谢龙服装类短视频全网年浏览量超百亿次，瑞纺直播基地代言人，西子环球直播基地好物推荐官，5季直播基地好物推荐官，银沙好物推荐官，国际纺织服装供应链博览会高级顾问，创始了千人服装高端私董会…`
      , `16 大会员权益，5000 万商家的生意必备工具箱`,
    ]
  },
  _detailAddress: '',
  _circleStatus: -1,

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    wx.getSystemInfo({
      success: res => {
        const {
          statusBarHeight,
        } = res;
        this.setData({
          topPaddig: statusBarHeight + 44 + 14
        });
      }
    });

    util.initQiniu();


  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    console.log('circle-apply onShow...');

    const isChecked = circleUtil.isMiniChecked();
    let ruzhuText = circleData.getCheckedText()["ruzhu"];
    this.setData({ ruzhuText, blurValue: isChecked ? 0 : 7 });

    if (isChecked && getApp().offline()) {
      getApp().globalData.triggerPagePath = '/pages/circle-apply/index?login=1';
      circleUtil.showLoginConfirm('登录已过期，请重新登录。');
      return;
    }

    //...
    this.getNetUserInfo();
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },



  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  onChangePage(e) {
    console.log('onChangePage ', e.detail.whichPage);
    const { whichPage } = e.detail;
    this.setData({ whichPage })
  },

  onJumpAppTap() {
    // circleUtil.jumpToWsxcApp();
    const toUrl = encodeURIComponent('https://mp.weixin.qq.com/s/CMeJqeUNID9BRacCLoSW6g');
    const url = "/pages/webview/index?url=" + toUrl;

    url && wx.navigateTo({ url: url });

    // wx.previewImage({
    //   current: '', // 当前显示图片的 http 链接
    //   urls: ['https://xcimg.szwego.com/circle_images/1213/640.png'] // 需要预览的图片 http 链接列表
    // })
  },

  onJumpMiniAppTap() {
    circleUtil.jumpToWsxcApp();
  },

  /**
   * 立即入住 支付998
   * @returns 
   */
  onPayBtnTap(type) {
    if (this._circleStatus < 0) { //wait to get status
      return;
    }
    const testAppId = 'wx0f731ab9ae18133e';
    const testPath = 'package-increase/pages/circle-pay-page/index';
    const { payMiniAppId = '', payPagePath, sellerAlbumId } = getApp().getCircleConfig();
    const appId = payMiniAppId;
    let path = payPagePath + '?albumId=' + sellerAlbumId;

    if (type == 'anchor pay') path += '&circle_type=anchor';

    console.log('onBtnTap...', appId, path);
    if (!payMiniAppId) {
      circleData.getCircleConfig();
      return;
    }

    this._isClickPay = true;
    wx.openEmbeddedMiniProgram({
      appId,
      path,
      extraData: {},
      // envVersion: 'trial',
      success(res) { }
    });
    // this.setData({ whichPage: 2 });
    return;


    // wx.setTabBarItem({
    //   index: 2,
    //   text: '已入住',
    //   "iconPath": "/assets/tab_icons/ruzhu1.png",
    //   "selectedIconPath": "/assets/tab_icons/ruzhu2.png"
    // })

    wx.navigateToMiniProgram({
      appId: 'wxb278781d654e8f81',
      path: 'pages/login/index?circle_id=CID000006',
      extraData: {
        foo: 'bar'
      },
      // envVersion: 'trial',
      success(res) {
        // 打开成功
      }
    });
  },

  // pay 9.9
  onAnchorPayBtnTap() {
    this.onPayBtnTap('anchor pay');
  },

  async getNetUserInfo() {
    // const { user = {} } = await circleData.getMyUserInfo();
    const { packOriginPrice = '' } = await circleData.getPackageDetail();

    this.setData({
      // userInfo: user,
      price: packOriginPrice,
    });

    // if (!this._isClickPay) return;

    //...get new state to decide where to goto?
    const { anchorStatus, merchantStatus } = await circleData.getCircleStatus();

    // for test
    // wx.showToast({
    //   title: `anchorStatus=${anchorStatus}, merchantStatus=${merchantStatus}`,
    //   icon: 'none'
    // });

    this._circleStatus = merchantStatus;
    console.log('this._circleStatus: ', this._circleStatus);
    if (anchorStatus == 3) {
      this.setData({ isAnchored: true });
    }
    if (1 && merchantStatus == 3) {
      this.setData({
        whichPage: 3
      });
      return;
    }
    //in profile editing...
    const isTestIng = 0; //true;
    if (isTestIng || anchorStatus == 1 || merchantStatus == 1) {
      this.setData({
        whichPage: 2,
        isEditZhubo: isTestIng || anchorStatus == 1,
      });
      return;
    }

    //init state...
    this.setData({
      whichPage: 1,
      isEditZhubo: false,
    });




    // const testToken = 'RjU4QTZGNUQ2Qzc5OUQ0MjVFQzY5NkFBODZFNzFDNzE5OThEMDI1RjI3RTc4MDUwNjgwRkQ2QjVBMkRBN0EwN0I5NkM5Rjk4REYzRkRBMjhDMDMwOUNDNTI4NEI4MjJGQ0JBNTk2RUU3OTM2RENFOTM5RjMwODY1MzMxNDY0RjA=';
    // const {
    //   isOk,
    //   result = {}
    // } = await circleUtil.fetchNetData({
    //   url: `/circle/circle_new_interface.jsp?act=getPersonalInfo&circle_id=CID000008&token=${encodeURIComponent(testToken)}`
    // });
    // if (isOk) {
    //   this.setData({
    //     userInfo: { ...result.base },
    //     circleShopInfo: result.circle,
    //     // tagNames,
    //   });
    //   console.log('userInfo: ', this.data.userInfo);

    //   this.setData({
    //     whichPage: 1
    //   })
    // }
  },

  // getConfigTags() {
  //   const {
  //     circleInfo
  //   } = getApp().globalData;
  //   const { config = {} } = circleInfo;
  //   return config.tags;
  // },

  getTagsShowText() {
    const tags = getApp().getCircleCategoryList();
    let ret = '';
    if (tags) {
      for (let index = 0; index < tags.length; index++) {
        const element = tags[index];
        element.checked && (ret += (element.categoryName + ','));
      }
      ret.length > 0 && (ret = ret.substr(0, ret.length - 1));
    }
    return ret;
  },

  onSelectTagsClick() {
    const that = this;
    wx.navigateTo({
      url: '/pages/select-tags/index?tagsShowText=' + this.data.tagsShowText,
      events: {
        // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
        acceptDataFromSelectTagPage(data) {
          console.log(data.tagsShowText, that.data);
          that.setData({ tagsShowText: data.tagsShowText }, () => {
            console.log(data.tagsShowText, that.data);
          });
        }
      },
    });
  },

  bindKeyInput: function (e) {
    console.log('bindKeyInput: ', e);
    // this.data.userInfo[e.currentTarget.id] = e.detail.value;
    this._detailAddress = e.detail.value;;
  },

  onQRCodeClick() {
    if (this.data.disableEdit) return;
    this.chooseImageUpload(url => {
      const {
        userInfo
      } = this.data;

      userInfo.wechat_qrcode = url;
      this.setData({
        userInfo
      });
    });
  },

  chooseImageUpload(callback) {
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album'],
      success: res => {
        let filePath = res.tempFilePaths[0];
        callback && util.qiniuUpload(filePath, callback);
      }
    });
  },

  onChooseLocationClick() {
    const that = this;
    wx.getFuzzyLocation({
      type: 'gcj02',
      success(res) {
        const latitude = res.latitude
        const longitude = res.longitude
        console.log(res.latitude);
        console.log(res.longitude);
        wx.chooseLocation({
          latitude: latitude, // 纬度，范围为-90~90，负数表示南纬
          longitude: longitude,
          success(res) {
            console.log('success: ', res);
            const { address = '', latitude = '', longitude = '' } = res;
            console.log('address: ', address, latitude, longitude);

            if (address) {
              that.setData({ address, latitude, longitude });
            }

          },
          fail(res) {
            console.log('fail: ', res);
          },
        });
      },
      fail(res) {
        console.log('fail: ', res);
      },
    });
  },


  async onPhoneNumber(e) {
    console.log("onPhoneNumber: ", e);
    const { encryptedData, iv } = e.detail;
    if (!encryptedData || !iv) {
      return;
    }
    let loginRes = await wx.login();
    console.log('loginRes: ', loginRes);

    const method = 'POST';
    const param = {
      encryptedData: encryptedData,
      iv: iv,
      code: loginRes.code,
      circle_id: constant.circle_id,
      client_type: 'miniapp',
    };
    console.log("onPhoneNumber param: ", param);
    const url = '/circle/circle_new_interface.jsp?act=decodeMiniAppPhoneNumber';
    const { isOk, result = {} } = await circleUtil.fetchNetData({ url, method, param });
    console.log('onPhoneNumber fetchNetData: ', isOk, result);

    if (isOk) {
      const { userInfo } = this.data;
      const { phoneNumber = '' } = result;
      userInfo.phone_number = phoneNumber;
      console.log('userInfo: ', userInfo);
      this.setData({ userInfo });
    }

  },

  /***
   * 提交信息
   */
  async postUserApplyInfo() {
    const {
      userInfo,
      address, latitude, longitude
    } = this.data;
    const { circleId } = getApp().getCircleConfig();

    const param = {
      circleId,
      shopId: userInfo.shop_id,
      shopName: userInfo.shop_name,
      wechatId: userInfo.wechat_id,
      wechatQrcode: userInfo.wechat_qrcode || '',
      shopIcon: userInfo.user_icon,
      phoneNumber: userInfo.phone_number,
      detailAddress: this._detailAddress, //userInfo.booth_id,
      // street: userInfo.street,
      // ext_info: `sceneInfo=${this._sceneInfo},${userInfo.street ? userInfo.street : ''}`,
      region: address, latitude, longitude,
      category: this.getTagsShowText(),
    };

    // if (!param.leimu) {
    //   param.leimu = '01';
    //   // wx.showToast({
    //   //     title: '请选择主营类目',
    //   // });
    //   // return;
    // }
    // if (!param.detailAddress) {
    //   wx.showToast({
    //     title: '请输入档口号',
    //   });
    //   return;
    // }
    // if (!param.phoneNumber) {
    //   wx.showToast({
    //     title: '请输入手机号码',
    //   });
    //   return;
    // }


    // getApp().globalData.circleInfo.applyInfo = param;
    // wx.navigateTo({
    //     url: '/pages/select-apply-into/index',
    // });

    console.log('param: ', param);
    const res = await circleData.saveCircleApply(param);
    this.setData({ whichPage: 3 });
  },
})