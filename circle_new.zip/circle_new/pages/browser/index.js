import { $cartSheet } from '../../components/wux';
import fourGrid from '../../utils/four-grid';
import nineGrid from '../../utils/nine-grid';
const util = require('../../utils/util');
const bury = require('../../utils/burypoint.js');

const app = getApp();

Page(Object.assign({}, fourGrid, nineGrid, {
    data: {
        showPreviewer: false,
        previewList: [],
        previewIndex: 0,
        preRoute: '',
        template: 4,
    },

    onShow() {
        // pendingEvent type: updateData
        const app = getApp();
        const { pendingEvent } = app.globalData;
        if (pendingEvent && pendingEvent.updateData) {
            const { data, eventEmitter } = pendingEvent.updateData;
            const { action } = data;
            if (action === 'del' && eventEmitter === 'pages/goods_edit/index') {
                this.previewImgs({ showPreviewer: false });
            }
        };
        wx.hideShareMenu();
    },

    onUnload() {
        this.$cartSheet.onHide();
    },

    onLoad(options) {
        const { route } = options;
        const decodedRoute = decodeURIComponent(route);
        const pages = getCurrentPages();
        const page = pages.find(item => item.route === decodedRoute);

        console.log('browser onLoad, page=', page);
        if (page) {
            const { data } = page;
            console.log('page data=', data);
            if (data.previewList) {
                this.setData({
                    ...data,
                    preRoute: decodedRoute,
                });
            } else {  //兼容内部自定义动态列表组件
                this.setData({
                    ...data.dynamicList.data,
                    preRoute: decodedRoute,
                });
            }

        };

        this.$cartSheet = $cartSheet.init({
            onAddCart() {
                this.setData({
                    showCart: true
                });
            }
        });
    },

    previewImgs(e) {
        this.setData({
            showPreviewer: true,
            ...e.detail,
        });
        wx.navigateBack();
    },

    updateData(e) {
        const { action, isTop } = e.detail;
        if (action === 'del') {
            this.emit(e.detail);
        } else if (action === 'top') {
            const originData = e.detail;
            const newData = { ...originData, isTop: isTop === 1 ? 0 : 1 };
            this.emit(newData);
            this.updateListItem(newData);
        } else if (action === 'circle') {
            this.emit(e.detail);
            // util.updateShareTime(e.detail, res => {
            //     // const originData = e.detail;
            //     // this.emit({ ...originData, ...res });
            // });
        }
    },

    emit(item) {
        const pages = getCurrentPages();
        const curPage = pages[pages.length - 1];
        getApp().globalData.pendingEvent = {
            updateData: {
                eventEmitter: curPage.route,
                data: item,
            },
        };
    },

    updateListItem(item) {
        const { template, list, preRoute } = this.data;
        if (template === 5) {
            for (let i = 0; i < list.length; i++) {
                const findedItemIndex = list[i].findIndex(item => item.goods_id === item.goods_id);
                if (findedItemIndex > -1) {
                    list[i][findedItemIndex] = item;
                    this.setData({
                        list: list.slice(0),
                    });
                    break;
                }
            }
        } else {
            if (preRoute === 'pages/goods_detail/index') {
                this.setData({
                    goods: item,
                });
            } else {
                const findedItemIndex = list.findIndex(item => item.goods_id === item.goods_id);
                if (findedItemIndex > -1) {
                    list[findedItemIndex] = item;
                    this.setData({
                        list: list.slice(0),
                    });
                }
            }
        }
    },

    onShareAppMessage(res) {
        const bury_config = app.globalData.bury_config;
        let {
            shop,
            list,
            goods,
            share,
            $title,
        } = this.data;
        let path = '';
        let title = '';
        let imageUrl = "";
        let share_content = '预览控件页';
        let sharedata = wx.getStorageSync('share_index');
        let shareIndex;
        let listidx;
        if (sharedata && sharedata != "") {
            shareIndex = sharedata.index;
            listidx = sharedata.listidx;
            console.log("shareIndex", shareIndex);
        }

        let imgsSrc = [];
        if (!goods) {
            goods = listidx > -1 ? list[listidx][shareIndex] : list[shareIndex];
        }
        const {
            shop_id,
            goods_id,
            share_shop_id,
            share_goods_id,
            themeType
        } = goods;
        imgsSrc = goods.imgsSrc;
        share_content = bury.shareContentOfType(themeType);
        title = util.getTextTitle(goods.title);
        path = `pages/goods_detail/index?goods_id=${share_goods_id || goods_id}&shop_id=${share_shop_id || shop_id}&is_icon=${true}`;

        if (sharedata && sharedata != "") {
            sharedata.listidx = -1;
            sharedata.index = -1;
            wx.setStorageSync('share_index', sharedata);
        }
        // bury.pageShare(bury_config, this.route);
        const obj = {
            route: 'pages/browser/index',
            $title: '预览商品页',
            share_method: '微信小程序',
            $screen_name: 'browser',
            share_content,
        };
        bury.share(bury_config, obj);

        const { tempFilePath = '', goods_id: storageGoodsId = '' } = wx.getStorageSync('share_goods_canvas_for_browser') || {};
        if (storageGoodsId && goods_id === storageGoodsId) {
            imageUrl = tempFilePath;
        } else {
            imageUrl = imgsSrc[0];
        }
        return {
            title: title,
            path: path,
            imageUrl: imageUrl,
            success: function (res) {
                // 转发成功
            },
            fail: function (res) {
                // 转发失败
            }
        };
    },
}));
