// pages/home/index.js
const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const app = getApp();

Page({
    /**
     * 页面的初始数据
     */
    data: {
        fansList: []
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {

        this.fetchFansData();
    },

    async fetchFansData() {
        let fansUrl = `/album/get_album_list.jsp?act=get_new_fans&search_value=&page_index=1`;
        let param = {};
        wx.showLoading({ title: '加载中...' });
        let res = await util.fetch(fansUrl, param);
        wx.hideLoading();
        console.log('fansUrl, res: ', res);

        const { errcode, errmsg, result } = res.data;
        if (errcode == 0) {
            const { count, list } = result;
            this.setData({ fansList: list });
        } else {
            wx.showToast({ title: errmsg });
        }

        // let userInfoUrl = `/account/user_info_operation.jsp?act=get_user_info`;
        // res = await util.fetch(userInfoUrl, param);
        // console.log('userInfoUrl, res: ', res);
    },

    async acceptReq(index) {
        const { fansList } = this.data;
        let url = `/album/album_operation.jsp?act=accept&shop_id=${fansList[index].shop_id}`;
        let param = {};
        wx.showLoading({ title: '操作中...', mask: true });
        let res = await util.fetch(url, param);
        wx.hideLoading();
        console.log('acceptReq, res: ', res);

        const { errcode, errmsg } = res.data;
        if (errcode == 0) {
            fansList[index].passed = true;
            this.setData({ fansList });
        } else {
            wx.showToast({ title: errmsg });
        }
    },

    onAgreeBtn(e) {
        const { index } = e.currentTarget.dataset;
        this.acceptReq(index);
    },

    onFansTap(e) {
        const { item } = e.currentTarget.dataset;
        console.log('onFansTap ', item);
        circleUtil.onShopItemTap(item.shop_id);
    },


    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
});
