

const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const getCommentListUrl = '/circle/circle_new_interface.jsp?act=getCommentsByShopId';
const updateApplyUrl = '/circle/circle_new_interface.jsp?act=updateApplyInfo';

Page({
    data: {
        commentList: []
    },

    onLoad(options) {
        console.info('onLoad', options);

        this.getCommentList();
    },

    onCommentItemTap(e) {
        const { index } = e.currentTarget.dataset;
        const { commentList } = this.data;
        console.log('onCommentItemTap...', commentList[index]);

        // circleUtil.onShopItemTap(commentList[index].shopId, false);

        const { shopId: shop_id, goodsId: goods_id } = commentList[index];
        wx.navigateTo({
            url: `/pages/goods_detail_circle/index?shop_id=${shop_id}&goods_id=${goods_id}`,
            success: function (res) {
                res.eventChannel.emit('acceptGoodsItemData', {});
            }
        });
    },

    async getCommentList() {
        wx.showLoading({ title: '加载中...' });
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url: getCommentListUrl });
        console.log('getCommentList: ', isOk, result);
        wx.hideLoading();

        if (isOk) {
            this.setData({
                commentList: result.comments
            });
        }
    },

    async acceptReq(index) {
        const { commentList } = this.data;
        const shop_id = commentList[index].shop_id;
        const param = { shop_id, status: 1 };
        wx.showLoading({ title: '操作中...', mask: true });
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url: updateApplyUrl, param });
        console.log('acceptReq: ', isOk, result);
        wx.hideLoading();

        if (isOk) {
            commentList[index].status = 1;
            this.setData({ commentList });
        }
    },

    onAcceptBtn(e) {
        const { index } = e.currentTarget.dataset;
        this.acceptReq(index);
    },


});
