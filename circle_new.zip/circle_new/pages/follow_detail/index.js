import {
    $tdSearchbar,
    $wuxToast,
    $tdTags,
    $ellipsis,
    $cartSheet
} from '../../components/wux';
import fourGrid from '../../utils/four-grid';
import nineGrid from '../../utils/nine-grid';
import logic from '../../utils/logic';
import launchAppError from '../../components/launch-app/launch-app';

import {
    shareAppMessageCanvas
} from "../../utils/canvas-composite-img";
const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const constant = require('../../utils/constant');
//const bury = require('../../utils/burypoint.js')
const app = getApp();
const waterfullId = 1; //瀑布流的id
let shareFriendsImgPath = "";
let shopInfo = null;
const categoryTitles = ['', '求购', '拼单', '二手', '招聘', '出租/转让'];
const getNewCommentCountUrl = `/circle/circle_new_interface.jsp?act=getNewCommentCount`;
const getCircleAlbumUrl = `/circle/circle_new_interface.jsp?act=single_album`;
const SWICTH_TEXTS = ['产品图册', '分类信息'];

function getData() {
    return {
        isIOS: util.isIOS(),

        col: 2,
        gap: 15,
        itemW: '48%', // 列宽
        addUrl: '/album/album_theme_operation.jsp?act=hold_theme',
        attentionUrl: '/album/att_album_mini.jsp?',
        tagsUrl: '/album/album_theme_tag_operation.jsp?act=get_tags_except&has_video=0&hide_uncategorized=true',
        // tagsUrl: 'https://www.wsxcme.com/commodity/tags?hasVideo=0&hideUnCategorized=true',
        // shopCartUrl: '/shoppingCart/shopping_card_index.jsp?act=check_shopping_cart',
        setTopUrl: '/album/album_operation.jsp?act=set_top',
        followUrl: '/album/att_album_mini.jsp',
        cancelFollowUrl: '/album/album_operation.jsp?act=del_album',
        loading: true, // 列表加载中
        loadingNoData: false, // 列表加载完成 & 无数据
        loadingEnd: false, // 列表加载完成 & 到底了
        cur_page: 1,
        filterText: '',
        filterImg: '',
        filterTag: [],
        listIndex: 0,
        list: [],
        showWechat: false,
        showTag: false,

        priceTypesObj: constant.priceTypesObj,
        showCart: false,
        openApp: false,
        videoPlaceholder: true,
        autoplay: true,
        navBgWhite: false,
        loadingNum: 0,
        showAddCart: false,
        // pxopen: true,
        selectShow: false,
        //0:瀑布流；1：商城模板；2：商城单图列表；3：微信朋友圈动态；4：微信朋友圈列表
        tagSelectSheetShow: false,
        windowWidth: 0,
        shop_id: '',

        showPreviewer: false,
        previewList: [],
        previewIndex: 0,
        vipConfrimShow: false,
        showPopoverMask: false,
        photoSearchCheck: 0, // 是否开启了搜图, 0：都开启，1：自己没开启，2：别人没开启
        isIpx: app.globalData.isIpx,
        hasBackRouter: true,
        isScroll: true,
        supportNavigationStyle: true,

        updateSticky: false,
        navList: [
            {
                title: '全部',
            },
            {
                title: categoryTitles[1],
            }, {
                title: categoryTitles[2],
            }, {
                title: categoryTitles[3],
            }, {
                title: categoryTitles[4],
            },
            {
                title: categoryTitles[5],
            }
        ],
        isMiniChecked: false,
    };
}

function getCol(width) {
    return width >= 600 ? 3 : 2;
}

Page(Object.assign({}, fourGrid, nineGrid, {
    data: {
        ...getData(),
        topDomHeight: 260,
        isMyAlbum: true,
        hasNewComments: false,
        actionStatus: false,
        cardInfo: {},

        //lt add 是否是商圈的个人发布
        isCirclePersonal: false,
        switchBtnText: SWICTH_TEXTS[0],
        switchBtnIcon: '/assets/images/album.png',
        marketBooth: '',
        booth: '',
        mediaInfoObj: [],
    },
    //circle
    currTabIndex: '0',

    onLoad(options) {

        // 判断是否支持自定义导航
        this.setData({
            supportNavigationStyle: util.supportNavigationStyle()
        });

        if (getCurrentPages().length <= 1) {
            this.setData({
                hasBackRouter: false
            });
        }
        this.localTemplateId = 0; //临时模板ID
        app.globalData.pageInfo = {
            $title: '相册',
            $screen_name: 'follow_detail'
        };
        const {
            globalData
        } = app;
        const {
            appInitOptions: {
                scene: entryScene
            } = {}
        } = globalData;
        console.log('entryScene: ', entryScene);
        if (entryScene == 1036 || entryScene == 1069) {
            this.data.openApp = true;
        } else {
            this.data.openApp = false;
        }
        const {
            isCircle = false,
            shop_id,
            wxid,
            listIndex = 0,
            filterText = ''
        } = options;
        let listNo = Number(listIndex);
        if (listNo < 4) {
            this.data.listIndex = Number(listIndex);
        }
        this.data.filterText = filterText;
        this.data.isCirclePersonal = isCircle;
        this.data.switchBtnText = isCircle ? SWICTH_TEXTS[0] : SWICTH_TEXTS[1];
        this.data.switchBtnIcon = isCircle ? '/assets/images/album.png' : '/assets/images/album_home_1.png';
        // console.log("isCircle: ", isCircle);
        this.setData(Object.assign({}, this.data));

        console.info('onLoad', options);
        this.shop_id = shop_id || '';
        this.wxid = wxid || '';

        // options 中的 scene 需要使用 decodeURIComponent 才能获取到生成二维码时传入的 scene
        let scene = options.scene && decodeURIComponent(options.scene);
        if (options.q) {
            const url = decodeURIComponent(options.q);
            scene = url.split('=')[1];
        }
        if (scene) {
            this.shop_id = scene;
        }
        this.list = [];
        this.listOrigin = []; // 用来获取正确的时间戳
        $ellipsis.init();
        this.$cartSheet = $cartSheet.init({
            onAddCart() {
                this.setData({
                    showCart: true
                });
            }
        });

        //...
        this.initTdSearchBar();

        this.tags = $tdTags.init({
            onClear: () => {
                this.clearTags();
            },
            onOk: (ev) => {
                this.okTags(ev);
            },
            onTapGroup: (groupId) => {
                this.onTapGroup(groupId);
            },
        });

        this.getItemW();

        this.setData({
            shop_id: this.shop_id
        });

        //...
        if (app.offline()) {
            circleUtil.showLoginModal();
            return;
        }

        wx.showLoading({
            mask: false,
            title: '加载中...',
        });
        app.getUserInfo(userInfo => {
            // setInterval(() => {
            //     this.insertVisitMsg(shop_id);
            // }, 20000);
            this.updateVisitRecord(shop_id);

            this.fetchTagsAndGroups();

            this.fetchCircleShopInfo();

        }, () => {
            wx.hideLoading();
        }, this.shop_id);

    },

    // async insertVisitMsg(shop_id) {
    //     const msg_type = "visit";
    //     const url = `/circle/circle_new_interface.jsp?act=insertMsg&shop_id=${shop_id}&msg_type=${msg_type}`;
    //     const { isOk, result = {} } = await circleUtil.fetchNetData({ url });

    //     if (isOk) {

    //     }
    // },

    async updateVisitRecord(shop_id) {
        const msg_type = "visit";
        const url = `/circle/circle_new_interface.jsp?act=updateVisitRecord&shop_id=${shop_id}&action_type=${msg_type}`;
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url });

        if (isOk) {

        }
    },

    async getMarketBooth() {
        const { building, booth, isBusiness, floor } = this.data;

        if (!isBusiness) return '';

        const obj = await circleUtil.getCircleConfigData();
        const { markets = [], buildings = [] } = obj;

        console.log("onAvatarTap 111", markets, building, buildings);
        // const { name } = circleUtil.getMarketById(markets, building); //circleInfo.LouDong[parseInt(building)];
        const { label, floors } = circleUtil.getBuildingById(buildings, building);

        // const addr = market.name + '-' + floor.split('|')[1] + '-' + booth;
        // const addr = name + '-' + booth;
        const addr = label + ' ' + floors[floor] + ' ' + booth;



        return addr;
    },

    getOtherMediaInfo() {
        const { list } = this.data;
        const ret = [];
        const maxItemCount = 3; // 1???

        for (let index = 0; index < list.length && index < maxItemCount; index++) {
            const element = list[index];

            for (let j = 0; j < element.imgs.length; j++) {
                if (element.videoURL && j == 0) {
                    ret.push({
                        src: element.imgs[j],
                        type: 'video',
                        video: element.videoURL
                    });
                    continue;
                }
                ret.push({
                    src: element.imgs[j],
                    type: 'image'
                });
            }
            if (ret.length >= 9) break;
        }
        return ret;
    },

    async onAvatarTap() {
        const { shop, isBusiness, building, floor, booth, tagNames, mediaInfoObj } = this.data;
        console.log("onAvatarTap mediaInfoObj: ", mediaInfoObj);

        // if (!isBusiness) return;

        const addr = await this.getMarketBooth(); //name + '-' + booth;

        console.log("onAvatarTap 333");
        this.setData({
            actionStatus: true,
            cardInfo: {
                name: shop.shop_name,
                avatar: shop.user_icon,
                addr,
                wechat_id: shop.wechat_id,
                wechat_qrcode: shop.wechat_qrcode, //'http://xcimg.szwego.com/circle_images/qrcode/wechatqrcode111.jpg',//
                phone: shop.phone_number,
                desc: shop.shop_desc,
                mediaInfoObj: mediaInfoObj.length > 0 ? mediaInfoObj : this.getOtherMediaInfo(),
                tagNames
            }
        });
        this.data.actionStatus = false;
    },

    /**
     * 分类信息和产品图册来回切换
     */
    onSwitchPageTap() {
        const { isCirclePersonal } = this.data;

        this.localTemplateId = 0;
        if (isCirclePersonal) {
            this.setData({
                isCirclePersonal: false,
                switchBtnText: SWICTH_TEXTS[1],
                switchBtnIcon: '/assets/images/album_home_1.png'
            });
        } else {
            this.setData({
                isCirclePersonal: true,
                switchBtnText: SWICTH_TEXTS[0],
                switchBtnIcon: '/assets/images/album.png'
            });
        }
        this.clearTags();
    },

    initTdSearchBar() {
        $tdSearchbar.init({
            style: 'border: none',
            image: !util.getIsGuest() && !this.data.isCirclePersonal,
            inputVal: this.data.filterText,
            onAddImg(upload) {
                const {
                    login_user: { // 登录用户
                        vip_status, // vip状态
                        photo_search_check: login_photo_search_check, // Boolean：搜图开关
                    } = {},
                    shop: { photo_search_check } = {}, // Boolean：当前店铺是否开启搜图开关
                    isMyAlbum,
                } = this.page.data;

                // vip_status: 0为非会员 1会员 2试用期 3会员过期
                switch (vip_status) {
                    case 0:
                    case 3:
                        this.setData({
                            vipConfrimShow: true
                        });
                        break;

                    case 1:
                        if (login_photo_search_check && photo_search_check) {
                            upload();
                        } else {
                            this.setData({
                                vipConfrimShow: true
                            });
                        }
                        break;

                    case 2:
                        if (!isMyAlbum && !photo_search_check) {
                            this.setData({
                                vipConfrimShow: true
                            });
                        } else {
                            upload();
                        }
                        break;

                    default:
                        break;
                }
            },
            searchHandler(text, img) {
                const {
                    listIndex,
                    filterTag,
                    isMyAlbum,
                    supportNavigationStyle,
                    photoSearchCheck
                } = this.page.data;

                console.info(`text: ${text}`, `img: ${img}`);
                console.info(this);

                // 搜索时停止递归renderList
                console.log("searchHandler set stopRenderList true");
                this.page.stopRenderList = true;
                this.page.list = [];
                this.setData(Object.assign({}, getData(), {
                    listIndex,
                    filterText: text,
                    filterImg: img,
                    filterTag,
                    isMyAlbum,
                    supportNavigationStyle,
                    photoSearchCheck
                }), () => {
                    // console.log("searchHandler set stopRenderList false");
                    // this.page.stopRenderList = false;
                    this.setData({
                        canvasId: null,
                    });
                    this.page.fetchData('', data => {
                        if (data.goods_list) {
                            this.page.initShareAppMessageToCanvas(data);
                        }
                    });
                });
            }
        });
    },

    /***兼容各个手机样式高度显示一样 */
    compatibleStyle() {
        this.setData({
            topDomHeight: 40 + this.data.statusBarHeight + 44 + 127 + 20
        });
    },

    onUnload() {
        shareFriendsImgPath = "";
    },
    onPageTap() {
        app.setGlobalData({
            showPopoverMask: false
        });
    },
    hiddenPopover() {
        this.setData({
            showPopoverMask: false
        });
        app.setGlobalData({
            showPopoverMask: false,
        });
    },
    goVipPage(e) {
        const {
            type
        } = e.target.dataset;
        if (type) {
            wx.navigateTo({
                url: '../vip/index', //vip
            });
        }

        this.closeVipConfrim();
    },
    closeVipConfrim() {
        this.setData({
            vipConfrimShow: false
        });
    },
    updateVip() {
        const { login_user = {} } = this.data;
        const { vip_status, photo_search_check } = app.globalData;

        if (typeof vip_status === 'undefined') return;
        if (typeof photo_search_check === 'undefined') return;

        this.setData({
            login_user: {
                ...login_user,
                vip_status,
                photo_search_check,
            },
        });
    },

    async checkNewComments() {
        const { isMyAlbum, isCirclePersonal } = this.data;
        if (!isMyAlbum || !isCirclePersonal) {
            return;
        }
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url: getNewCommentCountUrl });
        console.log('checkNewComments: ', isOk, result);

        if (isOk) {
            this.setData({
                hasNewComments: result > 0
            });
        }
    },


    onShow(e) {

        const isMiniChecked = circleUtil.isMiniChecked();
        this.setData({ isMiniChecked });

        console.log('onShow---------------->', this.data.isMiniChecked);

        this.updateVip();
        this.checkNewComments();
        // bury.pageShow(bury_config, this.route);
        const { filterImg, filterText } = this.data;
        const list = logic.updateGoodsFromEdit(this);
        if (!filterImg && !filterText && list) {
            this.setData({
                list,
            });
        }

        wx.getSystemInfo({
            success: res => {
                console.log("onShow:" + res.windowHeight);
                this.setData({
                    windowHeight: res.windowHeight,
                    windowWidth: res.windowWidth,
                    statusBarHeight: res.statusBarHeight,
                }, () => {
                    this.compatibleStyle();
                });
            }
        });
        // if (app.offline()) return;
        // const {
        //     shopCartUrl
        // } = this.data;
        // const url = shopCartUrl;
        // util.fetch(url)
        //     .then(res => {
        //         const {
        //             errcode,
        //             result
        //         } = res.data;
        //         const {
        //             showCart
        //         } = result;
        //         if (errcode == 0) {
        //             this.setData({
        //                 showCart
        //             });
        //         }
        //     }, res => {

        //     });
    },
    initShareAppMessageToCanvas(data) {
        return; //暂时屏蔽
        // 前6个商品，低于6个大于4个，拼4个图。大于2个低于4个，拼 2个图。如果少于2个，则默认按老的分享方式。
        function queryGoods(goodsList = []) {
            let goodsData = [];
            if (goodsList && goodsList instanceof Array) {
                goodsList.some((item, index) => {
                    if (goodsData.length < 6) {
                        if (item.themeType == 1 && item.imgs && item.imgs.length > 0) {
                            goodsData.push(item);
                        } else if (item.themeType == 4) {
                            if (item.imgs && item.imgs.length > 0) {
                                goodsData.push(item);
                            } else {
                                if (item.videoThumbImg && item.videoThumbImg != "") {
                                    goodsData.push(item);
                                }
                            }
                        } else {
                            if (item.imgs && item.imgs.length > 0) {
                                goodsData.push(item);
                            }
                        }
                    } else {
                        return true;
                    }
                });
            }
            // console.log("goodsData",goodsData)
            return goodsData;
        }
        let goodsData = queryGoods(data.goods_list);
        if (goodsData.length === 5) {
            goodsData.splice(4, 1);
        } else if (goodsData.length === 3) {
            goodsData.splice(2, 1);
        }
        if (goodsData.length >= 2) {
            // 每次都重新生成canvas-ID，不然画图失败
            let tempKey = Date.now();
            this.setData({
                canvasW: 1,
                canvasH: 1,
                canvasId: "J_canvas_share" + tempKey,
                clipCanvas: {
                    key: "clipCanvas",
                    idName: "clipCanvasShare" + tempKey,
                    width: 200,
                    height: 200,
                    value: []
                },
            }, () => {
                shareAppMessageCanvas({
                    goods_list: goodsData, ...shopInfo,
                    component: this,
                    canvasId: this.data.canvasId,
                    from: "menu"
                }).then((res) => {
                    console.log("后台画图完成", res);
                    shareFriendsImgPath = res;
                });
            });

        }

    },
    getItemW() {
        const {
            template,
            gap
        } = this.data;

        // if (template != 1) return;

        const {
            windowWidth
        } = wx.getSystemInfoSync();
        const col = getCol(windowWidth);
        const gapW = (col + 1) * gap;
        const itemW = `${((windowWidth - gapW) / col) | 0}px`;
        this.itemW = itemW;
        this.col = col;
        this.setData({
            col,
            itemW
        });
    },

    launchAppError,

    navTap(ev) {
        const {
            index
        } = ev.target.dataset;
        const {
            listIndex
        } = this.data;

        if (index == listIndex) {
            return false;
        }
        console.info('nav', index);
        this.refreshData(index);
    },

    /**重新获取列表数据 */
    refreshData(index) {
        const {
            loading,
            listIndex,
            filterText,
            filterImg,
            filterTag,
            isMyAlbum,
            photoSearchCheck,
            supportNavigationStyle,
            hasBackRouter
        } = this.data;
        this.list = [];
        this.setData(Object.assign({}, getData(), {
            listIndex: index,
            filterText,
            isMyAlbum,
            photoSearchCheck,
            supportNavigationStyle,
            filterImg,
            filterTag,
            list: [],
            hasBackRouter
        }));
        this.setData({
            loading: false
        });
        wx.showLoading({
            mask: true,
            title: '加载中...',
        });
        this.setData({
            canvasId: null,
        });
        this.fetchData('init', (data) => {
            wx.hideLoading();
            if (data.goods_list) {
                this.initShareAppMessageToCanvas(data);
            }
        });
    },
    onShareAppMessage(res) {
        console.log('onShareAppMessage...', res);
        const bury_config = app.globalData.bury_config;
        const {
            shop,
            list,
            share,
            $title
        } = this.data;
        let path = '';
        let title = '';
        let imageUrl = "";

        // console.log(`index: ${this.shareIndex} list: ${this.listidx}`);
        let share_content = '小程序个人主页';

        let sharedata = wx.getStorageSync('share_index');
        let shareIndex;
        let listidx;
        if (sharedata && sharedata != "") {
            shareIndex = sharedata.index;
            listidx = sharedata.listidx;
            console.log("shareIndex", shareIndex);
        }

        let imgsSrc = [];
        let goods_id = '';
        if (shareIndex > -1) {
            const goods = listidx > -1 ? list[listidx][shareIndex] : list[shareIndex];
            const {
                shop_id,
                share_shop_id,
                share_goods_id,
                themeType
            } = goods;
            imgsSrc = goods.imgsSrc;
            goods_id = goods.goods_id;
            //share_content = bury.shareContentOfType(themeType);
            title = util.getTextTitle(goods.title);
            path = `pages/goods_detail/index?goods_id=${share_goods_id || goods_id}&shop_id=${share_shop_id || shop_id}&is_icon=${true}`;
        } else {
            title = share.miniappTitle || '';
            path = `pages/follow_detail/index?shop_id=${shop.shop_id}`;
        }

        if (sharedata && sharedata != "") {
            sharedata.listidx = -1;
            sharedata.index = -1;
            wx.setStorageSync('share_index', sharedata);
        }


        // bury.pageShare(bury_config, this.route);
        const obj = {
            route: this.route,
            $title: '相册动态',
            share_method: '微信小程序',
            $screen_name: 'follw_detail',
            share_content,
        };
        //bury.share(bury_config, obj);

        if (res.from === 'button') {
            // 来自页面内转发按钮
            const { share_goods_id: id = '', tempFilePath = '' } = wx.getStorageSync('share_goods_canvas');
            imageUrl = (id.length && id == goods_id) ? tempFilePath : imgsSrc[0];
        } else {
            imageUrl = shareFriendsImgPath;
        }
        return {
            title: title,
            path: path,
            imageUrl: imageUrl,
            success: function (res) {
                // 转发成功
            },
            fail: function (res) {
                // 转发失败
            }
        };
    },

    getTimeList(list = []) {
        return list.map(item => item.time_stamp)
            .filter(item => item);
    },

    getTimestamp(type) {
        const {
            filterText,
            template,
            listIndex
        } = this.data;
        const timeList = this.getTimeList(this.listOrigin);
        let tList = [];
        if (listIndex == 0) {
            if (type == 'top' || !!filterText) {
                tList = timeList;
            } else {
                tList = this.listOrigin.filter(item => item.isTop !== 1);
                tList = this.getTimeList(tList);
            }
        } else {
            tList = timeList;
        }
        if (!!filterText) {
            const len = tList.length;
            if (len > 0) {
                const first = tList[0];
                const last = tList[len - 1];

                first < 0 && last > 0 &&
                    (tList = tList.filter(item => item > 0));
            }
        }
        tList.sort((a, b) => b - a);

        const len = tList.length;
        const max = tList[0] || '';
        const min = tList[len - 1] || 1; // 全部为置顶时，list为空[]，min=1停止加载

        return {
            top: max,
            bottom: min,
        };
    },

    getSearchDate(type) {
        console.log('getSearchDate, type: ', type);
        if (type == 'bottom') {
            const d = new Date(Date.now() - 24 * 3600000 * 7);
            const yy = d.getFullYear();
            const mm = (d.getMonth() + 1) + '';
            const dd = (d.getDate()) + '';
            return `start_date=${yy}-${mm.padStart(2, '0')}-${dd.padStart(2, '0')}`;
            // return 'start_date=2021-03-11&end_date=2021-03-12';
        } else {
            return '';
        }
    },

    getUrl(type) {
        const {
            listIndex,
            cur_page,
            filterText,
            filterImg,
            filterTag,
            isCirclePersonal
        } = this.data;
        console.log('isCirclePersonal: ', isCirclePersonal);
        const baseUrl = [`/album/get_album_themes_list.jsp?act=single_album&${this.getSearchDate(type)}`, getCircleAlbumUrl];

        let getUrl = [];
        let url = '';
        if (!isCirclePersonal) {
            getUrl = [
                `${baseUrl[0]}`,
                `${baseUrl[0]}&query_type=new`,
                `${baseUrl[0]}&query_type=video`,
                `${baseUrl[0]}&query_type=img`,
            ];
            url = `${getUrl[listIndex]}&shop_id=${this.shop_id}&search_img=${filterImg}&tag=${JSON.stringify(filterTag)}&page_index=${cur_page}`;
        } else {
            getUrl = [
                `${baseUrl[1]}`
            ];
            url = `${getUrl[0]}&shop_id=${this.shop_id}&category=${this.currTabIndex}`;

            // if (this.wxid){
            //     url = `/circle/circle_new_interface.jsp?act=getWxMomentGoods&wxid=cdd521188`;
            // }
        }

        const {
            top,
            bottom
        } = this.getTimestamp(type);

        switch (type) {
            case 'top':
                url = `${url}&slip_type=0&time_stamp=${top}`;
                break;

            case 'bottom':
                url = `${url}&slip_type=1&time_stamp=${bottom}`;
                break;
        }
        console.log('----------------url: ', url);
        return url;
    },


    async fetchCircleShopInfo() {
        const url = `${getCircleAlbumUrl}&shop_id=${this.shop_id}&exclude_list=1`;
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url });
        console.log('fetchCircleShopInfo: ', isOk, result);

        if (isOk) {
            const {
                booth = '',
                building,
                floor,
                leimu,
                leixing,
                tagNames,
                shop,
                isMyAlbum,
                isBusiness,
                is_attention,
                mediaInfo,
                plusAppId
            } = result;
            const mediaInfoObj = mediaInfo ? JSON.parse(mediaInfo) : [];
            this.setData({
                booth,
                building,
                floor,
                leimu,
                leixing,
                tagNames,
                shop,
                is_attention,
                isBusiness,
                mediaInfoObj,
                plusAppId
            }, async () => {
                const marketBooth = await this.getMarketBooth();
                this.setData({ marketBooth });
            });


            //...自动关注
            if (!isMyAlbum && !is_attention) {
                this.onSetFollow({
                    currentTarget: {
                        dataset: {
                            shop,
                            isattention: is_attention
                        }
                    }
                });
                return;
            }

            this.fetchData('init', (data) => {
                const { shop_name: title } = this.data.shop || {};

                // wx.hideLoading();
                title && wx.setNavigationBarTitle({
                    title
                });

                // this.list.length < constant.minPageSize && this.onReachBottom();

                this.setData({
                    isMyAlbum: data.isMyAlbum,
                    photoSearchCheck: data.photo_search_check
                });
                shopInfo = data.shop;
                if (data.goods_list) {
                    this.initShareAppMessageToCanvas(data);
                }
                this.setDialogInfo();

                //...
                // this.insertVisitMsg(shop_id);
            });
        }
    },



    fetchData(type, callback) {
        const bury_config = app.globalData.bury_config;
        const {
            filterText = '', filterImg = '', isCirclePersonal
        } = this.data;
        const isSearch = !!(filterText || filterImg);
        const searchType = isSearch && filterText ? '文字搜索' : '图搜';
        const url = this.getUrl(type);
        const {
            top = ''
        } = this.getTimestamp(type);
        // 初始化首次加载不需要显示loading
        if (type != "init") {
            this.setData({
                loading: true
            });
        }
        this.setData({
            loadingNum: 0
        });
        let param = {
            search_value: this.data.filterText
        };
        util.fetch(url, param)
            .then(res => {
                const {
                    errcode,
                    result,
                    total_page,
                    errmsg
                } = res.data;

                console.log('res.data: ', res.data);
                let obj = {};
                const isSuccess = errcode == 0;
                wx.hideLoading();
                if (errcode == 0) {
                    result.template = 2; //4;  //-----------------------先默认设为朋友圈动态模板
                    if (isCirclePersonal) {
                        result.template = 4;  //-----------------------
                    }


                    const {
                        goods_list = [], shop, ...others
                    } = result;
                    try {
                        const {
                            is_vip
                        } = shop;
                        if (shop &&
                            shop.hasOwnProperty('is_vip') &&
                            app.globalData.userInfo.shop_id === this.shop_id
                        ) {
                            app.globalData.is_vip = is_vip;
                            // bury.registerProperties({
                            //     is_vip
                            // });
                        }
                    } catch (e) {
                        console.log('e: ', e);
                    }
                    const {
                        listIndex
                    } = this.data;

                    obj = {
                        ...this.data,
                        ...others
                    };
                    // console.info('服务器返回的数据---》', goods_list);
                    // console.info('备份的数据---》', this.list);
                    if (type == 'top') {
                        // 去重
                        this.list = util.dedupArr([...goods_list, ...this.list], 'goods_id');
                        this.listOrigin = this.list;
                        // console.info('下拉去重后的数据---》', this.list);
                    } else {
                        if (type === '') {
                            this.list = [];
                        }
                        // this.list = [...this.list, ...goods_list];
                        this.listOrigin = [...this.list, ...goods_list];
                        this.list = util.dedupArr([...this.list, ...goods_list], 'goods_id');
                        // console.log('正常处理的数据---》', this.list);
                        // if (!!filterText) {
                        //     if (cur_page >= total_page) {
                        //         obj.loadingEnd = true;
                        //     } else {
                        //         obj.cur_page = cur_page + 1;
                        //     }
                        // } else {
                        // 到底了
                        goods_list.length <= 0 && (obj.loadingEnd = true);
                        // }
                    }

                    //...
                    // if (!isCirclePersonal) {
                    //     obj.loadingEnd = true;
                    // }

                    //lt add for circle
                    this.list = this.list.map(item => ({
                        categoryTitle: categoryTitles[item.category],
                        ...item
                    }));

                    //tab为全部时初始化临时模板ID
                    if (this.localTemplateId == 0 && listIndex == 0) {
                        this.localTemplateId = obj.template;
                    }

                    console.log('this.localTemplateId: ', this.localTemplateId);

                    //初始化各tab使用模板
                    obj.template = this.initTabTemplate(listIndex, this.localTemplateId);

                    //设置当前显示模板
                    if (listIndex === 0) {
                        obj.curTempObj = this.getTemplateById(obj.template, obj.template_list);
                    }
                    //----------------------------
                    //保存关注度及商品到缓存，用于后面进行商品分享
                    if (obj.shop) {
                        let { follow_num, new_goods, user_icon, shop_name } = obj.shop;
                        let shareShopData = {
                            follow_num,
                            new_goods,
                            user_icon,
                            shop_name,
                        };
                        console.log(shareShopData);
                        wx.setStorage({
                            key: 'share_shop_data',
                            data: shareShopData,
                        });
                    }


                    obj.guest = util.getIsGuest();

                    // 分组

                    if (obj.template != waterfullId) {
                        obj.list = logic.getGrouplist(util.dedupArr(this.list, 'goods_id'), obj.template, this, true);
                        obj.loading = false;
                    } else {

                        if (this.stopRenderList) {
                            console.log('设置空-----》');
                            obj.list = [];
                        }
                    }

                    // 无数据
                    if (this.list.length <= 0) {
                        obj.loadingNoData = true;
                    } else {
                        obj.loadingNoData = false;
                    }

                    console.info('这次要设置的数据---》', obj.list);

                    obj.itemW = this.itemW ? this.itemW : this.data.itemW;
                    obj.col = this.col ? this.col : this.data.col;


                    //设置tab显示
                    // navs: [{ label: '首页', idx: 0 }, { label: '上新', idx: 1 }, { label: '小视频', idx: 2 }, { label: '图集', idx: 3 }]

                    if (obj.hasVideo === undefined) {
                        obj.hasVideo = this.data.hasVideo || false;
                    }



                    if (obj.hasVideo) {
                        obj.navs = [{
                            label: '全部',
                            idx: 0
                        }, {
                            label: '上新',
                            idx: 1
                        },
                            // {
                            //     label: '小视频',
                            //     idx: 2
                            // },
                            // {
                            //     label: '图集',
                            //     idx: 3
                            // }
                        ];
                    } else {
                        obj.navs = [{
                            label: '全部',
                            idx: 0
                        }, {
                            label: '上新',
                            idx: 1
                        },
                            // {
                            //     label: '图集',
                            //     idx: 3
                            // }
                        ];
                    }

                    //处理
                    // console.log('111111111111----->', obj);
                    this.setData(obj, () => {
                        let goodsList = goods_list;
                        if (obj.template === waterfullId) {
                            console.log("renderList first");
                            this.stopRenderList = false;
                            //过滤数据
                            goodsList = logic.filterData(goodsList, waterfullId);

                            //过滤跟现有数据相同的
                            let that = this;

                            console.log('新数据----->', that.data.list);
                            console.log('老数据----->', that.data.list);
                            goodsList = goodsList.filter(item => {
                                let found = false;
                                for (let i = 0; i < that.data.list.length; i++) {
                                    if (item.goods_id == that.data.list[i].goods_id) {
                                        found = true;
                                    }
                                }
                                return found ? false : true;
                            });
                            //如果是top,则刷新所有数据
                            if (type == 'top' && goodsList.length > 0) {
                                goodsList = [...goodsList, ...this.data.list];
                                // console.log('刷新所有数据:')
                                //console.log(goodsList);
                                this.setData({
                                    list: []
                                }, () => {
                                    this.renderList(goodsList, 0, () => {
                                        if (this.data.template != waterfullId) {
                                            return;
                                        }
                                        let loadingNumTemp = this.data.loadingNum;
                                        this.setData({
                                            loading: false,
                                            loadingNum: 0
                                        }, () => {
                                            if (loadingNumTemp > 0) {
                                                // this.onReachBottom()
                                            }
                                        });

                                    });
                                });
                            } else {
                                this.renderList(goodsList, 0, () => {
                                    if (this.data.template != waterfullId) {
                                        return;
                                    }
                                    let loadingNumTemp = this.data.loadingNum;
                                    this.setData({
                                        loading: false,
                                        loadingNum: 0
                                    }, () => {
                                        if (loadingNumTemp > 0) {
                                            type != 'top' && this.onReachBottom();
                                        }
                                    });

                                });
                            }

                        } else {
                            //处理过滤商品后无法加载下一页的问题
                            goodsList = logic.filterData(goodsList, waterfullId);
                        }


                        // console.log('lin---------------->goodsList.len:'+goodsList.length);
                        this.checkNewComments();

                        //暂时屏蔽这里的加载
                        // res.statusCode == 200 && (this.list.length < constant.minPageSize || obj.template == 100 && this.list.length < 24 || goodsList.length <= 2) && (type != 'top') && this.onReachBottom();


                    });
                    typeof callback == 'function' && callback(result);

                } else {

                    wx.showModal({
                        title: '温馨提示',
                        content: errmsg || "服务器错误",
                        showCancel: false,
                        success(res) {
                            if (res.confirm) {
                                console.log('errcode: ', errcode);
                                wx.hideLoading();
                                if (errcode == 9) {
                                    wx.redirectTo({
                                        url: '/pages/login/index'
                                    });
                                } else if (errcode == 1016) {

                                } else {
                                    wx.navigateBack();
                                }
                            }
                        }
                    });

                    this.setData({
                        loading: false
                    });
                }

                // 清除失效token，触发重新获取
                // app.clearToken(res.data, () => {
                //     this.onPullDownRefresh();
                // });

                if (isSearch && !top) {
                    const obj = {
                        route: this.route,
                        $title: '个人主页',
                        search_method: searchType,
                        key_word: filterText ? filterText : filterImg,
                        has_result: isSuccess,
                    };
                    // bury.search(bury_config, obj)
                }

            }, () => {
                this.setData({
                    loading: false
                });
                typeof callback == 'function' && callback();

                if (isSearch && !top) {
                    const obj = {
                        route: this.route,
                        $title: '个人主页',
                        search_method: searchType,
                        key_word: filterText ? filterText : filterImg,
                        has_result: false,
                    };
                    // bury.search(bury_config, obj)
                }

            });
    },

    /**
     * 初始化各个tab使用的模板
     * @param {tab} listindex
     * @param {显示模板id} template
     */
    initTabTemplate(listindex, template) {
        let _template = template;
        switch (listindex) {
            case 0:
                break;
            case 1:
                _template = 5;
                break;
            case 2:
                _template = 4;
                break;
            case 3:
                _template = 100;
                break;
        }
        console.log("_template----------------" + _template);
        return _template;
    },

    renderList(goodsList, i, finish) {
        let {
            col,
            list,
            template
        } = this.data;

        const key = `list[${list.length}]`;
        if (template != waterfullId) {
            return;
        }
        // console.log(key)
        if (this.stopRenderList && i != 0) {
            console.log("renderList 1111");
            this.setData({
                list: []
            });
            return;
        } else {
            this.stopRenderList = false;
        }

        if (goodsList.length > i) {
            if (i < col) {
                const item = {
                    ...goodsList[i],
                    col: i,
                };
                console.log("renderList 3333--->" + i, goodsList[i]);
                this.setData({
                    [key]: item,
                }, () => {
                    this.renderList(goodsList, ++i, finish);
                });
            } else {
                if (this.data.listIndex != 0) {
                    return;
                }
                // console.log("renderList aaaaaaaaaaaaaa->"+i)
                this.selectComponent('#waterfall').getClientRect(res => {
                    //   console.log("boundingClientRect------->")
                    //   console.log(res)
                    const heights = res.map(item => item.height);
                    const min = Math.min(...heights);
                    const idx = heights.indexOf(min);
                    const item = {
                        ...goodsList[i],
                        col: idx,
                    };
                    //   console.log(item)
                    if (this.data.template != waterfullId || this.data.listIndex != 0) {
                        return;
                    }
                    this.setData({
                        [key]: item,
                    }, () => {
                        this.renderList(goodsList, ++i, finish);
                    });
                });

            }
        } else {
            console.log("renderList 555");

            finish();
        }
    },

    fetchTagsAndGroups(cb) {
        const {
            tagsUrl: url
        } = this.data;
        const params = {
            shop_id: this.shop_id,
        };

        util.fetch(url, params)
            .then(res => {
                const {
                    errcode,
                    result
                } = res.data;

                if (errcode == 0) {
                    const {
                        all_tags = [], groups = []
                    } = result;

                    this.setData({
                        all_tags,
                        groups,
                    });
                }
                typeof cb === "function" && cb();
            });
    },

    getGroups(data) {
        const {
            all_tags = [], groups = []
        } = data;

        return groups.map(group => {
            let {
                tags = []
            } = group;
            tags = tags.map(tagId => all_tags.filter(items => tagId == items.tagId)[0]);
            tags = tags.filter(item => !!item);
            return {
                ...group,
                tags
            };
        });
    },



    getPostItem() {
        const post = this.shop_id ? [] : [{
            type: 'post',
            time_stamp: Date.now(),
            onPost: 'onPost'
        }];

        return post;
    },

    onPost(ev) {
        console.info('发布图文', ev);
    },



    onReachBottom(lastTimeStamp) {
        const {
            loading,
            loadingNoData,
            loadingEnd
        } = this.data;

        if (loading) {
            //处理IOS下滑到最后无法加载的问题
            this.setData({
                loadingNum: this.data.loadingNum + 1
            });
        }
        if (loading || loadingNoData || loadingEnd) {
            return false;
        }

        console.info('onReachBottom');
        this.fetchData('bottom');
    },

    onPullDownRefresh() {
        wx.hideLoading();
        const {
            loading,
            filterText,
            template
        } = this.data;

        // if (loading || !!filterText) {
        if (loading) {
            return false;
        }
        this.setData({
            canvasId: null,
        });
        console.info('onPullDownRefresh');
        if (template != waterfullId) {
            this.fetchData('top', (data) => {
                console.log('stopPullDownRefresh');
                wx.stopPullDownRefresh();

                this.setDialogInfo();
                if (data.goods_list) {
                    this.initShareAppMessageToCanvas(data);
                }
            });
        } else {
            wx.stopPullDownRefresh();
        }

    },

    tapAttention(ev) {
        const {
            attentionUrl: url
        } = this.data;

        console.info('attention');
        wx.showLoading({
            mask: true,
            title: '加载中...',
        });
        let postData = {
            shop_id: this.shop_id
        };
        util.fetch(url, postData)
            .then(res => {
                const {
                    errcode
                } = res.data;

                // console.log(res);
                wx.hideLoading();
                if (errcode == 0) {
                    this.setData({
                        is_attention: true
                    });
                }
            }, () => {
                wx.hideLoading();
            });
    },

    tapContact(ev) {
        const bury_config = app.globalData.bury_config;
        // bury.profileBury('contact_ta', bury_config);

        wx.showActionSheet({
            itemList: ['微信', '电话'],
            success: res => {
                const {
                    tapIndex
                } = res;

                console.log(res, tapIndex, typeof tapIndex);
                switch (tapIndex) {
                    case 0:
                        this.tapWechat(ev);
                        break;

                    case 1:
                        this.tapCall(ev);
                        break;
                }
            },
            fail: res => {
                console.log(res);
            }
        });
    },

    tapWechat(ev) {
        const {
            wechat_id,
            wechat_icon,
            wechat_qrcode
        } = this.data.shop;

        if (1 || wechat_id || wechat_icon || wechat_qrcode) {
            this.setData({
                showWechat: true
            });
        } else {
            $wuxToast.show({
                type: 'text',
                text: '未设置微信号'
            });
        }
    },

    viewQrcode(ev) {
        const {
            src
        } = ev.target.dataset;

        console.log(src);
        wx.previewImage({
            current: src,
            urls: [src]
        });
    },

    copyWechat(ev) {
        const {
            wechat_id
        } = this.data.shop;

        this.copyTitle(wechat_id);
    },

    hideWechat(ev) {
        this.setData({
            showWechat: false
        });
    },

    tapCall(ev) {
        const {
            phone_number: phoneNumber
        } = this.data.shop;

        if (phoneNumber) {
            wx.makePhoneCall({
                phoneNumber, //: '18083020058',
                fail: res => {
                    const {
                        errMsg
                    } = res;

                    console.info(res);
                    !errMsg.match(/cancel/) &&
                        $wuxToast.show({
                            type: 'text',
                            text: '呼叫失败，请稍后重试~'
                        });
                }
            });
        } else {
            $wuxToast.show({
                type: 'text',
                text: '未设置电话号码'
            });
        }
    },

    tapQrcode(ev) {
        const bury_config = app.globalData.bury_config;
        const {
            shop_id
        } = this.data.shop;
        //bury.profileBury('share_profile', bury_config);
        wx.navigateTo({
            url: `/pages/album_qrcode/index?shop_id=${shop_id}`
        });
    },

    tapTags(ev) {
        const {
            all_tags: tags = [],
            filterTag
        } = this.data;
        const groups = this.getGroups(this.data);
        const bury_config = app.globalData.bury_config;
        //bury.profileBury('catalogue_and_tag', bury_config);
        if (!groups.length && !tags.length && !filterTag.length) {
            wx.showToast({
                title: "请添加商品并设置商品分类~",
                icon: "none",
            });
        } else {
            this.tags.onShow({
                tags,
                groups,
                filterTag,
            });
        }
    },

    tapTag(ev) {
        const {
            tagId
        } = ev.target.dataset;
        const {
            listIndex,
            filterText,
            filterImg,
            filterTag,
            supportNavigationStyle
        } = this.data;

        if (tagId == filterTag) {
            return false;
        }
        this.list = [];
        this.setData(Object.assign({}, getData(), {
            listIndex,
            filterText,
            filterImg,
            supportNavigationStyle,
            filterTag: tagId
        }));
        this.fetchData();
    },

    hideTags(ev) {
        this.setData({
            showTag: false
        });
    },

    clearTags() {
        const {
            listIndex,
            filterText,
            filterImg,
            filterTag,
            supportNavigationStyle
        } = this.data;

        console.log('clear');
        this.list = [];
        this.setData(Object.assign({}, getData(), {
            listIndex,
            filterText,
            supportNavigationStyle,
            filterImg,
            filterTag: []
        }));
        this.fetchData();
    },

    okTags(ev) {
        const {
            filterTag
        } = ev.detail;
        /* const {listIndex, filterText, filterImg} = this.data;

        console.log('ok', ev);
        this.list = [];
        this.setData(Object.assign({}, getData(), {
            listIndex,
            filterText,
            filterImg,
            filterTag
        }));
        this.fetchData(); */

        const route = '/pages/tag_goods_list/index';
        const options = {
            shop_id: this.shop_id,
            from: "tags",
            tag_id: JSON.stringify(filterTag),
        };
        util.navigateTo(route, options);
    },


    // onTapTag(ev) {
    //     const { tagId } = ev.target.dataset;
    //     const route = '/pages/tag_goods_list/index';
    //     const options = {
    //         shop_id: this.shop_id,
    //         from:"tags",
    //         tag_id: tagId,
    //     };
    //     util.navigateTo(route, options);
    // },

    onTapGroup(groupId) {
        const route = '/pages/tag_goods_list/index';
        const options = {
            shop_id: this.shop_id,
            from: "tags",
            group_id: groupId,
        };
        util.navigateTo(route, options);
    },

    // onRichTextLongTap(e) {
    //     if (!e.currentTarget.dataset.title) {
    //         return;
    //     }
    //     wx.setClipboardData({
    //         data: e.currentTarget.dataset.title,
    //         success: () => {
    //             wx.showToast({
    //                 title: '已复制',
    //                 icon: 'success',
    //                 duration: 1000,
    //                 mask: true
    //             })
    //         }
    //     })
    // },
    handleToShopCarDetail() {
        wx.navigateTo({
            url: '/pages/my_shopping_cart/index',
        });
    },

    /**
     * 新增商品
     */
    onAddGoods() {
        wx.showActionSheet({
            itemList: ['选择照片', '选择视频', '拍摄'],
            success: res => {
                this.chooseLocalFile(res.tapIndex, res.tapIndex === 0 ? 9 : 1);
            }
        });
    },

    chooseLocalFile(type, maxNum) {
        if (type === 0) {
            wx.chooseImage({
                count: maxNum,
                sourceType: ['album'],
                sizeType: ['original'],
                success: res => {
                    // compress && upload
                    console.log('res: ', res);
                    wx.setStorage({
                        key: 'image_tempfiles',
                        data: res,
                    });
                    this.toGoodsEditPage();
                }
            });
        } else if (type === 1) {
            wx.chooseVideo({
                count: 1,
                maxDuration: 30,
                sourceType: ['album'],
                sizeType: ['original'],
                compressed: false,
                success: res => {
                    console.log('res: ', res);
                    wx.setStorage({
                        key: 'video_tempfiles',
                        data: res,
                    });
                    this.toGoodsEditPage();
                }
            });
        } else if (type === 2) {
            wx.chooseImage({
                count: 1,
                sourceType: ['camera'],
                sizeType: ['original'],
                success: res => {
                    // compress && upload
                    console.log('res: ', res);
                    wx.setStorage({
                        key: 'image_tempfiles',
                        data: res,
                    });
                    this.toGoodsEditPage();
                }
            });
        }
    },

    /**
     * 转到新增商品界面
     */
    toGoodsEditPage() {
        wx.setStorage({
            key: 'goods_edit',
            data: 'shop_add',
        });
        wx.navigateTo({
            url: '/pages/goods_edit/index',
        });
    },

    /**
     * 改变模板下拉
     */
    onShowtemplate(e) {
        console.log("点击事件");
        let {
            selectShow
        } = this.data;
        console.log(this.data.selectShow);
        console.log(this.data.isScroll);
        this.setData({
            selectShow: !selectShow,
            isScroll: selectShow
        });
    },

    closeTemplateList(e) {
        console.log('closeTemplateList');
        this.setData({
            selectShow: false,
            isScroll: true
        });
    },

    /**
     * 改变模板
     */
    onChangeTemplate(e) {
        let id = e.currentTarget.dataset.id;
        if (!id) {
            return;
        }
        let {
            isMyAlbum,
            template,
            listIndex
        } = this.data;
        if (id != template && isMyAlbum) {
            //自己的相册才能修改
            this.saveTemplate(id);
        }
        // this.setData({
        //   template: id,
        //   curTempObj: this.getTemplateById(id, this.data.template_list),
        //   selectShow: false,
        // });
        this.localTemplateId = id;
        this.refreshData(listIndex);
        this.setData({
            selectShow: false
        });
    },

    /**
     * 根据ID获取模板对象
     */
    getTemplateById(id, template_list) {

        if (!template_list) {
            return null;
        }
        let obj = template_list.filter(item => {
            return item.id == id;
        });


        return obj[0] || template_list[0];
    },

    saveTemplate(id) {
        let saveTemplateUrl = '/album/album_config_operation.jsp?act=set_album_template';
        let param = {
            template: id
        };
        util.fetch(saveTemplateUrl, param).then(res => {
            let {
                errcode,
                errmsg
            } = res.data;
            if (errcode == 0) {
                // wx.showToast({
                //   title: errmsg,
                //   icon: "none",
                // })
            } else {
                wx.showToast({
                    title: errmsg || '异常',
                    icon: "none",
                });
            }
        });
    },
    onPageScroll(e) {
        let query = wx.createSelectorQuery();
        query.select('#J_avatar').boundingClientRect((rect) => {
            let top = rect.top;
            // 44 导航栏高度
            if (top <= this.data.statusBarHeight + 44) {

                if (!this.data.navBgWhite) {
                    this.setData({
                        navBgWhite: true,
                        topDomHeight: 40 + this.data.statusBarHeight + 44 + 127 + 20
                    });
                }

            } else {
                if (this.data.navBgWhite) {
                    this.setData({
                        navBgWhite: false
                    });
                    this.compatibleStyle();
                }
            }
        }).exec();
    },
    goBack() {
        util.navGoBack();
    },
    onSetTop(ev) {
        const {
            dataset
        } = ev.currentTarget;
        const {
            istop,
            shop
        } = dataset;
        // if(istop){
        //     wx.showModal({
        //         title: '温馨提示',
        //         content: '是否取消置顶好友相册',
        //         showCancel: true,
        //         confirmText: '确定',
        //         success: res => {
        //             if (res.confirm) {
        //                 requestSetTop.call(this,istop);
        //             } else {
        //                 console.log("取消")
        //             }
        //         },
        //         fail: res => {

        //         },
        //     });
        // } else {

        // }
        requestSetTop.call(this, istop);

        function requestSetTop(istop) {
            util.fetch(this.data.setTopUrl, {
                albumId: shop.shop_id,
                top: istop
            }, 'POST')
                .then(res => {
                    const {
                        errcode,
                        errmsg
                    } = res.data;
                    if (errcode == 0) {
                        this.setData({
                            top: !istop
                        });
                        const pages = getCurrentPages();
                        const followListPage = pages.find(i => i.route === 'pages/follow/index');
                        if (followListPage) {
                            followListPage.data.list = followListPage.data.list.map(item => {
                                if (item.shop_id === shop.shop_id) {
                                    return {
                                        ...item,
                                        isTop: item.isTop === 0 ? 1 : 0,
                                    };
                                }
                                return item;
                            });
                            // console.log(followListPage.data.list)
                        }
                        wx.showToast({
                            title: errmsg,
                        });
                    } else {
                        wx.showToast({
                            icon: 'none',
                            title: errmsg,
                        });
                    }
                }, errmsg => {
                    wx.showToast({
                        icon: 'none',
                        title: errmsg,
                    });
                });
        }
    },
    onSetFollow(ev) {
        const {
            dataset
        } = ev.currentTarget;
        const {
            isattention,
            shop
        } = dataset;

        console.info('onSetFollow, isattention: ', isattention);
        if (isattention) {
            wx.showModal({
                title: '温馨提示',
                content: '是否取消关注好友相册',
                showCancel: true,
                confirmText: '确定',
                success: res => {
                    if (res.confirm) {
                        requestSetFollow.call(this, {
                            url: this.data.cancelFollowUrl,
                            data: {
                                albumId: shop.shop_id
                            }
                        });
                    } else {
                        console.log("取消");
                    }
                },
                fail: res => {

                },
            });
        } else {
            requestSetFollow.call(this, {
                url: this.data.followUrl,
                data: {
                    shop_id: shop.shop_id
                }
            });
        }

        function requestSetFollow(param) {
            util.fetch(param.url, param.data, 'POST')
                .then(res => {
                    const {
                        errcode,
                        errmsg
                    } = res.data;
                    if (errcode == 0) {
                        app.globalData.updateHomeData = true;
                        this.setData({
                            is_attention: !isattention
                        });
                        wx.showToast({
                            title: errmsg,
                        });
                        // 取消关注的时候更新上一个页面数据
                        if (isattention) {
                            //直接更新数据
                            const pages = getCurrentPages();
                            const followListPage = pages.find(i => i.route === 'pages/follow/index');
                            if (followListPage) {
                                followListPage.data.list.splice(followListPage.data.list.findIndex(item => item.shop_id === param.data.albumId), 1);
                            }
                            wx.setStorage({
                                key: 'refresh_follow_list',
                                data: 1,
                            });

                        } else {
                            wx.removeStorageSync('refresh_follow_list');
                        }

                        //new add
                        if (errmsg == "关注成功") {
                            //拉取列表
                            this.setData({ loadingEnd: false }, () => this.fetchData(''));
                        }
                    } else {
                        wx.showToast({
                            icon: 'none',
                            title: errmsg,
                        });
                        this.setData({ loadingEnd: true });
                    }
                }, errmsg => {
                    wx.showToast({
                        icon: 'none',
                        title: errmsg,
                    });
                });
        }
    },

    showCartSheetListener(e) {
        console.log(e);
        this.$cartSheet.onShow(e.detail);
    },

    showTagSelectSheet(e) {
        const {
            all_tags = [], groups = [], tagSelectSheetShow = false
        } = this.data;

        console.log(tagSelectSheetShow);
        this.setData({
            tagSelectSheetShow: true,
            all_tags,
            groups,
            ...e.detail,
            isScroll: tagSelectSheetShow // 禁用滚动
        });
    },

    previewImgs(e) {
        console.log('previewImgs e.detail: ', e.detail);
        this.setData({
            showPreviewer: true,
            ...e.detail,
        }, () => {
            this.data.showPreviewer && util.navigateToBrowserPage();
        });
    },

    previewCardImgs(e) {
        console.log('previewCardImgs e.detail: ', e.detail);
        this.setData({
            showPreviewer: true,
            ...e.detail,
        }, () => {
            this.data.showPreviewer && util.navigateToBrowserPage();
        });
    },


    setDialogInfo() {
        const {
            login_user: { // 登录用户
                vip_status, // vip状态
                photo_search_check: login_photo_search_check, // Boolean：搜图开关
            } = {},
            shop: { photo_search_check } = {}, // Boolean：当前店铺是否开启搜图开关
            isMyAlbum,
        } = this.data;

        // vip_status: 0为非会员 1会员 2试用期 3会员过期
        switch (vip_status) {
            case 0:
            case 3:
                const dialogInfo = util.isIOS()
                    ? {
                        title: "温馨提示",
                        body: "由于相关规范，iOS暂不支持此功能，如有疑问，请联系客服",
                        button: "联系客服",
                        type: 1
                    }
                    : {
                        title: "会员特权",
                        body: "以图搜图是会员功能哟，马上开通吧",
                        button: "去开通",
                        type: 1
                    };
                this.setData({
                    dialogInfo
                });
                break;

            case 1:
                if (!login_photo_search_check) {
                    this.setData({
                        dialogInfo: {
                            title: "温馨提示",
                            body: "您的相册尚未开启以图搜图功能，请打开APP的【我】-【设置】进行开启。",
                            button: "知道了",
                            type: 0
                        }
                    });
                } else if (!photo_search_check) {
                    this.setData({
                        dialogInfo: {
                            title: "温馨提示",
                            body: "此相册尚未开启以图搜图功能，请提醒您的好友打开APP的【我】-【设置】进行开启。",
                            button: "知道了",
                            type: 0
                        }
                    });
                }
                break;

            case 2:
                if (!isMyAlbum && !photo_search_check) {
                    this.setData({
                        dialogInfo: {
                            title: "温馨提示",
                            body: "此相册尚未开启以图搜图功能，请提醒您的好友打开APP的【我】-【设置】进行开启。",
                            button: "知道了",
                            type: 0
                        }
                    });
                }
                break;

            default:
                break;
        }
    },
    onStopScroll() {
        // 阻止滚动
    },

    onTopTabEvent(e) {
        console.log('onTopTabEvent', e.detail, this.currTabIndex);

        if (this.currTabIndex != e.detail.key) {
            this.currTabIndex = e.detail.key;
            console.log('currTabIndex ', this.currTabIndex);
            wx.showLoading({
                mask: true,
                title: '加载中...',
            });
            this.setData({
                loadingEnd: false,
                loadingNoData: false,
                list: []
            });
            //...
            util.abortCurrRequestTask();
            // this.fetchData('', () => {
            //     wx.hideLoading();
            // });
            this.refreshData(0);
        }
    },

    toCommentListPage() {
        console.log('toCommentListPage...');
        wx.navigateTo({
            url: '/pages/new-comments/index',
        });
    },

    onPlusAppTap() {
        const { shop_id, plusAppId } = this.data;
        console.log('onPlusAppTap...', shop_id, plusAppId);
        wx.navigateToMiniProgram({
            appId: plusAppId, //'wx82768f631dd021fd', //'wx107b8fbd08e99afd', //'wx5b589968eff47164', //
            path: 'pages/follow_detail/index?shop_id=' + shop_id,
            // path: `/package-album/pages/vip/index`,
            extraData: {
                foo: 'bar'
            },
            // envVersion: 'trial',
            success(res) {
                // 打开成功
            }
        });
    },

    onPublishBtn() {
        console.log('onPublishBtn...');
        if (app.offline()) {
            circleUtil.showLoginModal();
            return;
        }
        wx.navigateTo({
            url: '/pages/goods_edit/index?category=' + 0,

            // events: {
            //     // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
            //     acceptDataFromOpenedPage: data => {
            //         // console.log('acceptDataFromOpenedPage ', data);
            //         if (list) {
            //             list.unshift(data);
            //             this.setData({ list });
            //         }
            //     },
            // },
        });

    },

    onShareBtnTap() {
        console.log('onShareBtnTap...');
    },
}));
