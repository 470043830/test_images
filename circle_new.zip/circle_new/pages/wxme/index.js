var util = require('../../utils/util.js');
const bury = require('../../utils/burypoint.js');
const circleUtil = require('../../utils/circle-util.js');

//获取应用实例
var app = getApp();

const GetFollowedShopsUrl = `/circle/circle_new_interface.jsp?act=getFollowedShops`;
const GetMyShopUrl = `/circle/circle_new_interface.jsp?act=getMyShopInfo`;

Page({
    data: {
        getUrl: '/account/get_user_system_status.jsp?',
        saveInfoUrl: '/account/user_info_operation.jsp?act=save_user_info',
        user: {
            avatar: '../../assets/images/no_login.svg',
            shopName: "点击登录"
        },

        hasUnread: false,
        hideRed: true,
        loginUrl: '/pages/login/index',
        showView: false,
        share_title: '😘快来我的微商相册看新品看款搜款、分享9图和小视频',
        vip_info: { //app保持不变，小程序提出来
            "name": "vip",
            "icon": "https://xcimg.szwego.com/i_vip.png",
            "link": "https://www.szwego.com/static/index.html?#/vip",
            "title": "会员有效期:2020-08-14",
            "desc": "查看特权",
            "desc_link": "https://www.szwego.com/static/index.html?#/vip"
        },

        followed_booths: [],
        customBar: 60,
        isShowPublish: false,
    },

    onLoad(options) {
        const { customBar } = app.getCustomBarInfo();
        this.setData({ customBar });
    },

    onBackTap(){
        wx.navigateBack();
    },

    onShow() {
        if (app.offline()) {
            this.setData({
                offline: true,
            });
            this.setData({
                showView: true
            });
            return;
        }
        this.setData({
            offline: false
        });

        const isShowPublish = circleUtil.isMiniChecked();
        this.setData({ isShowPublish });

        //调用应用实例的方法获取全局数据
        app.getUserInfo(this.onGetUserInfo, this.onGetUserInfoFail);
    },

    async onGetUserInfo(userInfo) {
        const { showView } = this.data;

        !showView && wx.showLoading({ title: '加载中...' });
        await circleUtil.fetchNetData({ url: GetMyShopUrl }, this.onMyShopInfoFetched);
        !showView && wx.hideLoading();
    },

    onGetUserInfoFail() {
        console.log('onGetUserInfoFail...');
    },

    /**
     * 监听用户下拉刷新事件
     */
    onPullDownRefresh() {
        if (app.offline()) {
            wx.stopPullDownRefresh();
            return;
        };

        if (app.globalData.userInfo) {
            circleUtil.fetchNetData({ url: GetMyShopUrl }, this.onMyShopInfoFetched);
        }

        //     console.log("onPullDownRefresh")
        //     this.setData({
        //         user: {},
        //     })

        //     this.fetchData(() => {
        //         console.log("stopPullDownRefresh")
        //         wx.stopPullDownRefresh();
        //     });

    },

    boothsTap(ev) {
        const { dataset } = ev.currentTarget;
        const { shopId } = dataset;
        const url = `/pages/follow_detail/index?shop_id=${shopId}`;

        console.info('boothsTap: ', dataset, url);
        circleUtil.onShopItemTap(shopId);
    },


    onMyShopInfoFetched(isOk, result) {
        if (!isOk) {
            console.log('onMyShopInfoFetched: ', result);
            if (result.title == 'No user id'){
                wx.redirectTo({
                    url: '/pages/login/index'
                });
            }
            return;
        }
        console.log('app.globalData.userInfo: ', app.globalData.userInfo);
        //..登过一次管理员账号的情况
        if (result.admin) {
            app.globalData.userInfo.admin = true;
            app.storageUserInfo(app.globalData.userInfo);
        }
        result.admin = app.globalData.userInfo.admin;

        this.setData({ user: result, showView: true });

        //...暂时屏蔽我的关注
        // this.fetchFollowedShops();
    },

    followedDynamicTap() {
        console.log('followedDynamicTap...');
        wx.navigateTo({
            url: '/pages/shop-list/index?from=followedDynamicTap',
        });
    },

    saveFollowedShopIds(shop_list) {
        let shopIds = '';

        for (let index = 0; index < shop_list.length; index++) {
            shopIds += shop_list[index].shopId;
            shopIds += ',';
        }
        circleUtil.saveFollowedShopIds(shopIds);
    },

    async fetchFollowedShops() {
        let param = {};
        // wx.showLoading({ title: '加载中...' });
        let res = await util.fetch(GetFollowedShopsUrl, param);
        // wx.hideLoading();
        console.log('fetchFollowedShops, res: ', res);

        const { errcode, errmsg, result } = res.data;
        if (errcode == 0) {
            const { shop_list } = result;
            this.saveFollowedShopIds(shop_list);
            this.setData({ followed_booths: shop_list });
        } else {
            wx.showToast({ title: errmsg });
        }
    },

    fetchData(cb) {
        if (app.offline()) return;
        //setData 函数用于将数据从逻辑层发送到视图层（异步），同时改变对应的 this.data 的值（同步）。
        this.setData({
            loading: true
        });
        util.fetch(this.data.getUrl).then(res => {
            console.log(res.data);
            typeof cb === 'function' && cb();
            const {
                result
            } = res.data;
            const {
                user,
                ...others
            } = result;
            const obj = {
                user,
                ...others
            };

            //TODO:调试
            // obj.user.vip_status = 3;//0为非会员1会员2试用期3会员过期
            // obj.user.show_vip = true;
            // obj.user.remark = '四季酒店';
            //-------------
            this.setData({
                ...obj,
                loading: false,
                showView: true,
            });
            console.log(this.data);
            // 清除失效token，触发重新获取
            app.clearToken(res.data, () => {
                this.onPullDownRefresh();
            });
            wx.hideLoading();
        }, () => {
            this.setData({
                loading: false
            });
        });
    },


    onNewStarted: function () { //跳转到新手入门
        let data = {
            url: 'https://mp.weixin.qq.com/s/JKU5rTaXPxp45Lb_WWLxtg',
            title: '新手入门'
        };
        util.openWebview(data);
    },
    onShareAppMessage: function (ev) { //推荐给朋友
        const bury_config = app.globalData.bury_config;
        // bury.pageShare(bury_config, this.route);
        const obj = {
            route: this.route,
            $title: '我',
            share_method: '微信小程序',
            $screen_name: 'wxme',
            share_content: '小程序个人主页',
        };
        bury.share(bury_config, obj);
        const {
            user
        } = this.data;
        console.log(" this.data.shop_id" + user.shop_id);
        return {
            title: '😘快来我的微商相册看新品看款搜款、分享9图和小视频',
            imageUrl: user.user_baner_img,
            path: '/pages/follow_detail/index?shop_id=' + user.shop_id,
            success: function (res) {
                // 转发成功

            },
        };
    },
    saveInfo(data) {  // 同步个人信息到后端接口
        const { nickName, avatarUrl } = data;
        if (nickName) {
            util.fetch(this.data.saveInfoUrl, {
                shop_name: nickName,
                user_icon: avatarUrl
            }, 'POST').then(res => {
                if (res.data && res.data.errcode == 0) {
                    // 更新本地页面缓存数据
                    const curUserInfo = this.data.user;
                    curUserInfo.user_icon = avatarUrl;
                    curUserInfo.shop_name = nickName;
                    this.setData({
                        user: curUserInfo
                    });
                }
            });
        }
    },
    bindGetUserInfo: function (res) {
        console.log('bindGetUserInfo...', res);

        //暂时屏蔽这里
        // this.saveInfo(res.detail.userInfo);
        // app.globalData.updateHomeData = true;

        wx.navigateTo({
            url: `/pages/personal-info/index`,
        });
    },

    onBoothApply() {
        console.log('onBoothApply...');
        // this.getApplyInfo();
        wx.navigateTo({ url: '/pages/personal-info/index?scene=10001' });
    },

    async getApplyInfo() {
        wx.showLoading({ title: '加载中...' });
        await circleUtil.fetchNetData({ url: '/circle/circle_new_interface.jsp?act=getMyApplyInfo' }, this.onMyApplyInfoFetched);
        wx.hideLoading();
    },

    onMyApplyInfoFetched(isOk, result = {}) {
        if (!isOk) {
            return;
        }
        const { status = -1 } = result;
        console.log('onMyApplyInfoFetched, status: ', status);
        //this.setData({ user: result, showView: true });
        if (status == -1) {
            wx.navigateTo({ url: '/pages/personal-info/index?scene=10001' });
        } else if (status == 0) {
            //this.setData({ posted: true });
            wx.navigateTo({ url: '/pages/msg_tip/index' });
        } else if (status == 1) {
            wx.showToast({ title: '已AppRuzhulyGaiCircle' });
        }
    },

    onOtherUserLogin(){
        console.log('onOtherUserLogin...');
        wx.navigateTo({url: '/pages/super-login/index'});
    },

    onRadarTap() {
        console.log('onRadarTap...');
        wx.navigateTo({ url: '/pages/customer-radar/index' });

        // wx.navigateToMiniProgram({
        //     appId: 'wxa4b1582a24a34d16',
        //     path: 'pages/index/index',
        //     extraData: {
        //     },
        //     // envVersion: 'develop',
        //     success(res) {
        //         // 打开成功
        //     }
        // })
    },

    onPlusAppTap(){
        const { user } = this.data;
        const url = '/pages/follow_detail/index?shop_id=' + user.shopId;

        console.log('onPlusAppTap...', url);
        wx.navigateTo({
            url
        });
        // wx.navigateToMiniProgram({
        //     appId: 'wx107b8fbd08e99afd',
        //     path: 'pages/home/index',
        //     extraData: {
        //         foo: 'bar'
        //     },
        //     // envVersion: 'develop',
        //     success(res) {
        //         // 打开成功
        //     }
        // });
    },

    onWxShopTap1(){
        const productId = '29440749'; // 填写具体的商品Id

        wx.navigateTo({
            url: `plugin-private://wx34345ae5855f892d/pages/productDetail/productDetail?productId=${productId}`,
        });

        // wx.navigateTo({
        //     url: 'plugin-private://wx34345ae5855f892d/pages/orderList/orderList',
        // });
    },
    onWxShopTap2() {
        wx.navigateTo({
            url: 'plugin-private://wx34345ae5855f892d/pages/shoppingCart/shoppingCart',
        });
    },
    onWxShopTap3() {
        wx.navigateTo({

            url: 'plugin-private://wx34345ae5855f892d/pages/orderList/orderList',

        });
    },
});
