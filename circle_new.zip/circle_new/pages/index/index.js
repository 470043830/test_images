import {
    $tdSearchbar,
    $tdUploader,
    $wuxToast
} from '../../components/wux';

const util = require('../../utils/util.js');
const logic = require('../../utils/logic.js');
const constant = require('../../utils/constant.js');
const app = getApp();

Page({
    data: {
        // getUrl: '/data/index.json',
        getUrl: '/circle/miniapp_circle_main.jsp?act=get_circle_detail',
        getNew: '/circle/miniapp_circle_main.jsp?act=get_new_store',
        getRecommend: '/circle/miniapp_circle_main.jsp?act=get_recommend',
        loading: false,
        phone_number: '4006655659',
        latitude: undefined,
        longitude: undefined,
        isGuest: false,
    },

    onLoad(options) {
        // let extConfig = wx.getExtConfigSync ? wx.getExtConfigSync() : {}
        // console.log(extConfig)

        // wx.reLaunch({ url: '/pages/home/index' });

        // return;


        console.info('onLoad', options);
        this.new_page_index = 1;
        this.recommend_page_index = 1;
        // search
        $tdSearchbar.init({
            style: 'border: none; background-color: #fff',
            image: true
        });

        wx.showLoading({
            mask: false,
            title: '加载中...',
        });

        wx.getSetting({
            success: (res) => {
                if (!res.authSetting['scope.userInfo']) {
                    // 未授权
                    // wx.hideLoading();
                    // wx.redirectTo({
                    //     url: '/pages/login/index'
                    // });
                    this.setGuestInfo();
                    this.onLoadFetchData(true);
                } else {
                    //...
                    let info = wx.getStorageSync(USER_INFO_STORAGE);
                    console.log('已经授权...', info);
                    if (info && info.isGuest) {
                        //删除之前保存的游客信息
                        wx.removeStorageSync(USER_INFO_STORAGE);
                        app.globalData.userInfo = null;
                    }
                    this.onLoadFetchData(false);
                }

            }
        });
    },

    /**
     * @description
     */
    onLoadFetchData(isGuest) {
        this.fetchData(() => {
            const { circle_name: title } = this.data;

            title && wx.setNavigationBarTitle({ title });
            wx.hideLoading();

            if (!isGuest) {
                // 更新市场距离
                this.updateDistance();
                // this.getMyUserInfo();
            }

        });
    },

    /**
     * @description 设置游客信息
     */
    setGuestInfo() {
        console.log('setGuestInfo...');
        let guest =
        {
            "country": "Israel", "gender": 1, "province": "", "city": "", "isGuest": true,
            "avatarUrl": "", "nickName": "guest", "new_token": true,
            "token": constant.GUEST_TOKEN
        };
        wx.setStorageSync(USER_INFO_STORAGE, guest);
    },

    /**
     * @description 取出自己的shopid 对 followed_booths 进行排序
     */
    getMyUserInfo() {
        let url = '/account/app_auth.jsp?act=get_album_info';
        util.fetchAuthInst(url, null, res => {
            const { errcode, result } = res.data;
            // let obj = {};
            // console.log('res: ', res);
            console.log('followed_booths: ', this.data.followed_booths);
            if (errcode == 0) {
                const followed_booths = this.data.followed_booths;
                const myShop = this.getShopItemById(result.shop_id, followed_booths);
                console.log('myShop: ', myShop);
                if (myShop && myShop.index != 0) {
                    followed_booths.splice(myShop.index, 1);
                    followed_booths.unshift(myShop.element);
                    this.setData({ followed_booths });
                }
            }
        }, err => {
            console.log(err);
        });
    },

    getShopItemById(shop_id, list) {
        for (let index = 0; index < list.length; index++) {
            const element = list[index];
            if (element.shop_id == shop_id) {
                return { element, index };
            }
        }
        return null;
    },

    updateDistance() {
        if (!this.hasCoordinate()) {
            app.getLocation(res => {
                console.log(res);
                this.setData({
                    market: this.getLocationMarket(res),
                });
            });
        } else {
            this.setData({
                market: this.getLocationMarket(this.data),
            });
        }
    },

    hasCoordinate() {
        const { latitude, longitude } = this.data;

        return typeof latitude !== 'undefined' && typeof longitude !== 'undefined';
    },

    getLocationMarket(location) {
        const { latitude: lat, longitude: lng } = location;
        const { market: _market = [] } = this.data;

        let market = _market.map(item => {
            const { latitude, longitude } = item;
            let distance = util.getDistance(lat, lng, latitude, longitude);
            let _distance = distance;
            if (distance < 1) {
                distance = distance * 1000;
                distance = `${distance.toFixed(0)}米`;
            } else {
                distance = `${distance.toFixed(2)}公里`;
            }

            return {
                ...item,
                distance,
                _distance,
            };
        });
        return market.sort((x, y) => x._distance - y._distance);
    },

    onShow() {
        console.info('onShow');
    },

    onShareAppMessage(res) {
        const { share_title } = this.data;

        console.log(res);
        return {
            title: share_title,
            path: `/pages/index/index`,
            success: function (res) {
                // 转发成功
            },
            fail: function (res) {
                // 转发失败
            }
        };
    },

    fetchData(callback) {
        const { getUrl: url } = this.data;

        console.info(url);
        this.setData({ loading: true });
        let postData = {
            lat: '0',
            lng: '0'
        };
        util.fetchAuthInst(url, postData, res => {
            const { errcode, result, errmsg, token } = res.data;
            let obj = {};

            console.log(res);
            if (errcode == 0) {
                obj = Object.assign({}, this.data, result);
            } else {
                wx.showToast({
                    title: errmsg,
                    icon: 'fail',
                    duration: 1500
                });
                obj.loading = false;
                return;
            }
            obj.loading = false;
            obj.isGuest = (token == constant.GUEST_TOKEN);

            this.setData(obj);
            typeof callback == 'function' && callback();

            // 清除失效token，触发重新获取
            app.clearToken(res.data, () => {
                this.onPullDownRefresh();
            });
        }, err => {
            console.log(err);
            this.setData({ loading: false });
            typeof callback == 'function' && callback();
        });
    },

    onPullDownRefresh() {
        wx.hideLoading();
        const { loading } = this.data;

        if (loading) {
            return false;
        }

        console.log("onPullDownRefresh");
        this.fetchData(() => {
            console.log("stopPullDownRefresh");
            wx.stopPullDownRefresh();

            // 更新市场距离
            this.updateDistance();
        });
    },

    showLoginModal() {
        wx.showModal({
            title: '提示',
            content: '请先登录',
            success(res) {
                if (res.confirm) {
                    console.log('用户点击确定');
                    wx.redirectTo({
                        url: '/pages/login/index'
                    });
                } else if (res.cancel) {
                    console.log('用户点击取消');
                }
            }
        });
    },

    searchTap(ev) {
        const url = '/pages/search/index';

        console.info('search');
        url && wx.navigateTo({ url });
    },

    swiperTap(ev) {
        const { dataset } = ev.currentTarget;
        const { url } = dataset;

        console.info('swiper', dataset);
        url && wx.navigateTo({ url });
    },

    dynamicTap(ev) {
        const url = '/pages/dynamic/index';

        console.info('动态');
        url && wx.switchTab({ url });
    },

    boothsTap(ev) {
        const { isGuest } = this.data;
        const { dataset } = ev.currentTarget;
        const { shopId } = dataset;
        const url = `/pages/follow_detail/index?shop_id=${shopId}`;

        console.info('booths', dataset, url);
        if (isGuest) {
            this.showLoginModal();
            return;
        }
        url && wx.navigateTo({ url });
    },

    newTap(ev) {
        const { getNew: url } = this.data;
        this.new_page_index++;
        wx.showLoading({
            mask: true,
            title: '加载中...',
        });
        let postData = {
            page_index: this.new_page_index
        };
        util.fetchAuthInst(url, postData, res => {
            const { errcode, result } = res.data;

            console.log(res);
            wx.hideLoading();
            if (errcode == 0) {
                if (res.data.total_page <= res.data.cur_page) {
                    this.new_page_index = 0;
                }
                result.new_booths && result.new_booths.length > 0 && this.setData({
                    new_booths: result.new_booths
                });
            }
        }, err => {
            console.log(err);
            wx.hideLoading();
        });
    },

    recommendTap(ev) {
        const { getRecommend: url } = this.data;
        this.recommend_page_index++;
        let postData = {
            page_index: this.recommend_page_index
        };
        wx.showLoading({
            mask: true,
            title: '加载中...',
        });

        util.fetchAuthInst(url, postData, res => {
            const { errcode, result } = res.data;

            console.log(res);
            wx.hideLoading();
            if (errcode == 0) {
                if (res.data.total_page <= res.data.cur_page) {
                    this.recommend_page_index = 0;
                }
                result.recommend_booths && result.recommend_booths.length > 0 && this.setData({
                    recommend_booths: result.recommend_booths
                });
            }
        }, err => {
            console.log(err);
            wx.hideLoading();
        });
    },

    marketTap(ev) {
        const { isGuest } = this.data;
        const { market_id } = this.getMarket(ev);
        const url = `/pages/market/index?market_id=${market_id}`;

        console.info('market', url);
        if (isGuest) {
            this.showLoginModal();
            return;
        }
        url && wx.navigateTo({ url });
    },

    getMarket(ev) {
        const { dataset } = ev.currentTarget;
        const { index } = dataset;
        const { market } = this.data;
        const data = market[index];

        console.info(dataset, data);
        return data;
    },

    locationTap(ev) {
        const { latitude, longitude, name, address } = this.getMarket(ev);

        console.info('location');
        wx.openLocation({
            latitude,
            longitude,
            name,
            address,
            fail: res => {
                console.info('fail', res);
            },
        });
    },

    joinTap(ev) {
        const { isGuest } = this.data;
        const url = `/pages/join/index`;

        if (isGuest) {
            this.showLoginModal();
            return;
        }
        url && wx.navigateTo({ url });
    },

    contactTap(ev) {
        const { phone_number: phoneNumber } = this.data;

        wx.makePhoneCall({
            phoneNumber,
            fail: res => {
                const { errMsg } = res;

                console.info(res);
                !errMsg.match(/cancel/) &&
                    $wuxToast.show({
                        type: 'text',
                        text: '呼叫失败，请稍后重试~'
                    });
            }
        });
    },

});
