// pages/personal-info/index.js
const util = require('../../utils/util.js');
const constant = require('../../utils/constant');
const circleUtil = require('../../utils/circle-util.js');
const app = getApp();

const getUserInfoUrl = `/account/user_info_operation.jsp?act=get_user_info`;
const postUserInfoUrl = `/account/user_info_operation.jsp?act=save_user_info`;

Page({

    /**
     * 页面的初始数据
     */
    data: {
        isIOS: false,
        disableEdit: true,
        userInfo: {
            // link: "",
            // phone_number: "321321312",
            // shop_desc: "美众议院通过特朗普弹劾案 特朗普成首位遭两次弹劾美总统",
            // shop_detail: "",
            // shop_id: "A201906031621498020000323",
            // shop_name: "liuttttttt",
            // user_icon: "https://xcimg.szwego.com/o_1ertt4as61tk9l3gvp517dnbbvn.jpg",
            // user_name: "LiuTao",
            // wechat_id: "wechat_id111",
            // wechat_qrcode: "https://xcimg.szwego.com/o_1esrle406n5v1up18fhbq4fbdc.png",
        },
        applyInfo: false,
        showUI: false,
        leimuShowText: '',
        tagsShowText: '',
        inputCount: '0/140',
        multiIndex: [0, 0],
        multiArray: [
            ['楼栋1', '楼栋2', '楼栋3', '楼栋4'],
            ['一层', '二层', '三层', '四层', '五层', '六层', '七层', '八层']
        ],
        leixingIndex: 0,
        pickLeixingArray: ['类型1', '类型2', '类型3'],
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        const { scene = "" } = options;
        const sceneInfo = decodeURIComponent(scene);

        console.log('sceneInfo: ', sceneInfo);
        this._sceneInfo = sceneInfo;
        if (app.offline()) {
            // circleUtil.showLoginModal();
            wx.redirectTo({
                url: `/pages/login/index?pagePath=contact-info&pageParam=scene:${sceneInfo}`
            });
            return;
        }

        const {
            platform
        } = wx.getSystemInfoSync();
        const isIOS = (platform == 'ios');
        const applyInfo = (sceneInfo.startsWith("10001"));
        const disableEdit = (options.disableEdit == 1);

        applyInfo && wx.setNavigationBarTitle({
            title: 'AppRuzhuly咨询',
        });
        applyInfo && this.initBuildingPicker();
        this.setData({
            isIOS,
            disableEdit,
            applyInfo
        });
        console.log('platform: ', platform);
        //...
        if (disableEdit) {
            this.setData({
                showUI: true
            });
            const eventChannel = this.getOpenerEventChannel();
            // 监听acceptDataFromOpenerPage事件，获取上一页面通过eventChannel传送到当前页面的数据
            eventChannel.on('acceptDataFromApplyListPage', data => {
                console.log('acceptDataFromApplyListPage: ', data);
                const { shopName: shop_name, avatar: user_icon, phoneNumber: phone_number, wechatId: wechat_id, wechatQrcode: wechat_qrcode, leimu, leixing, building, floor, ...other } = data;
                this.setData({
                    leimuShowText: this.getLeimuShowTextByStr(leimu),
                    leixingIndex: parseInt(leixing),
                    multiIndex: [parseInt(building) - 1, parseInt(floor) - 1],
                    userInfo: {
                        shop_name,
                        user_icon,
                        phone_number,
                        wechat_id,
                        wechat_qrcode,
                        ...other
                    }
                });
            });
        } else {
            util.initQiniu();
            this.getNetUserInfo(applyInfo);
        }

    },

    async initBuildingPicker() {
        let {
            circleInfo
        } = app.globalData;
        let {
            multiArray,
            pickLeixingArray
        } = this.data;
        if (!circleInfo.LouDong) {
            circleInfo = await circleUtil.getCircleConfigData();
        }

        const { markets = [] } = circleInfo;
        console.log('circleInfo: ', circleInfo);
        if (markets.length > 0) {
            // multiArray[0] = circleInfo.LouDong.map(item => item.name);
            // multiArray[1] = circleInfo.LouDong[0].floor;
            multiArray[0] = markets.map(item => item.name);
            this.setData({
                multiArray
            });
        }
        if (circleInfo.LeiXing) {
            console.log('circleInfo.LeiXing: ', circleInfo.LeiXing);
            let array1 = circleInfo.LeiXing[0].map(item => item.name);
            let array2 = circleInfo.LeiXing[1].map(item => item.name);
            pickLeixingArray = [...array1, ...array2];
            this.setData({
                pickLeixingArray
            });
        }
    },


    onAcceptApplyBtn() {
        this.acceptReq();
    },

    async acceptReq() {
        const { userInfo } = this.data;
        const shop_id = userInfo.shopId;
        const param = { shop_id, status: 1 };
        wx.showLoading({ title: '操作中...', mask: true });
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url: '/circle/circle_new_interface.jsp?act=updateApplyInfo', param });
        console.log('acceptReq: ', isOk, result);
        wx.hideLoading();

        if (isOk) {
            const eventChannel = this.getOpenerEventChannel();
            eventChannel.emit('acceptDataFromPersonalPage', result);
            wx.navigateBack();
        }
    },

    async onPhoneNumber(e) {
        console.log("onPhoneNumber: ", e);
        const { encryptedData, iv } = e.detail;
        if (!encryptedData || !iv) {
            return;
        }
        const method = 'POST';
        const param = {
            encryptedData: encryptedData,
            iv: iv,
            code: this._loginCode,
            circle_id: constant.circle_id,
            client_type: 'miniapp',
        };
        console.log("onPhoneNumber param: ", param);
        const url = '/circle/circle_new_interface.jsp?act=decodeMiniAppPhoneNumber';
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url, method, param });
        console.log('onPhoneNumber fetchNetData: ', isOk, result);

        if (isOk) {
            const { userInfo } = this.data;
            const { phoneNumber = '' } = result;
            userInfo.phone_number = phoneNumber;
            this.setData({ userInfo });
        }

    },

    gotoNextStep() {
        const {
            userInfo
        } = this.data;

        const param = {
            shop_name: userInfo.shop_name,
            avatar: userInfo.user_icon,
            phone_number: userInfo.phone_number,
            booth_id: userInfo.booth_id,
            ext_info: this._sceneInfo,
        };

        if (!param.leimu) {
            param.leimu = '01';
            // wx.showToast({
            //     title: '请选择主营类目',
            // });
            // return;
        }
        if (!param.booth_id) {
            wx.showToast({
                title: '请输入档口号',
            });
            return;
        }

        setTimeout(async () => {
            const name_booth = `${userInfo.shop_name}(${userInfo.booth_id})`;
            // const url = `/circle/circle_new_interface.jsp?act=saveCustomerPhone&name=${name_booth}&phone=${userInfo.phone_number}&booth=${userInfo.booth_id}`;
            const url = `/circle/circle_new_interface.jsp?act=saveCustomerPhone&name=${name_booth}&phone=${userInfo.phone_number}`;
            const { isOk, result = {} } = await circleUtil.fetchNetData({ url });

            if (isOk) {
                wx.showModal({
                    title: '提交成功',
                    content: '您的AppRuzhulyShenqing已收到，工作人员会尽快与您联系。\n如有疑问，请与圣名管理处联系。',
                    showCancel: false,
                    confirmText: '我知道了',
                    success(res) {
                        if (res.confirm) {
                            console.log('用户点击确定');
                            wx.navigateBack();
                        } else if (res.cancel) {
                            console.log('用户点击取消');
                        }
                    }
                });
            }
        }, 10);


    },

    getConfigLeiMu() {
        const {
            circleInfo
        } = app.globalData;
        const { config = {} } = circleInfo;
        return config.LeiMu;
    },

    getConfigTags() {
        const {
            circleInfo
        } = app.globalData;
        const { config = {} } = circleInfo;
        return config.tags;
    },

    getLeimuPostStr() {
        const LeiMu = this.getConfigLeiMu();
        let ret = '';
        if (LeiMu) {
            for (let index = 0; index < LeiMu.length; index++) {
                const element = LeiMu[index];
                element.checked && (ret += ((index + 1).toString().padStart(2, '0') + '_'));
            }
            ret.length > 0 && (ret = ret.substr(0, ret.length - 1));
        }
        return ret;
    },

    getLeimuShowTextByStr(leimu) {
        const LeiMu = this.getConfigLeiMu();
        let ret = '';
        let leimus = leimu.split('_');
        for (let index = 0; index < leimus.length; index++) {
            const element = parseInt(leimus[index]);
            ret += (LeiMu[element - 1].name + ' ');
        }
        return ret;
    },

    getLeimuShowText() {
        const LeiMu = this.getConfigLeiMu();
        let ret = '';
        if (LeiMu) {
            for (let index = 0; index < LeiMu.length; index++) {
                const element = LeiMu[index];
                element.checked && (ret += (element.name + ','));
            }
            ret.length > 0 && (ret = ret.substr(0, ret.length - 1));
        }
        return ret;
    },

    getTagsShowText() {
        const tags = this.getConfigTags();
        let ret = '';
        if (tags) {
            for (let index = 0; index < tags.length; index++) {
                const element = tags[index];
                element.checked && (ret += (element.name + ','));
            }
            ret.length > 0 && (ret = ret.substr(0, ret.length - 1));
        }
        return ret;
    },

    async getApplyInfo() {
        // wx.showLoading({ title: '加载中...' });
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url: '/circle/circle_new_interface.jsp?act=getMyApplyInfo' });
        // wx.hideLoading();

        if (!isOk) {
            return;
        }
        const { status = -1 } = result;
        console.log('getApplyInfo, status: ', status);

        if (status >= 0) {
            wx.redirectTo({ url: '/pages/msg_tip/index?status=' + status });
        } else {
            this.setData({
                showUI: true
            });
        }
    },

    async getNetUserInfo(isApplyInfo) {
        wx.login({
            success: (res) => {
                if (res.code) {
                    this._loginCode = res.code;
                    console.log("this._loginCode: ", this._loginCode);
                } else {
                    console.log('登录失败！' + res.errMsg);
                }
            }
        });

        wx.showLoading({
            title: '加载中...'
        });
        const {
            isOk,
            result = {}
        } = await circleUtil.fetchNetData({
            url: getUserInfoUrl
        });
        // console.log('getNetUserInfo: ', isOk, result);
        wx.hideLoading();

        if (isOk) {
            this.setData({
                userInfo: result
            });
            console.log('userInfo: ', this.data.userInfo);

            if (isApplyInfo) {
                this.getApplyInfo();
            } else {
                this.setData({
                    showUI: true
                });
            }
        }
    },

    async postNetUserInfo() {
        wx.showLoading({
            title: '保存...'
        });
        const {
            userInfo
        } = this.data;
        const {
            isOk,
            result = {}
        } = await circleUtil.fetchNetData({
            url: postUserInfoUrl,
            method: 'POST',
            param: userInfo
        });
        console.log('postNetUserInfo: ', isOk, result);
        wx.hideLoading();

        if (isOk) { }
    },



    onAvatarClick() {
        if (this.data.disableEdit) return;
        this.chooseImageUpload(url => {
            const {
                userInfo
            } = this.data;

            userInfo.user_icon = url;
            this.setData({
                userInfo
            });
        });
    },

    onQRCodeClick() {
        if (this.data.disableEdit) return;
        this.chooseImageUpload(url => {
            const {
                userInfo
            } = this.data;

            userInfo.wechat_qrcode = url;
            this.setData({
                userInfo
            });
        });
    },

    chooseImageUpload(callback) {
        wx.chooseImage({
            count: 1,
            sizeType: ['original', 'compressed'],
            sourceType: ['album'],
            success: res => {
                let filePath = res.tempFilePaths[0];
                callback && util.qiniuUpload(filePath, callback);
            }
        });
    },

    onTextareaInput(e) {
        const {
            value,
            cursor,
            keyCode
        } = e.detail;
        // console.log('value ', value, value.length);
        this.setData({
            inputCount: `${value.length}/140`
        });
        this.data.userInfo.shop_desc = e.detail.value;
    },

    bindKeyInput: function (e) {
        console.log('bindKeyInput: ', e);
        this.data.userInfo[e.currentTarget.id] = e.detail.value;
    },

    onSelectLeimuClick() {
        if (this.data.disableEdit) return;
        wx.navigateTo({
            url: '/pages/select-leimu/index',
        });
    },

    onSelectTagsClick() {
        if (this.data.disableEdit) return;
        wx.navigateTo({
            url: '/pages/select-tags/index',
        });
    },

    onSelectBuildingClick() { },

    bindPickerChange: function (e) {
        console.log('picker发送选择改变，携带值为', e.detail.value);
        this.setData({
            leixingIndex: parseInt(e.detail.value)
        });
    },

    bindMultiPickerChange: function (e) {
        // console.log('picker发送选择改变，携带值为', e.detail.value);
        this.setData({
            multiIndex: e.detail.value
        });
    },
    bindMultiPickerColumnChange: function (e) {
        const {
            circleInfo
        } = app.globalData;
        const {
            multiArray
        } = this.data;

        // console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
        if (e.detail.column == 0) {
            // 暂时都设置为八层可选
            // multiArray[1] = circleInfo.LouDong[e.detail.value].floor;
            // this.setData({
            //     multiArray
            // });
        }
        return;
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
        //这里需要用eventChannel优化一下
        const { applyInfo, disableEdit } = this.data;
        if (applyInfo && !disableEdit) {
            this.setData({
                leimuShowText: this.getLeimuShowText(),
                tagsShowText: this.getTagsShowText()
            });
        }
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
});
