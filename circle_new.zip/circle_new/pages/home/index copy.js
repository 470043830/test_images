// import { $tdSearchbar, $tdUploader, $wuxToast } from '../../components/wux';
// import nineGrid from '../../utils/nine-grid';

const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const circleData = require('../../utils/circle-data.js');
const constant = require('../../utils/constant');
const app = getApp();
// const circleConfigInfoUrl = '/circle/circle_new_interface.jsp?act=getCircleConfigInfo';
// const circleVideosUrl = '/circle/circle_new_interface.jsp?act=findAllVideos';



let page = {};
function onNoticeAniStart() {
    const noticeIndex = Math.floor(Math.random() * (getNoticeTexts().length - 1));
    // console.log("onNoticeAniStart, noticeIndex: ", noticeIndex);
    page.setData({ noticeIndex });
}


function getNoticeTexts() {
    // return []
    return [""];
}

function getData() {
    return {
        // getUrl: [
        //     '/data/dynamic_1.json?tab=0',
        //     '/data/dynamic_1.json?tab=1',
        // ],
        tabbar: {},
        getUrl: [
            '/circle/circle_new_interface.jsp?act=getGoodsListByPage',
            '/circle/miniapp_circle_themes_list.jsp?act=get_circle_themes_plaza',
            '/circle/miniapp_circle_themes_list.jsp?act=get_circle_themes_attention',
        ],
        addUrl: '/album/album_theme_operation.jsp?act=hold_theme',
        loading: false,
        loadingNoData: false, // 无数据
        loadingEnd: false, // 到底了
        filterText: '',
        filterImg: '',
        latestTime: '',
        listIndex: 0,
        list: [],
        navs: [{ label: '已关注' }, { label: '广场' }],
        priceTypesObj: constant.priceTypesObj,

        background: ['demo-text-1', 'demo-text-2', 'demo-text-3'],
        indicatorDots: true,
        vertical: false,

        user_type: 1,
        recommend_booths: [
        ],


        updateSticky: false,
    }
}

Page({
    data: {
        ...getData(),

        phone_number: '4006655659',
        circleName: '',
        banner: [],
        navList: [],
        showCustomBar: true,
        showStickBar: false,
        stickStyle: '',

        videoNavCurrent: 0,
        videoNavList: ['最新', '热门', '推荐'],
        marketList: [],
        isLiXiuVersion: false,  //荔秀版本
        netWorkError: false,
        followed_booths: [],
        themeTag: 0,
        dynamicList: null,
        isOnLine: false,
        noticeTexts: getNoticeTexts(),
        noticeIndex: 0,
        onNoticeAniStart: onNoticeAniStart,
        loadingPage: true,
        notices: [],
        showWoYaoRuzhu: false,
        showSelectRole: false,
        ruzhuStr: '',
        ruzhuStr2: '用户',
        selectRoleItems: [
            {
                title: '我是织里厂家', color: 'background: #E7FCEA;', icon: '/assets/newui/icon11.svg', pageType: 'factory'
            },
            {
                title: '我是采购商', color: 'background: #FFF4E8;', icon: '/assets/newui/icon22.svg', pageType: 'buyer'
            }
        ],
        clickedTabIndex: 0,
    },
    currTabIndex: '0',
    pageName: 'home',

    onLoad(options) {
        console.log('onLoad', options);
        // if (options.login) {
        //     this.setData({ showSelectRole: true });
        // }
        page = this;

        // 隐藏本页面的转发按钮
        // wx.hideShareMenu();
        wx.showShareMenu({
            withShareTicket: false, //true,
            menus: ['shareAppMessage', 'shareTimeline']
        });

        // $tdSearchbar.init({
        //     style: 'border: none',
        //     image: false,
        //     searchHandler(text, img) {
        //         const { listIndex } = this.page.data;

        //         console.info(`text: ${text}`, `img: ${img}`);
        //         this.setData(Object.assign({}, getData(), {
        //             listIndex,
        //             filterText: text,
        //             filterImg: img,
        //         }));
        //         this.page.fetchData();
        //     }
        // });

        //...
        // this.getCircleConfigData();
        // this.getCircleVideosData();

        // wx.showLoading({
        //     mask: false,
        //     title: '加载中...',
        // });
        // this.fetchData('', () => {
        //     wx.hideLoading();
        // });


        //...
        if (!getApp().offline()) {
            // 增加测试数据;
            // setInterval(() => {
            //     circleUtil.fetchNetData({ url: "/album/album_theme_operation.jsp?act=save_theme&title=title_" + new Date().getTime() });
            // }, 2000);
        }


        // this.testCodes();
        // this.test_save_theme();

        // setInterval(() => {
        //     this.setData({ noticeIndex: this.data.noticeIndex+1})
        // }, 6000);

        //...
        // this.getConfigNotice();

    },

    onShow() {
        console.log('home onShow-------------------', this.data.list);
        const { list } = this.data;

        this.setData({ isOnLine: !app.offline() });

        this.getCircleConfigData();
        // app.globalData.currTabPageUrl = '/pages/home/index';
        // wx.showTabBar();
        this.showTabBar();
        if (list.length > 0) {
            let param = { ids: [] };
            for (let index = 0; index < list.length && index < 16; index++) {  //max is 16
                const element = list[index];
                param.ids.push(element.goods_id);
            }

            util.fetch('/circle/circle_new_interface.jsp?act=getGoodsExtInfoList', param, 'POST').then(res => {
                const { errcode, result } = res.data;
                let newData = {};

                if (errcode == 0) {
                    let extInfoList = result.list;
                    console.log('extInfoList: ', extInfoList);
                    for (let index = 0; index < extInfoList.length; index++) {
                        const ele = extInfoList[index];
                        const gIndex = this.getGoodsIndexInList(ele.goodsId);
                        if (gIndex >= 0 && (list[gIndex].commentCount != ele.commentCount || list[gIndex].shareCount != ele.shareCount)) {
                            list[gIndex].commentCount = ele.commentCount;
                            list[gIndex].shareCount = ele.shareCount;
                            newData["list[" + gIndex + "]"] = list[gIndex];
                        }
                    }
                }
                console.log('newData: ', newData);
                this.setData(newData);
            }, (err) => {
            });
        }

    },

    onReady() {
        console.log('onReady...')
        this.listComponent = this.selectComponent('#ks-combined-list');
        this.listComponent.getListData({ urlType: 'circleMoments', type: 'init', shopId: '', callback: null });
    },

    onUnload() {
        if (this._observer) this._observer.disconnect();
    },

    onTabIndexTap(e) {
        console.log('onTabIndexTap...', e.currentTarget.dataset);
        // this.openMap();
        // wx.setTabBarItem({
        //     index: 2,
        //     "pagePath": "pages/booth-video/index",
        //     "text": "旺铺111",
        //     "iconPath": "/assets/humen/v.png",
        //     "selectedIconPath": "/assets/humen/v2.png"
        // })
    },

    openMap() {
        wx.chooseLocation({
            latitude: 22.52291, // 纬度，范围为-90~90，负数表示南纬
            longitude: 114.05454,
            success(res) {
                console.log('success: ', res);
            },
            fail(res) {
                console.log('fail: ', res);
            },
        });

        return;
        wx.getLocation({
            type: 'gcj02',
            success(res) {
                const latitude = res.latitude
                const longitude = res.longitude
                console.log(res.latitude);
                console.log(res.longitude);
                wx.openLocation({
                    latitude: res.latitude + 0.01, // 纬度，范围为-90~90，负数表示南纬
                    longitude: res.longitude, // 经度，范围为-180~180，负数表示西经
                    scale: 16, // 缩放比例
                    name: "去哪儿...",
                    address: "要去的地点详细描述"
                });
            },
            fail(res) {
                console.log('fail: ', res);
            },
        });
        return;
        wx.openLocation({
            latitude: 22.52291, // 纬度，范围为-90~90，负数表示南纬
            longitude: 114.05454, // 经度，范围为-180~180，负数表示西经
            scale: 18, // 缩放比例
            name: "去哪儿...",
            address: "要去的地点详细描述..."
        });
        return;

        wx.getLocation({
            type: 'gcj02', // 默认为 wgs84 返回 gps 坐标，gcj02 返回可用于 wx.openLocation 的坐标
            success: function (res) {
                // success
                console.log(res.latitude);
                console.log(res.longitude);
                wx.openLocation({
                    latitude: res.latitude, // 纬度，范围为-90~90，负数表示南纬
                    longitude: res.longitude, // 经度，范围为-180~180，负数表示西经
                    scale: 28, // 缩放比例
                    name: "去哪儿",
                    address: "要去的地点详细描述"
                })
            }
        })
    },



    /**
     * 处理 stickbar
     */
    async startStickObserver() {
        const { customBar } = app.getCustomBarInfo();
        const top = -(customBar); //-(customBar + 45);

        this._observer = wx.createIntersectionObserver(this);
        this._observer.relativeToViewport({ top, bottom: 300 }).observe('#the-stick-watcher', (res) => {
            console.log('the-stick-watcher ', res.intersectionRatio);
            const showStickBar = res.intersectionRatio == 0;
            if (showStickBar != this.data.showStickBar) {
                this.setData({ showStickBar, stickStyle: showStickBar ? `position:fixed; top:${customBar}px;z-index: 999;` : `` });
            }
        });
        console.log('this._observer: ', this._observer);

        const ret = await circleUtil.querySingleSelector('#the-up-parter');
        // console.log('ret: ', ret);
        if (ret) {
            this._stickScrollTop = (ret.bottom - ret.top) - customBar;
            console.log('this._stickScrollTop: ', this._stickScrollTop, customBar);
        }
    },

    /*
    onPageScroll(e) {
        const { scrollTop } = e;
        const { customBar } = app.getCustomBarInfo();
        const showCustomBar = scrollTop > (180 - customBar);

        // console.log('onPageScroll: ', scrollTop);
        if (showCustomBar != this.data.showCustomBar) {
            this.setData({ showCustomBar });
        }
    },*/

    async getCircleConfigData() {
        console.log('getCircleConfigData...');
        const { isLiXiuVersion } = this.data;
        const obj = await circleUtil.getCircleConfigData();
        const { config = {}, markets = [], floors = [] } = obj;

        // if (!config.circleId) {
        //     this.setData({ netWorkError: true });
        //     return;
        // }

        //... for test
        config.circleName = '杭州主播线上选品平台';

        this.setData({ ...config, floors }, () => {
            const dynamicList = this.selectComponent('#dynamic-list');

            if (!dynamicList) {
                return;
            }
            this.setData({ dynamicList });
        });

        if (isLiXiuVersion) {
            const filters = ['108', '110', '103', '尚道中心'];
            const marketList = markets.filter(item => {
                // console.log(item.name);
                // return true;
                for (let index = 0; index < filters.length; index++) {
                    if (item.name.indexOf(filters[index]) != -1) {
                        return true;
                    }
                }
                return false;
            });
            console.log('marketList: ', marketList);
            this.setData({
                marketList
            });
        } else {
            this.setData({ marketList: markets });
        }



        const isMiniChecked = circleUtil.isMiniChecked();
        console.log('isMiniChecked: ', isMiniChecked);
        console.log('config.publish=' + config.publish);

        //...
        if (isMiniChecked) {
            this.setData({
                ruzhuStr: config.texts.str001,
                ruzhuStr2: config.texts.str001,
            });
        }
        const tabBar = this.getTabBar();
        if (tabBar) {
            if (isMiniChecked) {
                tabBar.setData({ isShowPublish: true });
            } else {
                tabBar.setData({ isShowPublish: false });
            }
        }

        if (isLiXiuVersion) {
            this.getGoodsListData();
            this.setData({}, () => {
                this.startStickObserver();
            });
        }

        //...
        this.setData({ loadingPage: false });
        // this.fetchFollowedShops();
        this.fetchNewShops();
        this.fetchVipShops();
        // if (isMiniChecked) {
        //     this.getMyCircleInfo();
        // }

        // this.fetcWxTempShops();
        if (!app.offline()) {
            // circleUtil.fetchNetData({
            //     url: `/album/att_album_mini.jsp`, method: 'POST', param: { shop_id: 'A2017040516295634599' }
            // });
        }

    },

    getMarket(ev) {
        const { dataset } = ev.currentTarget;
        const { index } = dataset;
        const { marketList } = this.data;
        const data = marketList[index];

        console.info(dataset, data);
        return data;
    },

    marketTap(ev) {
        const { market_id, name } = this.getMarket(ev);
        wx.navigateTo({
            url: `/pages/market-shops/index?market_id=${market_id}&title=${name}`
        });
    },

    floorTap(ev) {
        const market_id = 'CBIZM20210621001';
        const { index } = ev.currentTarget.dataset;
        console.log('floorTap: ', index);
        wx.navigateTo({
            // url: `/pages/market-shops/index?market_id=${market_id}`
            url: `/pages/market-shops/index?floorIndex=${index}`
        });
    },

    marketTap111(ev) {
        const { market_id } = this.getMarket(ev);
        // const url = `/pages/market/index?market_id=${market_id}`;

        // console.info('market', url);
        // url && wx.navigateTo({ url });
        console.log('market_id: ', market_id);

        const url = `https://www.wsxcme.com/service/circle/miniapp_circle_main2.jsp?act=get_market_store&market_id=${market_id}&search_img=&page_index=1&token=RjU4QTZGNUQ2Qzc5OUQ0MjVFQzY5NkFBODZFNzFDNzE5OThEMDI1RjI3RTc4MDUwNjgwRkQ2QjVBMkRBN0EwN0I5NkM5Rjk4REYzRkRBMjhDMDMwOUNDNTI4NEI4MjJGQ0JBNTk2RUU3OTM2RENFOTM5RjMwODY1MzMxNDY0RjA%3D&client_type=miniapp&version=199&circle_id=CBIZ000001`;

        wx.request({
            url,
            success: res => {
                const { result = {} } = res.data;
                const { shop_list = [] } = result;
                console.log(result);

                if (shop_list.length > 0) {
                    let newList = [];
                    for (let index = 0; index < shop_list.length; index++) {
                        const element = shop_list[index];
                        for (let j = 0; j < element.length; j++) {
                            let leimu = '' + Math.floor(Math.random() * (8 - 1 + 1) + 1);
                            element[j].leimu = leimu.padStart(2, '0');
                            newList.push(element[j]);
                        }
                    }
                    this.addBatchShops(market_id, newList);
                }
            }
        });
    },

    async addBatchShops(market_id, shop_list) {
        console.log('addBatchShops: ', market_id, shop_list);

        const param = {
            shop_list: JSON.stringify(shop_list)
        };
        const method = 'POST';
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url: `/circle/circle_new_interface.jsp?act=addBatchShops&market_id=${market_id}`, method, param });
        console.log('addBatchShops, result: ', result);
    },

    /**
     * @description 获取市场列表
     * @param {*} type
     */
    async getMarketListData() {
        console.log('getMarketListData');
        const url = '/circle/circle_new_interface.jsp?act=subscribeMessage';

        // this.setData({ loading: true });
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url });

        if (isOk) {
            console.log('result: ', result);
            this.setData({ marketList: result });
        }
    },

    /**
     * @description 获取分类（商品）信息列表
     * @param {*} type
     */
    getGoodsListData(type) {
        console.log('getGoodsListData, type=', type);
        const url = this.getUrl(type);

        this.setData({ loading: true });
        let param = {
            search_value: this.data.filterText
        };
        let extInfo = { type };
        circleUtil.fetchNetData({ url, param, extInfo }, this.onGoodsListDataFetched);
    },

    /**
     * @description 处理网络商品列表数据
     * @param {*} isok
     * @param {*} result
     * @param {*} { type = '' }
     * @returns
     */
    onGoodsListDataFetched(isok, result, { type = '' }) {
        let obj = {};

        wx.hideLoading();
        if (type == 'top') {
            wx.stopPullDownRefresh();
        }
        if (!isok) {
            obj.loading = false;
            this.setData(obj);
            return;
        };

        const { goods_list, ...others } = result;
        const { list, filterText, navList } = this.data;

        obj = { ...this.data, ...others };
        if (type == 'top') {
            obj.list = this.getNoRepeatData(goods_list, list);
        } else {
            obj.list = [...list, ...goods_list];
            // 到底了
            goods_list.length <= 0 && (obj.loadingEnd = true);
        }
        //这里的处理暂时屏蔽掉
        // obj.list = obj.list.map(item => {
        //     return {
        //         rows: constant.ROWS,
        //         richTitle: '', //!!filterText ? util.getRichTitle(item.title, filterText) : undefined,
        //         // categoryTitle: navList[item.category].title,
        //         ...item
        //     };
        // });
        // console.log('obj.list: ', obj.list);
        // 无数据
        if (obj.list.length <= 0) {
            obj.loadingNoData = true;
        } else {
            obj.loadingNoData = false;
        }
        obj.latestTime = this.getLatestTime(obj.list);
        obj.loading = false;

        this.setData(obj);
    },


    fetchData(type, callback) {
        const url = this.getUrl(type);

        console.log('fetchData, url ', url, type);
        this.getGoodsListData(type);
    },


    onTitleTap(data) {
        const item = this.data.list[data.index];
        console.log('onTitleTap...', data, item);
        wx.navigateTo({
            url: `/pages/goods_detail/index?shop_id=${item.shop_id}&goods_id=${item.goods_id}`
        });
    },

    getGoodsIndexInList(goodsId) {
        const { list } = this.data;
        for (let index = 0; index < list.length; index++) {
            if (list[index].goods_id == goodsId) {
                return index;
            }
        }
        return -1;
    },

    showTabBar() {
        if (typeof this.getTabBar === 'function' && this.getTabBar()) {
            this.getTabBar().setData({
                selected: 0
            });
        }
    },



    navTap(ev) {
        const { index } = ev.target.dataset;
        const { listIndex, filterText, filterImg } = this.data;

        if (index == listIndex) {
            return false;
        }

        console.info('nav', index);
        wx.showLoading({
            mask: true,
            title: '加载中...',
        });
        this.setData(Object.assign({}, getData(), {
            listIndex: index,
            filterText,
            filterImg,
        }));
        this.fetchData('', () => {
            wx.hideLoading();
        });
    },

    // onShareAppMessage(res) {
    //     console.log('onShareAppMessage...', res);
    //     return {
    //         title: '深圳南油服装批发商圈',
    //         path: '/pages/home/index'
    //     };
    // },

    // onShareTimeline(){
    //     return {
    //         title: '深圳南油服装批发商圈',
    //         path: '/pages/home/index'
    //     };
    // },

    // onShareAppMessage111(res) {
    //     const { list } = this.data;
    //     const length = list.length;
    //     let path = '';
    //     let title = '';
    //     let imageUrl = '';

    //     console.log("onShareAppMessage:" + length);

    //     if (res.from === 'button') {
    //         // 来自页面内转发按钮
    //         console.log(res.target);

    //         if (res.target.id == "circle-share-btn") {
    //             const { index } = res.target.dataset;
    //             const goods = list[index];
    //             const { shop_id, goods_id, imgsSrc, share_shop_id, share_goods_id } = goods;

    //             title = goods.title;
    //             path = `pages/goods_detail/index?goods_id=${share_goods_id || goods_id}&shop_id=${share_shop_id || shop_id}`;
    //             imageUrl = imgsSrc[0] || '';

    //             util.fetchAuthInst('/circle/circle_new_interface.jsp?act=addShareCount',
    //                 { goods_id: goods_id },
    //                 res => { },
    //                 err => { });

    //             return {
    //                 title,
    //                 path: path,
    //                 imageUrl
    //             };
    //         }
    //     }


    //     if (this.shareIndex >= 0 && this.shareIndex < length) {
    //         const goods = list[this.shareIndex];
    //         const { shop_id, goods_id, imgsSrc, share_shop_id, share_goods_id } = goods;

    //         title = goods.title;
    //         path = `pages/goods_detail/index?goods_id=${share_goods_id || goods_id}&shop_id=${share_shop_id || shop_id}`;
    //         imageUrl = imgsSrc[0] || '';
    //     }
    //     this.shareIndex = -1;

    //     return {
    //         title: title,
    //         path: path,
    //         imageUrl
    //     };
    // },

    getTimestamp() {
        const { list, latestTime } = this.data;
        const len = list.length;

        if (len > 0) {
            return {
                top: latestTime,
                bottom: list[len - 1].time_stamp
            };
        } else {
            return {
                top: '',
                bottom: ''
            };
        }
    },

    getUrl(type) {
        const { listIndex, getUrl, filterText, filterImg } = this.data;
        const { top, bottom } = this.getTimestamp();
        let url = `${getUrl[listIndex]}&search_img=${filterImg}`;
        let category = this.currTabIndex;
        //for test
        if (category == '6') {
            url = `${getUrl[2]}&search_img=${filterImg}`;
        }

        switch (type) {
            case 'top':
                url = `${url}&slip_type=0&time_stamp=${top || ''}`;
                break;

            case 'bottom':
                url = `${url}&slip_type=1&time_stamp=${bottom || ''}`;
                break;
        }
        url += `&category=${category}`;
        return url;
    },



    getNoRepeatData(newData, oldData) {
        const data = [...newData, ...oldData];
        const len = data.length;
        const hash = {};
        const result = [];

        for (let i = 0; i < len; i++) {
            let goods = data[i];
            let goods_id = goods.goods_id;

            if (!hash[goods_id]) {
                hash[goods_id] = true;
                result.push(goods);
            } else {
                hash[goods_id].shareCount = goods.shareCount;
            }
        }

        // console.info(result);
        return result;
    },

    getLatestTime(data) {
        return data.map(item => item.time_stamp).filter(item => item)[0] || '';
    },


    onReachBottom: function () {
        this.listComponent.getListData({ urlType: 'circleMoments', type: 'bottom', shopId: '' });
        return;
        const { dynamicList } = this.data;
        if (dynamicList) {
            dynamicList.onReachBottom();
        }
    },

    // onReachBottom() {
    //     const { loading, loadingNoData, loadingEnd, isLiXiuVersion } = this.data;

    //     console.log("onReachBottom ", loading, loadingNoData, loadingEnd);
    //     if (loading || loadingNoData || loadingEnd) {
    //         return false;
    //     }

    //     if (isLiXiuVersion) {
    //         this.fetchData('bottom');
    //     }
    // },

    onPullDownRefresh() {
        wx.hideLoading();
        // const { loading, isLiXiuVersion } = this.data;

        // if (loading) {
        //     return false;
        // }
        console.log("onPullDownRefresh...");
        this.listComponent.getListData({ urlType: 'circleMoments', type: 'top', shopId: '' });
        setTimeout(() => {
            wx.stopPullDownRefresh();
        }, 300);
        return;

        if (isLiXiuVersion) {
            this.fetchData('top', () => {
                console.log("stopPullDownRefresh");
                wx.stopPullDownRefresh();
            });
        } else {
            setTimeout(() => {
                wx.stopPullDownRefresh();
            }, 200);
        }

    },

    getJumpLink() {
        let access_token = "40_kdiwIvjco04iBu6F2GMMjrXCpFGHNWOaet3ZR49tJ2R3BYAYj09UWmfPRS5QPpGRjA1V1s8gf1EFZ0mfD7C5inawAH8DTpoRJrq3D1qEZsckYQTln08VUMIawu7Kx7ngaRNIYeJ8qAsaEO9OIRPeACALUS";
        let method = 'POST';
        let jump_wxa = { path: "/pages/follow_detail/index", query: "shop_id=A201805111026533690115" };
        let data = { jump_wxa };
        wx.request({
            url: `https://api.weixin.qq.com/wxa/generatescheme?access_token=${access_token}`,
            data,
            // header: { 'Content-Type': 'application/x-www-form-urlencoded' },
            method,
            success: () => { }
        });
    },

    toGoodsEditPage() {
        if (app.offline()) {
            circleUtil.showLoginModal();
            return;
        }
        wx.showActionSheet({
            itemList: ['商品', '求购', '拼单', '二手', '招聘', '出租/转让'],
            success: res => {
                console.log(res.tapIndex);
                wx.setStorage({
                    key: 'goods_edit',
                    data: 'home_add',
                });
                const { list } = this.data;
                wx.navigateTo({
                    url: '/pages/goods_edit/index?category=' + res.tapIndex,
                    events: {
                        // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
                        acceptDataFromOpenedPage: data => {
                            // console.log('acceptDataFromOpenedPage ', data);
                            if (list) {
                                list.unshift(data);
                                this.setData({ list });
                            }
                        },
                    },
                });
            },
            fail(res) {
                console.log(res.errMsg);
            }
        });

    },

    onTopTabEvent(e) {
        console.log('onTopTabEvent', e.detail, this.currTabIndex);
        //return;
        if (this.currTabIndex != e.detail.key) {
            this.currTabIndex = e.detail.key;
            console.log('currTabIndex ', this.currTabIndex);
            // wx.showLoading({
            //     mask: true,
            //     title: '加载中...',
            // });
            this.setData({
                loadingEnd: false,
                loadingNoData: false,
                //list: []
            });
            this.data.list = [];
            //...
            util.abortCurrRequestTask();
            this.fetchData('', () => {
                wx.hideLoading();
            });

            //...
            const { showStickBar } = this.data;
            if (showStickBar && this._stickScrollTop > 0) {
                wx.pageScrollTo({
                    scrollTop: this._stickScrollTop + 1,
                    duration: 0,
                    success: () => {
                        //const showStickBar = false;
                        //this.setData({ showStickBar, stickStyle: `` });
                    }
                });
            }

        }
    },

    onLeiMuItemTap(e) {
        let index = e.target.dataset.index;

        console.log('onLeiMuItemTap ', index);
        let leimu = (index + 1);
        leimu = leimu <= 9 ? `0${leimu}` : leimu;
        wx.navigateTo({
            url: '/pages/shop-list/index?leimu=' + leimu,
        });
    },

    onLeiXingItemTap(e) {
        let index = e.target.dataset.index;

        console.log('onLeiXingItemTap ', index);
        wx.navigateTo({
            url: '/pages/shop-list/index?leixing=' + (index + 1),
        });
    },

    onBuildingItemTap(e) {
        let index = e.target.dataset.index;

        console.log('onBuildingItemTap ', index);
        wx.navigateTo({
            url: '/pages/shop-list/index?building=' + (index + 1),
        });
    },

    onCircleShare(e) {
        console.log('onCircleShare, ', e);
    },

    previewImgs(e) {
        this.setData({
            showPreviewer: true,
            ...e.detail,
        }, () => {
            this.data.showPreviewer && util.navigateToBrowserPage();
        });
    },

    swiperTap(ev) {
        // wx.navigateTo({ url: "/pages/customer-radar/index?url=" });
        // return;

        const { dataset } = ev.currentTarget;
        const { url } = dataset;
        const url111 = "/pages/webview/index?url=" + encodeURIComponent(url);

        console.info('swiper', dataset);
        url111 && wx.navigateTo({ url: url111 });
    },

    bottomBannerTap() {
        const { banner } = this.data;
        // console.log('banner: ', banner);
        let jumpUrl = 'https://mp.weixin.qq.com/s/eMV76IAiur7ABB89SMOP3g';
        if (banner.length >= 6) {
            jumpUrl = banner[5].url;
        }
        const url111 = "/pages/webview/index?url=" + encodeURIComponent(jumpUrl);
        wx.navigateTo({ url: url111 });
    },

    onPersonalTap() {
        wx.navigateTo({ url: "/pages/wxme/index" });
    },

    // onSendNewCommet(){
    //     console.log('onSendNewCommet...');
    // },

    joinCircleTap() {
        wx.navigateTo({ url: '/pages/personal-info/index?scene=10001' });
    },

    joinCircleTap2() {
        if (app.offline()) {
            circleUtil.gotoLoginPage('home-woyaoruzhu');
            return;
        }

        wx.navigateTo({ url: '/pages/personal-info/index?scene=10001' });
        // wx.navigateTo({ url: '/pages/circle-contact/index?pageType=factory' });
        return;


        const url111 = "/pages/webview/index?url=" + encodeURIComponent('https://mp.weixin.qq.com/s/MK5BDlNxBp6FaN4L7heP1g');
        url111 && wx.navigateTo({ url: url111 });
    },

    onSelectItemTap(e) {
        const { selectRoleItems } = this.data;
        const { index } = e.currentTarget.dataset;
        console.log('onSelectItemTap ', index);
        selectRoleItems[0].checked = 0;
        selectRoleItems[1].checked = 0;
        selectRoleItems[index].checked = true;
        this.setData({ selectRoleItems }, () => {
            if (this._selectRoleTimer) {
                clearTimeout(this._selectRoleTimer);
                this._selectRoleTimer = null;
            }
            this._selectRoleTimer = setTimeout(() => {
                this.setData({
                    showSelectRole: false
                });
                wx.navigateTo({ url: '/pages/circle-contact/index?pageType=' + selectRoleItems[index].pageType });
            }, 500);
        });
    },

    onGongHuoTap() {
        this.setData({
            showSelectRole: false
        });
        wx.navigateTo({ url: '/pages/circle-contact/index?pageType=factory' });
        // wx.navigateTo({ url: '/pages/personal-info/index?scene=10001' });
    },

    onCaiGouTap() {
        this.setData({
            showSelectRole: false
        });
        wx.navigateTo({ url: '/pages/circle-contact/index?pageType=buyer' });
    },


    contactUsTap(ev) {
        const { phone_number: phoneNumber } = this.data;

        wx.makePhoneCall({
            phoneNumber,
            fail: res => {
                const { errMsg } = res;

                console.info(res);
                !errMsg.match(/cancel/) &&
                    wx.showToast({
                        title: '呼叫失败，请稍后重试~',
                        icon: 'none',
                    });
            }
        });
    },

    getShopAddress(marketList, shop) {
        let address = '';
        for (let index = 0; index < marketList.length; index++) {
            const element = marketList[index];
            if (element.market_id == shop.building) {
                address += element.short_name;
                break;
            }
        }
        // address += shop.floor.split('|')[1] + shop.booth;
        address += shop.booth;
        return address;
    },

    async fetchFollowedShops() {
        if (app.offline()) {
            return;
        }
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url: `/circle/circle_new_interface.jsp?act=getFollowedShops` });
        const { marketList } = this.data;

        // wx.hideLoading();
        console.log('fetchFollowedShops, result: ', result);
        // console.log('marketList: ', marketList);

        if (isOk) {
            const { shop_list } = result;
            for (let index = 0; index < shop_list.length; index++) {
                const shop = shop_list[index];
                shop.address = this.getShopAddress(marketList, shop); //shop.floor.split('|')[1] + shop.booth;
            }
            this.setData({ followed_booths: shop_list });
        }
    },

    async fetchNewShops() {
        let new_booths = await circleData.getNewShops();

        if (new_booths.length > 0) {
            this.setData({ new_booths });
        }
    },

    async fetchVipShops() {
        let shop_list = await circleData.getVipShops();

        if (shop_list.length > 0) {
            this._vipList = shop_list;
            this.setData({ vip_booths: shop_list.slice(0, 15) });
        }
    },

    flashVipShops() {
        if (!this._vipList || this._vipList.length < 15) {
            return;
        }
        const offset = Math.floor(Math.random() * (this._vipList.length - 1));
        const vip_booths = [];
        for (let index = 0; index < 15; index++) {
            const element = this._vipList[(index + offset) % this._vipList.length];
            vip_booths.push(element);
        }
        this.setData({ vip_booths });
    },

    async fetcWxTempShops(new_list) {
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url: `/circle/circle_new_interface.jsp?act=getWxTempShops` });

        console.log('fetcWxTempShops, result: ', result);

        if (isOk) {
            const { shop_list } = result;
            for (let index = 0; index < shop_list.length; index++) {
                const shop = shop_list[index];
                shop.address = '富民时装城'; //'朋友圈';
            }
            const new_booths = new_list.concat(shop_list);
            // this.setData({ new_booths, temp_booths: shop_list });
            this.setData({ new_booths });
        }
    },

    async getConfigNotice() {
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url: `/circle/circle_new_interface.jsp?act=getConfigNotice` });


        if (isOk) {
            const { jsonStr } = result;
            const notices = JSON.parse(jsonStr);
            // console.log('getConfigNotice, notices: ', notices);
            this.setData({
                notices
            });
        }
    },

    async getMyCircleInfo() {
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url: `/circle/circle_new_interface.jsp?act=getMyCircleInfo` });
        console.log('getMyCircleInfo: ', isOk, result);

        if (isOk) {
            if (result.isLogin) {
                //...
                const { apply, buyer, factory, isBusiness } = result;
                if (isBusiness) {
                    this.setData({ showWoYaoRuzhu: false });
                } else {
                    this.setData({ showWoYaoRuzhu: true });
                }
                if (!apply && !buyer && !factory) {
                    this.setData({ showSelectRole: true });
                }
            } else {
                this.setData({ showWoYaoRuzhu: true });

                let albumInfo = wx.getStorageSync(constant.USER_INFO_STORAGE);
                if (albumInfo) {
                    //token expire...
                    // console.log('app.globalData.userInfo: ', app.globalData.userInfo);
                    app.globalData.userInfo.tokenExpired = true;
                    console.log('tokenExpired...');
                    // wx.removeStorageSync(constant.USER_INFO_STORAGE);
                }
            }

        } else {
            this.setData({ showWoYaoRuzhu: true });
        }



    },


    followedDynamicTap() {
        console.log('followedDynamicTap...');
        wx.navigateTo({
            url: '/pages/dynamic_followed/index?from=followedDynamicTap',
        });
    },

    boothsTap(ev) {
        if (!circleUtil.isMiniChecked() && app.offline()) {
            return;
        }
        const { dataset } = ev.currentTarget;
        const { shopId, wxid } = dataset;

        //to wx moment show
        if (wxid) {
            const url = '/pages/personal-album/index?wxid=' + dataset.wxid;
            wx.navigateTo({
                url
            });
        } else {
            // const url = `/pages/follow_detail/index?shop_id=${shopId}`;
            // console.info('boothsTap: ', dataset, url);
            circleUtil.onShopItemTap(shopId, true);
        }

    },


    onSearchBarTap() {
        console.log('onSearchBarTap...');
        wx.navigateTo({
            url: `/pages/search-page/index`
        });
    },

    onThemeTagChanged(e) {
        const { index } = e.detail;
        console.log('onThemeTagChanged...', index);
        this.setData({
            themeTag: index
        });
    },

    onScrollToTap() {

        if (app.offline()) {
            circleUtil.gotoLoginPage('home-woyaoruzhu');
            return;
        }

        wx.navigateTo({ url: '/pages/circle-contact/index?pageType=finder' });
        return;

        var me = this;
        var query = wx.createSelectorQuery().in(me);
        query.selectViewport().scrollOffset();
        query.select("#scorllId001").boundingClientRect();
        query.exec(res => {
            console.log(res);
            var miss = res[0].scrollTop + res[1].top - res[1].height;
            wx.pageScrollTo({
                scrollTop: miss,
                duration: 300
            });

        });
    },

    onSwitchTabTap() {
        wx.switchTab({
            url: '/pages/category/index'
        });
    },

    onSearchConfirm(e) {
        console.log('onSearchConfirm: ', e);
        const {
            inputVal, searchImg
        } = e.detail;

        this.setData({ filterText: inputVal });



    },


    test_save_theme() {
        const token = "RjkxMjUwNUYyQUI3MjBFM0I1RTk5RjdBMTBENTNCQUZCQjYzN0JGODY0MTNCRDM1RkEyNEUwNEQxNTRDM0UwRjQ4NzNERDgwRUY0QUU0OEFGOTIzNDg4RjA0RTJFNURD";
        // let url = `http://10.20.1.100:8080/service/album/album_theme_operation.jsp?act=save_theme_old&title=777&token=${token}`;
        const title = "title  " + Math.random();
        let url = `https://www.wsxcme.com/service/circle/circle_new_interface.jsp?act=save_theme_old&title=${title}&token=${token}`;

        // const dev_token =`NkZGN0YwNkVEMzQ0OTI1QzA2QzIyMTIyRjFGMUJGMjdDRkVBQTU4MTFDRDFBOTU0N0MwNkIzNjlBNjMzOEM1NDA2RTY5M0YxRjg1NUYwODc2ODIzRDNBNjk5OTA0RjBE`
        // let url = `http://localhost:8080/service/circle/circle_new_interface.jsp?act=save_theme_old&title=777&token=${dev_token}`;

        url += `&videoImg=${encodeURIComponent("https://xcimg.szwego.com/o_1fdcsj6631ldqhqmv9s2501u5vn.mp4?vframe/jpg/offset/0")}`;
        url += `&videoUrl=${encodeURIComponent("https://xcimg.szwego.com/o_1fdcsj6631ldqhqmv9s2501u5vn.mp4")}`;
        url += `&themeType=1`;
        console.log("test_save_theme, url: ", url);
        wx.request({
            url, //仅为示例，并非真实的接口地址
            method: 'GET',
            success(res) {
                console.log(res.data);
            }
        });
    },


    testCodes() {
        let param = {
            name: 'name ' + Math.random(),
            imgUrls: 'https://xcimg.szwego.com/20201227/i1609063581_9666_0.jpg,https://xcimg.szwego.com/20201227/i1609063581_9666_0.jpg',
            title: '注意  course 的编码仍然为 latin1 ，虽然此时表的编码已经是 utf8 , 但是不知道为什么 列的编码没有更改过来下面就是更改列的编码即可',
        };
        let postData = [
            {
                uid: '111',
                wxid: 'wx001',
                title: '三膏标题名3333333333333',
                createTime: Date.now(),
                imgUrls: ['http://img/dasda111', 'http://img/dasda111'], //JSON.stringify(['http://img/dasda111', 'http://img/dasda111']),
                videoUrl: 'http://video/dasda111',
                videoThumb: 'http://video/videoThumb',
            }
        ];
        // wx.request({
        //     url: 'https://www.wsxcme.com/service/circle/circle_new_interface.jsp?act=getWxMoments&wxid=wx001', //仅为示例，并非真实的接口地址
        //     method: 'GET',
        //     success(res) {
        //         console.log(res.data);
        //     }
        // })
        wx.request({
            url: 'http://localhost:8080/service/circle/circle_new_interface.jsp?act=addWxMoments', //仅为示例，并非真实的接口地址
            method: 'POST',
            data: postData,
            header: {
                'content-type': 'application/json' // 默认值
            },
            success(res) {
                console.log(res.data);
            }
        });
        // wx.request({
        //     url: 'http://www.szwego.com/service/circle/circle_new_interface.jsp?act=addWxBaseInfo', //仅为示例，并非真实的接口地址
        //     method: 'POST',
        //     data: {
        //         wxid: "1111",
        //         nickName: "21212",
        //         headUrl:"http1111111111111"
        //     },
        //     header: {
        //         'content-type': 'application/json' // 默认值
        //     },
        //     success(res) {
        //         console.log(res.data)
        //     }
        // })
        return;
        util.fetch('/circle/circle_new_interface.jsp?act=addGoods', param, 'POST').then(res => {
            console.log("res ", res);
        }, (err) => {
            console.log("err ", err);
        });
        return;

        util.fetch('/circle/circle_new_interface.jsp?act=addGoods', param, 'POST').then(res => {
            console.log("res ", res);
        }, (err) => {
            console.log("err ", err);
        });

        util.fetch('/circle/circle_new_interface.jsp?act=getGoodsListByPage&start=0', param).then(res => {
            const { errcode, result, errmsg } = res.data;
            if (errcode == 0) {
                const { goods_list, ...others } = result;
                console.log("goods_list: ", goods_list, others);
            } else {
                wx.showToast({
                    title: errmsg,
                    duration: 1500
                });
            }

        }, (err) => {
            console.log("err ", err);
        });

        // util.fetch('/circle/circle_new_interface.jsp?act=getUserId', {}, 'POST').then(res => {
        //     console.log("res ", res);
        // }, (err) => {
        //     console.log("err ", err);
        // });
    },



});





