import { $tdSearchbar, $tdUploader, $wuxToast } from '../../components/wux';
import nineGrid from '../../utils/nine-grid';

const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const constant = require('../../utils/constant');
const app = getApp();
const circleVideosUrl = '/circle/circle_new_interface.jsp?act=findAllVideos';

function getData() {
    return {
        tabbar: {},
        loading: false,
        loadingNoData: false, // 无数据
        loadingEnd: false, // 到底了
        filterText: '',
        filterImg: '',
        latestTime: '',
        listIndex: 0,
        list: [],
        navs: [{ label: '已关注' }, { label: '广场' }],
        priceTypesObj: constant.priceTypesObj,

        indicatorDots: true,
        vertical: false,
        user_type: 1,
        updateSticky: false,
    };
}

Page(Object.assign({}, nineGrid, {
    data: {
        ...getData(),
        navList: [{ title: '档口' }, { title: '动态' }],
        videoList: [],
        showCustomBar: true,
        showStickBar: false,
        stickStyle: '',
        topNavCurrent: 0,
        videoNavList: ['档口', '动态'], //['最新', '热门', '推荐'],
        titleNavList: ['店铺封面', '广场动态'],
    },
    stickTabIndex: '0',
    pageName: 'home',

    onLoad(options) {
        console.log('discovery onLoad', options);
        const { customBar } = app.getCustomBarInfo();
        this.setData({ showStickBar: true, stickStyle: `position:fixed; top:${customBar}px;z-index: 999;` });

        // 隐藏本页面的转发按钮
        // wx.hideShareMenu();
        wx.showShareMenu({
            withShareTicket: false, //true,
            menus: ['shareAppMessage', 'shareTimeline']
        });

        $tdSearchbar.init({
            style: 'border: none',
            image: false,
            searchHandler(text, img) {
                const { listIndex } = this.page.data;

                console.info(`text: ${text}`, `img: ${img}`);
                this.setData(Object.assign({}, getData(), {
                    listIndex,
                    filterText: text,
                    filterImg: img,
                }));
                this.page.getGoodsListData();
            }
        });

        if (getApp().offline()) {
            return;
        }

        //...
        setTimeout(() => {
            this.getCircleConfigData();
            // this.getCircleVideosData();
            // this.getGoodsListData();
        }, 100);

    },

    onShow() {
        if (getApp().offline()) {
            circleUtil.showLoginModal();
            return;
        }

        // wx.showTabBar();
        this.showTabBar();
    },


    onUnload() {
        if (this._observer) this._observer.disconnect();
    },

    async getCircleVideosData() {
        console.log('getCircleVideoData...');
        wx.showLoading({
            mask: true,
            title: '加载中...',
        });
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url: circleVideosUrl, param: { circle_id: 'CID000001' } });
        wx.hideLoading();
        if (isOk) {
            this._videoList = result;
            this.setData({
                videoList: this._videoList
            });
        }
    },

    async getCircleConfigData() {
        let circleInfo = await circleUtil.getCircleConfigData();
        const { config } = circleInfo;
        this.setData(circleInfo.config);
        //...
        const tabBar = this.getTabBar();
        if (tabBar) {
            const isShowPublish = circleUtil.isMiniChecked();
            this.setData({ isShowPublish });
        }
    },


    /**
     * @description 获取分类（商品）信息列表
     * @param {*} type
     */
    async getGoodsListData(type) {
        console.log('getGoodsListData, type=', type);
        const { loading } = this.data;

        if (loading) {
            console.log('!!! loading=', loading);
            return;
        }

        const url = this.getUrl(type);

        this.setData({ loading: true });
        let param = {
            search_value: this.data.filterText
        };
        let extInfo = { type };

        //...start fetchNetData
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url, param, extInfo });
        let obj = {};

        wx.hideLoading();
        if (type == 'top') {
            wx.stopPullDownRefresh();
        }
        if (!isOk) {
            obj.loading = false;
            this.setData(obj);
            return;
        };
        const { goods_list, ...others } = result;
        const { list } = this.data;

        obj = { ...this.data, ...others };
        if (type == 'top') {
            obj.list = this.getNoRepeatData(goods_list, list);
        } else {
            obj.list = [...list, ...goods_list];
            // 到底了
            goods_list.length <= 0 && (obj.loadingEnd = true);
        }
        // 无数据
        if (obj.list.length <= 0) {
            obj.loadingNoData = true;
        } else {
            obj.loadingNoData = false;
        }
        obj.latestTime = this.getLatestTime(obj.list);
        obj.loading = false;

        this.setData(obj);
    },

    onTitleTap(data) {
        const item = this.data.list[data.index];
        console.log('onTitleTap...', data, item);
        wx.navigateTo({
            url: `/pages/goods_detail/index?shop_id=${item.shop_id}&goods_id=${item.goods_id}`
        });
    },

    getGoodsIndexInList(goodsId) {
        const { list } = this.data;
        for (let index = 0; index < list.length; index++) {
            if (list[index].goods_id == goodsId) {
                return index;
            }
        }
        return -1;
    },

    showTabBar() {
        if (typeof this.getTabBar === 'function' && this.getTabBar()) {
            this.getTabBar().setData({
                selected: 2
            });
        }
    },

    getTimestamp() {
        const { list, latestTime } = this.data;
        const len = list.length;

        if (len > 0) {
            return {
                top: latestTime,
                bottom: list[len - 1].time_stamp
            };
        } else {
            return {
                top: '',
                bottom: ''
            };
        }
    },

    getSearchDate() {
        const d = new Date();
        const yy = d.getFullYear();
        const mm = (d.getMonth() + 1) + '';
        const dd = (d.getDate() - 2) + '';
        return `start_date=${yy}-${mm.padStart(2, '0')}-${dd.padStart(2, '0')}`;
        // return 'start_date=2021-03-11&end_date=2021-03-12';
    },

    getUrl(type) {
        const { filterText, filterImg } = this.data;
        const { top, bottom } = this.getTimestamp();
        let url = ''; //`${getUrl[listIndex]}&search_img=${filterImg}`;
        let category = this.stickTabIndex;
        let baseUrl = '';
        //for test
        if (category == '0') {
            baseUrl = `/circle/circle_new_interface.jsp?act=get_circle_themes_plaza&${this.getSearchDate()}`;
        } else {
            baseUrl = '/circle/circle_new_interface.jsp?act=getGoodsListByPage';
        }
        url = `${baseUrl}&search_img=${filterImg}`;

        switch (type) {
            case 'top':
                url = `${url}&slip_type=0&time_stamp=${top || ''}`;
                break;

            case 'bottom':
                url = `${url}&slip_type=1&time_stamp=${bottom || ''}`;
                break;
        }
        url += `&category=${category}`;
        return url;
    },

    getNoRepeatData(newData, oldData) {
        const data = [...newData, ...oldData];
        const len = data.length;
        const hash = {};
        const result = [];

        for (let i = 0; i < len; i++) {
            let goods = data[i];
            let goods_id = goods.goods_id;

            if (!hash[goods_id]) {
                hash[goods_id] = true;
                result.push(goods);
            }
        }

        // console.info(result);
        return result;
    },

    getLatestTime(data) {
        return data.map(item => item.time_stamp).filter(item => item)[0] || '';
    },

    onReachBottom() {
        const { loading, loadingNoData, loadingEnd } = this.data;

        console.log("onReachBottom ", loading, loadingNoData, loadingEnd);
        if (loading || loadingNoData || loadingEnd) {
            return false;
        }

        this.getGoodsListData('bottom');
    },

    onPullDownRefresh() {
        const { topNavCurrent } = this.data;

        //暂时只支持动态下拉刷新
        if (topNavCurrent == 1) {
            wx.hideLoading();
            const { loading } = this.data;

            if (loading) {
                return false;
            }

            console.log("onPullDownRefresh");
            this.getGoodsListData('top', () => {
                console.log("stopPullDownRefresh");
                wx.stopPullDownRefresh();
            });
        } else {
            setTimeout(() => {
                wx.stopPullDownRefresh();
            }, 300);
        }

    },


    previewImgs(e) {
        console.log("discovery previewImgs....");
        this.setData({
            showPreviewer: true,
            ...e.detail,
        }, () => {
            this.data.showPreviewer && util.navigateToBrowserPage();
        });
    },

    swiperTap(ev) {
        const { dataset } = ev.currentTarget;
        const { url } = dataset;
        const url111 = "/pages/webview/index?url=" + url;

        console.info('swiper', dataset);
        url111 && wx.navigateTo({ url: url111 });
    },

    onTitleNavTap(e) {
        const { index } = e.currentTarget.dataset;

        this.switchTitleNav(index);
    },

    switchTitleNav(index) {
        app.globalData.discoveryIndex = index;
        this.setData({ topNavCurrent: index });

        if (index == 1) {
            this.setData({ list: [] }, () => {
                this.getGoodsListData();
            });
            // const { list } = this.data;
            // if (list.length <= 0) {
            //     this.getGoodsListData();
            // }
        }
    },

    switchStickTabNav(index) {
        if (this.stickTabIndex != index) {
            this.stickTabIndex = index;
            app.globalData.discoveryCategory = index;
            console.log('stickTabIndex ', this.stickTabIndex);
            // wx.showLoading({
            //     mask: true,
            //     title: '加载中...',
            // });
            this.setData({
                loadingEnd: false,
                loadingNoData: false,
                list: []
            });
            // this.data.list = [];
            //...
            util.abortCurrRequestTask();
            this.getGoodsListData('', () => {
                wx.hideLoading();
            });

            //...
            const { showStickBar } = this.data;
            if (showStickBar && this._stickScrollTop > 0) {
                wx.pageScrollTo({
                    scrollTop: this._stickScrollTop + 1,
                    duration: 0,
                    success: () => {
                        //const showStickBar = false;
                        //this.setData({ showStickBar, stickStyle: `` });
                    }
                });
            }
        }
    },

    onStickTabEvent(e) {
        console.log('onStickTabEvent', e.detail, this.stickTabIndex);
        this.switchStickTabNav(e.detail.key);
    },


}));
