import { $wuxToast } from '../../components/wux';

const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const getApplyListUrl = '/circle/circle_new_interface.jsp?act=getApplyList';
const updateApplyUrl = '/circle/circle_new_interface.jsp?act=updateApplyInfo';

Page({
    data: {
        applyList: []
    },

    onLoad(options) {
        console.info('onLoad', options);

        this.getApplyList();
    },

    onFansTap(e) {
        const { applyList } = this.data;
        const { index } = e.currentTarget.dataset;
        console.log('onFansTap...', index);
        wx.navigateTo({
            url: '/pages/personal-info/index?disableEdit=1&scene=10001',
            events: {
                // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
                acceptDataFromPersonalPage: data => {
                    console.log('acceptDataFromPersonalPage: ', data);
                    for (let index = 0; index < applyList.length; index++) {
                        const element = applyList[index];
                        if (element.shopId == data.shopId){
                            element.status = data.status;
                            break;
                        }
                    }
                    this.setData({ applyList });
                },
            },
            success: function (res) {
                // 通过eventChannel向被打开页面传送数据
                res.eventChannel.emit('acceptDataFromApplyListPage', applyList[index]);
            }
        });
    },


    async getApplyList() {
        wx.showLoading({ title: '加载中...' });
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url: getApplyListUrl });
        console.log('getApplyList: ', isOk, result);
        wx.hideLoading();

        if (isOk) {
            this.setData({
                applyList: result
            });
        }
    },

    async acceptReq(index) {
        const { applyList } = this.data;
        const shop_id = applyList[index].shop_id;
        const param = { shop_id, status: 1 };
        wx.showLoading({ title: '操作中...', mask: true });
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url: updateApplyUrl, param });
        console.log('acceptReq: ', isOk, result);
        wx.hideLoading();

        if (isOk) {
            applyList[index].status = 1;
            this.setData({ applyList });
        }
    },

    onAcceptBtn(e) {
        const { index } = e.currentTarget.dataset;
        this.acceptReq(index);
    },


});
