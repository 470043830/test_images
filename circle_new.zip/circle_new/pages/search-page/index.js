import { $tdSearchbar, $tdUploader, $wuxToast } from '../../components/wux';
import nineGrid from '../../utils/nine-grid';


const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const constant = require('../../utils/constant');
const app = getApp();


Page(Object.assign({}, nineGrid, {
    data: {
        getUrl: '/circle/miniapp_circle_themes_list.jsp?act=getAlbumItemsInCircle', //'/circle/miniapp_circle_themes_list.jsp?act=get_circle_themes_plaza',
        addUrl: '/album/album_theme_operation.jsp?act=hold_theme',
        filterText: '',
        filterImg: '',
        allTags: [],
        searchBooths: [],
        priceTypesObj: constant.priceTypesObj,
        isMiniChecked: false,
    },

    onLoad(options) {
        console.log('onLoad', options);

        const dynamicList = this.selectComponent('#dynamic-list');

        if (!dynamicList) {
            return;
        }
        this.setData({ dynamicList });

        const thisPage = this;
        this.searchBarComp = $tdSearchbar.init({
            style: 'border: none',
            image: false,
            searchHandler(text, img) {
                this.setData({ filterText: text });
                if (text) {
                    dynamicList.searchHandler(text, img);
                    thisPage.fetchShops(text);
                } else {
                    dynamicList.clearList();
                    thisPage.setData({ searchBooths: [] })
                }

            }
        });

        //...
        this.fetchTags();
    },

    onShow() {
        setTimeout(async () => {
            await circleUtil.getCircleConfigData();
            this.setData({
                isMiniChecked: circleUtil.isMiniChecked()
            });
        }, 10);
    },

    async fetchTags() {
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url: `/circle/circle_new_interface.jsp?act=getCircleAlbumTags` });

        console.log('fetchTags, result: ', result);

        if (!isOk) {
            return;
        }
        const { allTags = [] } = result;

        this.setData({ allTags })
    },

    async fetchShops(search_value) {
        console.log('fetchShops: ', search_value);
        const param = {
            search_value,
        };
        const method = 'GET';
        const url = `/circle/circle_new_interface.jsp?act=getShops`;
        const { isOk, result = {} } = await circleUtil.fetchNetData({ url, method, param });
        console.log('on fetchShops: ', isOk, result);
        if (!isOk) {
            return;
        }
        const { shop_list = [] } = result;

        this.setData({ searchBooths: shop_list });
    },

    onTagTap(e) {
        const { allTags, dynamicList } = this.data;
        const { index } = e.currentTarget.dataset;
        const filterText = allTags[index].tagName;
        console.log('onTagTap...', allTags[index]);
        this.searchBarComp.changeInput({ target: { value: filterText } });
        this.setData({ filterText });
        dynamicList.searchHandler(filterText, '');
        this.fetchShops(filterText);
    },

    boothsTap(ev) {
        if (!circleUtil.isMiniChecked() && app.offline()) {
            return;
        }
        const { dataset } = ev.currentTarget;
        const { shopId } = dataset;
        const url = `/pages/follow_detail/index?shop_id=${shopId}`;

        console.info('boothsTap: ', dataset, url);
        circleUtil.onShopItemTap(shopId, true);
    },


    onReachBottom() {

    },

    onPullDownRefresh() {

    },

}))
