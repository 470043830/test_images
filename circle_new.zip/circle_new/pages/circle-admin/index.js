// pages/circle-admin/index.js
const circleData = require('../../utils/circle-data.js');


Page({

  /**
   * 页面的初始数据
   */
  data: {
    count1: 0,
    count2: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.updateListCount();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /***
   * 
   */
  async updateListCount() {
    let list1 = await circleData.queryMerchantsList();
    let list2 = await circleData.queryAnchorApplyList();

    this.setData({
      count1: list1.length,
      count2: list2.length,
    })
  },

  /**
   * 已入驻商户
   */
  onMerchantTap() {
    wx.navigateTo({ url: '/pages/circle-applyed-list/index?type=0' });
  },

  /**
   * 已入驻主播
   */
  onZhuboTap() {
    wx.navigateTo({ url: '/pages/circle-applyed-list/index?type=1' });
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})