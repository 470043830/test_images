

Component({
    // externalClasses: ['f-flex', 'f-vc', 'f-flex-wrap', 'success-color', 'f12', 'g3'],
    options: {
        addGlobalClass: true,
    },
    properties: {
        LouDong: Array
    },
    data: {
        // buildingSrc: [
        //     "https://xcimg.szwego.com/m1611057415809_6387.jpg",
        //     "https://xcimg.szwego.com/m1611048872977_2324.png",
        //     "https://xcimg.szwego.com/m1611057326254_5020.png",
        // ],
        // buildingTitle: [
        //     "天安1栋",
        //     "天安2栋",
        //     "天安3栋",
        // ],

        // LouDong: [{name: '  '}],
    },
    methods: {

        onItemTap: function (e) {
            const { index } = e.currentTarget.dataset;
            const url = `/pages/market-shops/index?market_id=${this.data.LouDong[index].market_id}`;
            // `/pages/market-shops/index?building=${(index + 1)}&title=${this.data.LouDong[index].name}`

            console.log('onItemTap...', index);
            wx.navigateTo({
                url
            });

        }
    },

    // 以下是旧式的定义方式，可以保持对 <2.2.3 版本基础库的兼容
    attached: function () {
        // 在组件实例进入页面节点树时执行
        console.log('building-bar attached...', this.data.LouDong);
    },
    detached: function () {
        // 在组件实例被从页面节点树移除时执行
        //console.log('detached...');
    },

    pageLifetimes: {

        ///
        show: function () {
            // 页面被展示
            console.log('building-bar show...');
        },
        hide: function () {
            // 页面被隐藏
            console.log('building-bar hide...');
        },
        resize: function (size) {
            // 页面尺寸变化
            console.log('building-bar resize...');
        }
    }
});
