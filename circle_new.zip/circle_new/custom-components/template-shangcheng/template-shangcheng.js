// custom-components/template-shangcheng/template-shangcheng.js
import nineGrid from '../../utils/nine-grid.js';
import fourGrid from '../../utils/four-grid.js';
const util = require('../../utils/util');

Component({
    /**
     * 组件的属性列表
     */
    properties: {
        list: {
            type: Array,
            value: []
        },
        col: {
            type: Number,
            value: 0
        },
        itemW: {
            type: String,
            value: '48%'
        },
        gap: {
            type: Number,
            value: 0
        },
        isMiniChecked: {
            type: Boolean,
            value: false
        }
    },

    /**
     * 组件的初始数据
     */
    data: {

    },

    options: {
        addGlobalClass: true
    },
    pageLifetimes: {
        show: function () {
            // 页面被展示
            const app = getApp();
            const { willUpdateGoods } = app.globalData;
            if (willUpdateGoods) {
                this.updateShareTime(willUpdateGoods);
                delete app.globalData.willUpdateGoods;
            }
        },
    },

    /**
     * 组件的方法列表
     */
    methods: {
        onAddCart(e) {
            const { dataset } = e.currentTarget;
            const { showcart } = dataset;
            if (showcart) {
                nineGrid.onAddCartTheme(e, this);
            }

        },
        onTapTow(e) {
            console.log("onTapTow...", e);
            const { themeType } = e.currentTarget.dataset;
            if ((themeType == 1 || themeType == 4) && !this.properties.isMiniChecked) return;
            fourGrid.onTapTow(e, this);
        },
        onShare(e) {
            console.log('onShare');

            nineGrid.onShareTheme(e, this);
        },
        onAdd(e) {
            // nineGrid.onAddTheme(e, this);
            let { goods_id, shop_id } = e.currentTarget.dataset;
            util.openGoodsEdit({
                goods_id: goods_id,
                shop_id: shop_id
            });
        },
        updateData(e) {
            let data = e.detail;
            if (data.action == 'del') {
                this.delGoods(data);
            } else if (data.action == 'top') {
                this.setTopGoods(e.detail);
            } else if (data.action == 'circle') {
                util.updateShareTime(data, res => {
                    this.updateShareTime(res);
                });
            }
        },
        updateShareTime(data) {
            let { goods_id, share_time } = data;

            const list = this.data.list.map(item =>
                item.goods_id === goods_id ? { ...item, share_time } : item
            );
            this.setData({ list });
        },
        delGoods(data) {
            let { goods_id } = data;
            //删除本地商品
            this.data.list.splice(this.data.list.findIndex(item => item.goods_id === goods_id), 1);
            this.setData({ list: this.data.list });
        },
        setTopGoods(data) {
            let { isTop, goods_id } = data;
            //更新本地置顶状态
            isTop = isTop == 1 ? 0 : 1;
            const list = this.data.list.map(item =>
                item.goods_id === goods_id ? { ...item, isTop } : item
            );
            this.setData({ list });
        }
    }
});
