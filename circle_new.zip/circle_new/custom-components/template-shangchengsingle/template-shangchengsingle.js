// custom-components/template-shangchengsingle/template-shangchengsingle.js
import nineGrid from '../../utils/nine-grid.js'
import fourGrid from '../../utils/four-grid.js'
const util = require('../../utils/util')

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    list: {
      type: Array,
      value: []
    },
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  options: {
    addGlobalClass: true
  },
    pageLifetimes: {
        show: function() {
            // 页面被展示
            const app = getApp();
            const { willUpdateGoods } = app.globalData;
            if (willUpdateGoods) {
                this.updateShareTime(willUpdateGoods);
                delete app.globalData.willUpdateGoods;
            }
        },
    },

  /**
   * 组件的方法列表
   */
  methods: {
    onAddCart(e){
      const { dataset } = e.currentTarget;
      const { showcart } = dataset;
      if (showcart){
        nineGrid.onAddCartTheme(e, this);
      }
    },
    onTapTag(e){
      nineGrid.onTapTag(e,this);
    },
    onTapTow(e){
      fourGrid.onTapTow(e,this);
    },
    onShare(e){
      console.log('onShare')

      nineGrid.onShareTheme(e, this);
    },
    onAdd(e){
      // nineGrid.onAddTheme(e, this);
      let {goods_id, shop_id} = e.currentTarget.dataset;
      util.openGoodsEdit({
        goods_id:goods_id,
        shop_id:shop_id
      });
    },
    updateData(e){
      let data = e.detail;
      if (data.action=='del'){
        this.delGoods(data);
      }else if (data.action=='top'){
        this.setTopGoods(e.detail);
      }else if (data.action=='circle'){
        util.updateShareTime(data, res=>{
          this.updateShareTime(res)
        });
      }
    },
    updateShareTime(data){
      let {goods_id, share_time} = data;

      const list = this.data.list.map(item =>
          item.goods_id === goods_id ? { ...item, share_time } : item
      );
      this.setData({ list });
    },
    delGoods(data){
      let {goods_id} = data;
      //删除本地商品
      this.data.list.splice(this.data.list.findIndex(item => item.goods_id === goods_id), 1)
      this.setData({ list: this.data.list });
    },
    setTopGoods(data){
      let {isTop, goods_id} = data;
      //更新本地置顶状态
      isTop = isTop == 1 ? 0 : 1;
      const list = this.data.list.map(item =>
          item.goods_id === goods_id ? { ...item, isTop } : item
      );
      this.setData({ list });
    },
    onlongPressShare(e){
      let { dataset } = e.currentTarget;
      let {is_my_album,goods_id,shop_id} = dataset.item;
      util.longpressShareRequest({goods_id,shop_id}).then(res => {
        let resData = res.data;
        if(resData.errcode == 0){
          if(is_my_album){
            this.onShare(e);
          }else{
            this.onAdd(e);
          }
        }
      })
    },
    // imgTap(e){
    //   fourGrid.imgTap(e, this);
    // },
    // onDownload(e){
    //   fourGrid.onDownload(e, this);
    // },
    // onCopyRemark(e){
    //   fourGrid.onCopyRemark(e, this);
    // },
    // onToggleRemark(e){
    //   fourGrid.onToggleRemark(e, this);
    // }
  },

  
})
