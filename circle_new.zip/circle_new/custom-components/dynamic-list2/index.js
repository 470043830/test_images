
import nineGrid from '../../utils/nine-grid';

const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const constant = require('../../utils/constant');
const app = getApp();


function getData() {
    return {
        tabbar: {},
        loading: false,
        loadingNoData: false, // 无数据
        loadingEnd: false, // 到底了
        filterText: '',
        filterImg: '',
        latestTime: '',
        listList: [],
        list: [],
        priceTypesObj: constant.priceTypesObj,

        indicatorDots: true,
        vertical: false,
        user_type: 1,
        updateSticky: false,
    };
}

Component(Object.assign({}, nineGrid, {
    options: {
        addGlobalClass: true,
    },

    data: {
        ...getData(),
        showCustomBar: true,
        stickStyle: '',
        videoNavList: ['档口', '动态'], //['最新', '热门', '推荐'],
        titleNavList: ['店铺封面', '广场动态'],
    },

    attached() {

        //...
        this.delayFetchData();

    },


    detached() {
    },

    pageLifetimes: {
        show: function () {
            // 页面被展示
            const { isShowPublish } = this.data;
            if (isShowPublish && getApp().offline()) {
                circleUtil.showLoginModal();
                return;
            }
            //...
            // const { listList } = this.data;
            // if (listList.length == 0) {
            //     this.delayFetchData();
            // }
            const { list } = this.data;
            if (list.length == 0) {
                this.delayFetchData();
            }
        },
        hide: function () {
            // 页面被隐藏
        },
        resize: function (size) {
            // 页面尺寸变化
        }
    },

    methods: {
        delayFetchData() {
            if (this._delayTimer) {
                clearTimeout(this._delayTimer);
                this._delayTimer = null;
            }
            this._delayTimer = setTimeout(() => {
                this.getCircleConfigData();
            }, 100);
        },

        searchHandler(text, img) {
            console.log("searchHandler: ", text, img);

            console.info(`text: ${text}`, `img: ${img}`);
            this.setData(Object.assign({}, getData(), {
                filterText: text,
                filterImg: img,
            }));
            this.getGoodsListData('init');
        },


        async getCircleConfigData() {
            let {
                circleInfo
            } = app.globalData;

            console.log('getCircleConfigData, circleInfo:', circleInfo);

            if (!circleInfo.config) {
                circleInfo = await circleUtil.getCircleConfigData();
                // this.setData(obj, () => { this.startStickObserver(); });
            }
            const { config = {} } = circleInfo;
            this.setData(config);
            const isShowPublish = circleUtil.isMiniChecked();
            //...
            const tabBar = this.getTabBar();
            console.log('dlist isShowPublish: ', isShowPublish);
            if (tabBar) {
                tabBar.setData({ isShowPublish });
            }
            this.setData({ isShowPublish });

            if (isShowPublish && getApp().offline()) {
                circleUtil.showLoginModal();
                return;
            }
            this.setData(getData(), () => {
                this.getGoodsListData('init');
            });
        },


        /**
         * @description 获取分类（商品）信息列表
         * @param {*} type
         */
        async getGoodsListData(type) {
            console.log('getGoodsListData, type=', type);
            const { loading } = this.data;

            if (loading) {
                console.log('!!! loading=', loading);
                return;
            }

            const url = this.getUrl(type);

            this.setData({ loading: true });
            let param = {
                search_value: this.data.filterText
            };
            let extInfo = { type };

            //...start fetchNetData
            const { isOk, result = {} } = await circleUtil.fetchNetData({ url, param, extInfo });
            let obj = {};

            wx.hideLoading();
            obj.loading = false;
            if (type == 'top') {
                wx.stopPullDownRefresh();
            }
            if (!isOk) {
                this.setData(obj);
                return;
            };

            //...
            // const { goods_list = [] } = result;
            // if (type == 'init' && goods_list.length > 16) {
            //     const list1 = goods_list.slice(0, 16);
            //     const list2 = goods_list.slice(16, goods_list.length);

            //     this.setData(this.getNewData(type, list1), () => {
            //         this.setData(this.getNewData('bottom', list2));
            //     });
            // } else {
            //     this.setData(this.getNewData(type, goods_list));
            // }


            // const { goods_list = [], ...others } = result;
            const { goods_list = [] } = result;
            const { list } = this.data;

            obj = {}; //{ ...this.data, ...others };
            if (type == 'top') {
                obj.list = this.getNoRepeatData(goods_list, list);
            } else {
                obj.list = [...list, ...goods_list];
                // 到底了
                goods_list.length <= 0 && (obj.loadingEnd = true);
            }
            // 无数据
            if (obj.list.length <= 0) {
                obj.loadingNoData = true;
            } else {
                obj.loadingNoData = false;
            }
            obj.latestTime = this.getLatestTime(obj.list);
            obj.loading = false;

            this.setData(obj);
        },

        getNewData(type, goods_list) {
            const { list } = this.data;
            const { listList } = this.data;
            const obj = {};

            // 无数据
            if (list.length <= 0 && goods_list.length <= 0) {
                obj.loadingNoData = true;
            } else {
                obj.loadingNoData = false;
            }

            obj.listList = listList;
            if (type == 'top') {
                // obj.list = this.getNoRepeatData(goods_list, list);
                obj.listList.unshift(this.getNoRepeatData(goods_list, list));
            } else if (type == 'bottom') {
                // let gIndex = list.length;
                // for (let index = 0; index < goods_list.length; index++) {
                //     obj["list[" + gIndex + "]"] = goods_list[index];
                //     gIndex++;
                // }
                obj.listList.push(goods_list);
            } else {
                // obj.list = goods_list; //goods_list.slice(0, 16);
                obj.listList = [];
                obj.listList[0] = goods_list;
            }

            // obj.latestTime = this.getLatestTime([...list, ...goods_list]);
            obj.loading = false;
            return obj;
        },

        // onTitleTap(data) {
        //     const item = this.data.list[data.index];
        //     console.log('onTitleTap...', data, item);
        //     wx.navigateTo({
        //         url: `/pages/goods_detail/index?shop_id=${item.shop_id}&goods_id=${item.goods_id}`
        //     });
        // },

        getGoodsIndexInList(goodsId) {
            const { list } = this.data;
            for (let index = 0; index < list.length; index++) {
                if (list[index].goods_id == goodsId) {
                    return index;
                }
            }
            return -1;
        },

        showTabBar() {
            if (typeof this.getTabBar === 'function' && this.getTabBar()) {
                this.getTabBar().setData({
                    selected: 1
                });
            }
        },

        getTimestamp() {
            const { list, latestTime, listList } = this.data;
            const len = list.length;
            // const len = listList.length;

            // console.log('getTimestamp, list: ', list);
            // console.log('getTimestamp, listList: ', listList);

            // if (len > 0) {
            //     const len2 = listList[len - 1].length;
            //     return {
            //         top: latestTime,
            //         bottom: listList[len - 1][len2 - 1].time_stamp
            //     };
            // } else {
            //     return {
            //         top: '',
            //         bottom: ''
            //     };
            // }

            if (len > 0) {
                return {
                    top: latestTime,
                    bottom: list[len - 1].time_stamp
                };
            } else {
                return {
                    top: '',
                    bottom: ''
                };
            }
        },

        getSearchDate() {
            const d = new Date();
            const yy = d.getFullYear();
            const mm = (d.getMonth() + 1) + '';
            const dd = (d.getDate() - 2) + '';
            return `start_date=${yy}-${mm.padStart(2, '0')}-${dd.padStart(2, '0')}`;
            // return 'start_date=2021-03-11&end_date=2021-03-12';
        },


        getUrl(type) {
            const { filterText, filterImg } = this.data;
            const { top, bottom } = this.getTimestamp();
            let url = '';
            let category = '0';
            let baseUrl = '';
            //for test
            if (category == '0') {
                baseUrl = `/circle/circle_new_interface.jsp?act=get_circle_themes_plaza&${this.getSearchDate()}`;
            } else {
                baseUrl = '/circle/circle_new_interface.jsp?act=getGoodsListByPage';
            }
            url = `${baseUrl}&search_img=${filterImg}`;

            switch (type) {
                case 'top':
                    url = `${url}&slip_type=0&time_stamp=${top || ''}`;
                    break;

                case 'bottom':
                    url = `${url}&slip_type=1&time_stamp=${bottom || ''}`;
                    break;
            }
            url += `&category=${category}`;

            //for mini check
            if (!circleUtil.isMiniChecked() && getApp().offline()) {
                url += `&token=RjU4QTZGNUQ2Qzc5OUQ0MjVFQzY5NkFBODZFNzFDNzE5OThEMDI1RjI3RTc4MDUwNjgwRkQ2QjVBMkRBN0EwN0I5NkM5Rjk4REYzRkRBMjhDMDMwOUNDNTI4NEI4MjJGQ0JBNTk2RUU3OTM2RENFOTM5RjMwODY1MzMxNDY0RjA%3D`;
                console.log('url : ', url);
            }
            return url;
        },

        getNoRepeatData(newData, oldData) {
            const data = [...newData, ...oldData];
            const len = data.length;
            const hash = {};
            const result = [];

            for (let i = 0; i < len; i++) {
                let goods = data[i];
                let goods_id = goods.goods_id;

                if (!hash[goods_id]) {
                    hash[goods_id] = true;
                    result.push(goods);
                }
            }

            // console.info(result);
            return result;
        },

        getLatestTime(data) {
            return data.map(item => item.time_stamp).filter(item => item)[0] || '';
        },

        onReachBottom() {
            const { loading, loadingNoData, loadingEnd, filterText } = this.data;

            console.log("onReachBottom ", loading, loadingNoData, loadingEnd);
            if (loading || loadingNoData || loadingEnd || filterText) {
                return false;
            }

            this.getGoodsListData('bottom');
        },

        onPullDownRefresh() {
            wx.hideLoading();
            const { loading, filterText } = this.data;

            if (loading || filterText) {
                wx.stopPullDownRefresh();
                return false;
            }

            console.log("onPullDownRefresh");
            this.getGoodsListData('top', () => {
                console.log("stopPullDownRefresh");
                wx.stopPullDownRefresh();
            });
        },

        previewImgs(e) {
            console.log("dynamic-list previewImgs....", e.detail);
            if (!circleUtil.isMiniChecked()){
                return;
            }
            this.setData({
                showPreviewer: true,
                ...e.detail,
            }, () => {
                this.data.showPreviewer && util.navigateToBrowserPage();
            });
        },
    },




}));
