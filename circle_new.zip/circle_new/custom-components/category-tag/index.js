

const tagColors = [
    ['#eee','#777'],
    ['#FFF3ED', '#FE5E0C'],  //求购
    ['#FEEDEC', '#F64B3E'],  //拼单
    ['#FFF4E7', '#FF9310'],  //二手
    ['#EDF9F0', '#49C167'],  //招聘
    ['#F0F6FF', '#5196FF'],  //出租
    ['#EDF9F0', '#49C167']
];
Component({
    // externalClasses: ['f-flex', 'f-vc', 'f-flex-wrap', 'success-color', 'f12', 'g3'],
    options: {
        addGlobalClass: true,
    },
    properties: {
        category: {
            type: Number,
            value: 0,
        },
    },
    data: {
        title: '',
        colors: [],
        customStyle: {}
    },
    methods: {
        setTitleStyle() {
            // const { navList } = getApp().globalData.circleInfo;
            const titles = ['商品', '求购', '拼单', '二手', '招聘', '出租/转让'];
            const { category } = this.properties;
            const title = titles[category]; //navList[category].title;
            const customStyle = `background: ${tagColors[category][0]}; color: ${tagColors[category][1]}`;
            this.setData({ title, customStyle });
        },
    },

    attached() {

    },

    detached() {

    },



    observers: {
        'category': function (category) {
            // 在 numberA 或者 numberB 被设置时，执行这个函数
            // console.log('7777777777777777777777category: ', category, this.data);
            this.setTitleStyle();
            // this.setData({
            //     sum: numberA + numberB
            // });
        }
    }

});
