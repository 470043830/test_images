

const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const constant = require('../../utils/constant');
const app = getApp();


Component({
    options: {
        // addGlobalClass: true,
    },

    data: {
        activityList: [
            // {
            //     img:"https://xcimg.szwego.com/circle_images/fzt/huodong001.png",
            //     title:"7.26--大型史诗电影《觉悟者.六祖惠能》《觉悟者.六祖惠能》《觉悟者.六祖惠能》缘起赠礼活...",
            //     datetime: "2021.7.26",
            //     addr: "广西容县",
            // },
            // {
            //     img: "https://xcimg.szwego.com/circle_images/fzt/huodong002.png",
            //     title: "7.26--大型史诗电影《觉悟者.六祖惠能》《觉悟者.六祖惠能》《觉悟者.六祖惠能》缘起赠礼活...",
            //     datetime: "2021.7.26",
            //     addr: "广西容县",
            // }
        ],
    },

    attached() {
        console.log("---------------------activityList attached...");
        // 在组件实例进入页面节点树时执行
        // if (getApp().offline()) {
        //     return;
        // }

        //...
        this.delayFetchData();

    },
    detached() {
        // 在组件实例被从页面节点树移除时执行
    },

    methods: {
        delayFetchData() {
            if (this._delayTimer) {
                clearTimeout(this._delayTimer);
                this._delayTimer = null;
            }
            this._delayTimer = setTimeout(() => {
                this.getActivityList();
            }, 100);
        },

        async getActivityList() {
            console.log('getActivityList...');
            if (!this._activityList){
                wx.showLoading({
                    mask: true,
                    title: '加载中...',
                });
            }

            const { isOk, result = {} } = await circleUtil.fetchNetData({ url: `/circle/circle_new_interface.jsp?act=getActivityList` });
            wx.hideLoading();
            if (isOk) {
                if (!this.isListEqual(result)){
                    console.log("update _activityList!!!");
                    const { list=[] } = result;

                    for (let index = 0; index < list.length; index++) {
                        const element = list[index];
                        element.datetime = circleUtil.formatDate(element.start, '.');
                        element.isOver = Date.now() > element.end;
                    }
                    this._activityList = result.list;
                    this.setData({
                        activityList: this._activityList
                    });
                }

            }
        },

        isListEqual(newList) {
            console.log("newList: ", newList);
            console.log("this._activityList: ", this._activityList);
            if (newList) {
                if (!this._activityList || newList.length != this._activityList.length) {
                    return false;
                }
                let str1 = JSON.stringify(this._activityList);
                let str2 = JSON.stringify(newList);
                return str1 == str2;
            }
            return false;
        },

        onVideoItemTap(e) {
            if (!circleUtil.isMiniChecked()) {
                return;
            }
            const { videoList } = this.data;
            const { index } = e.currentTarget.dataset;
            wx.navigateTo({
                url: "/pages/vdo-swiper-list/index?current=" + index,
                success(res) {
                    // 通过eventChannel向被打开页面传送数据
                    res.eventChannel.emit('homeVideoList', videoList);
                }
            });
        },

        onUserItemTap(e) {
            // const shopId = "A202005081156220500000644";
            // circleUtil.onShopItemTap(shopId);
        },
    },

    pageLifetimes: {
        show: function () {
            //...
            this.delayFetchData();
        },
        hide: function () {
            // 页面被隐藏
        },
        resize: function (size) {
            // 页面尺寸变化
        }
    },






});
