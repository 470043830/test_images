

Component({
    // externalClasses: ['f-flex', 'f-vc', 'f-flex-wrap', 'success-color', 'f12', 'g3'],
    options: {
        addGlobalClass: true,
    },
    properties: {
        LeiMu: Array,
    },
    data: {
        leimuStr: '针织衫,卫衣,小西装,连衣裙,衬衫,内衣,裤衩',
        iconStr: '01,02,03,04,05,06,07',
        array1: [],
        array2: [],
        allList: [],
        isExpanded: false,

        buildingSrc: {
            "0": "https://xcimg.szwego.com/m1611048872899_5328.png",
            "1": "https://xcimg.szwego.com/m1611048872977_2324.png",
            "2": "https://xcimg.szwego.com/m1611048873064_7718.png",
        }
    },
    methods: {

        leimuItemTap(e) {
            const { index, title } = e.detail;
            console.log('leimuItemTap...', index);

            let leimu = (index + 1);
            leimu = leimu <= 9 ? `0${leimu}` : leimu;
            wx.navigateTo({
                url: `/pages/market-shops/index?leimu=${leimu}&title=${title}`
            });

            // letdasda = [{ "name": "针织衫", "img": "01.png" }, { "name": "卫衣", "img": "01.png" }, { "name": "小西装", "img": "01.png" }, { "name": "连衣裙", "img": "01.png" }, { "name": "衬衫", "img": "01.png" }, { "name": "内衣", "img": "01.png" }, { "name": "裤衩", "img": "01.png"}]
        },

        onExpandTap(e) {
            const { isExpanded } = this.data;
            // console.log('onExpandTap...', isExpanded);

            this.setData({ isExpanded: !isExpanded });
        }
    },

    // 以下是旧式的定义方式，可以保持对 <2.2.3 版本基础库的兼容
    attached: function () {
        // 在组件实例进入页面节点树时执行
        console.log('leimu-bar attached...');
        let allList = [];

        allList = this.properties.LeiMu.map(item => item.img = { name: item.name, icon: `/assets/icons/${item.icon}` });
        // console.log('allList...', allList);
        this.setData({
            allList
            // array1: allList.slice(0, 5),
            // array2: allList.slice(5, 9)
        });

        // console.log('array1...', this.data.array1);
    },
    detached: function () {
        // 在组件实例被从页面节点树移除时执行
        console.log('detached...');
    },
});
