// custom-components/my-card/index.js
const circleUtil = require('../../utils/circle-util.js');
const util = require('../../utils/util.js');

Component({
    options: {
        addGlobalClass: true,
    },

    /**
     * 组件的属性列表
     */
    properties: {
        actionStatus: {
            type: Boolean,
            value: false,
            observer: function (newVal, oldVal) {
                console.log('actionStatus: ', newVal, oldVal);
            }
        },
        listIndex: String,
        shopId: String,
        goodsId: {
            type: String,
            value: '',
            observer: function (newVal, oldVal) {
                console.log('goodsId: ', newVal, oldVal);

                if(newVal){
                    this.getCommentList(newVal);
                }
            }
        },


    },

    /**
     * 组件的初始数据
     */
    data: {
        comments: [],
        insideHeight: 400
    },

    attached() {
        const { safeArea } = wx.getSystemInfoSync();
        const clientHeight = safeArea.bottom - safeArea.top;

        console.log('clientHeight: ', clientHeight);
        this.setData({
            insideHeight: clientHeight * 0.75 - 48
        });
    },

    detached() {

    },

    /**
     * 组件的方法列表
     */
    methods: {

        onCopyTap(e) {
            console.log(e);
            const { id } = e.currentTarget;

        },

        onActionHide() {
            console.log('onActionHide...');
            this.setData({ actionStatus: false, goodsId: '', comments: [] });
        },

        async getCommentList(goods_id) {
            if (!goods_id){
                return;
            }
            //wx.showLoading({ title: '加载中...' });
            const fetchCommentUrl = '/circle/circle_new_interface.jsp?act=getCommentsByGoodsId';
            const url = `${fetchCommentUrl}&goods_id=${goods_id}`;

            const { isOk, result = {} } = await circleUtil.fetchNetData({ url });
            console.log('getCommentList: ', isOk, result);
            //wx.hideLoading();

            if (isOk) {
                const { comments = [] } = result;
                if (comments.length > 0){
                    this.setData({
                        comments
                    });

                    const commentCount = comments.length;
                    const listIndex = this.properties.listIndex;
                    this.triggerEvent('onCommetSended', { goods_id, commentCount, listIndex }, {});
                }
            }
        },

        sendCommentReq(content) {
            const { shopId, goodsId} = this.properties;
            const addCommentUrl = '/circle/circle_new_interface.jsp?act=addComment';
            const url = `${addCommentUrl}&goods_id=${goodsId}&title=${content}&shop_id=${shopId}`;
            util.fetchAuthInst(url, null, res => {
                const { errcode, result } = res.data;
                console.log('addCommentUrl: ', res.data);
                //...
                wx.showToast({
                    title: '留言成功',
                    duration: 1500
                });
                // wx.pageScrollTo({
                //     scrollTop: 0,
                //     duration: 300
                // });
                // this.fetchComments();
                this.getCommentList(this.properties.goodsId);

                //订阅消息
                // wx.requestSubscribeMessage({
                //     tmplIds: ['RicDQlVCFdOsG7RIyu4fcuIbrs5BKbBvcnux3LnF3CI'],
                //     success(res) { }
                // });
            }, err => {
                console.log(err);
            });
        },

        onInput(e){
            console.log('onInput ', e.detail.value);
            this._inputValue = e.detail.value;

            this.setData({ inputComment: e.detail.value });
        },

        onInputConfirm(e) {
            console.log('onInputConfirm ', e);
            this.sendCommentReq(e.detail.value);

            //reset
            let inputComment = '';
            this.setData({ inputComment });
        },

        onSendCommentTap() {
            if (this._inputValue){
                this.sendCommentReq(this._inputValue);

                //reset
                this._inputValue = '';
                this.setData({ inputComment: this._inputValue });
            }

            // const itemList = ['快捷留言 AAA', '快捷留言 BBB'];
            // wx.showActionSheet({
            //     itemList,
            //     success: res => {
            //         const { tapIndex } = res;
            //         console.log('', itemList[tapIndex], this.properties.goodsId);
            //         this.sendCommentReq(itemList[tapIndex]);

            //     },
            //     fail: res => {
            //         console.log(res);
            //     }
            // });
        },
    }
});
