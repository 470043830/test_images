// custom-components/template-wxc/template-wxc.js
const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util');
// const commonGrid = require('../../utils/common-grid.js');
import nineGrid from '../../utils/nine-grid.js';
import { $cartSheet } from '../../components/wux';
// const nineGrid = require('../../utils/nine-grid.js');
Component({
    /**
     * 组件的属性列表
     */
    properties: {
        list: {
            type: Array,
            value: [],
            observer: function (newVal, oldVal) {
                // console.log('list: ', newVal, oldVal);
                const isShowPublish = circleUtil.isMiniChecked();

                this.setData({ isShowPublish });
            }
        },
        priceTypesObj: {
            type: Object,
            value: {}
        },
        videoPlaceholder: {
            type: Boolean,
            value: true
        },
        guest: {
            type: Boolean,
            value: false
        },
        filterText: String,
        isMyAlbum: {
            type: Boolean,
            value: false
        },
        myAlbumId: {
            type: String,
            value: ''
        },
    },

    /**
     * 组件的初始数据
     */
    data: {
    },

    options: {
        addGlobalClass: true
    },
    pageLifetimes: {
        show: function () {
            // 页面被展示
            const app = getApp();
            const { willUpdateGoods, pendingEvent } = app.globalData;
            if (willUpdateGoods) {
                this.updateShareTime(willUpdateGoods);
                delete app.globalData.willUpdateGoods;
            }
            // pendingEvent type: updateData
            if (pendingEvent && pendingEvent.updateData) {
                const { data } = pendingEvent.updateData;
                this.updateData({ detail: data });
                delete app.globalData.pendingEvent.updateData;
            }
        },
    },
    /**
     * 组件的方法列表
     */
    methods: {
        onTimeTap: util.onTimeTap,
        //iconTap: util.iconTap,
        onlongPressShare(e) {
            let { dataset } = e.currentTarget;
            let { is_my_album, goods_id, shop_id } = dataset.item;
            util.longpressShareRequest({ goods_id, shop_id }).then(res => {
                let resData = res.data;
                if (resData.errcode == 0) {
                    if (is_my_album) {
                        this.onShareTheme(e);
                    } else {
                        this.onAddTheme(e);
                    }
                }
            });

        },
        onDelGoods(e) {
            let { dataset } = e.currentTarget;
            let goods_id = dataset.goodsid;
            let param = {
                goods_id
            };
            let that = this;
            nineGrid.onDelGoods(param, (data) => {
                // let {goods_id} = data;
                // //删除本地商品
                // that.data.list.splice(that.data.list.findIndex(item => item.goods_id === goods_id), 1)
                // that.setData({ list: that.data.list });
                this.delGoods(data);
            });
        },

        delGoods(data) {
            let { goods_id } = data;
            //删除本地商品
            this.data.list.splice(this.data.list.findIndex(item => item.goods_id === goods_id), 1);
            this.setData({ list: this.data.list });
        },

        onRefreshGoods(e) {
            let goods_id = e.currentTarget.dataset.goodsid;
            let param = {
                goods_id
            };
            nineGrid.onRefreshGoods(param);
        },

        onSetTopGoods(e) {
            let that = this;
            let { dataset } = e.currentTarget;
            let goods_id = dataset.goodsid;
            let isTop = dataset.istop;
            if (!goods_id) {
                return;
            }
            let param = {
                goods_id,
                isTop
            };
            nineGrid.onSetTopGoods(param, (data) => {
                // let {isTop, goods_id} = data;
                // //更新本地置顶状态
                // isTop = isTop == 1 ? 0 : 1;
                // const list = that.data.list.map(item =>
                //     item.goods_id === goods_id ? { ...item, isTop } : item
                // );
                // that.setData({ list });
                this.setTopGoods(data);
            });
        },

        setTopGoods(data) {
            let { isTop, goods_id } = data;
            //更新本地置顶状态
            isTop = isTop == 1 ? 0 : 1;
            const list = this.data.list.map(item =>
                item.goods_id === goods_id ? { ...item, isTop } : item
            );
            const pages = getCurrentPages();
            console.log('pages: ', pages);
            // 同步修改home中的data数据
            const homePage = pages.find(item => item.route === 'pages/home/index');
            if (homePage) {
                const { list = [] } = homePage.data;
                const goodsIndex = list.findIndex(item => item.goods_id === goods_id);
                if (goodsIndex >= 0) {
                    list[goodsIndex].isTop = isTop;
                }
            }
            this.setData({ list });
        },

        onEditGoods(e) {
            let param = {
                goods_id: e.currentTarget.dataset.goodsid,
                shop_id: e.currentTarget.dataset.shopid
            };
            nineGrid.onEditGoods(param);
        },

        onViewImg(e) {
            nineGrid.onViewImg(e, this);
            // console.log(onViewImg1)
            // onViewImg1(e);
        },
        onViewVideo(e) {
            nineGrid.onViewVideo(e, this);
        },
        onAddTheme(e) {
            // nineGrid.onAddTheme(e, this);
            let { goods_id, shop_id } = e.currentTarget.dataset;
            util.openGoodsEdit({
                goods_id: goods_id,
                shop_id: shop_id
            });
        },
        onShareTheme(e) {
            nineGrid.onShareTheme(e, this);
        },
        onAddThemeToAlbum(e) {
            nineGrid.onAddThemeToAlbum(e, this);
        },
        onAddCartTheme(e) {
            nineGrid.onAddCartTheme(e, this);
        },
        iconTap(e) {
            nineGrid.iconTap(e, this);
        },
        titleTap(e) {
            nineGrid.titleTap(e, this);
        },
        onDownload(e) {
            nineGrid.onDownload(e, this);
        },
        onCopyRemark(e) {
            nineGrid.onCopyRemark(e, this);
        },
        onGridTap(e) {
            nineGrid.onGridTap(e, this);
        },

        onGridItemTap(e) {
            console.log('onGridItemTap...', e);
            this.titleTap(e);
        },

        onSanDianTap(e) {
            let { list } = this.data;
            const { index } = e.currentTarget.dataset;
            console.log('onSanDianTap: ', list[index]);
            list[index].isShowReport = !list[index].isShowReport;
            const obj = {};
            obj[`list[${index}]`] = list[index];
            this.setData(obj);
        },

        onHideReportTap(e) {
            let { list } = this.data;
            const { index } = e.currentTarget.dataset;
            console.log('onHideReportTap: ', list[index]);
            list[index].isShowReport = false;
            const obj = {};
            obj[`list[${index}]`] = list[index];
            this.setData(obj);
        },

        onReportTap(e) {
            let { list } = this.data;
            const { index, ismyalbum } = e.currentTarget.dataset;

            console.log('onReportTap...', list[index], ismyalbum);

            //...hide the 举报 tip
            list[index].isShowReport = false;
            const obj = {};
            obj[`list[${index}]`] = list[index];
            this.setData(obj);

            if (ismyalbum) {
                setTimeout(async () => {
                    wx.showLoading();
                    const { isOk, result = {} } = await circleUtil.fetchNetData({ url: `/circle/circle_new_interface.jsp?act=deleteGoods&goods_id=${list[index].goods_id}` });
                    wx.hideLoading();
                    if (isOk) {
                        this.delGoods(list[index]);
                        wx.showToast({
                            title: '已删除'
                        });
                    }

                }, 100);
                return;
            }
            wx.showToast({
                title: '已提交'
            });
        },

        onCommetSended(e) {
            let { list } = this.data;
            let { listIndex: index, commentCount } = e.detail;

            console.log('onCommetSended...', index);
            list[index].commentCount = commentCount;
            const obj = {};
            obj[`list[${index}]`] = list[index];
            this.setData(obj);
        },

        onCommentTap(e) {
            let { list } = this.data;
            const { index } = e.currentTarget.dataset;

            console.log('onCommentTap: ', list[index]);
            this.setData({
                actionStatus: true,
                listIndex: index,
                commentGoodsId: list[index].goods_id,
                commentShopId: list[index].shop_id
            });
            this.data.actionStatus = false;

            //...hide the 举报 tip
            list[index].isShowReport = false;
            const obj = {};
            obj[`list[${index}]`] = list[index];
            this.setData(obj);
        },

        onRichTextLongTap(e) {
            if (!e.currentTarget.dataset.title) {
                return;
            }
            wx.setClipboardData({
                data: e.currentTarget.dataset.title,
                success: () => {
                    wx.showToast({
                        title: '已复制',
                        icon: 'success',
                        duration: 1000,
                        mask: true
                    });
                }
            });
        },

        updateData(e) {
            let data = e.detail;
            if (data.action == 'del') {
                this.delGoods(data);
            } else if (data.action == 'top') {
                this.setTopGoods(e.detail);
            } else if (data.action == 'circle') {
                util.updateShareTime(data, res => {
                    this.updateShareTime(res);
                });
            }
        },
        updateShareTime(data) {
            let { goods_id, share_time } = data;

            const list = this.data.list.map(item =>
                item.goods_id === goods_id ? { ...item, share_time } : item
            );
            this.setData({ list });
        },
        onTapTag(e) {
            nineGrid.onTapTag(e, this);
        },


    }
});
