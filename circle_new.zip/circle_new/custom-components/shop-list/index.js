

Component({
    // externalClasses: ['f-flex', 'f-vc', 'f-flex-wrap', 'success-color', 'f12', 'g3'],
    options: {
        addGlobalClass: true,
    },
    properties: {
        listHeight: { // 属性名
            type: Number,
            value: 330
        },
        listWidth: { // 属性名
            type: Number,
            value: 303
        },
        shopList: Array,
    },
    data: {
    },
    methods: {
    },

    // 以下是旧式的定义方式，可以保持对 <2.2.3 版本基础库的兼容
    attached: function () {
    },
    detached: function () {
        // 在组件实例被从页面节点树移除时执行
        //console.log('detached...');
    },
});
