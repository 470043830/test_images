// custom-components/theme-switch-tags/index.js
Component({
    /**
     * 组件的属性列表
     */
    properties: {

    },

    /**
     * 组件的初始数据
     */
    data: {
        activeIndex: -1,
        tags: ['灵器', '福串', '法宝', '书籍'], //['上新', '推荐', '活动', '关注']
    },

    /**
     * 组件的方法列表
     */
    methods: {

        onTagTap: function (e) {
            const { index } = e.currentTarget.dataset;

            // console.log('floorItemTap...', index);
            this.onThemeTagChanged(index);
        },
        onThemeTagChanged(index) {
            const activeIndex = index;
            this.setData({
                activeIndex
            });
            this.triggerEvent('onThemeTagChanged', { index }, {});
        }
    },

    attached: function () {
        // this.onThemeTagChanged(0);
    },
    detached: function () {
    },
});
