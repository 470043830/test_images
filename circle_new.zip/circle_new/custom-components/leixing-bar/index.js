

Component({
    // externalClasses: ['f-flex', 'f-vc', 'f-flex-wrap', 'success-color', 'f12', 'g3'],
    options: {
        addGlobalClass: true,
    },
    properties: {
        LeiXing: Array,
    },
    data: {
        // array1: ["买手", "广告/摄影", "游学/培训", "面辅料"],
        // array2: ["设计师", "配件/周边", "工厂/设备", "陈列搭配"]
        // array1: [" "],
        // array2: [" "]
    },
    methods: {

        onItemTap: function (e) {
            const { index } = e.currentTarget.dataset;

            console.log('onItemTap...', index);
            wx.navigateTo({
                url: '/pages/shop-list/index?leixing=' + (index + 1),
            });
        }
    },

    // 以下是旧式的定义方式，可以保持对 <2.2.3 版本基础库的兼容
    attached: function () {
        // 在组件实例进入页面节点树时执行

    },
    detached: function () {
        // 在组件实例被从页面节点树移除时执行
        //console.log('detached...');
    },
});
