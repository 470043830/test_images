

const circleUtil = require('../../utils/circle-util');

Component({

    options: {
        addGlobalClass: true,
    },
    properties: {
        commentItem: Object,
    },
    data: {

    },
    methods: {

        onItemTap: function (e) {
            console.log('commentItem onItemTap...', e);
            const { commentItem } = this.properties;
            circleUtil.oncommentItemTap(commentItem.shopId, commentItem.total_goods > 0 && commentItem.c_goods_num == 0);

        }
    },

    // 以下是旧式的定义方式，可以保持对 <2.2.3 版本基础库的兼容
    attached: function () {
        // 在组件实例进入页面节点树时执行
    },
    detached: function () {
        // 在组件实例被从页面节点树移除时执行
        //console.log('detached...');
    },
});
