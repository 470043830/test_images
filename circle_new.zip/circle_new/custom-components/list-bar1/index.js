

const circleUtil = require('../../utils/circle-util');

Component({

    options: {
        addGlobalClass: true,
    },
    properties: {
        leimuIndex: {
            type: Number,
            value: 0,
        },
        titleText: {
            type: String,
            value: '针织衫1',
        },
        imgSrc: {
            type: String,
            value: '/assets/icons/01.svg',
        },
        shopItem: Object,
    },
    data: {
        // shopItem: { name: 'D奥欧美时装批发', img:'https://xcimg.szwego.com/s5XqniaEBh14CS43TIDRRfXwX5ujZxR9QWIeBQ1GIic3pvr9KP2fb0lrCUGwxmPnSpibiaZEhtdBjB5Z8CUMYeicyYg'},
    },
    methods: {

        onItemTap: function (e) {
            console.log('onItemTap...', e);
            const { shopItem } = this.properties;
            const toAlbum = true; //shopItem.total_goods > 0 && shopItem.c_goods_num == 0;
            circleUtil.onShopItemTap(shopItem.shopId, toAlbum);
            // var myEventDetail = {
            //     index: this.properties.leimuIndex
            // }; // detail对象，提供给事件监听函数
            // var myEventOption = {}; // 触发事件的选项
            // this.triggerEvent('shopItemTap', myEventDetail, myEventOption);
        }
    },

    // 以下是旧式的定义方式，可以保持对 <2.2.3 版本基础库的兼容
    attached: function () {
        // 在组件实例进入页面节点树时执行
        const { shopItem } = this.properties;
        // console.log('attached...', shopItem);
    },
    detached: function () {
        // 在组件实例被从页面节点树移除时执行
        //console.log('detached...');
    },
});
