

Component({
    // externalClasses: ['f-flex', 'f-vc', 'f-flex-wrap', 'success-color', 'f12', 'g3'],
    options: {
        addGlobalClass: true,
    },
    properties: {
        listHeight: { // 属性名
            type: Number,
            value: 330
        },
        floorList: Array,
    },
    data: {
        // floorList: ['全部', '1层', '2层', '3层', '4层', '5层', '6层', '7层', '8层', '9层'],
        checkedIndex: 0
    },
    methods: {

        onItemTap: function (e) {
            const { index } = e.currentTarget.dataset;

            // console.log('floorItemTap...', index);
            const checkedIndex = index;
            this.setData({
                checkedIndex
            });
            this.triggerEvent('floorItemTap', { index }, {});
        }
    },

    // 以下是旧式的定义方式，可以保持对 <2.2.3 版本基础库的兼容
    attached: function () {
    },
    detached: function () {
        // 在组件实例被从页面节点树移除时执行
        //console.log('detached...');
    },
});
