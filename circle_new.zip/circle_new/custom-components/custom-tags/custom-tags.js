import {$wuxToast} from '../../components/wux';

Component({
    // externalClasses: ['f-flex', 'f-vc', 'f-flex-wrap', 'success-color', 'f12', 'g3'],
    properties: {
        show: {
            type: Boolean,
            value: false,
        },
        tags: {
            type: Array,
            value: [],
            observer: '_changeTags',
        },
        filterTag: {
            type: Array,
            value: [],
        },
    },
    data: {
        filterTags: [],
    },
    methods: {
        _changeTags: function(newVal, oldVal) {
            const filterTags = newVal.filter(item => item.checked);

            this.setData({
                filterTags
            });
        },
        onHide: function() {
            this.triggerEvent('hide');
        },
        onTapTag: function(ev) {
            const { item } = ev.target.dataset;
            const { tagId, checked } = item;
            let { tags, filterTags } = this.data;
            const len = filterTags.length;

            if (!checked && len >= 3) {
                $wuxToast.show({
                    type: 'text',
                    text: '最多支持3个标签'
                });
                return false;
            }

            tags = tags.map(item => {
                return tagId == item.tagId ? {...item, checked: !item.checked} : item;
            });

            this.setData({
                tags
            });
        },
        onClear: function() {
            this.triggerEvent('clear');
        },
        onOk: function() {
            const { filterTags } = this.data;
            const filterTag = filterTags.map(item => item.tagId);

            this.triggerEvent('ok', {filterTag});
            // this.triggerEvent('ok', {}, {bubbles: true});
        },
    }
});
