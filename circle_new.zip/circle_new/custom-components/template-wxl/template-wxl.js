const util = require('../../utils/util.js');
import fourGrid from '../../utils/four-grid.js';
import nineGrid from '../../utils/nine-grid.js';
import logic from '../../utils/logic.js';

const app = getApp();
Component({
    /**
     * 组件的属性列表
     */
    properties: {
        list: {
            type: Array,
            value: []
        },
        showMoreIdx: {
            type: String,
            value: ''
        },
        callerType: {
            type: Number, //区分是否要更新置顶排序:1为不更新排序
            value: ''
        },
        priceTypesObj: {
            type: Object,
            value: {}
        }
    },

    /**
     * 组件的初始数据
     */
    data: {
        showPopover: false
    },

    options: {
        addGlobalClass: true
    },
    ready() {
        console.log('this.watchGlobal...');
        this.watchGlobal();
    },
    pageLifetimes: {
        show: function () {
            // 页面被展示
            const app = getApp();
            const { willUpdateGoods, pendingEvent } = app.globalData;
            if (willUpdateGoods) {
                this.updateShareTime(willUpdateGoods);
                delete app.globalData.willUpdateGoods;
            }
            // pendingEvent type: updateData
            if (pendingEvent && pendingEvent.updateData) {
                const { data } = pendingEvent.updateData;
                this.updateData({ detail: data });
                delete app.globalData.pendingEvent.updateData;
            }
        },
    },
    /**
     * 组件的方法列表
     */
    methods: {
        onTap(e) {
            fourGrid.onTap(e, this);
        },
        imgTap(e) {
            fourGrid.imgTap(e, this);
        },
        onAdd(e) {
            this.onEditGoods(e);
            // fourGrid.onAdd(e, this);
        },
        onlongPressShare(e) {
            let { dataset } = e.currentTarget;
            let { is_my_album, goods_id, shop_id } = dataset.item;
            util.longpressShareRequest({ goods_id, shop_id }).then(res => {
                let resData = res.data;
                if (resData.errcode == 0) {
                    if (is_my_album) {
                        this.onShare(e);
                    } else {
                        this.onAdd(e);
                    }
                }
            });
        },
        onShare(e) {
            fourGrid.onShare(e, this);
        },
        onAddToAlbum(e) {
            fourGrid.onAddToAlbum(e, this);
        },
        onToggleRemark(e) {
            fourGrid.onToggleRemark(e, this);
        },
        onTapTow(e) {
            fourGrid.onTapTow(e, this);
        },
        onAddCart(e) {
            fourGrid.onAddCart(e, this);
        },

        onDownload(e) {
            fourGrid.onDownload(e, this);
        },
        onCopyRemark(e) {
            fourGrid.onCopyRemark(e, this);
        },
        onDelGoods(e) {
            console.log('onDelGoods');
            this.setData({
                showMoreIdx: '',
                showPopover: false
            });
            app.setGlobalData({
                showPopoverMask: false,
            });
            let { dataset } = e.currentTarget;
            let goods_id = dataset.goodsid;
            let listidx = dataset.listidx;
            let param = {
                goods_id,
                listidx
            };
            let that = this;
            fourGrid.onDelGoods(param, (data) => {
                this.delGoods(data);
            });
        },

        delGoods(data) {
            let { goods_id, listidx } = data;
            console.log(data);
            //删除本地商品
            let { list } = this.data;
            list[listidx].splice(list[listidx].findIndex(item => item.goods_id === goods_id), 1);
            if (list[listidx].length == 0) {
                //当数据为空时删除该组数据
                list.splice(listidx, 1);
            }
            this.setData({ list });
        },

        onRefreshGoods(e) {
            this.setData({
                showMoreIdx: '',
                showPopover: false
            });
            app.setGlobalData({
                showPopoverMask: false,
            });
            let goods_id = e.currentTarget.dataset.goodsid;
            let param = {
                goods_id
            };
            fourGrid.onRefreshGoods(param);
        },

        onHidePopover(e) {
            this.setData({
                showMoreIdx: '',
                showPopover: false
            });

        },

        onSetTopGoods(e) {
            this.setData({
                showMoreIdx: '',
                showPopover: false
            });
            let that = this;
            let { dataset } = e.currentTarget;
            let goods_id = dataset.goodsid;
            let isTop = dataset.istop;
            let listidx = dataset.listidx;
            if (!goods_id) {
                return;
            }
            let param = {
                goods_id,
                isTop,
                listidx
            };

            fourGrid.onSetTopGoods(param, data => {
                this.setTopGoods(data);
            });
        },

        setTopGoods(data) {
            let { goods_id, listidx, isTop, time_stamp } = data;
            let { list } = this.data;
            //更新本地置顶状态
            isTop = isTop == 1 ? 0 : 1;
            let listnew = list[listidx].map(item =>
                item.goods_id === goods_id ? { ...item, isTop } : item
            );
            list[listidx] = listnew;
            if (this.data.callerType == 1) {
                this.setData({ list });
                return;
            }
            let obj = list[listidx].filter(item => item.goods_id === goods_id);
            obj = obj[0];
            obj.isTop = isTop;
            obj.time_stamp = time_stamp;

            //TODO:处理置顶列表
            let hasTop = false;
            if (list[0][0].date.date_text == '置顶') {
                hasTop = true;
            }
            if (isTop) {
                //置顶操作
                console.log(list);
                console.log(obj);
                obj.date = { date_text: '置顶' };
                if (hasTop) {
                    list[0].unshift(obj);
                } else {
                    list.unshift([obj]);
                    listidx++;
                }
                //删除原来的数据
                list[listidx] = list[listidx].filter(item => item.goods_id !== goods_id);
                if (list[listidx].length == 0) {
                    list.splice(listidx, 1);
                }
                console.log(list);
            } else {
                //取消置顶操作
                let date = logic.getDateText(obj.time_stamp);
                obj.date = date;
                list[0] = list[0].filter(item => item.goods_id != goods_id);
                if (list[0].length == 0) {
                    list.shift();
                }
                let hasGruop = false;
                console.log(list);
                for (let i = 0; i < list.length; i++) {
                    if (list[i][0].date.date_text == date.date_text) {
                        list[i].unshift(obj);
                        hasGruop = true;
                        break;
                    }
                }
                if (!hasGruop) {
                    if (hasTop) {
                        list.splice(1, 0, [obj]);
                    } else {
                        list.unshift([obj]);
                    }
                }
            }
            this.setData({ list });
        },

        onEditGoods(e) {
            // let param ={
            //   goods_id:e.currentTarget.dataset.goodsid,
            //   shop_id:e.currentTarget.dataset.shopid
            // }
            // fourGrid.onEditGoods(param);
            let { goods_id, shop_id } = e.currentTarget.dataset;
            util.openGoodsEdit({
                goods_id: goods_id,
                shop_id: shop_id
            });
        },
        watchGlobal() {
            let that = this;
            app.$watch("showPopoverMask", (Val, oldVal) => {
                if (Val) {
                    that.setData({
                        showPopover: Val
                    });
                } else {
                    this.setData({
                        showMoreIdx: "",
                    });
                }
            });
        },
        onShowMore(e) {
            const { dataset } = e.currentTarget;
            const { goodsid } = dataset;
            console.log('onShowMore');
            let idx = goodsid == this.data.showMoreIdx ? '' : goodsid;
            console.log(idx);
            this.setData({
                showMoreIdx: idx,
            });
            this.setData({
                showPopover: !this.data.showPopover
            });
            if (idx != "") {
                app.setGlobalData({
                    showPopoverMask: true,
                });
            } else {
                app.setGlobalData({
                    showPopoverMask: true,
                });
            }

        },
        updateShareTime(data, temp) {
            let { goods_id, share_time } = data;

            let { listidx } = temp;
            let { list } = this.data;

            let listItem = list[listidx].map(item =>
                item.goods_id === goods_id ? { ...item, share_time } : item
            );
            list[listidx] = listItem;
            this.setData({ list });
        },
        previewImgs(e) {
            this.triggerEvent('previewImgs', { showPreviewer: false });
        },
        updateData(e) {
            let data = e.detail;
            if (data.action == 'del') {
                this.delGoods(data);
            } else if (data.action == 'top') {
                this.setTopGoods(e.detail);
            } else if (data.action == 'circle') {
                util.updateShareTime(data, res => {
                    this.updateShareTime(res, data);
                });
            }
        },

        onTimeTap: util.onTimeTap,

        onTapTag(e) {
            nineGrid.onTapTag(e, this);
        }

    }
});
