
import nineGrid from '../../utils/nine-grid';

const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const constant = require('../../utils/constant');
const app = getApp();

function getCol(width) {
    return width >= 600 ? 3 : 2;
}


function getData() {
    return {
        tabbar: {},
        loading: false,
        loadingNoData: false, // 无数据
        loadingEnd: false, // 到底了
        filterText: '',
        filterImg: '',
        latestTime: '',
        list: [],
        priceTypesObj: constant.priceTypesObj,

        indicatorDots: true,
        vertical: false,
        user_type: 1,
        updateSticky: false,
    };
}

Component(Object.assign({}, nineGrid, {
    options: {
        addGlobalClass: true,
    },

    properties: {
        // interfaceAct: String,
        interfaceAct: {
            type: String,
            value: '',
            observer: function (newVal, oldVal) {
                console.log('interfaceAct: ', newVal, oldVal);
                this.delayFetchData();
            }
        },
        actionType: String,
        goodsCount: Number,
    },

    data: {
        ...getData(),
        showCustomBar: true,
        stickStyle: '',
        videoNavList: ['档口', '动态'], //['最新', '热门', '推荐'],
        titleNavList: ['店铺封面', '广场动态'],
        col: 2,
        gap: 15,
        itemW: '48%', // 列宽
    },

    attached() {
        //...
        this.getItemW();
        this.delayFetchData();
    },


    detached() {
    },

    pageLifetimes: {
        show: function () {
            // 页面被展示
            const { isShowPublish } = this.data;
            if (isShowPublish && getApp().offline()) {
                circleUtil.showLoginModal();
                return;
            }
            //...
            const { list } = this.data;
            if (list.length == 0) {
                this.delayFetchData();
            }
        },
        hide: function () {
            // 页面被隐藏
        },
        resize: function (size) {
            // 页面尺寸变化
        }
    },

    methods: {
        onMoreBtnTap(){
            wx.navigateTo({
                url: `/pages/fzt-goods/index`,
            });
        },

        delayFetchData() {
            console.log('this.properties.actionType=' + this.properties.actionType);
            if (this.properties.actionType == 'search-page') {
                return;
            }

            if (this._delayTimer) {
                clearTimeout(this._delayTimer);
                this._delayTimer = null;
            }
            this._delayTimer = setTimeout(() => {
                this.getCircleConfigData();
            }, 100);
        },

        searchHandler(text, img) {
            console.log("searchHandler: ", text, img);

            console.info(`text: ${text}`, `img: ${img}`);
            this.setData(Object.assign({}, getData(), {
                filterText: text,
                filterImg: img,
            }));
            this.getGoodsListData('init');
        },

        clearList() {
            this.setData({ list: [] });
        },


        async getCircleConfigData() {
            let circleInfo = await circleUtil.getCircleConfigData();
            const { config = {} } = circleInfo;
            this.setData(config);
            const isShowPublish = circleUtil.isMiniChecked();
            //...
            const tabBar = this.getTabBar();
            console.log('dlist isShowPublish: ', isShowPublish);
            if (tabBar) {
                tabBar.setData({ isShowPublish });
            }
            this.setData({ isShowPublish });

            if (isShowPublish && getApp().offline()) {
                circleUtil.showLoginModal();
                return;
            }
            this.setData(getData(), () => {
                this.getGoodsListData('init');
            });
        },


        /**
         * @description 获取分类（商品）信息列表
         * @param {*} type
         */
        async getGoodsListData(type) {
            console.log('getGoodsListData, type=', type);
            const { loading, isShowPublish } = this.data;

            if (loading) {
                console.log('!!! loading=', loading);
                return;
            }

            const url = this.getUrl(type);

            this.setData({ loading: true });
            let param = {
                search_value: this.data.filterText
            };
            let extInfo = { type };

            if (!isShowPublish && app.offline() && type != 'bottom') {
                param.token = `RjU4QTZGNUQ2Qzc5OUQ0MjVFQzY5NkFBODZFNzFDNzE5OThEMDI1RjI3RTc4MDUwNjgwRkQ2QjVBMkRBN0EwN0I5NkM5Rjk4REYzRkRBMjhDMDMwOUNDNTI4NEI4MjJGQ0JBNTk2RUU3OTM2RENFOTM5RjMwODY1MzMxNDY0RjA=`;
            }
            console.log("param: ", param);

            //...start fetchNetData
            const { isOk, result = {} } = await circleUtil.fetchNetData({ url, param, extInfo });
            let obj = {};

            wx.hideLoading();
            obj.loading = false;
            if (type == 'top') {
                wx.stopPullDownRefresh();
            }
            if (!isOk) {
                this.setData(obj);
                return;
            };

            //...
            const { goods_list = [] } = result;

            if (!circleUtil.isMiniChecked()) {
                for (let index = 0; index < goods_list.length; index++) {
                    const item = goods_list[index];
                    if (item.videoURL) {
                        item.videoURL = "";
                        item.videoUrl = "";
                        item.themeType = 0;
                    }
                }
            }
            if (type == 'init' && goods_list.length > 16) {
                const list1 = goods_list.slice(0, 16);
                const list2 = goods_list.slice(16, goods_list.length);

                this.setData(this.getNewData(type, list1), () => {
                    this.setData(this.getNewData('bottom', list2));
                });
            } else {
                this.setData(this.getNewData(type, goods_list));
            }

        },

        getNewData(type, goods_list) {
            const { list } = this.data;
            const { goodsCount } = this.properties;
            const obj = {};


            // 无数据
            if (list.length <= 0 && goods_list.length <= 0) {
                obj.loadingNoData = true;
            } else {
                obj.loadingNoData = false;
            }

            if (type == 'top') {
                obj.list = this.getNoRepeatData(goods_list, list);
            } else if (type == 'bottom') {
                if (goods_list.length > 0) {
                    let gIndex = list.length;
                    for (let index = 0; index < goods_list.length; index++) {
                        obj["list[" + gIndex + "]"] = goods_list[index];
                        gIndex++;
                    }
                } else {
                    // 到底了
                    obj.loadingEnd = true;
                }

            } else {
                console.log('goods_list: ', goods_list);
                obj.list = goods_list.slice(0, goodsCount);
                console.log('obj.list: ', goodsCount, obj.list);
            }

            obj.latestTime = this.getLatestTime([...list, ...goods_list]);
            obj.loading = false;
            return obj;
        },

        onTitleTap(data) {
            if (!circleUtil.isMiniChecked()) {
                return;
            }

            const item = this.data.list[data.index];
            console.log('onTitleTap...', data, item);
            wx.navigateTo({
                url: `/pages/goods_detail/index?shop_id=${item.shop_id}&goods_id=${item.goods_id}`
            });
        },

        getGoodsIndexInList(goodsId) {
            const { list } = this.data;
            for (let index = 0; index < list.length; index++) {
                if (list[index].goods_id == goodsId) {
                    return index;
                }
            }
            return -1;
        },

        showTabBar() {
            if (typeof this.getTabBar === 'function' && this.getTabBar()) {
                this.getTabBar().setData({
                    selected: 1
                });
            }
        },

        getTimestamp() {
            const { list, latestTime } = this.data;
            const len = list.length;

            if (len > 0) {
                return {
                    top: latestTime,
                    bottom: list[len - 1].time_stamp
                };
            } else {
                return {
                    top: '',
                    bottom: ''
                };
            }
        },

        getSearchDate() {
            const deltaTime = 30 * 24 * 3600 * 1000;
            const d = new Date(Date.now() - deltaTime);
            const yy = d.getFullYear();
            const mm = (d.getMonth() + 1) + '';
            const dd = d.getDate() + '';
            return `start_date=${yy}-${mm.padStart(2, '0')}-${dd.padStart(2, '0')}`;
            // return 'start_date=2021-03-11&end_date=2021-03-12';
        },


        getUrl(type) {
            const { filterText, filterImg } = this.data;
            const { interfaceAct } = this.properties;
            const { top, bottom } = this.getTimestamp();
            let url = '';
            let category = '0';
            let baseUrl = '';
            //for test
            console.log("interfaceAct: ", interfaceAct);
            baseUrl = `/circle/circle_new_interface.jsp?act=${interfaceAct}&${this.getSearchDate()}&split_size=160`;
            // if (category == '0') {
            //     baseUrl = `/circle/circle_new_interface.jsp?act=get_circle_themes_plaza&${this.getSearchDate()}&split_size=160`;
            // } else {
            //     baseUrl = '/circle/circle_new_interface.jsp?act=getGoodsListByPage';
            // }
            url = `${baseUrl}&search_img=${filterImg}`;

            switch (type) {
                case 'top':
                    url = `${url}&slip_type=0&time_stamp=${top || ''}`;
                    break;

                case 'bottom':
                    url = `${url}&slip_type=1&time_stamp=${bottom || ''}`;
                    break;
            }
            url += `&category=${category}`;
            return url;
        },

        getNoRepeatData(newData, oldData) {
            const data = [...newData, ...oldData];
            const len = data.length;
            const hash = {};
            const result = [];

            for (let i = 0; i < len; i++) {
                let goods = data[i];
                let goods_id = goods.goods_id;

                if (!hash[goods_id]) {
                    hash[goods_id] = true;
                    result.push(goods);
                }
            }

            // console.info(result);
            return result;
        },

        getLatestTime(data) {
            return data.map(item => item.time_stamp).filter(item => item)[0] || '';
        },

        onReachBottom() {
            const { loading, loadingNoData, loadingEnd, filterText } = this.data;

            console.log("onReachBottom ", loading, loadingNoData, loadingEnd);
            if (loading || loadingNoData || loadingEnd || filterText) {
                return false;
            }

            this.getGoodsListData('bottom');
        },

        onPullDownRefresh() {
            wx.hideLoading();
            const { loading, filterText } = this.data;

            if (loading || filterText) {
                wx.stopPullDownRefresh();
                return false;
            }

            console.log("onPullDownRefresh");
            this.getGoodsListData('top', () => {
                console.log("stopPullDownRefresh");
                wx.stopPullDownRefresh();
            });
        },

        previewImgs(e) {
            console.log("dynamic-list previewImgs....", e.detail);
            this.setData({
                showPreviewer: true,
                ...e.detail,
            }, () => {
                this.data.showPreviewer && util.navigateToBrowserPage();
            });
        },

        getItemW() {
            const {
                gap
            } = this.data;

            const {
                windowWidth
            } = wx.getSystemInfoSync();
            const col = getCol(windowWidth);
            const gapW = (col + 1) * gap;
            const itemW = `${((windowWidth - gapW) / col) | 0}px`;
            this.itemW = itemW;
            this.col = col;
            this.setData({
                col,
                itemW
            });
        },
    },




}));
