

const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const constant = require('../../utils/constant');
const app = getApp();
const circleVideosUrl = '/circle/circle_new_interface.jsp?act=findAllVideos&searchValue=视频号';



Component({
    options: {
        addGlobalClass: true,
    },

    data: {
        videoList: [],
    },

    attached() {
        console.log("---------------------hot-video attached...");
        // 在组件实例进入页面节点树时执行
        // if (getApp().offline()) {
        //     return;
        // }

        //...
        this.delayFetchData();

    },
    detached() {
        // 在组件实例被从页面节点树移除时执行
    },

    methods: {
        delayFetchData() {
            if (this._delayTimer) {
                clearTimeout(this._delayTimer);
                this._delayTimer = null;
            }
            this._delayTimer = setTimeout(() => {
                this.getCircleVideosData();
            }, 100);
        },

        async getCircleVideosData() {
            console.log('getCircleVideoData...');
            if (!this._videoList){
                wx.showLoading({
                    mask: true,
                    title: '加载中...',
                });
            }

            const { isOk, result = {} } = await circleUtil.fetchNetData({ url: circleVideosUrl, param: { circle_id: constant.circle_id } });
            wx.hideLoading();
            if (isOk) {
                if (!this.isListEqual(result)){
                    console.log("update _videoList!!!");
                    this._videoList = result;
                    this.setData({
                        videoList: this._videoList
                    });
                }

            }
        },

        isListEqual(newList) {
            console.log("newList: ", newList);
            console.log("this._videoList: ", this._videoList);
            if (newList) {
                if (!this._videoList || newList.length != this._videoList.length) {
                    return false;
                }
                let str1 = JSON.stringify(this._videoList);
                let str2 = JSON.stringify(newList);
                return str1 == str2;
            }
            return false;
        },

        onVideoItemTap(e) {
            if (!circleUtil.isMiniChecked()) {
                return;
            }
            const { videoList } = this.data;
            const { index } = e.currentTarget.dataset;
            wx.navigateTo({
                url: "/pages/vdo-swiper-list/index?current=" + index,
                success(res) {
                    // 通过eventChannel向被打开页面传送数据
                    res.eventChannel.emit('homeVideoList', videoList);
                }
            });
        },

        onUserItemTap(e) {
            // const shopId = "A202005081156220500000644";
            // circleUtil.onShopItemTap(shopId);
        },
    },

    pageLifetimes: {
        show: function () {
            //...
            this.delayFetchData();
        },
        hide: function () {
            // 页面被隐藏
        },
        resize: function (size) {
            // 页面尺寸变化
        }
    },






});
