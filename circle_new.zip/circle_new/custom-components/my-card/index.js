// custom-components/my-card/index.js
const util = require('../../utils/util.js');

Component({
    options: {
        addGlobalClass: true,
    },

    /**
     * 组件的属性列表
     */
    properties: {
        actionStatus: Boolean,
        cardInfo: Object,
    },

    /**
     * 组件的初始数据
     */
    data: {
        cardHeight: 398, //590,
    },

    attached() {
        console.log("attached ", getApp().globalData.systemInfo.windowHeight);
        let { cardHeight } = this.data;
        if (getApp().globalData.systemInfo.windowHeight < cardHeight) {
            cardHeight = getApp().globalData.systemInfo.windowHeight - 30;
            this.setData({ cardHeight });
        }

    },

    /**
     * 组件的方法列表
     */
    methods: {

        onPlusLinkTap(e) {
            wx.navigateToMiniProgram({
                appId: 'wx107b8fbd08e99afd',
                path: 'page/index/index?id=123',
                extraData: {
                    foo: 'bar'
                },
                // envVersion: 'develop',
                success(res) {
                    // 打开成功
                }
            });
        },

        onAddrNavTap(e) {
            const {
                latitude, // 纬度，范围为-90~90，负数表示南纬
                longitude,
                addr,
            } = this.properties.cardInfo;
            console.log('onAddrNavTap...', latitude, longitude);
            wx.openLocation({
                latitude: Number(latitude), // 纬度，范围为-90~90，负数表示南纬
                longitude: Number(longitude), // 经度，范围为-180~180，负数表示西经
                scale: 16, // 缩放比例
                name: addr,
                address: "..."
            });
        },

        onCopyTap(e) {
            console.log(e);
            const { id } = e.currentTarget;
            const text = this.properties.cardInfo[id];
            wx.setClipboardData({
                data: text,
                success(res) {
                    wx.getClipboardData({
                        success(res) {
                            console.log(res.data); // data
                        }
                    });
                }
            });
        },

        onPreviewQrcode() {
            console.log('onPreviewQrcode...');
            const { cardInfo } = this.properties;

            wx.previewImage({
                current: cardInfo.wechat_qrcode,
                urls: [cardInfo.wechat_qrcode]
            });
        },

        dasdasda() {
            console.log('catch dasdasda...');
        },

        getPreviewList() {
            const { mediaInfoObj } = this.properties.cardInfo;
            let previewList = [];
            let startIndex = 0;

            for (let index = startIndex; index < mediaInfoObj.length; index++) {
                const element = mediaInfoObj[index];
                if (element.type == 'video') {
                    previewList.push({
                        fileSource: element.video,
                        fileType: 'video',
                        title: ''
                    });
                } else {
                    previewList.push({
                        fileSource: element.src,
                        fileType: 'image',
                        title: ''
                    });
                }
            }
            return previewList;
        },

        onPreviewTap(e) {
            const { index } = e.currentTarget.dataset;

            let previewList = this.getPreviewList();
            let previewIndex = index;
            // this.setData({ previewList, showPreviewer: true, previewIndex }, () => {
            //     util.navigateToBrowserPage();
            // });

            var myEventDetail = { previewList, showPreviewer: true, previewIndex }; // detail对象，提供给事件监听函数
            var myEventOption = {}; // 触发事件的选项
            console.log('myEventDetail: ', myEventDetail);
            this.triggerEvent('previewImgs', myEventDetail, myEventOption);

            /*
            return;  //以下是使用系统预览组件的版本

            const { mediaInfoObj } = this.properties.cardInfo;
            const { index } = e.currentTarget.dataset;
            const current = mediaInfoObj[index];

            console.log('onPreviewTap: ', index, current, mediaInfoObj);

            const sources = [];

            for (let index = 0; index < mediaInfoObj.length; index++) {
                const element = mediaInfoObj[index];
                if (element.type == 'video') {
                    sources.push({ url: element.video, type: 'video', poster: element.src });
                } else {
                    sources.push({ url: element.src });
                }

            }
            if (wx.previewMedia) {
                wx.previewMedia({
                    current: index, // 当前显示图片的http链接
                    sources, // 需要预览的图片http链接列表
                });
            } else {
                wx.previewImage({
                    current, // 当前显示图片的http链接
                    urls: imgssrc, // 需要预览的图片http链接列表
                });
            }*/
        }
    }
});
