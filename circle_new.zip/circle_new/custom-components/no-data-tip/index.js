


Component({
    options: {
        // addGlobalClass: true,
    },
    properties: {
    },
    data: {
    },
    methods: {
    },

    attached() {
    },

    detached() {
    },

});
