const tabbarConfig = [
    {
        "pagePath": "/pages/home/index",
        "iconPath": "icon/icon_home.png",
        "selectedIconPath": "icon/icon_home_HL.png",
        "text": "商圈"
    },
    {
        "pagePath": "/pages/goods_edit/index",
        "iconPath": "icon/icon_release.png",
        "isSpecial": true,
        "text": "发布"
    },
    {
        "pagePath": "/pages/mine/index",
        "iconPath": "icon/icon_mine.png",
        "selectedIconPath": "icon/icon_mine_HL.png",
        "text": "我"
    }
];
export default tabbarConfig;
