import re,os
pattern1 = re.compile(r'("appid":\s+")(.*)(",)')
pattern2 = re.compile(r'(BASE_URL\s+=\s+\')(.*)(\')')
pattern3 = re.compile(r'(CIRCLE_ID\s+=\s+\')(.*)(\')')
appid = ""
localurl = ""
circleid = ""

def motify(file, pattern, text):

    with open(file, "r", encoding="utf-8") as f1,open("%s.bak" % file, "w", encoding="utf-8") as f2:
        for line in f1:
            f2.write(re.sub(pattern,text,line))
    os.remove(file)
    os.rename("%s.bak" % file, file)


choice= input("Please intput env:\n1.开发环境 \n2.测试环境 \n3.预发布环境 \n4.现网环境\n请输入:")
if choice=='1':
	localurl = r"\1https://www.wemicroboss.com/service\3"
elif choice=='2':
	localurl = r"\1https://www.wegoab.com/service\3"
elif choice=='3':
	localurl = r"\1https://www.micbosscloud.com/service\3"
elif choice=='4':
	localurl = r"\1https://www.wsxcme.com/service\3"
	pass

if localurl != '':
	motify("utils/env.js", pattern2, localurl)
else:
	print("选择输入错误！")


choice= input("Please intput env:\n1.深圳南油服装批发商圈 \n2.桐乡濮院批发商圈 \n3.嘉兴平湖羽绒服批发商圈 \n请输入:")
if choice=='1':
	appid = r"\1wx5c0115b4375c2831\3"
	circleid = r"\1CBIZ000001\3"
elif choice=='2':
	appid = r"\1wxcb08e5a392de3c8c\3"
	circleid = r"\1CBIZ000005\3"
elif choice=='3':
	appid = r"\1wx74c445212f848d0a\3"
	circleid = r"\1CBIZ000006\3"

	pass


if appid != '':
	motify("project.config.json", pattern1, appid)
	motify("utils/env.js", pattern3, circleid)
else:
	print("选择输入错误！")





