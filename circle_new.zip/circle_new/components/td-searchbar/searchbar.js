import WuxComponent from '../component'
const util = require('../../utils/util.js')
const constant = require('../../utils/constant.js')

export default {
    /**
     * 默认参数
     */
    setDefaults() {
        return {
            placeholder:'搜索',
            inputShowed: false,
            inputVal: "",
            searchImg: "",
            onAddImg() {},
            searchHandler() {},
        }
    },
    init(opts = {}) {

        const options = Object.assign({}, this.setDefaults(), opts)

        // 实例化组件
        const component = new WuxComponent({
            scope: `$td.searchbar`,
            data: options,
            methods: {
                changeInput (e) {
                    this.setData({
                        [`$td.searchbar.inputVal`]: e.target.value
                    });
                },
                showInput () {
                    this.setData({
                        [`$td.searchbar.inputShowed`]: true
                    })
                },
                hideInput () {
                    this.setData({
                        [`$td.searchbar.inputVal`]: "",
                        [`$td.searchbar.inputShowed`]: false
                    });
                },
                clearInput () {
                    this.setData({
                        [`$td.searchbar.inputVal`]: "",
                        [`$td.searchbar.searchImg`]: ""
                    });
                    //搜索
                    this.search()
                },

                inputTyping (e) {
                    console.log(e)
                    let searchData = this.getComponentData()
                    if (e.detail.value) {
                        this.setData({
                            [`$td.searchbar.inputVal`]: e.detail.value
                        });
                        searchData.inputVal = e.detail.value
                    } else {
                        let search = false
                        if (searchData.inputVal) {
                            search = true;
                        }
                        this.setData({
                            [`$td.searchbar.searchImg`]: '',
                            [`$td.searchbar.inputVal`]: ''
                        });

                        if (search){
                          this.search()
                        }

                    }

                },

                search(){
                    const searchData = this.getComponentData()

                    typeof options.searchHandler === `function` && options.searchHandler(searchData.inputVal.trim(),  searchData.searchImg)
                    this.setData({
                        [`$td.searchbar.inputShowed`]: false
                    });
                },
                callback(url){
                    console.log(url)
                    const searchData = this.getComponentData()
                    if (searchData.inputVal){
                        this.setData({
                            [`$td.searchbar.inputVal`]: ' '+searchData.inputVal, //前面用空格代替图片，回退时可以删除图片
                            [`$td.searchbar.searchImg`]: url
                        });
                    }else{
                        this.setData({
                            [`$td.searchbar.inputVal`]: ' ', //前面用空格代替图片，回退时可以删除图片
                            [`$td.searchbar.searchImg`]: url
                        });
                    }

                    //搜索
                    this.search()
                },

                bindconfirm(e){
                    console.log('bindconfirm: ', e)
                    this.setData({
                        [`$td.searchbar.inputVal`]: e.detail.value
                    }, () => {
                        this.search()
                    });
                },

                bindfocus(e){
                    console.log(e)
                },

                bindblur(e){
                    console.log(e)
                },

                uploadFile(){
                    const upload = () => {
                        util.initQiniu();
                        // 微信 API 选文件
                        wx.chooseImage({
                            count: 1,
                            success:  res=>{
                                let filePath = res.tempFilePaths[0];
                                // 交给七牛上传
                                util.qiniuUpload(filePath, this.callback)
                            }
                        })
                    }
                    if (typeof options.onAddImg === 'function') {
                        options.onAddImg(upload);
                    } else {
                        upload();
                    }
                }
            },
        })
        return component
    },

}
