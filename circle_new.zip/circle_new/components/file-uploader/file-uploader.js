import WuxComponent from '../component';
const constant = require('../../utils/constant');
import { getFileTypeFromExt } from '../../utils/util';
// import { log } from '../../utils/log';
import regeneratorRuntime, { async } from '../../utils/runtime.js';
const app = getApp();

const maxVideoSize = 50 * 1024 * 1024;
const maxImageSize = 500 * 1024;

function compareVersion(v1, v2) {
    v1 = v1.split('.')
    v2 = v2.split('.')
    const len = Math.max(v1.length, v2.length)

    while (v1.length < len) {
      v1.push('0')
    }
    while (v2.length < len) {
      v2.push('0')
    }

    for (let i = 0; i < len; i++) {
      const num1 = parseInt(v1[i])
      const num2 = parseInt(v2[i])

      if (num1 > num2) {
        return 1
      } else if (num1 < num2) {
        return -1
      }
    }

    return 0
}

const canvasShowState = {
    compress_canvas_1: false,
    compress_canvas_2: false,
    compress_canvas_3: false,
    compress_canvas_4: false,
    compress_canvas_5: false,
    compress_canvas_6: false,
    compress_canvas_7: false,
    compress_canvas_8: false,
    compress_canvas_9: false,
    compress_canvas_10: false,
}

export default {
    uptoken: '',
    uploadImgUrl: 'https://upload.qiniup.com/',
    getImgUrl: 'https://xcimg.szwego.com/',
    canMoving: false,
    /**
     * 默认参数
     */
    setDefaults() {
        return {
            // ...canvasShowState,
            compressedW: 0,
            compressedH: 0,
            imageWidth: 0,
            files: [],
            videoURL: '',
            themeType: 0,
            videoImg: '',
            videoFullScreen: false,
            showPlayVideo: false,
            showItemVideo: false,
        };
    },

    init(opts = {}) {
        this.getQiniuToken();
        const options = Object.assign({}, this.setDefaults(), opts);
        const scope = '$fileUploader';

        const { windowWidth, imageWidth, files, playVideo, themeType: initThemeType } = options;

        const movableAreaW = windowWidth - 30;
        const maxNumPerRow = parseInt(movableAreaW/imageWidth);

        // 实例化组件
        const component = new WuxComponent({
            scope,
            data: {
                ...options,
                movableAreaW, // 滑动区域宽度
                maxNumPerRow, // 滑动区域每行最大图片数量
                movingIndex: 0,
                rows: 1,
                movable: false,
                files: files.map((item, index) => ({ ...item, cdnSource: item.cdnSource, index })),
                showItemVideo: initThemeType === 1 || initThemeType === 4,
            },
            methods: {
                chooseFile: () => {
                    if (this.hasShowSheet) return;
                    this.hasShowSheet = true;
                    const { files, videoURL } = component.getComponentData();
                    const { imageNum, videoNum } = this.getFilesNum(files, videoURL);

                    if (imageNum < 9 && videoNum < 1) {
                        wx.showActionSheet({
                            itemList: ['选择照片', '选择视频', '拍摄'],
                            success: res => {
                                this.chooseLocalFile(res.tapIndex, res.tapIndex === 0 ? 9 - imageNum : 1);
                            },
                            complete: res => {
                                this.hasShowSheet = false;
                            }
                        })
                    } else if (imageNum === 9 && videoNum < 1) {
                        this.chooseLocalFile(1, 1);
                        this.hasShowSheet = false;
                    } else if (imageNum < 9 && videoNum === 1) {
                        wx.showActionSheet({
                            itemList: ['选择照片', '拍摄'],
                            success: res => {
                                this.chooseLocalFile(res.tapIndex === 0 ? 0 : 2, res.tapIndex === 0 ? 9 - imageNum : 1);
                            },
                            complete: res => {
                                this.hasShowSheet = false;
                            }
                        })
                        // this.chooseLocalFile(0, 9 - imageNum);
                    }
                },
                handleChangePos: e => {
                    // console.log('----touch move----');
                    // if (!this.canMoving) return;
                    const { dataset } = e.currentTarget;
                    const { index } = dataset;
                    const { x, y, source } = e.detail;
                    if (source === 'touch') {
                        const imgPos = this.imgPosRealTime(x + imageWidth/3, y + imageWidth/3);
                        this.moveEndInfo = {...imgPos, index, x, y};
                        this.canMoving = true;
                    }
                },
                handleChangePosStart: e => {
                    console.log('----touch start----');
                    const { dataset } = e.currentTarget;
                    const { index } = dataset;
                    component.setData({
                        ['$fileUploader.movingIndex']: index,
                    });
                },
                handleTapItem: e => {
                    console.log('----tap----', this.canMoving);
                    if (!this.canMoving) {
                        const { dataset } = e.currentTarget;
                        const { index } = dataset;
                        // 预览
                        const { files, themeType } = component.getComponentData();
                        const containVideo = themeType === 4 || themeType === 1;
                        if (containVideo && index === 0) {
                            component.setData({
                                ['$fileUploader.showPlayVideo']: true,
                            }, () => {
                                this.videoContext = wx.createVideoContext('preview-video', this);
                                setTimeout(() => {
                                    this.videoContext.requestFullScreen({
                                        direction: 0
                                    });
                                    this.videoContext.play();
                                    const time = app.globalData.isIOS ? 200 : 0;
                                    console.log('time: ', time, app.globalData);
                                    setTimeout(() => {
                                        playVideo(true);
                                    }, time);
                                }, 200);
                            });
                        } else if (containVideo && index !== 0) {
                            wx.previewImage({
                                current: files[index].cdnSource || files[index].name,
                                urls: [...files.slice(1).map(item => (item.cdnSource || item.name))],
                            });
                        } else {
                            wx.previewImage({
                                current: files[index].cdnSource || files[index].name,
                                urls: [...files.map(item => (item.cdnSource || item.name))],
                            });
                        }
                    }
                },
                handleLongPressMovableItem: (e) => {
                    console.log('----long tap----: ', e);
                    const { dataset: { index } } = e.currentTarget;
                    const { themeType } = this.component.getComponentData();
                    if ((themeType === 4 || themeType === 1) && index === 0) {
                        return;
                    }
                    this.canMoving = true;
                    wx.vibrateShort();
                    component.setData({
                        ['$fileUploader.movable']: true,
                    })
                },
                handleChangePosEnd: () => {
                    console.log('----touch end----');
                    if (!this.moveEndInfo) return;
                    const { files, themeType } = component.getComponentData();
                    const { index, endIndex } = this.moveEndInfo;
                    const movingImg = files[index];
                    if (endIndex >= files.length || (themeType === 4 && endIndex === 0)) {
                        files[index] = movingImg;
                    } else {
                        if (endIndex > index) {
                            for (let i = 0; i < files.length; i++) {
                                if (i >= index && i <= endIndex) {
                                    files[i] = files[i + 1];
                                }
                            }
                        } else if (endIndex < index) {
                            for (let i = files.length - 1; i >= 0; i--) {
                                if (i <= index && i >= endIndex) {
                                    files[i] = files[i - 1];
                                }
                            }
                        }
                        files[endIndex] = movingImg;
                    }
                    component.setData({
                        ['$fileUploader.files']: files,
                        ['$fileUploader.movable']: false,
                    }, () => {
                        setTimeout(() => {
                            this.moveEndInfo = null;
                            this.canMoving = false;
                        }, 50);
                    });
                },
                deleteFile: (e) => {
                    let { files, themeType, videoURL } = component.getComponentData();
                    const { dataset } = e.currentTarget;
                    const { index } = dataset;
                    const newFiles = [
                        ...files.slice(0, index),
                        ...files.slice(index + 1),
                    ];
                    let obj = {};
                    if (themeType === 4 || themeType === 1) {
                        if (index === 0) {
                            videoURL = '';
                            obj = {
                                ['$fileUploader.showItemVideo']: false,
                            }
                        }
                    }
                    const { themeType: newThemeType } = this.getFilesNum(newFiles, videoURL);
                    component.setData({
                        ['$fileUploader.files']: newFiles.map(((item, index) => ({...item, index}))),
                        ['$fileUploader.themeType']: newThemeType,
                        ['$fileUploader.videoURL']: videoURL,
                        ...obj,
                    });
                },
                fullScreenChange: e => {
                    const { fullScreen } = e.detail;
                    if (!fullScreen) {
                        this.videoContext.pause();
                        const time = app.globalData.isIOS ? 100 : 0;
                        console.log('time: ', time, app.globalData);
                        component.setData({
                            ['$fileUploader.showPlayVideo']: false,
                        });
                        setTimeout(() => {
                            playVideo(false);
                        }, time);
                    }
                },
                videoLoaded: e => {
                    console.log('videoLoaded: ', e)
                },
                onVideoError: e => {
                    console.log('onVideoError: ', e)
                },
                bindrendererror: e => {
                    console.log('bindrendererror: ', e)
                },
                videoItemLoaded: e => {
                    console.log('videoItemLoaded: ', e);
                }
            },
        });

        this.component = component;

        // 等待组件渲染完毕后设置
        setTimeout(() => {
            this.setTempfiles();
        }, 500);

        return component;
    },

    imgPosRealTime(x, y) {
        const { maxNumPerRow, imageWidth, files } = this.component.getComponentData();
        const lastRowNum = files.length%maxNumPerRow;

        const row = parseInt(y/(imageWidth + 10));
        const col = parseInt(x/(imageWidth + 10));
        const endIndex = row * maxNumPerRow + col;

        return { lastRowNum, row, col, endIndex };
    },

    chooseLocalFile(type, maxNum) {
        if (type === 0) {
            wx.chooseImage({
                count: maxNum,
                sourceType: ['album'],
                sizeType: ['original'],
                success: res => {
                    console.log('res: ', res);
                    const { tempFiles } = res;
                    const queue = [];
                    for (let i = 0; i < tempFiles.length; i++) {
                        const { path } = tempFiles[i];
                        queue.push(this.getImageInfo(path, tempFiles[i]));
                    }
                    Promise.all(queue).then(res => {
                        this.createUploadImageTask(tempFiles);
                    });
                }
            });
        } else if (type === 1) {
            wx.chooseVideo({
                count: 1,
                maxDuration: 30,
                sourceType: ['album'],
                sizeType: ['original'],
                compressed: false,
                success: res => {
                    console.log('res: ', res)
                    this.createUploadVideoTask(res);
                }
            })
        } else if (type === 2) {
            wx.chooseImage({
                count: 1,
                sourceType: ['camera'],
                sizeType: ['original'],
                success: res => {
                    console.log('res: ', res);
                    const { tempFiles } = res;
                    const queue = [];
                    for (let i = 0; i < tempFiles.length; i++) {
                        const { path } = tempFiles[i];
                        queue.push(this.getImageInfo(path, tempFiles[i]));
                    }
                    Promise.all(queue).then(res => {
                        this.createUploadImageTask(tempFiles);
                    });
                }
            });
        }
    },

    async createUploadImageTask(tempFiles) {
        // wx.showLoading({
        //     title: '正在上传...'
        // });
        const { files, compressedW } = this.component.getComponentData();
        const initTempFiles = tempFiles.map((item, index) => ({
            ...item,
            name: item.path + Date.now() + index,
            path: item.path,
            status: 'before_upload',
            index: files.length + index
        }));
        const newFiles = [
            ...files,
            ...initTempFiles,
        ];
        console.log('---newFiles: ', newFiles);
        this.component.setData({
            ['$fileUploader.files']: newFiles
        });
        const uploadQueue = [];
        const needCompressImgs = []; // TODO: 可考虑是否需要分批同步压缩问题
        // 传chooseIndex: files.length + i
        const { version } = wx.getSystemInfoSync();
        const v = compareVersion(version, '7.0.15');
        for (let i = 0; i < initTempFiles.length; i++) {
            const chooseIndex = files.length + i;
            const { size, path, name, width, height } = initTempFiles[i];
            if (size > maxImageSize && (width < 6000 && height < 6000 || v > 0)) {
                needCompressImgs.push({
                    name,
                    path,
                    chooseIndex,
                });
            } else {
                const uploadItem = this.uploadFileToQinniu(path, '', '', chooseIndex, 'image', initTempFiles[i]);
                uploadQueue.push(uploadItem);
            }
        }
        console.log('needCompressImgs: ', needCompressImgs);
        if (needCompressImgs.length) {
            if (!!compressedW) {
                this.dealCompressImgs1(needCompressImgs, 1, tempFiles.length, files.length);
            } else {
                this.component.setData({
                    ['$fileUploader.compressedW']: 1280,
                    ['$fileUploader.compressedH']: 1280,
                }, () => {
                    this.dealCompressImgs1(needCompressImgs, 1, tempFiles.length, files.length);
                })
            }
        }
    },

    dealCompressImgs(needCompressImgs) {
        const compressAndUploadQueue = [];
        for (let i = 0; i < needCompressImgs.length; i++) {
            const { path, chooseIndex } = needCompressImgs[i];
            const compressAndUploadItem = this.compressImage(path, chooseIndex);
            compressAndUploadQueue.push(compressAndUploadItem);
        }
    },

    // 分批处理压缩任务，暂时不需要
    dealCompressImgs1(needCompressImgs, taskNum = 1, batchNum, oriNum) {
        if (!needCompressImgs.length) {
            console.log('--- 上传完毕 ---');
            const { files } = this.component.getComponentData();
            const failedNum = batchNum + oriNum - files.length;
            if (failedNum > 0) {
                wx.showToast({
                    title: `压缩程序异常，共${failedNum}张图片上传失败，请到客户端重新上传。`,
                    icon: 'none',
                });
            }
            return;
        };
        const compressAndUploadQueue = [];
        for (let i = 0; i < taskNum; i++) {
            const { path, chooseIndex } = needCompressImgs[i];
            const compressAndUploadItem = this.compressImage(path, chooseIndex, needCompressImgs[i]);
            compressAndUploadQueue.push(compressAndUploadItem);
        }
        Promise.all(compressAndUploadQueue).then((res) => {
            // TODO: 判断每个任务状态，处理异常时考虑
            console.log('------Promise.all-------: ', res);
            this.dealCompressImgs1(needCompressImgs.slice(taskNum), taskNum, batchNum, oriNum);
        });
    },

    async createUploadVideoTask(file) {
        const { files } = this.component.getComponentData();
        // 真机无法拿到 thumbTempFilePath
        const { size, tempFilePath, thumbTempFilePath } = file;
        if (size > maxVideoSize) {
            // 提示
            console.log('---- size flow ----');
            wx.hideLoading();
            wx.showModal({
                title: '提示',
                content: '视频大小不能超过50M，上传大于50M视频请前往app',
                showCancel: false,
                confirmText: '知道了'
            })
        } else {
            const newFiles = [
                {
                    name: tempFilePath,
                    status: 'before_upload',
                    isLocalFile: true,
                    index: 0,
                },
                ...files.map((item, index) => ({ ...item, index: index + 1 })),
            ];
            const { themeType } = this.getFilesNum(newFiles, true);
            this.component.setData({
                ['$fileUploader.files']: newFiles,
                ['$fileUploader.themeType']: themeType,
                ['$fileUploader.videoURL']: 'TEMP_VIDEOURL',
            });
            // 500ms render local video
            setTimeout(() => {
                this.component.setData({
                    ['$fileUploader.showItemVideo']: true,
                }, () => {
                    this.uploadFileToQinniu(tempFilePath, '', '', 0);
                })
            }, 300);
        }
    },

    /**
     * 压缩图片
     * @param {*} imgPath 图片临时文件
     * @param {*} chooseIndex 选择图片的顺序
     */
    compressImage(imgPath, chooseIndex, originFile) {
        console.log("1: ", Date.now());
        // log('1', Date.now());
        return new Promise((resolve, reject) => {
            wx.getImageInfo({
                src: imgPath,
                success: res => {
                    console.log("2: ", Date.now());
                    // log('2', Date.now());
                    // console.log('compressImage res: ', res)
                    const { height, width, path, type } = res;
                    const longerSide = height >= width ? height : width;
                    if (longerSide > 1280) {
                        // 压缩尺寸
                        const compressedW = longerSide === width ? 1280 : parseInt((1280 / height) * width);
                        const compressedH = longerSide === height ? 1280 : parseInt((1280 / width) * height);

                        // console.log('compressedSize: ', compressedW, compressedH);
                        const ctx = wx.createCanvasContext('compress_canvas');
                        ctx.drawImage(path, 0, 0, width, height, 0, 0, compressedW, compressedH);

                        setTimeout(() => {
                            ctx.draw(false, () => {
                                wx.canvasToTempFilePath({
                                    x: 0,
                                    y: 0,
                                    width: compressedW,
                                    height: compressedH,
                                    destWidth: compressedW,
                                    destHeight: compressedH,
                                    canvasId: 'compress_canvas',
                                    fileType: 'jpg',
                                    success: res => {
                                        console.log("3: ", Date.now());
                                        // log('3', Date.now());
                                        // console.log('canvasToTempFilePath: ', res.tempFilePath)
                                        const compressedSizeImagePath = res.tempFilePath;
                                        originFile.canvasCompressedFile = compressedSizeImagePath;
                                        this.compressImageQuality(compressedSizeImagePath, resolve, reject, chooseIndex, originFile, 80, 0);
                                    },
                                    fail: res => {
                                        console.log('canvasToTempFilePath fail: ', res);
                                        resolve(true);
                                    },
                                })
                            });
                        }, 1000)
                    } else {
                        // 直接压缩质量
                        if (type === 'jpeg' || type === 'jpg') {
                            this.compressImageQuality(path, resolve, reject, chooseIndex, originFile, 80, 0);
                        } else {
                            const ctx = wx.createCanvasContext('compress_canvas');
                            this.canvasCompressQuality(ctx, imgPath, width, height, resolve, reject, chooseIndex, 'compress_canvas', originFile);
                        }
                    }
                }
            })
        });
    },

    canvas2img(ctx, compressedW, compressedH, chooseIndex) {
        return new Promise((resolve, reject) => {
            this.canvas2imgInterval = setInterval(() => {
                ctx.draw(false, () => {
                    wx.canvasToTempFilePath({
                        x: 0,
                        y: 0,
                        width: compressedW,
                        height: compressedH,
                        destWidth: compressedW,
                        destHeight: compressedH,
                        canvasId: `compress_canvas_${chooseIndex + 1}`,
                        fileType: 'jpg',
                        success: res => {
                            // console.log('canvasToTempFilePath: ', res)
                            const compressedSizeImagePath = res.tempFilePath;
                            this.canvasCompressQuality(
                                ctx,
                                compressedSizeImagePath,
                                compressedW,
                                compressedH,
                                resolve,
                                reject,
                                chooseIndex
                            );
                        },
                        fail: res => {
                            console.log('canvasToTempFilePath fail: ', res);
                            // reject(res);
                        },
                    })
                });
            }, 200);
        });
    },

    compressImageQuality(compressedSizeImagePath, resolve, reject, chooseIndex, originFile, quality = 80, failTimes = 0) {
        wx.getFileInfo({
            filePath: compressedSizeImagePath,
            success: res => {
                // console.log('compressImageQuality getFileInfo: ', res, compressedSizeImagePath, quality)
                if (res.size > maxImageSize) {
                    wx.compressImage({
                        src: compressedSizeImagePath,
                        quality,
                        success: res => {
                            // console.log('compressImage success: ', res.tempFilePath)
                            if (failTimes > 5 || res.size > originFile.size) {
                                console.log('--------压缩质量失败');
                                // log(
                                //     '压缩质量失败',
                                //     `${failTimes} ${originFile.canvasCompressedFile} ${originFile.path} ${res.size} ${originFile.size}`
                                // );
                                resolve(true); // 压缩完成
                                this.uploadFileToQinniu(
                                    originFile.canvasCompressedFile || originFile.path,
                                    resolve,
                                    reject,
                                    chooseIndex,
                                    'image',
                                    originFile
                                );
                            } else {
                                this.compressImageQuality(res.tempFilePath, resolve, reject, chooseIndex, originFile, quality - 5, failTimes + 1);
                            }
                        },
                        fail: res => {
                            console.log('compressImage fail: ', res)
                            // log(
                            //     'compressImage',
                            //     'compressImage fail:',
                            //     res
                            // );
                            if (failTimes > 1) {
                                resolve(true);
                                this.deleteFailedFile(chooseIndex, originFile);
                            } else {
                                this.compressImageQuality(compressedSizeImagePath, resolve, reject, chooseIndex, originFile, quality, failTimes + 1);
                            }
                        }
                    })
                } else {
                    resolve(true); // 压缩完成
                    // log('4', Date.now());
                    this.uploadFileToQinniu(compressedSizeImagePath, resolve, reject, chooseIndex, 'image', originFile);
                }
            },
            fail: res => {
                console.log('getFileInfo: ', res);
                resolve(true);
            },
        })
    },

    canvasCompressQuality(ctx, compressedSizeImagePath, compressedW, compressedH, resolve, reject, chooseIndex, canvasId, originFile) {
        wx.getFileInfo({
            filePath: compressedSizeImagePath,
            success: res => {
                // console.log('canvasCompressQuality getFileInfo: ', res)
                if (res.size > maxImageSize) {
                    ctx.drawImage(compressedSizeImagePath, 0, 0, compressedW, compressedH, 0, 0, compressedW, compressedH);
                    setTimeout(() => {
                        ctx.draw(false, () => {
                            wx.canvasToTempFilePath({
                                x: 0,
                                y: 0,
                                width: compressedW,
                                height: compressedH,
                                destWidth: compressedW,
                                destHeight: compressedH,
                                canvasId,
                                fileType: 'jpg',
                                // quality,
                                success: res => {
                                    // console.log('canvasToTempFilePath: ', res)
                                    const compressedSizeImagePath = res.tempFilePath;
                                    originFile.canvasCompressedFile = compressedSizeImagePath;
                                    this.compressImageQuality(compressedSizeImagePath, resolve, reject, chooseIndex, originFile);
                                },
                                fail: res => {
                                    console.log('canvasToTempFilePath fail: ', res);
                                    // log(
                                    //     'canvasToTempFilePath',
                                    //     'canvasToTempFilePath fail:',
                                    //     res,
                                    // );
                                    resolve(true);
                                },
                            })
                        });
                    }, 300);
                } else {
                    resolve(true); // 压缩完成
                    this.uploadFileToQinniu(compressedSizeImagePath, resolve, reject, chooseIndex, originFile);
                }
            },
            fail: res => {
                resolve(true);
            },
        });
    },

    getQiniuToken() {
        wx.request({
            url: constant.BASE_URL + '/get_qiuniu_token.jsp',
            success: (res) => {
                const token = res.data.uptoken
                if (token && token.length > 0) {
                    console.log('qiniuToken: ', token)
                    this.uptoken = token

                    // 处理缓存中要上传的临时文件
                } else {
                    console.error('qiniuUploader cannot get your token, please check the uptokenURL or server')
                }
            },
            fail: function (error) {
                console.error('qiniu UploadToken is null, please check the init config or networking: ' + error)
            }
        })
    },

    getRandomName(filePath = '') {
        const a = parseInt(Math.random() * 10);
        const b = parseInt(Math.random() * 10);
        const c = parseInt(Math.random() * 10);
        const d = parseInt(Math.random() * 10);
        const ext = filePath.substring(filePath.lastIndexOf('.'));
        return `m${Date.now()}_${a}${b}${c}${d}${ext}`;
    },

    getImageInfo(path, tempFile) {
        return new Promise((resolve, reject) => {
            wx.getImageInfo({
                src: path,
                success: res => {
                    resolve(res);
                    const { size } = tempFile;
                    const { height, width } = res;
                    if (size > 3 * 1024 * 1024 || height > 4000 || width > 4000) {
                        tempFile.unsetMode = true;
                    }
                    tempFile.height = height;
                    tempFile.width = width;
                },
                fail: res => {
                    reject();
                },
            });
        });
    },

    setTempfiles() {
        try {
            const imageTempfiles = wx.getStorageSync('image_tempfiles');
            const videoTempFiles = wx.getStorageSync('video_tempfiles');
            if (imageTempfiles) {
                const { tempFiles } = imageTempfiles;
                const queue = [];
                for (let i = 0; i < tempFiles.length; i++) {
                    const { path } = tempFiles[i];
                    queue.push(this.getImageInfo(path, tempFiles[i]));
                }
                Promise.all(queue).then(res => {
                    console.log('---tempFiles: ', tempFiles);
                    this.createUploadImageTask(tempFiles);
                });
            }
            if (videoTempFiles) {
                this.createUploadVideoTask(videoTempFiles);
            }
            wx.removeStorageSync('image_tempfiles');
            wx.removeStorageSync('video_tempfiles');
        } catch(e) {}
    },

    uploadFileToQinniu(filePath, resolve, reject, chooseIndex, fileType, originFile) {
        if (typeof resolve === 'function') {
            const randomName = this.getRandomName(filePath);
            wx.uploadFile({
                url: this.uploadImgUrl,
                filePath,
                name: 'file',
                formData: {
                    'token': this.uptoken,
                    'key': randomName,
                    'name': randomName,
                },
                success: res => {
                    // log('image uploaded', res);
                    // log('5', Date.now());
                    this.fileAdded(res, resolve, reject, chooseIndex, fileType, originFile);
                },
                fail: (error) => {
                    console.error(error);
                    reject(error);
                    this.deleteFailedFile(chooseIndex, originFile);
                }
            })
        } else {
            return new Promise((resolve, reject) => {
                const randomName = this.getRandomName(filePath);
                wx.uploadFile({
                    url: this.uploadImgUrl,
                    filePath,
                    name: 'file',
                    formData: {
                        'token': this.uptoken,
                        'key': randomName,
                        'name': randomName,
                    },
                    success: res => {
                        // log('image uploaded', res);
                        this.fileAdded(res, resolve, reject, chooseIndex, fileType, originFile);
                    },
                    fail: (error) => {
                        console.error(error);
                        reject(error);
                        this.deleteFailedFile(chooseIndex, originFile);
                    }
                })
            })
        }
    },

    fileAdded(res, resolve, reject, chooseIndex, curfileType, originFile) {
        const dataString = res.data;

        console.log('fileAdded, dataString: ', dataString);
        try {
            const dataObject = JSON.parse(dataString);
            console.log('dataObject: ', dataObject);
            const fileUrl = this.getImgUrl + dataObject.key;
            const fileType = curfileType || getFileTypeFromExt(fileUrl);
            console.log('fileType: ', fileType);
            let videoImg = '';
            if (fileType === 'video') {
                videoImg = fileUrl + '?vframe/jpg/offset/0';
            }
            // 处理files
            let { files, videoURL, themeType } = this.component.getComponentData();
            let newFiles = [];
            if (fileType === 'video' && files[0].index === 0) {
                newFiles = [
                    {
                        ...files[0],
                        // name: videoImg || fileUrl,
                        cdnSource: videoImg || fileUrl,
                        status: 'uploaded',
                        index: 0,
                    },
                    ...files.slice(1),
                ];
            } else {
                const index = files.findIndex(file => file.name === originFile.name);
                files[index] = {
                    ...files[index],
                    cdnSource: videoImg || fileUrl,
                    status: 'uploaded',
                    index,
                };
                newFiles = [...files];
            }
            let obj = {};
            if (fileType === 'video') {
                obj = {
                    ['$fileUploader.videoURL']: fileUrl,
                }
                const { themeType: themeTypeNew } = this.getFilesNum(newFiles, fileUrl);
                themeType = themeTypeNew;
            } else {
                const { themeType: themeTypeNew } = this.getFilesNum(newFiles, videoURL);
                themeType = themeTypeNew;
            }

            console.log('newFiles: ', newFiles);

            this.component.setData({
                ['$fileUploader.files']: newFiles,
                ['$fileUploader.themeType']: themeType,
                ['$fileUploader.videoImg']: videoImg,
                ...obj,
            })
            // resolve(fileUrl);
        } catch (e) {
            reject(res);
            console.log('parse JSON failed, origin String is: ' + dataString)
        }
    },

    deleteFailedFile(chooseIndex, originFile) {
        const { files, videoURL } = this.component.getComponentData();
        if (videoURL) {
            this.component.deleteFile({currentTarget: { dataset: { index: 0 }}});
        } else {
            const index = files.findIndex(file => file.name === originFile.name);
            this.component.deleteFile({currentTarget: { dataset: { index }}});
        }
    },

    getFilesNum(files, videoURL) {
        let { themeType } = this.component.getComponentData();
        let imageNum = 0;
        let videoNum = 0;
        if (videoURL) {
            videoNum = 1;
            imageNum = files.length - 1;
        } else {
            imageNum = files.length;
        }
        if (videoNum > 0 && imageNum > 0) {
            themeType = 4;
        } else if (videoNum === 0 && imageNum > 0) {
            themeType = 0;
        } else if (videoNum === 1 && imageNum === 0) {
            themeType = 1;
        } else if (videoNum === 0 && imageNum === 0) {
            themeType = 2;
        }
        return {
            themeType,
            imageNum,
            videoNum,
        }
    }
}
