import WuxComponent from '../component'

export default {
    /**
     * 默认参数
     */
    setDefaults() {
        return {
            className: 'f14',
            style: '',
            navIndex: 0,
            navs: [],
            navTap() {}
        }
    },

    /**
     * 初始化navbar组件
     * @param {Object} opts 配置项
     * @param {String} opts.className 组件className
     * @param {String} opts.style 组件style
     * @param {Number} opts.navIndex 当前nav索引
     * @param {Array} opts.navs navs
     * @param {String} opts.navs.className nav的className
     * @param {String} opts.navs.label nav的文本
     */
    init(opts = {}) {
        const options = Object.assign({}, this.setDefaults(), opts);

        // 实例化组件
        const component = new WuxComponent({
            scope: `$td.navbar`,
            data: options,
            methods: {
                /**
                 * 点击nav
                 */
                bindtap(ev) {
                    const { dataset } = ev.currentTarget;
                    const { index } = dataset;
                    const { navIndex } = this.getComponentData();

                    if (index == navIndex) {
                        return false;
                    }

                    this.setData({
                        '$td.navbar.navIndex': index
                    });
                    typeof options.navTap == 'function' && options.navTap(index);
                },
            },
        });
    },

}
