import {
    shareAppMessageCanvas
} from "../../utils/canvas-composite-img";

import util from "../../utils/util"

Component({
    options: {

    },
    /**
     * 组件的属性列表
     */
    properties: {
        /**
         * wechart 发送给好 \t 友/群
         * friends 分享到朋 \t 友圈
         * more    更多平台
         * join    拼图分享
         * advs    海报分享
         * editor  编辑
         * refresh 刷新
         * settop  置顶
         * download下载
         * delete  删除
         */
        list: {
            type: Array,
            value: ['wechart', 'friends', 'more', 'join', 'advs', 'editor', 'refresh', 'settop', 'download', 'delete'],
            observer: 'list',
        },
        shareData:{
            type:Object,
            value:{},
            observer: 'shareData',
        }
    },

    observers: {
        // 'list'(data) { //单个监听
        //     this.setRenderList(data);
        // },
        // 'shareData'(data) { //单个监听

        //     this.createShareImg(data);
        // }
    },
    ready(){
        const { system, version } = wx.getSystemInfoSync();
        let iosVersion = '';
        if (system.indexOf('iOS') > -1) {
            iosVersion = system.substr(system.indexOf('iOS') + 4);
        }

        this.setRenderList(this.data.list, iosVersion);
        if (iosVersion && util.compareVersion(version, '7.0.15') >= 0){
            this.setData({
                guideVideoUrl: "https://xcimg.szwego.com/20201111/guide_video_1603787850355_2420663.mp4"
            })
        }
        // console.log('system: ', iosVersion, wx.getSystemInfoSync());
    },
    /**
     * 组件的初始数据
     */
    data: {
        isShow: false,
        transitioned: 'in',
        showFriendsDialog:false,
        renderList: {
            top: [],
            bottom: []
        },
        shareMap: {
            'wechart': {
                key: 'wechart',
                icon: '/assets/images/share_wechart.svg',
                label: '发送给好 \t 友/群'
            },
            'friends': {
                key: 'friends',
                icon: '/assets/images/share_friends.svg',
                label: '分享到朋 \t 友圈'
            },
            'more': {
                key: 'more',
                icon: '/assets/images/share_more.svg',
                label: '更多平台'
            },
            'join': {
                key: 'join',
                icon: '/assets/images/share_join.svg',
                label: '拼图分享'
            },
            'advs': {
                key: 'advs',
                icon: '/assets/images/share_advs.svg',
                label: '海报分享'
            },
            'editor': {
                key: 'editor',
                icon: '/assets/images/share_editor.svg',
                label: '编辑'
            },
            'refresh': {
                key: 'refresh',
                icon: '/assets/images/share_refresh.svg',
                label: '刷新'
            },
            'settop': {
                key: 'settop',
                icon: '/assets/images/share_settop.png',
                label: '置顶'
            },
            'canceltop': {
                key: 'canceltop',
                icon: '/assets/images/share_canceltop.png',
                label: '取顶'
            },
            'download': {
                key: 'download',
                icon: '/assets/images/share_download.svg',
                label: '下载'
            },
            'delete': {
                key: 'delete',
                icon: '/assets/images/share_delete.svg',
                label: '删除'
            },
        },
        canvasW: 1,
        canvasH: 1,
        canvasId: "J_canvas_share",
        clipCanvas: {
            key: "clipCanvas",
            idName:"clipCanvasShare",
            width: 200,
            height: 200,
            value: []
        },
        guideVideoUrl: "https://xcimg.szwego.com/5ec447c2ba8361d5bc2fc8a3276a1467.mp4",
    },

    /**
     * 组件的方法列表
     */
    methods: {
        list(data) { //单个监听
            this.setRenderList(data);
        },
        shareData(data) { //单个监听
            this.createShareImg(data);
        },
        setRenderList(li, iosVersion){
            let list = {
                top: [],
                bottom: []
            };
            if (li && li instanceof Array) {
                li.forEach((item) => {
                    let data = this.data.shareMap[item];
                    if (this.data.shareMap[item]) {
                        if (item === "wechart" || item === "friends" || item === "more") {
                            list.top.push(data);
                        } else {
                            list.bottom.push(data);
                        }
                    }
                })
            }
            let obj = {};
            if (iosVersion) {
                obj.ios9 = parseInt(iosVersion) === 9;
            }
            this.setData({
                renderList: list,
                ...obj,
            })
        },
        hideFriendsDialog(){
            this.setData({
                showFriendsDialog:false
            })
            this.triggerEvent("close", false);
            util.shareComplete("friends");
        },
        showFriendsDialog(){
            this.setData({
                showFriendsDialog:true
            })
            this.triggerEvent("close", true);
        },
        share(e) {
            let item = e.currentTarget.dataset.item;
            console.log(e);
            let that = this;
            this.triggerEvent("onShare", item);
            // app.globalData.title = title;
            this.onShare(item, data => {
                // console.log(that.data);
                // console.log(data);
                const { isTop, action } = data;
                // //更新本地置顶状态
                // isTop = isTop == 1 ? 0 : 1;
                // const list = that.data.list.map(item =>
                //     item.goods_id === goods_id ? { ...item, isTop } : item
                // );
                // that.setData({ list });

                this.triggerEvent("updateData", data);
                if(item.key != "friends"){
                    util.shareComplete(item.key);
                }

            }, this);
            this.close();
            if(item.key === "more"){
              wx.showModal({
                title: '提示',
                content: '小程序暂时不支持此操作，请关注【微商相册】公众号下载APP，确认即复制微信号：mmicroboss',
                success:(res)=> {
                  if (res.confirm) {
                    this.hideDownloadConfrim(1)
                  }
                }
              })
            }
        },
        hideDownloadConfrim(e) {
          e && util.copyTitle("mmicroboss",() => {
              util.shareComplete("more");
          });
        },
        show() {
            this.setData({
                isShow: true,
                transitioned: 'in'
            })
            this.triggerEvent("onShareShow");
        },
        createShareImg(data){
            const { goods_list = [], shop = {} } = data;
            shareAppMessageCanvas({
                goods_list,
                ...shop,
                component: this,
                canvasId: this.data.canvasId,
                from: 'button', // 根据分享类型判断拼图样式
            }).then((res) => {
                let share_goods_id = '';
                if (goods_list && goods_list.length === 1) {
                    const { goods_id = '' } = goods_list[0];
                    share_goods_id = goods_id;
                    wx.setStorageSync('share_goods_canvas_for_browser', {
                        goods_id,
                        tempFilePath: res,
                    });
                }
                console.log("分享组件后台画图完成", res, data);
                wx.setStorageSync('share_goods_canvas', {
                    share_goods_id,
                    tempFilePath: res,
                });
            },(e) => {
                console.log("画图失败",e)
            });
        },
        close() {
            //console.log('分享组件关闭 showFriendsDialog : ' + this.data.showFriendsDialog)
            this.setData({
                transitioned: 'out'
            });
            setTimeout(function () {
                this.setData({
                    isShow: false
                })
                this.triggerEvent("close", this.data.showFriendsDialog);
                // 清空缓存的图片
                wx.setStorageSync('share_goods_canvas', "");

                // 清空分享商品索引
                wx.setStorageSync('share_index', {
                    listidx:-1,
                    index:-1
                });
            }.bind(this), 300)
        },
        preventDefaultEv() {
            return;
        }
    }
})
