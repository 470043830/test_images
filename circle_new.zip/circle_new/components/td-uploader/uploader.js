import WuxComponent from '../component'
const qiniuUploader = require("../../assets/plugins/qiniuUploader");
const util = require('../../utils/util.js')
const constant = require('../../utils/constant.js')

// 初始化七牛相关参数
function initQiniu() {
    var options = {
        region: 'ECN', //
        uptokenURL: constant.BASE_URL+'/get_qiuniu_token.jsp',
        // uptoken: 'xxxx',
        domain: 'http://lookbook-server-img.bkt.clouddn.com',
        shouldUseQiniuFileName: false
    };
    qiniuUploader.init(options);
}


export default {
    /**
     * 默认参数
     */
    setDefaults() {
        return {
            callback(){}
        }
    },
    init(opts = {}) {

        const options = Object.assign({}, this.setDefaults(), opts)

        // 实例化组件
        const component = new WuxComponent({
            scope: `$td.uploader`,
            data: options,
            methods: {
                /**
                 * 显示
                 */
                show() {
                    this.setVisible()
                },

                callback(url){
                    typeof options.callback === `function` && options.callback(url)
                },

                uploadFile(){
                    initQiniu();
                    // 微信 API 选文件
                    wx.chooseImage({
                        count: 1,
                        success:  res=>{
                            let filePath = res.tempFilePaths[0];
                            // 交给七牛上传
                            qiniuUploader.upload(filePath, (res) => {
                                    // this.setData({
                                    //     [`$td.searchbar.imageObject`]: res
                                    // });
                                let sourceLink = constant.QINIU_IMG_URL + res.key;
                                this.callback(sourceLink);

                                }, (error) => {
                                    console.error('error: ' + JSON.stringify(error));
                                }
                            );
                        }
                    })

                }
            },
        })

        component.show()

        return component
    },

}
