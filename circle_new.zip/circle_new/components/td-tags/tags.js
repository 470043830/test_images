import WuxComponent from '../component'
import { dedupArr } from '../../utils/util';

export default {
    /**
     * 默认参数
     */
    setDefaults() {
        return {
            show: false,
            tags: [],
            groups: [],
            filterTag: [],
            filterTags: [],
            onClear() {},
            onOk() {},
        }
    },

    init(opts = {}) {
        const options = Object.assign({}, this.setDefaults(), opts);

        console.log('options: ', options);
        // 实例化组件
        const component = new WuxComponent({
            scope: `$td.tags`,
            data: options,
            methods: {
                onShow(obj) {
                    let { tags, groups, filterTag } = obj;
                    let filterTags = this.getFilterTags(obj);
                    this.hasGroup = groups.length > 0;
                    if (this.hasGroup) {
                        groups = this.getGroups(groups, filterTag);
                    } else {
                        tags = this.getTags(tags, filterTag);
                    }

                    this.setData({
                        [`$td.tags.show`]: true,
                        [`$td.tags.tags`]: tags,
                        [`$td.tags.groups`]: groups,
                        [`$td.tags.filterTag`]: filterTag,
                        [`$td.tags.filterTags`]: filterTags,
                    });
                },
                getGroups(groups, filterTag) {
                    groups = groups.map(item => {
                        let { tags } = item;
                        tags = this.getTags(tags, filterTag);

                        return {...item, tags};
                    });

                    return groups;
                },
                getTags(tags, filterTag) {
                    tags = tags.map(item => {
                        const { tagId } = item;
                        const checked = filterTag.some(item => tagId == item);

                        return {...item, checked};
                    });

                    return tags;
                },
                getFilterTags(obj) {
                    const { tags, groups, filterTag } = obj;
                    let filterTags = [];
                    if (this.hasGroup) {
                        filterTags = groups.map(item => item.tags)
                            .reduce((prev, curr) => [...prev, ...curr]);
                        filterTags = dedupArr(filterTags, 'tagId');
                        filterTags = this.getTags(filterTags, filterTag)
                            .filter(item => item.checked);
                    } else {
                        filterTags = this.getTags(tags, filterTag)
                            .filter(item => item.checked);
                    }

                    return filterTags;
                },
                onHide() {
                    this.setData({
                        [`$td.tags.show`]: false
                    });
				},
                onTapTag(ev) {
                    const { item } = ev.target.dataset;
                    const { tagId, checked } = item;
                    let { tags, groups, filterTags } = this.getComponentData();
                    const len = filterTags.length;
                    const filterTag = filterTags.map(item => item.tagId);
                    const index = filterTag.indexOf(tagId);

                    if (checked) {
                        filterTag.splice(index, 1);
                    } else {
                        if (len >= 3) {
                            return;
                        } else {
                            filterTag.push(tagId);
                        }
                    }

                    const obj = {tags, groups, filterTag};
                    filterTags = this.getFilterTags(obj);
                    if (this.hasGroup) {
                        groups = this.getGroups(groups, filterTag);
                    } else {
                        tags = this.getTags(tags, filterTag);
                    }

                    this.setData({
                        [`$td.tags.tags`]: tags,
                        [`$td.tags.groups`]: groups,
                        [`$td.tags.filterTags`]: filterTags,
                    });
                },
                onClear() {
                    const { onClear } = options;

                    component.onHide();
                    typeof onClear === 'function' && onClear();
                },
                onOk() {
                    const { filterTags } = this.getComponentData();
                    const filterTag = filterTags.map(item => item.tagId);
                    const obj = {
                        detail: {filterTag}
                    };
                    const { onOk } = options;

                    component.onHide();
                    typeof onOk === 'function' && onOk(obj);
                },
            },
        });

        return component;
    },

}
