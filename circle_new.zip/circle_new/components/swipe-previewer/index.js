import { $wuxToast } from '../../components/wux';
import { openGoodsEdit } from '../../utils/util';
//import { saveFilesToAlbum } from '../../utils/download';
const app = getApp();

const autoPrefixTime = num => {
    return num < 10 ? `0${num}` : num;
};

function formatVideoTime(videoTime) {
    const m = autoPrefixTime(parseInt(videoTime/60));
    const s = autoPrefixTime(videoTime%60);
    return `${m}:${s}`;
}

Component({
    properties: {
        showPreviewer: {
            type: Boolean,
            value: false,
            observer: 'showPreviewer',
        },
        previewList: {
            type: Array,
            value: [],
        },
        previewIndex: {
            type: Number,
            value: 0,
        },
        guest:{
            type: Boolean,
            value: false,
        }
    },
    data: {
        show: false,
        renderQueue: [],
        circular: true,
        lastShowIndex: 1,
        initCurrent: 1,
        indexAll: 0,
        renderQueueIndex: 1,
        playTime: 0,
        playTimeForShow: '00:00',
        videoTimeForShow: '00:00',
        percentage: 0,
        fullScreen: true,
        total: 0,
        statusBarHeight: 0,
        isIPhoneX: app.globalData.isIpx, // iPhoneX系列
    },
    observers: {
        // showPreviewer(show) {
        //     if (show) {
        //         // 隐藏底部tabbar
        //         // wx.hideTabBar();
        //         this.initPreviewer();
        //     } else {
        //         // wx.showTabBar();
        //         this.setData({
        //             playTime: 0,
        //             playTimeForShow: '00:00',
        //             videoTimeForShow: '00:00',
        //             percentage: 0,
        //             renderQueue: [],
        //             show: false,
        //         })
        //     }
        // }
    },
    methods: {
        showPreviewer(show) {
            if (show) {
                // 隐藏底部tabbar
                // wx.hideTabBar();
                this.initPreviewer();
            } else {
                // wx.showTabBar();
                this.setData({
                    playTime: 0,
                    playTimeForShow: '00:00',
                    videoTimeForShow: '00:00',
                    percentage: 0,
                    renderQueue: [],
                    show: false,
                })
            }
        },
        initPreviewer() {
            const { previewList, previewIndex } = this.data;
            this.imgs = previewList.map((item, index) => ({ ...item, key: index }));
            console.log('previewIndex: ', previewIndex)
            this.initPreviewList(this.imgs, previewIndex);
        },
        // 通过处理数组实现初始化预览index
        initPreviewList(list, previewIndex) {
            const {
                statusBarHeight,
            } = wx.getSystemInfoSync();
            let initIndex = previewIndex;
            let preIndex = previewIndex - 1;
            let nextIndex = previewIndex + 1;
            if (initIndex === 0) {
                preIndex = list.length - 1;
            } else if (initIndex === list.length - 1) {
                nextIndex = 0;
            }
            let renderQueue = [];
            if (list.length === 1) {
                renderQueue = list;
            } else if (list.length === 2) {
                if (initIndex === 0) {
                    renderQueue = [list[previewIndex], list[nextIndex]];
                } else {
                    renderQueue = [list[preIndex], list[previewIndex]]
                }
            } else {
                renderQueue = [list[preIndex], list[previewIndex], list[nextIndex]];
            }
            let initCurrent = 0;
            let renderQueueIndex = 0;
            let lastShowIndex = 0;
            if (list.length < 3) {
                initCurrent = previewIndex;
                lastShowIndex = previewIndex;
                renderQueueIndex = previewIndex;
            } else {
                initCurrent = 1;
                lastShowIndex = 1;
                renderQueueIndex = 1;
            }
            this.setData({
                total: list.length,
                show: true,
                indexAll: previewIndex,
                renderQueue,
                initCurrent,
                renderQueueIndex,
                lastShowIndex,
                fullScreen: true,
                statusBarHeight,
            }, () => {
                console.log('initPreviewList, this.data: ', this.data)
                // 播放第一条视频
                const { fileType } = list[previewIndex];
                console.log('initPreviewList, fileType: ', fileType, list);
                if (fileType === 'video') {
                    try {
                        const videoId = `${list.length <= 2 ? 'video_0' : 'video_1'}`;  //liu add
                        console.log('initPreviewList, videoId: ', videoId)
                        this.videoContext = wx.createVideoContext(`${list.length === 1 ? 'video_0' : 'video_1'}`, this);
                        // this.videoContext = wx.createVideoContext(videoId, this);
                        console.log('initPreviewList, this.videoContext: ', this.videoContext)
                        setTimeout(() => {
                            this.videoContext.play();
                        }, 200);
                    } catch(e) {
                        console.log('play error: ', e);
                    }
                }
            });
        },
        handleTouchStart(e) {
            this.lastestTouchPoint = e.touches[0];
        },
        handleTouchMove(e) {
            if (!this.swiperTransition) {
                const { clientY: startClientY, clientX: startClientX } = this.lastestTouchPoint;
                const { clientY: moveClientY, clientX: moveClientX } = e.touches[0];
                if (
                    Math.abs(moveClientX - startClientX) > 40 &&
                    moveClientY - startClientY <= 55 &&
                    moveClientY - startClientY > 0
                ) {
                    this.disabledBack = true;
                }
            }
        },
        handleTouchEnd(e) {
            const { clientY: startClientY, clientX: startClientX } = this.lastestTouchPoint;
            const { clientY: endClientY, clientX: endClientX } = e.changedTouches[0];
            if (
                !this.swiperTransition &&
                !this.disabledBack &&
                Math.abs(endClientX - startClientX) < 40 &&
                endClientY - startClientY > 55
            ) {
                console.log('start and end point: ',this.lastestTouchPoint,  e.changedTouches[0], this.disabledBack);
                this.closePreview();
            } else {
                this.disabledBack = false;
                this.swiperTransition = false; // handleTransition flag set null
            }
        },
        handleTransition() {
            if (!this.swiperTransition) {
                this.swiperTransition = true;
            }
        },
        animationfinish(e) {
            this.swiperTransition = false; // handleTransition flag set null
            const {
                lastShowIndex,
                renderQueue,
            } = this.data;
            const current = e.detail.current;
            const diff = current - lastShowIndex;
            if (diff === 0) return;

            const { fileType } = renderQueue[lastShowIndex];
            if (fileType === 'video') {
                this.videoContext.stop();
                // const videoContext = wx.createVideoContext(`video_${lastShowIndex}`, this);
                // videoContext.stop();
            }

            this.data.lastShowIndex = current;
            const direction = diff === 1 || diff === -2
                ? 'left'
                : 'right';

            let shouldChangeIndex = 0;
            if (direction === 'left') {
                shouldChangeIndex = (current + 1) % 3;
                let newIndex = this.imgs.findIndex(item => item.key === renderQueue[current].key) + 1;
                if (newIndex > this.imgs.length - 1) {
                    newIndex = 0;
                }
                renderQueue[shouldChangeIndex] = this.imgs[newIndex];
            }
            if (direction === 'right') {
                shouldChangeIndex =
                    current - 1 >= 0
                    ? (current - 1) % 3
                    : 2;
                let newIndex = this.imgs.findIndex(item => item.key === renderQueue[current].key) - 1;
                if (newIndex < 0) {
                    newIndex = this.imgs.length - 1;
                }
                renderQueue[shouldChangeIndex] = this.imgs[newIndex];
            }
            const { videoTime } = renderQueue[current];
            const obj = {};
            if (videoTime) {
                const videoTimeForShow = formatVideoTime(videoTime);
                obj.videoTimeForShow = videoTimeForShow;
            }
            this.setData({
                ...obj,
                playTime: 0,
                percentage: 0,
                playTimeForShow: formatVideoTime(0),
                renderQueue,
                renderQueueIndex: current,
            }, () => {
                const { fileType } = renderQueue[current];
                if (fileType === 'video') {
                    this.videoContext = wx.createVideoContext(`video_${current}`, this);
                    setTimeout(() => {
                        this.videoContext.play();
                    }, 200);
                }
            });
        },
        videoLoaded(e) {
            const { renderQueue, renderQueueIndex, videoTimeForShow } = this.data;
            const { dataset, id } = e.currentTarget;
            const { indexAll } = dataset;
            const { duration } = e.detail;
            this.imgs[indexAll].videoTime = parseInt(duration);
            const { key, videoTime } = renderQueue[renderQueueIndex];
            console.log('videoLoaded: ', key, e);
            if (key === indexAll) {
                if (!videoTime || videoTimeForShow === '00:00') {
                    this.setData({
                        videoTimeForShow: formatVideoTime(videoTime),
                    });
                }
            }
        },
        videoPlayEnd(e) {
            this.setData({
                playTime: 0,
                playTimeForShow: formatVideoTime(parseInt(0)),
                percentage: 0,
            });
            setTimeout(() => {
                this.videoContext && this.videoContext.play();
            }, 100);
        },
        playTimeUpdate(e) {
            const { currentTime, duration } = e.detail;
            const { playTime } = this.data;
            if (playTime !== parseInt(currentTime)) {
                const percentage = parseInt(currentTime)/parseInt(duration);
                this.setData({
                    playTime,
                    playTimeForShow: formatVideoTime(parseInt(currentTime)),
                    percentage: percentage * 100,
                })
            }
        },
        handleTapSwiper(e) {
            this.setData({
                fullScreen: !this.data.fullScreen,
            })
        },
        closePreview() {
            this.setData({
                show: false,
            });
            this.triggerEvent('previewImgs', {
                showPreviewer: false,
            });
        },
        downloadFiles(e) {
            const { dataset: { goodsId } } = e.currentTarget;
            const allGoodsFileSource = this.imgs.filter(item => item.goods_id === goodsId);
            const images = allGoodsFileSource.reduce((pre, item) => item.fileType === 'image' ? [...pre, item.fileSource] : pre, []);
            const video = allGoodsFileSource.reduce((pre, item) => item.fileType === 'video' ? [...pre, item.fileSource] : pre, []);
            const { themeType, title } = allGoodsFileSource[0];

            const obj = {
                title,
                images,
                video: video[0],
                themetype: themeType,
                downloadStartCB: () => {
                    if (this.toast) {
                        this.toast.updateText('开始下载')
                    } else {
                        this.toast = $wuxToast.show({
                            type: 'watiing',
                            color: '#fff',
                            text: '开始下载',
                        })
                    }
                    this.toast.setHidden()
                },
                downloadingCB: (progress, text) => {
                    if (this.toast) {
                        wx.showLoading({
                            title: text,
                            mask: true
                        })
                        if (progress == 100) {
                            this.toast.setHidden()
                            wx.hideLoading()
                        }
                    }
                },
            };

            console.log('obj: ', obj);
            saveFilesToAlbum(obj);
        },
        onAddCart(e) {
            const { dataset: { goods } } = e.currentTarget;
            this.triggerEvent('onAddCart', goods);
        },
        // 分享跳转后，预览控件需要关闭
        onShareTap(e) {
            if (this.shareLongtap) return;
            const { dataset: { goods } } = e.currentTarget;
            const { is_my_album, goods_id } = goods;
            const allGoodsFileSource = this.imgs.filter(item => item.goods_id === goods_id);
            const images = allGoodsFileSource.reduce((pre, item) => item.fileType === 'image' ? [...pre, item.fileSource] : pre, []);
            const video = allGoodsFileSource.reduce((pre, item) => item.fileType === 'video' ? [...pre, item.fileSource] : pre, []);

            goods.images = images;
            goods.video = video;
            if (is_my_album) {
                this.triggerEvent('onShare', goods);
            } else {
                // 跳转
                openGoodsEdit(goods);
            }
        },
        onShareLongTap(e) {
            this.shareLongtap = true;
            const { dataset: { goods } } = e.currentTarget;
            this.triggerEvent('onShare', goods);
        },
        onShareTouchend() {
            setTimeout(() => {
                this.shareLongtap = false;
            }, 100)
        },
        preventDefaultEv() {
            return;
        },
    },
    ready() {},
})
