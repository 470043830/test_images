const util = require('../../utils/util.js');


Component({
  properties: {
    isIpx: {
      type: Boolean,
      value: false,
    },
    showProp: {
      type: Boolean,
      value: false,
      observer(newVal, oldVal) {
        this.show(newVal);
      },
    },
    all_tags: {
      type: Array,
      value: [],
    },
    groups: {
      type: Array,
      value: [],
    },
    shop_id: {
      type: String,
      value: '',
    },
    isMyAlbum: {
      type: Boolean,
      value: false,
    },
  },
  data: {
    currentTab: '',
    scrollTop: 0,
    scrollTopLeftMenu: 0,
    renderGroups: [],
    windowWidth: 0,
    windowHeight: 0,
    sheetH: 0,
    noTag: false,
    intoindex: "",
    /**是否显示复选框 */
    isShow: false,
    /**暂时储存选中的id */
    tagIdList: [],
    isShowImg: false
  },
  // 低版本小程序不支持
  // observers: {
  //     show: function(val) {
  //         this.show(val);
  //     },
  // },
  methods: {
    show(show) {
      const {
        windowWidth,
        windowHeight,
      } = wx.getSystemInfoSync();
      console.log('show: ', show, this.data.windowWidth)
      if (show) {
        this.initSheet(windowWidth, windowHeight);
      }
    },
    /**复选框选中事件 */
    isSelected(e) {
      const { tagId, groupId, index, idx, status } = e.currentTarget.dataset;
      let list = this.data.tagIdList;
      let data = status ? this.data.all_tags : this.data.renderGroups;
      let name = status ? 'all_tags' : 'renderGroups';
      let state = false;
      let num = 0;
      for (let i = 0; i < list.length; i++) {
        let item = list[i];
        if (item.tagId === tagId && (!groupId || groupId === item.groupId)) {
          state = true;
          num = i;
        }
      }
      if (state) {
        list.splice(num, 1)
      } else {
        if (list.length >= 3) {
          wx.showToast({
            title: '最多支持三个标签',
            icon: "none",
            image: ""
          })
          return
        }
        list.push({
          tagId,
          groupId: groupId || false
        })
      }
      if (status) {
        data[index].isCheckbox = data[index].isCheckbox ? false : true;
      } else {
        data[index].tags[idx].isCheckbox = data[index].tags[idx].isCheckbox ? false : true;
      }
      this.setData({
        tagIdList: list,
        [name]: data,
        checkDataStatus: status || false
      })
    },

    /**是否显示复选框 */
    isShowCheckbox() {
      this.setData({
        isShow: !this.data.isShow
      })
      this.clearData()
    },
    /**清除选中的数据 */
    clearData() {
      if (!this.data.isShow) {
        setTimeout(res => {
          let data = this.data.checkDataStatus ? this.data.all_tags : this.data.renderGroups;
          let name = this.data.checkDataStatus ? 'all_tags' : 'renderGroups';
          if (this.data.checkDataStatus) {
            for (let item of data) {
              item.isCheckbox = false;
            }
          } else {
            for (let item of data) {
              for (let options of item.tags) {
                options.isCheckbox = false;
              }
            }
          }
          this.setData({
            tagIdList: [],
            [name]: data
          })

        })
      }
    },
    /**点击多选跳转页面 */
    clickRouter() {
      const { shop_id } = this.data;
      const route = '/pages/tag_goods_list/index';
      let list = [];
      if (!this.data.tagIdList.length) {

        return
      };
      for (let item of this.data.tagIdList) {
        list.push(item.tagId)
      }
      const options = {
        shop_id,
        from: 'tags',
        tag_id: JSON.stringify(list),
      };
      util.navigateTo(route, options);
    },
    onHide() {
      /**弹窗隐藏的时候，所选中的数据 */
      setTimeout(res => {
        this.setData({
          isShow: false
        })
        this.clearData()
      }, 1000)

      this.triggerEvent('showTagSelectSheet', {
        tagSelectSheetShow: false
      });

    },
    initSheet(windowWidth, windowHeight) {
      const {
        all_tags,
        groups
      } = this.data;
      const dealedGroups = this.getGroups({
        all_tags,
        groups
      });
      const obj = {};
      const minH = 1 / 3 * windowHeight;
      const medH = 3 / 5 * windowHeight;
      const maxH = 4 / 5 * windowHeight;
      let sheetH = 0;
      console.log(dealedGroups);
      if (dealedGroups.length) {
        obj.currentTab = dealedGroups[0].groupId;
        this.caculateEachGroupArea(dealedGroups, 0, 0, windowWidth, windowHeight);
        const curH = dealedGroups[dealedGroups.length - 1].maxHeight;
        if (dealedGroups.length == 1 || dealedGroups.length == 0) {
          sheetH = minH;
        }
        if (dealedGroups.length >= 2 && dealedGroups.length < 4) {
          sheetH = medH;
        }
        if (dealedGroups.length > 4) {
          sheetH = maxH;
        }
        if (curH < minH) {
          sheetH = minH;
        } else if (curH > maxH) {
          sheetH = maxH;
        } else {
          sheetH = curH;
        }
      } else {
        const curH = Math.ceil(all_tags.length / 4) * ((windowWidth - 30) * 1 / 4 + 25);
        console.log('curH: ', curH)
        if (curH < minH) {
          sheetH = minH;
        } else if (curH > maxH) {
          sheetH = maxH;
        } else {
          sheetH = curH;
        }
      }
      this.setData({
        windowWidth,
        windowHeight,
        renderGroups: JSON.parse(JSON.stringify(dealedGroups)),
        sheetH,
        noTag: groups.length === 0 && all_tags.length === 0,
        ...obj,
      }, () => {
        // 可视区域
        this.getContainViews();
      });
    },
    getContainViews() {
      const {
        scrollTopLeftMenu,
        sheetH,
        renderGroups = []
      } = this.data;
      if (renderGroups.length) {
        const num = Math.round(scrollTopLeftMenu / 44);
        this.containViewsNum = Math.round(sheetH / 44);
        this.containViews = renderGroups.slice(num, num + this.containViewsNum);
      }
    },
    getGroups(data) {
      const {
        all_tags = [], groups = []
      } = data;

      return groups.map(group => {
        let {
          tags = []
        } = group;
        tags = tags.map(tagId => all_tags.filter(items => tagId == items.tagId)[0]);
        tags = tags.filter(item => !!item);
        return {
          ...group,
          tags
        };
      });
    },
    caculateEachGroupArea(dealedGroups, lastMaxHeight, index, windowWidth, windowHeight) {
      if (index < dealedGroups.length) {
        const {
          tags = []
        } = dealedGroups[index];
        const rows = Math.ceil(tags.length / 3);
        // const maxHeight = lastMaxHeight + rows * ((windowWidth * 3/4)/3 - 20 + 20 + 25) + 30;
        const imgW = (windowWidth * 3 / 4) / 3 - 20;
        const tagNameH = 25;
        const padding = 16;
        const perRowH = imgW + padding * 2 + tagNameH;
        const maxHeight = lastMaxHeight + rows * perRowH + 30;

        dealedGroups[index].minHeight = lastMaxHeight;
        dealedGroups[index].maxHeight = maxHeight - 1;
        this.caculateEachGroupArea(dealedGroups, maxHeight, index + 1, windowWidth, windowHeight);
      }
    },
    handleScrollRight(e) {

      /**
       * scroll_disabled
       * true 代表点击tab使右侧scroll-view滑动页面，此时不能调用右侧scroll-view页面滚动事件
      */
      if (this.data.scroll_disabled) {
        this.setData({
          scroll_disabled: false
        })
        return
      }

      const {
        scrollTop
      } = e.detail;
      let {
        renderGroups = [], currentTab, scrollTopLeftMenu
      } = this.data;
      let newTab = '';
      for (let i = 0; i < renderGroups.length; i++) {
        const {
          minHeight,
          maxHeight,
          groupId
        } = renderGroups[i];

        if (scrollTop < maxHeight && scrollTop >= minHeight) {
          //   console.log(minHeight, maxHeight, "maxHeightminHeight")
          newTab = groupId;
        }
      }

      if (newTab && newTab != currentTab) {
        const index = this.containViews.findIndex(item => item.groupId === newTab);
        if (index < 2) {
          // 向上滚动3个元素
          const newScrollT = scrollTopLeftMenu - 44 * 3;
          scrollTopLeftMenu = newScrollT >= 0 ? newScrollT : 0;
        } else if (index > this.containViews.length - 3) {
          scrollTopLeftMenu = scrollTopLeftMenu + 44 * 3;
        }
        this.setData({
          currentTab: newTab,
          scrollTopLeftMenu,
        }, () => {
          this.getContainViews();
        });
      }
    },
    tapLeftGroupMenu(e) {

      const {
        renderGroups
      } = this.data;
      const {
        dataset,
      } = e.currentTarget;
      const {
        groupId, idx
      } = dataset;
      const group = renderGroups.find(item => item.groupId == groupId);
      this.setData({
        scrollTop: group.minHeight + 1,
        currentTab: groupId,
        scroll_disabled: true,
        intoindex: `text${idx}`
      })

    },
    tapTag(e) {
      /**isShow 为防止冒泡 */
      if (this.data.isShow) {
        return
      }
      const { shop_id } = this.data;
      const { dataset } = e.currentTarget;
      const { tagId } = dataset;
      const route = '/pages/tag_goods_list/index';
      const options = {
        shop_id,
        from: 'tags',
        tag_id: JSON.stringify([tagId]),
      };
      util.navigateTo(route, options);
    },
    tapGroup(e) {
      const {
        shop_id
      } = this.data;
      const {
        dataset
      } = e.currentTarget;
      const {
        groupId
      } = dataset;
      const route = '/pages/tag_goods_list/index';
      const options = {
        shop_id,
        from: 'tags',
        group_id: groupId,
      };
      util.navigateTo(route, options);
    },
    preventDefaultEv() {
      return;
    },
  },
})
