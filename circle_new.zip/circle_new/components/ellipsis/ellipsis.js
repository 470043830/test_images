import WuxComponent from '../component'

export default {
    /**
     * 默认参数
     */
    setDefaults() {
        return {
            // onEllipsisLongTap: () => {}
        }
    },
    init(opts = {}) {
        const options = Object.assign({}, this.setDefaults(), opts)
        // 实例化组件
        const component = new WuxComponent({
            scope: '$ellipsis',
            data: options,
            methods: {
                onEllipsisLongTap(e) {
                    if (!e.currentTarget.dataset.title) {
                        return;
                    }
                    wx.setClipboardData({
                        data: e.currentTarget.dataset.title,
                        success: () => {
                            wx.showToast({
                                title: '已复制',
                                icon: 'success',
                                duration: 1000,
                                mask: true
                            })
                        }
                    })
                }
            },
        })
        return component
    },
}
