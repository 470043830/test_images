import WuxComponent from '../component'

import { fetch } from '../../utils/util';
import { getSkus, getColors } from '../../utils/sku-util';

export default {
    /**
     * 默认参数
     */
    setDefaults() {
        return {
            addCartUrl: '/shoppingCart/shopping_cart_operation.jsp?act=add_shopping_cart',
            postCartUrl: '/order/buyer_order_operation.jsp?act=create_order_temp',
            iconSize: 60,
            skuSlideNum: 5,
            step: 1,
            min: 0,
            max: 100000,
            onAddCart: undefined,
            onPostOrder: undefined,
        };
    },

    init(opts = {}) {
        const options = Object.assign({}, this.setDefaults(), opts);
        const scope = '$td.cartSheet';

        console.log('options: ', options);
        // 实例化组件
        const component = new WuxComponent({
            scope,
            data: options,
            methods: {
                onHide() {
                    this.setData({
                        [`${scope}.show`]: false,
                    });
                },
                onShow(props) {
                    let {
                        is_my_album = false,
                        shop_id = '',
                        goods_id = '',
                        imgs = [],
                        priceArr = [],
                        price = '',
                        skus = [],
                        sku = null,
                        colors = [],
                        formats = [],
                        max = options.max,
                        negativeStock = true,
                        skuPriceType,
                    } = props;
                    skus = getSkus(props);
                    const formatID = this.getFormatID({...props, skus});
                    console.log('skuPriceType: ', skuPriceType);
                    this.setData({
                        [`${scope}.show`]: true,
                        [`${scope}.is_my_album`]: is_my_album,
                        [`${scope}.shop_id`]: shop_id,
                        [`${scope}.goods_id`]: goods_id,
                        [`${scope}.icon`]: imgs[0],
                        [`${scope}.priceArr`]: priceArr,
                        [`${scope}.price`]: price,
                        [`${scope}.skus`]: skus,
                        [`${scope}.sku`]: sku,
                        [`${scope}.colors`]: colors,
                        [`${scope}.formats`]: formats,
                        [`${scope}.max`]: max,
                        [`${scope}.negativeStock`]: negativeStock,
                        [`${scope}.formatID`]: formatID,
                        [`${scope}.note`]: '',
                        [`${scope}.skuPriceType`]: skuPriceType,
                    });
                },
                getFormatID(props) {
                    let { colors = [], formats = [], skus = [] } = props;

                    if (skus.length <= 0) return '';

                    // 数组以对象方式解构
                    let { 0: { formatId = '' } = {} } = getColors(colors, skus);
                    if (formats.length <= 0) {
                        formatId = '';
                    }

                    return formatId;
                },
                onClickSlide(ev) {
                    const { id } = ev.currentTarget;

                    this.setData({
                        [`${scope}.formatID`]: id.substring(2),
                    });
                },
                updateSkus({id = '', quantity = 0}) {
                    let { skus } = this.getComponentData();
                    skus = skus.map(sku => {
                        return id == sku.id ? {...sku, quantity} : sku;
                    });

                    this.setData({
                        [`${scope}.skus`]: skus,
                    });
                },
                onPlus(ev) {
                    let { sku } = ev.target.dataset;
                    let { quantity, stock = '' } = sku;
                    const { step, max } = options;
                    quantity = quantity + step;
                    const { negativeStock, price } = this.getComponentData();
                    console.log('price: ', price)
                    const skuMax = negativeStock ? max : (!!`${stock}` ? Math.min(stock, max) : max);
                    sku = {
                        ...sku,
                        quantity,
                    };

                    if (!this.validateMax(quantity, skuMax)) return;

                    this.updateSkus(sku);
                },
                onMinus(ev) {
                    let { sku } = ev.target.dataset;
                    let { quantity } = sku;
                    const { step, min } = options;
                    quantity = quantity - step;
                    sku = {
                        ...sku,
                        quantity,
                    };

                    if (!this.validateMin(quantity, min)) return;

                    this.updateSkus(sku);
                },
                validateMax(quantity, max) {
                    if (typeof max === undefined) return false;

                    if (isNaN(max)) return false;

                    if (quantity > max) {
                        wx.showToast({
                            icon: 'none',
                            title: max > 0 ? `最大不能超过${max}` : '库存不足',
                        });
                        return false;
                    }

                    return true;
                },
                validateMin(quantity, min) {
                    if (typeof min === undefined) return false;

                    if (isNaN(min)) return false;

                    if (quantity < min) {
                        wx.showToast({
                            icon: 'none',
                            title: `最小不能小于${min}`,
                        });
                        return false;
                    }

                    return true;
                },
                onChange(ev) {
                    let { sku } = ev.target.dataset;
                    let quantity = ev.detail.value;
                    quantity = !!quantity ? quantity|0 : quantity;
                    if (!!quantity) {
                        const { min, max } = options;
                        const { negativeStock } = this.getComponentData();
                        const { stock = '' } = sku;
                        const skuMax = negativeStock ? max : (!!`${stock}` ? Math.min(stock, max) : max);
                        if (!this.validateMax(quantity, skuMax)) return sku.quantity;
                        if (!this.validateMin(quantity, min)) return sku.quantity;
                    }
                    sku = {
                        ...sku,
                        quantity,
                    };

                    this.updateSkus(sku);
                },
                onBlur(ev) {
                    let { sku } = ev.target.dataset;
                    let { quantity } = sku;
                    if (!quantity) {
                        const { min } = options;
                        sku = {
                            ...sku,
                            quantity: min || 0,
                        }

                        this.updateSkus(sku);
                    }
                },
                onChangeNote(ev) {
                    const note = ev.detail.value;

                    this.setData({
                        [`${scope}.note`]: note,
                    });
                },
                getPostData() {
                    let { shop_id, goods_id, skus, note } = this.getComponentData();
                    skus = skus.filter(sku => sku.quantity > 0);

                    return {
                        shop_id,
                        goods_id,
                        skus,
                        note,
                    };
                },
                onAddCart(ev) {
                    const data = this.getPostData();
                    const { note, ...rest } = data;
                    const goodsInfo = {
                        ...rest,
                        goodsNote: note,
                    };
                    const postData = {
                        goodsInfo: JSON.stringify(goodsInfo),
                    };
                    const { addCartUrl: url, onAddCart } = options;

                    wx.showLoading({
                        mask: true,
                        title: '加载中...',
                    });
                    fetch(url, postData, 'POST')
                        .then(res => {
                            const { errcode, errmsg } = res.data;

                            wx.hideLoading();
                            if (errcode == 0) {
                                this.onHide();
                                wx.showToast({
                                    icon: 'success',
                                    title: errmsg,
                                });
                                typeof onAddCart === 'function' && onAddCart();
                            } else {
                                wx.showToast({
                                    icon: 'none',
                                    title: errmsg,
                                });
                            }
                        }, res => {
                            console.log(res);
                            wx.hideLoading();
                            wx.showToast({
                                icon: 'none',
                                title: '请求失败，请稍后重试~',
                            });
                        });
                },
                onPost(ev) {
                    const data = this.getPostData();
                    const { note, ...goods } = data;
                    const postData = {
                        orderFrom: 1,
                        goodsList: JSON.stringify([goods]),
                        goodsNote: note,
                    };
                    const { postCartUrl: url, onPostOrder } = options;

                    wx.showLoading({
                        mask: true,
                        title: '加载中...',
                    });
                    fetch(url, postData, 'POST')
                        .then(res => {
                            const { errcode, errmsg, result: { orderId } } = res.data;

                            wx.hideLoading();
                            if (errcode == 0) {
                                this.onHide();
                                wx.navigateTo({
                                    url: `/pages/new_order/index?orderId=${orderId}`,
                                });
                                typeof onPostOrder === 'function' && onPostOrder();
                            } else {
                                wx.showToast({
                                    icon: 'none',
                                    title: errmsg,
                                });
                            }
                        }, res => {
                            console.log(res);
                            wx.hideLoading();
                            wx.showToast({
                                icon: 'none',
                                title: '请求失败，请稍后重试~',
                            });
                        });
                },
                preventDefaultEv() {
                    return;
                },
            },
        });

        return component;
    },

}
