import { isIOS, navigateTo } from '../../utils/util';

function launchAppError() {
    const isIos = isIOS();
    let content = '';
    if (isIos) {
        content = '请手动打开App，下载App请前往苹果APP store 搜索「微商相册」。';
    } else {
        content = '请手动打开App，下载App请前往百度搜索「微商相册」。';
    }

    wx.showModal({
        title: '提示',
        content,
        success: function (res) {
            if (res.confirm) {
                const route = '/pages/app/index';

                navigateTo(route);
            } else if (res.cancel) {
                console.log('用户点击取消');
            }
        }
    });
}

export default launchAppError;
