
// app.js
// const ald = require('./utils/ald-stat.js');
// const miniShopPlugin = requirePlugin('mini-shop-plugin');
var constant = require('./utils/constant.js');
// const circleData = require('./utils/circle-data.js');
// const util = require('./utils/util');  //不能包含这个，会报错
// import tabbarConfig from './tabbar-component/tabbar-cfg';

App({
    globalData: {
        authSetting: null,
        userInfo: null,
        systemInfo: null,//客户端设备信息
        // tabBar: {
        //     "backgroundColor": "#ffffff",
        //     "color": "#979795",
        //     "selectedColor": "#1c1c1b",
        //     "list": tabbarConfig
        // },
        showPopoverMask: false,
        pageInfo: {},
        circleInfo: {},

        //1215 add
        circleConfig: {},
        circleCategoryList: [],
        circleApplyInfo: {},  //my info
        circleStatus: {},
        triggerPagePath: '', //login action trigger
    },

    getToken() {
        const { userInfo, circleConfig } = this.globalData;
        if (userInfo && userInfo.token) {
            return userInfo.token;
        }
        if (circleConfig.touristToken) {
            return circleConfig.touristToken;
        }
        return '';
    },

    setCircleConfig(obj) {
        this.globalData.circleConfig = obj;
    },

    getCircleConfig() {
        return this.globalData.circleConfig;
    },

    setCircleApplyInfo(obj) {
        this.globalData.circleApplyInfo = obj;
    },

    getCircleApplyInfo() {
        return this.globalData.circleApplyInfo;
    },

    setCircleCategoryList(list) {
        this.globalData.circleCategoryList = list;
    },

    getCircleCategoryList() {
        return this.globalData.circleCategoryList;
    },

    getCircleId() {
        const { circleId = '' } = this.globalData.circleConfig;
        return circleId;
    },

    getMyShopId() {
        const { shopId = '' } = this.globalData.circleApplyInfo;
        return shopId;
    },

    setCircleStatus(circleStatus) {
        this.globalData.circleStatus = circleStatus;
    },

    getCircleStatus() {
        return this.globalData.circleStatus;
    },

    setCircleAdminValue(v) {
        this.globalData.circleAdminValue = v;
    },

    getCircleAdminValue() {
        return this.globalData.circleAdminValue;
    },

    onLaunch(options) {
        console.log('App onLaunch', options);
        // miniShopPlugin.initApp(this, wx);
        // miniShopPlugin.initHomePath('/pages/home/index');
        // if (options.scene == 1035){
        //   //公众号菜单
        //   this.globalData.property_id = options.query.property_id||''
        // }else{
        //   //其它入口移除物业ID,直接进入的是商圈首页
        //   this.globalData.property_id = ''
        // }
        this.globalData.entry_scene = options.scene;
        //隐藏系统tabbar
        // wx.hideTabBar();
        //获取设备信息
        this.getSystemInfo();
        this.globalData.property_id = options.query.property_id || '';
        this.globalData.proxy_id = options.query.proxy_id || '';

    },
    onShow(options) {
        const { scene } = options;
        console.log('App onShow: ', scene, options);
        // if (options.scene == 1035) {
        //   //公众号菜单
        //   this.globalData.property_id = options.query.property_id||''
        // } else {
        //   //其它入口移除物业ID,直接进入的是商圈首页
        //   this.globalData.property_id = ''
        // }
        this.globalData.property_id = options.query.property_id || '';
        this.globalData.proxy_id = options.query.proxy_id || '';

        //...
        if (options.referrerInfo && options.referrerInfo.appId) {
            const extraData = options.referrerInfo.extraData;
            if (extraData) {
                const { albumInfo = {}, extParam = '' } = extraData;
                console.log('extParam: ', extParam);
                if (albumInfo.albumId) {
                    wx.setStorageSync(constant.USER_INFO_STORAGE, albumInfo);
                    this.globalData.userInfo = this.getStorageUserInfo();
                    console.log('triggerPagePath: ', this.globalData.triggerPagePath);
                    if (this.globalData.triggerPagePath) {
                        wx.reLaunch({ url: this.globalData.triggerPagePath });
                        this.globalData.triggerPagePath = ''; //reset
                    } else {
                        wx.reLaunch({ url: '/pages/home/index?login=1' });
                    }

                }
            }
        }

        //...
        this.updateApp();
    },
    onHide(options) {
        console.log('onHide', options);
    },

    // for test
    updateApp() {
        const updateManager = wx.getUpdateManager()

        updateManager.onCheckForUpdate(function (res) {
            // 请求完新版本信息的回调
            console.log(res.hasUpdate)
        })

        updateManager.onUpdateReady(function () {
            wx.showModal({
                title: '更新提示',
                content: '新版本已经准备好，是否重启应用？',
                success: function (res) {
                    if (res.confirm) {
                        // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
                        updateManager.applyUpdate()
                    }
                }
            })
        })

        updateManager.onUpdateFailed(function () {
            // 新版本下载失败
        })

    },

    /**
     * 获取位置信息
     * @param cb
     */
    getLocation(suc, fail, finish) {
        wx.getLocation({
            type: 'wgs84',
            success: res => {
                typeof suc === `function` && suc(res);
            },
            fail: (err) => {
                //重新获取授权
                // this.setInfoPromission();
                console.log(err);
                typeof fail === `function` && fail();
            }
        });
    },

    // 清除失效token：重新请求时执行this.login获取新token
    clearToken(data = {}, callback) {
        const { errcode } = data;

        if (errcode == 9) {
            this.globalData.userInfo = null;
            typeof callback === 'function' && callback();
        }
    },

    getCustomBarInfo() {
        let e = wx.getSystemInfoSync();
        let statusBarHeight = e.statusBarHeight;
        let rect = wx.getMenuButtonBoundingClientRect();
        let customBar = 0;
        let headerBar = 0;

        headerBar = rect.height + (rect.top - e.statusBarHeight) * 2;
        customBar = headerBar + e.statusBarHeight;

        return {
            headerBar, customBar, statusBarHeight
        };
    },

    getSystemInfo() {
        let t = this;
        wx.getSystemInfo({
            success(res) {
                t.globalData.systemInfo = res;
                const { model = '', screenHeight = 0 } = res;
                const isIPhone = model.toLowerCase().indexOf('iphone') != -1;
                t.globalData.isIphoneX = isIPhone && screenHeight >= 812;
                t.globalData.isIpx = t.globalData.isIphoneX;
            }
        });
    },

    editTabbar() {
        // let tabbar = this.globalData.tabBar;
        // let currentPages = getCurrentPages();
        // let _this = currentPages[currentPages.length - 1];
        // let pagePath = _this.route;
        // (pagePath.indexOf('/') != 0) && (pagePath = '/' + pagePath);
        // for (let i in tabbar.list) {
        //     tabbar.list[i].selected = false;
        //     (tabbar.list[i].pagePath == pagePath) && (tabbar.list[i].selected = true);
        // }
        // _this.setData({
        //     tabbar: tabbar
        // });
    },




    /**
     * 获取用户信息
     * @param sucCB
     * @param failCB
     */
    getUserInfo(sucCB, failCB, album_id) {
        if (this.globalData.userInfo) {
            typeof sucCB == "function" && sucCB(this.globalData.userInfo);
        } else {
            //util.getPromission();
            //this.getPromission();
            //调用登录接口
            // util.login(sucCB, failCB, album_id);
        }
    },

    // 未登录：离线
    offline() {
        const userInfo = this.getStorageUserInfo();
        let offline = !this.globalData.userInfo && !userInfo;
        if (!this.globalData.userInfo && userInfo) {
            this.globalData.userInfo = userInfo;
        }

        //handle token expired
        if (this.globalData.userInfo && this.globalData.userInfo.tokenExpired) {
            offline = true;
        }
        return offline;
    },


    storageUserInfo(obj) {
        console.log('storageUserInfo: ', constant.USER_INFO_STORAGE);
        wx.setStorageSync(constant.USER_INFO_STORAGE, obj);
    },

    getStorageUserInfo() {
        let userInfo = wx.getStorageSync(constant.USER_INFO_STORAGE);

        // console.log('userInfo: ', constant.USER_INFO_STORAGE, userInfo);

        if (!userInfo || !userInfo.token) {
            userInfo = null;
        }
        // 游客
        if (userInfo && userInfo.is_guest) {
            userInfo = null;
        }

        return userInfo;
    },

    clearStorageUserInfo() {
        wx.removeStorageSync(constant.USER_INFO_STORAGE);
    },


    /** 监听函数的对象数组 */
    watchCallBack: {},
    watchingKeys: [],

    setGlobalData: function (obj) {
        console.log('setGlobalData: ', obj);
        Object.keys(obj).map(key => {
            this.globalData[key] = obj[key];
        });
    },

    $watch(key, cb) {
        // this.watchCallBack = Object.assign({}, this.watchCallBack, {
        //     [key]: this.watchCallBack[key] || []
        // });
        // this.watchCallBack[key].push(cb);
        // if (!this.watchingKeys.find(x => x === key)) {
        //     const that = this;
        //     this.watchingKeys.push(key);
        //     Object.defineProperty(this.globalData, key, {
        //         configurable: true,
        //         enumerable: true,
        //         set: function (val) {
        //             const old = that.globalData$[key];
        //             that.globalData$[key] = val;
        //             that.watchCallBack[key].map(func => func(val, old));
        //         },
        //         get: function () {
        //             return that.globalData$[key];
        //         }
        //     });
        // }
    },
});
