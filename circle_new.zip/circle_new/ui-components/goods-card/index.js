// ui-components/custom-title-bar/index.js
const circleUtil = require('../../utils/circle-util.js');

Component({
    /**
     * 组件的属性列表
     */
    properties: {
        goods: Object,
        isShopName: false,
    },

    /**
     * 组件的初始数据
     */
    data: {

    },

    /**
     * 组件的方法列表
     */
    methods: {
        onGoodsTap() {
            const goods = this.properties.goods;
            console.log('onGoodsTap...', goods);
            if (!circleUtil.isMiniChecked()) {
                return;
            }

            const { goods_id, shop_id } = goods;
            wx.navigateTo({
                url: `/pages/goods_detail_circle/index?shop_id=${shop_id}&goods_id=${goods_id}&from=wsxc`,
                success: function (res) {
                    // if (goods.videoURL && !goods.imgs){
                    //     goods.imgs = ['http://xcimg.szwego.com/circle_images/newui/black.jpg'];
                    //     goods.themeType = 1;
                    // }
                    res.eventChannel.emit('acceptGoodsItemData', goods);
                }
            });

            // let postData = [
            //     {
            //         snsId: '111',
            //         wxid: 'wx001',
            //         title: '三膏标题名3333333333333',
            //         createTime: Date.now(),
            //         imgUrls: ['http://img/dasda111', 'http://img/dasda111'], //JSON.stringify(['http://img/dasda111', 'http://img/dasda111']),
            //         videoUrl: "http://video/dasda111"
            //     }
            // ];
            // postData[0].title = this.properties.goods.title;
            // wx.request({
            //     url: 'https://www.wsxcme.com/service/circle/circle_new_interface.jsp?act=addWxMoments', //仅为示例，并非真实的接口地址
            //     method: 'POST',
            //     data: postData,
            //     header: {
            //         'content-type': 'application/json' // 默认值
            //     },
            //     success(res) {
            //         console.log(res.data);
            //     }
            // });
        },
        onBackTap() {
            console.log('onBackTap...');
            this.triggerEvent('backTap', {}, {});
        }
    },

    attached() {

    }
});
