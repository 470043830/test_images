
const circleUtil = require('../../utils/circle-util.js');
const util = require('../../utils/util.js');

Component({
  options: {
    addGlobalClass: true
  },

  /**
   * 组件的属性列表
   */
  properties: {
    title111: {
      type: String,
      value: ''
    },

    list: {
      type: Array,
      value: [],
      observer: function (newVal, oldVal) {
        const {
          listIndex,
        } = this.properties;
        // console.log('grid observer, ', listIndex, newVal[listIndex]);
        if (this.data.itemData.goods_id != newVal[listIndex].goods_id) {
          this.setData({
            itemData: newVal[listIndex]
          });
        }
      }
    },

    listIndex: {
      type: Number,
      value: 0
    },

  },

  /**
   * 组件的初始数据
   */
  data: {
    lazyload: true,

    title: '市场全景指引图...',
    imgs: [
      // 'https://xcimg.szwego.com/o_1fegksd7ivimcv33t5j3n1v64v.jpg?imageMogr2/auto-orient/thumbnail/!310x310r/quality/100/format/jpg',
      // 'https://xcimg.szwego.com/o_1fegksd7ivimcv33t5j3n1v64v.jpg?imageMogr2/auto-orient/thumbnail/!310x310r/quality/100/format/jpg',
      // 'https://xcimg.szwego.com/o_1fegksd7ivimcv33t5j3n1v64v.jpg?imageMogr2/auto-orient/thumbnail/!310x310r/quality/100/format/jpg',
      // 'https://xcimg.szwego.com/o_1fegksd7ivimcv33t5j3n1v64v.jpg?imageMogr2/auto-orient/thumbnail/!310x310r/quality/100/format/jpg',
      // 'https://xcimg.szwego.com/o_1fegksd7ivimcv33t5j3n1v64v.jpg?imageMogr2/auto-orient/thumbnail/!310x310r/quality/100/format/jpg',
      // 'https://xcimg.szwego.com/o_1fegksd7ivimcv33t5j3n1v64v.jpg?imageMogr2/auto-orient/thumbnail/!310x310r/quality/100/format/jpg',
      // 'https://xcimg.szwego.com/o_1fegksd7ivimcv33t5j3n1v64v.jpg?imageMogr2/auto-orient/thumbnail/!310x310r/quality/100/format/jpg',
      // 'https://xcimg.szwego.com/o_1fegksd7ivimcv33t5j3n1v64v.jpg?imageMogr2/auto-orient/thumbnail/!310x310r/quality/100/format/jpg'
    ],
    itemData: {
      imgs: [],
      time_stamp: 0,
      themeType: 0,
    },

    priceTypesObj: {
      '1': '拿货价',
      '2': '零售价',
      '3': '批发价',
      '4': '打包价'
    },

    category: 0,
    filterText: '',


    // share_time: '2022/10/10',
  },

  /**
   * 组件的方法列表
   */
  methods: {
    iconTap(e) {
      console.log('iconTap...', e);
      // nineGrid.iconTap(e, this);
    },

    titleTap(e) {
      console.log('titleTap......', e);
      // nineGrid.titleTap(e, this);
      this.onGridItemTap(e);
    },

    onGridItemTap(e) {
      console.log('onGridItemTap111...', e);
      //for test...
      // this.titleTap(e);

      const {
        shop_id,
        goods_id,
        category = 0
      } = this.data.itemData;

      let url = `/pages/goods_detail_circle/index?shop_id=${shop_id}&goods_id=${goods_id}`;

      if (category == 0) {
        url += '&from=wsxc';
      }

      console.log('url: ', url);
      // return;

      wx.navigateTo({
        url,
        success: function (res) {
          //   res.eventChannel.emit('acceptGoodsItemData', item);
        }
      });

    },

    onTestCatchTap111(e) {
      const {
        gid
      } = e.currentTarget.dataset;
      console.log('onTestCatchTap111111...', gid);
      circleUtil.tempData.shareChosedGid = gid;
    },

    onTestTap111(e) {
      const {
        gid
      } = e.currentTarget.dataset;

      console.log('onTestTap111...', gid);
      circleUtil.tempData.shareChosedGid = gid;
      // wx.setStorageSync('share_chosed_gid', gid);
      // this.triggerEvent("customevent_wxc", { gid }, { bubbles: true, composed: true });
    },

    onViewImg(e) {
      console.log("grid onViewImg ", e);
      const {
        listIndex
      } = this.properties;
      const {
        index
      } = e.currentTarget.dataset;
      this.triggerEvent('previewMedias', {
        listIndex,
        index
      }, { bubbles: true, composed: true });
    },

    onViewImg111(e) {
      console.log("grid onViewImg111", e);

      const {
        index,
        imgssrc,
        goodsIndex
      } = e.target.dataset;
      console.log("grid onViewImg222", index, imgssrc, goodsIndex);

      wx.previewImage({
        current: imgssrc[index],
        // 当前显示图片的http链接
        urls: imgssrc // 需要预览的图片http链接列表
      });

      return;


      const current = imgssrc[index];
      let that = this;
      const {
        list
      } = that.data; // const urls = list.map(item => item.imgsSrc)
      //     .reduce((prev, curr) => [...prev, ...curr]);

      console.log("onViewImg, list[goodsIndex]: ", list[goodsIndex], goodsIndex); // wx.previewImage({


      const {
        previewList,
        previewIndex
      } = util.getPreviewerInitData(list, goodsIndex, index, true); // console.log('goodsIndex: ', goodsIndex);
      // console.log('index: ', index)
      // console.log('previewList: ', previewList.length, previewList);

      that.triggerEvent('previewImgs', {
        previewList,
        previewIndex
      }, { bubbles: true, composed: false });
    }

  },
  attached: function () {

    // const{
    //   listIndex,
    //   list
    // } = this.properties;
    // console.log('grid attached, ', listIndex, list[listIndex]);
    // this.setData({
    //   itemData: list[listIndex]
    // });
  },
  detached: function () { }
});
