
Component({
  options: {
    addGlobalClass: true
  },

  /**
   * 组件的属性列表
   */
  properties: {
    list: {
      type: Array,
      value: [],
      // observer: function (newVal, oldVal) {
      // console.log('grid list: ', newVal);
      // this.setData({
      //   items: newVal
      // });
      // }
    },

  },

  /**
   * 组件的初始数据
   */
  data: {
    clamp: 6,
    texts: [],
    // items: [],
  },

  /**
   * 组件的方法列表
   */
  methods: {
    // iconTap(e) {
    //   console.log('iconTap...', e);
    //   // nineGrid.iconTap(e, this);
    // },

    // titleTap(e) {
    //   console.log('titleTap...', e);
    //   // nineGrid.titleTap(e, this);
    // },

    // onGridItemTap(e) {
    //   console.log('onGridItemTap111...', e);
    //   //for test...
    //   // this.titleTap(e);
    // },

    onTestCatchTap111(e) {
    },

  },
  attached: function () {
    console.log('grid list attached...');
  },
  detached: function () { }
});
