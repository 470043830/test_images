// ui-components/button/index.js
Component({
    /**
     * 组件的属性列表
     */
    properties: {
        buttonText: String,
        openType: String,
        isCoverView: {
            type: Boolean,
            value: false
        }
    },

    /**
     * 组件的初始数据
     */
    data: {

    },

    /**
     * 组件的方法列表
     */
    methods: {
        onBtnTap(){
            console.log('onBtnTap...');
            this.triggerEvent('onBtnTap', {}, {});
        },
        bindPhoneNumber(e) {
            // console.log(e.detail.errMsg);
            // console.log(e.detail.iv);
            // console.log(e.detail.encryptedData);
            this.triggerEvent('onPhoneNumber', e.detail, {});
        }
    }
});
