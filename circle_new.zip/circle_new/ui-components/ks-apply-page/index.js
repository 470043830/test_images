// ui-components/ks-apply-page/index.js
const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const circleData = require('../../utils/circle-data.js');

Component({
  options: {
    addGlobalClass: true
  },
  /**
   * 组件的属性列表
   */
  properties: {
    isApplying: true,
    isZhuBo: false,
    titleText: '',
  },

  /**
   * 组件的初始数据
   */
  data: {
    ruzhuText: '',
    userInfo: {},
    applyInfo: {},
    priceArray: ['高端', '中高端', '极致性价比'],
  },

  // 以下生命周期会被lifetimes对应生命周期覆盖
  attached: function () {
    console.log('ks-apply-page attached...');
    const { isApplying, isZhuBo } = this.properties;
    let ruzhuText = circleData.getCheckedText()["ruzhu"];
    let titleText = '';
    if (isApplying) {
      if (isZhuBo) {
        titleText = '主播采购方入驻';
      } else {
        titleText = '入驻申请';
      }
    } else {
      titleText = '编辑';
    }
    this.setData({ ruzhuText, titleText });

    util.initQiniu();
    setTimeout(async () => {
      const { user = {} } = await circleData.getMyUserInfo();
      let applyInfo = {};

      if (this.properties.isZhuBo) {
        applyInfo = await circleData.getAnchorCircleApply();
        if (applyInfo.priceDesc) {
          let priceIndex = this.data.priceArray.indexOf(applyInfo.priceDesc);
          // console.log('priceIndex: ', priceIndex);
          this.setData({ priceIndex });
        }
      } else {
        applyInfo = await circleData.getCircleApply();
      }
      this.setData({
        userInfo: user,
        applyInfo
      });
    }, 10);


  },
  detached: function () {
  },

  /**
   * 组件的方法列表
   */
  methods: {
    /***
    * 提交信息
    */
    async postUserApplyInfo() {
      const {
        userInfo,
        applyInfo, priceArray, priceIndex
      } = this.data;
      const { region, latitude, longitude, category, detailAddress, age, platform, remark } = applyInfo;
      const { circleId } = getApp().getCircleConfig();

      const param = {
        circleId,
        shopId: userInfo.shop_id,
        shopName: applyInfo.shopName || userInfo.shop_name,
        wechatId: applyInfo.wechatId || userInfo.wechat_id,
        wechatQrcode: applyInfo.wechatQrcode || userInfo.wechat_qrcode || '',
        shopIcon: applyInfo.shopIcon || userInfo.user_icon,
        phoneNumber: applyInfo.phoneNumber || userInfo.phone_number,
        detailAddress, //userInfo.booth_id,
        region, latitude, longitude, category, age, platform, remark,
        priceDesc: priceIndex >= 0 ? priceArray[priceIndex] : '',
        accountName: applyInfo.accountName,
      };
      console.log('param: ', param);

      //...
      if (this.properties.isZhuBo) {
        if (!category || !param.wechatId || !param.phoneNumber || !param.age || !param.remark
          || !param.platform || !param.priceDesc) {
          wx.showModal({
            title: '提示',
            content: '主播入驻信息需填写完整，不能为空',
            showCancel: true,
            cancelText: '取消',
            cancelColor: '#000000',
            confirmText: '确定',
            confirmColor: '#285B9A',
          });
          return;
        }
        console.log('start save to cloud...');
        const res = await circleData.saveCircleAnchorApply(param);
      } else {
        //check param
        if (!category) {
          wx.showToast({
            title: '请先选择经营类目！',
            icon: 'none',
          });
          return;
        }
        const res = await circleData.saveCircleApply(param);
      }

      // this.setData({ changePage: 3 });
      this.triggerEvent('saveInfoOk', { whichPage: 3 });
    },

    onSelectTagsClick() {
      const { applyInfo } = this.data;
      const that = this;
      let tagsShowText = applyInfo.category || '';
      wx.navigateTo({
        url: '/pages/select-tags/index?tagsShowText=' + tagsShowText,
        events: {
          // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
          acceptDataFromSelectTagPage(data) {
            console.log(data.tagsShowText, that.data);
            applyInfo.category = data.tagsShowText;
            that.setData({ applyInfo }, () => {
              console.log(data.tagsShowText, that.data);
            });
          }
        },
      });
    },

    onSelectPlatformClick() {
      const { applyInfo } = this.data;
      const that = this;
      let tagsShowText = applyInfo.platform || '';
      wx.navigateTo({
        url: '/pages/select-tags/index?platform=1&tagsShowText=' + tagsShowText,
        events: {
          // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
          acceptDataFromSelectTagPage(data) {
            console.log(data.tagsShowText, that.data);
            applyInfo.platform = data.tagsShowText;
            that.setData({ applyInfo }, () => {
              console.log(data.tagsShowText, that.data);
            });
          }
        },
      });
    },

    bindKeyInput: function (e) {
      let { applyInfo = {} } = this.data;
      console.log('bindKeyInput: ', e.currentTarget.id, e, applyInfo);
      // this.data.userInfo[e.currentTarget.id] = e.detail.value;
      applyInfo[e.currentTarget.id] = e.detail.value;
      // applyInfo.detailAddress = e.detail.value;;
      console.log('applyInfo: ', applyInfo);
      this.setData({ applyInfo });
    },

    bindPricePickerChange: function (e) {
      // console.log('picker发送选择改变，携带值为', e.detail.value)
      this.setData({
        priceIndex: e.detail.value
      })
    },

    onAvatarClick() {
      if (this.data.disableEdit) return;
      this.chooseImageUpload(url => {
        const {
          applyInfo
        } = this.data;

        applyInfo.shopIcon = url;
        this.setData({
          applyInfo
        });
      });
    },

    onQRCodeClick() {
      if (this.data.disableEdit) return;
      this.chooseImageUpload(url => {
        const {
          applyInfo
        } = this.data;

        applyInfo.wechatQrcode = url;
        this.setData({
          applyInfo
        });
      });
    },

    chooseImageUpload(callback) {
      wx.chooseImage({
        count: 1,
        sizeType: ['original', 'compressed'],
        sourceType: ['album'],
        success: res => {
          let filePath = res.tempFilePaths[0];
          callback && util.qiniuUpload(filePath, callback);
        }
      });
    },

    onChooseLocationClick() {
      const that = this;
      wx.getFuzzyLocation({
        type: 'gcj02',
        success(res) {
          const latitude = res.latitude
          const longitude = res.longitude
          console.log(res.latitude);
          console.log(res.longitude);
          wx.chooseLocation({
            latitude: latitude, // 纬度，范围为-90~90，负数表示南纬
            longitude: longitude,
            success(res) {
              console.log('success: ', res);
              const { address = '', latitude = '', longitude = '' } = res;
              console.log('address: ', address, latitude, longitude);

              if (address) {
                const { applyInfo } = that.data;
                applyInfo.region = address;
                applyInfo.latitude = latitude;
                applyInfo.longitude = longitude;
                that.setData({ applyInfo });
              }

            },
            fail(res) {
              console.log('fail: ', res);
            },
          });
        },
        fail: async (res) => {
          console.log('fail: ', res);
          const settings = await wx.getSetting();
          console.log('settings: ', settings);
          if (!settings.authSetting['scope.userFuzzyLocation']) {
            wx.showModal({
              title: '提示',
              content: '您拒绝了定位权限，请点击确定允许位置信息获取。',
              showCancel: true,
              success: (result) => {
                if (result.confirm) {
                  wx.openSetting();
                }
              },
              fail: () => { },
              complete: () => { }
            });
          }
        },
      });
    },
    async onPhoneNumber(e) {
      console.log("onPhoneNumber: ", e);
      const { encryptedData, iv } = e.detail;
      if (!encryptedData || !iv) {
        return;
      }
      let loginRes = await wx.login();
      console.log('loginRes: ', loginRes);
      const { circleId } = getApp().getCircleConfig();

      const method = 'POST';
      const param = {
        encryptedData: encryptedData,
        iv: iv,
        code: loginRes.code,
        circle_id: 'CID000008', //circleId,
        client_type: 'miniapp',
      };
      console.log("onPhoneNumber param: ", param);
      const url = '/circle/circle_new_interface.jsp?act=decodeMiniAppPhoneNumber';
      const { isOk, result = {} } = await circleUtil.fetchNetData({ url, method, param });
      console.log('onPhoneNumber fetchNetData: ', isOk, result);

      if (isOk) {
        const { userInfo } = this.data;
        const { phoneNumber = '' } = result;
        userInfo.phone_number = phoneNumber;
        console.log('userInfo: ', userInfo);
        this.setData({ userInfo });
      }

    },
  }
})
