// ui-components/custom-title-bar/index.js
Component({
    /**
     * 组件的属性列表
     */
    properties: {
    },

    /**
     * 组件的初始数据
     */
    data: {

    },

    /**
     * 组件的方法列表
     */
    methods: {
        onSearchBarTap(){
            console.log('onSearchBarTap...');
            wx.navigateTo({
                url: `/pages/search-page/index`
            });
        },
    },

    attached() {

    }
});
