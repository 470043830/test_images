
Component({
    /**
     * 组件的属性列表
     */
    properties: {
        title: {
            type: String,
            value: '',
        },
        isShowPerson: {
            type: Boolean,
            value: false,
        },
        isShowBack: {
            type: Boolean,
            value: false,
        },
        isPlaced: {
            type: Boolean,
            value: false,
        },
        isTransparent: {
            type: Boolean,
            value: false,
        },
    },

    /**
     * 组件的初始数据
     */
    data: {
        statusBarHeight: 0,
        headerBar: 0,
        customBar: 0
    },

    /**
     * 组件的方法列表
     */
    methods: {

        onPersonalTap() {
            console.log('onPersonalTap...');
            this.triggerEvent('personalTap', {}, {});
        },
        onBackTap() {
            console.log('onBackTap...');

            this.triggerEvent('backTap', {}, {});
            wx.navigateBack();
        }
    },

    attached() {
        // let e = wx.getSystemInfoSync();
        // let statusBarHeight = e.statusBarHeight;
        // let rect = wx.getMenuButtonBoundingClientRect();
        // let customBar = 0;
        // let headerBar = 0;

        // // console.log('sys: ', e);

        // //下面是代码 , CustomBar 代表标题栏加状态栏的高度，HeaderBar 代表 标题栏的高度
        // headerBar = rect.height + (rect.top - e.statusBarHeight) * 2;
        // customBar = headerBar + e.statusBarHeight;

        // if (e.system.toLowerCase().indexOf('iossss') > -1) {
        //     //IOS
        //     customBar = rect.bottom + (rect.top - e.statusBarHeight) * 2;
        //     headerBar = customBar - e.statusBarHeight;
        // } else {
        //     //安卓
        //     headerBar = rect.height + (rect.top - e.statusBarHeight) * 2;
        //     customBar = headerBar + e.statusBarHeight;
        // }

        // console.log('sys rect: ', statusBarHeight, rect, customBar);

        const { statusBarHeight, headerBar, customBar } = getApp().getCustomBarInfo();
        this.setData({ statusBarHeight, headerBar, customBar });
        // console.log('sys rect: ', this.data);
    }
});
