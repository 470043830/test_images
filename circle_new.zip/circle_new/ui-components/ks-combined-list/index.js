

const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');
const circleData = require('../../utils/circle-data.js');
const app_switch = require('../../utils/app_switch.js');

Component({
  options: {
    addGlobalClass: true
  },

  /**
   * 组件的属性列表
   */
  properties: {
    // list: {
    //   type: Array,
    //   value: [],
    // },
    isShopName: false, //goods card show shop name
    listType: {
      type: Number,
      value: app_switch.listType,
      observer(newVal, oldVal) {
        console.log('observer listType ', newVal, oldVal);
        this.onListTypeChanged(newVal, oldVal);
      }
    },
    filterText: {
      type: String,
      value: '',
      observer(newVal, oldVal) {
        console.log(`observer filterText newVal: ${newVal}, oldVal: ${oldVal}`);
        this.onSearchValueChanged(newVal, oldVal);
      }
    },
    filterBlur: {
      type: Number,
      value: 0,
    },
  },

  /**
   * 组件的初始数据
   */
  data: {
    loading: true,
    // 列表加载中
    loadingNoData: false,
    // 列表加载完成 & 无数据
    loadingEnd: false,
    // 列表加载完成 & 到底了
    cur_page: 1,

    //...
    list: [],

    //for test
    test_list: [],
  },

  // 以下生命周期会被lifetimes对应生命周期覆盖
  attached: function () {
    console.log('ks-combined-list attached...');
  },
  detached: function () {
    if (this.delayRenderTimer > 0) {
      clearTimeout(this.delayRenderTimer);
      this.delayRenderTimer = 0;
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    onTestTap(e) {
      console.log('onTestTap...', e);
    },

    //search value
    onSearchValueChanged(newVal, oldVal) {
      //...
      this.listOrigin = [];
      this.setData({
        list: []
      });
      this.getListData({ urlType: this._urlType, type: '', shopId: this.shop_id });
      // this.getListData('');
    },

    // two kind of list to switch
    onListTypeChanged(newVal, oldVal) {
      this.listOrigin = this.listOrigin.slice(0, 16);

      if (newVal == 0) {
        let obj = {
          loadingEnd: false,
          list: this.listOrigin.slice(0, 2),
        };
        if (this.listOrigin.length > 2) {
          this.setData(obj, () => {
            obj.list = this.listOrigin;
            this.delayRenderTimer = setTimeout(() => { this.setData(obj); }, 300);
          });
        }
      } else {
        // let testIndex = this.data.test_list.length;
        // let key = "test_list[" + testIndex + "]";
        this.setData({
          loadingEnd: false,
          list: this.listOrigin,
          // [key]: "testIndex " + testIndex,
        });
        //for test
        // console.log('this.data.test_list: ', this.data.test_list);
      }

    },

    // onViewImgHandler(e) {
    //   console.log('ks-combined-list onViewImgHandler...', e);
    // },

    getListData(param) { //0: init, 1: more onReachBottom, 2: pull down flash
      // util.fetch(`/album/personal/all?&albumId=A2018010521093602411&searchValue=&searchImg=&startDate=&endDate=&sourceId=&requestDataType=`, {});
      // return;
      const { urlType, type, shopId, callback } = param;

      if (!urlType) {
        console.log('urlType is not valid...', urlType);
        return;
      }
      this._urlType = urlType;

      console.log('getListData...', urlType, type, shopId);
      if (type == 'init' && shopId) {
        this.shop_id = shopId;
      }
      if (type == 'single' && !this.shop_id) return;

      const {
        loading,
        loadingNoData,
        loadingEnd
      } = this.data;

      if (type == 'top') { //get more
        if (loading) {
          wx.stopPullDownRefresh();
          return;
        }
      }
      if (type == 'bottom') { //get more
        if (loading || loadingNoData || loadingEnd) {
          return;
        }
      }

      //...
      this.fetchData(type, callback);
    },

    /**
     * get the right url
     * @param {*} type 
     * @param {*} filterText 
     * @returns { url, param }
     */
    getUrl(type, filterText) {
      let url = '', param = {};
      const {
        top,
        bottom
      } = circleData.getTimestamp(this.listOrigin);

      //type==init have no timestamp
      param.slipType = '';
      if (type == 'top') {
        param.slipType = 0;
        param.timestamp = top;
      }
      else if (type == 'bottom') {
        param.slipType = 1;
        param.timestamp = bottom;
      }
      if (this._urlType == 'single') {
        param.searchValue = filterText; //encodeURIComponent(filterText); //'',
        param.albumId = this.shop_id; //'A201910211430090851163' ////'A202212191541552710001195';
        // param.requestDataType = 'itemName';
        url = circleData.getDomainUrl('/album/personal/all');
        // if (circleData.testDomain)
        //   url = circleData.testDomain + this.getUrl111(type);
        // else
        //   url = this.getUrl111(type);
      }
      if (this._urlType == 'circleMoments') {
        if (!filterText) {
          url = circleData.getDomainUrl('/portal/api/v3/album/circleMoments');
        } else {
          let api = '/commoditysearch/api/v3/search/moments?';
          let tail = `searchValue=${filterText}&searchQuerySource=1&sort=%7B%22type%22%3A%22updateTime%22%7D`;
          if (type == 'bottom') tail += `&timestamp=${bottom}`;
          tail += '&circleId=CID000009';
          url = circleData.getDomainUrl(api + tail);
          // if (circleData.testDomain)
          //   url = circleData.testDomain + api + tail;
          // else
          //   url = 'https://www.wsxcme.com' + api + tail;
        }

      }
      return { url, param };
    },

    /**
     * fetch list Data
     * @param {*} type 
     * @param {*} callback 
     * @returns 
     */
    async fetchData(type, callback) {
      const {
        filterText = '',
        filterImg = '',
      } = this.properties;
      // const isSearch = !!(filterText || filterImg);
      // const searchType = isSearch && filterText ? '文字搜索' : '图搜';

      const { url, param } = this.getUrl(type, filterText);
      // const {
      //   top = '',
      //   bottom = '',
      // } = this.getTimestamp(type);

      // 初始化首次加载不需要显示loading
      if (type != "init") {
        this.setData({
          loading: true
        });
      }

      console.log('fetchData, url: ', url);
      console.log('filterText: ', filterText, this._urlType);

      //...
      let res = null;
      if (this._urlType == 'single') {
        res = await util.fetch(url, param);
      } else {
        // param.slipType = '';
        // if (type == 'top') param.slipType = 0;
        // else if (type == 'bottom') param.slipType = 1;
        // param.timestamp = (type == 'bottom' ? bottom : top);
        res = await util.fetchPost(url, param);
      }
      const {
        errcode,
        result,
        errmsg
      } = res.data;
      console.log('--- res.data: ', res.data);

      wx.hideLoading();

      if (errcode != 0) {
        if (errcode == 9) {
          circleUtil.showLoginConfirm(errmsg);
        } else if (errcode == 1017) {
          // wx.navigateTo({
          //   url: "/pages/circle-contact-tip/index?current=",
          // })
          const { albumIcon, albumName, mobile = '', wxNum = '', wxNumQrCodeUrl = '' } = result;
          let pageCount = getCurrentPages();
          console.log('getCurrentPages(): ', pageCount);
          if (pageCount > 1) {
            wx.navigateBack({
              success: () => wx.navigateTo({
                url: `/pages/circle-contact-tip/index?icon=${albumIcon}&name=${albumName}&phone=${mobile}&wx=${wxNum}&qr=${wxNumQrCodeUrl}`,
              })
            });
          } else {
            wx.redirectTo({
              url: `/pages/circle-contact-tip/index?icon=${albumIcon}&name=${albumName}&phone=${mobile}&wx=${wxNum}&qr=${wxNumQrCodeUrl}`,
            });
          }

        } else {
          wx.showModal({
            title: '提示',
            content: errmsg,
            showCancel: false, //true,
            // confirmText: '确定',
            // confirmColor: '#3CC51F',
            success: (result) => {
              if (result.confirm) {
                wx.navigateBack();
              }
            },
          });
        }
        //...
        this.triggerEvent('onGoodsListInfo', {
          listSize: 0
        }, { bubbles: false, composed: false });
        return;
      }

      let goods_list = [], shop = {};
      let {
        share
      } = result;

      if (this._urlType == 'single') {
        goods_list = result.items; //result.goods_list;
        shop = result.targetAlbum; //result.shop;
      } else {
        goods_list = result.items;
        shop = result.album;
      }

      //...
      type != 'bottom' && this.triggerEvent('onGoodsListInfo', {
        listSize: goods_list.length
      }, { bubbles: false, composed: false });

      if (type == 'init') {
        this.triggerEvent('onShopDataGetted', {
          banner: shop.banner,
          shop,
          share_title: share.title,
          share,
          is_attention: shop.isFollowed,
          isMyAlbum: shop.isMy,
        }, { bubbles: false, composed: false });

        //...
        this.listOrigin = [];
      }


      //liu add for sort, maybe put the isTop to end???
      // goods_list.length > 0 && (goods_list = goods_list.sort((a, b) => {
      //   return b.time_stamp - a.time_stamp;
      // }));

      console.log('--- goods_list.length: ', goods_list.length);

      let obj = {
        loading: false,
        loadingEnd: false,
        list: [],
      }

      if (type == 'top') {
        let topList = this.listOrigin.filter((item) => item.isTop);
        console.log('topList: ', topList)
        // 去重
        this.listOrigin = util.dedupArr([...topList, ...goods_list, ...this.listOrigin], 'goods_id');
      } else {
        this.listOrigin = [...this.listOrigin, ...goods_list];
        this.listOrigin = util.dedupArr([...this.listOrigin, ...goods_list], 'goods_id'); // console.log('正常处理的数据---》', this.list);

        goods_list.length <= 0 && (obj.loadingEnd = true);

        //liu add, test album just get one page
        // if (this.shop_id == app_cfg.defaultShopId) {
        //   obj.loadingEnd = true;
        // }
        //set the max len
        if (this.listOrigin.length >= 32 * 5) {
          obj.loadingEnd = true;
        }
      }

      //...
      if (type == 'init' && this.listOrigin.length > 10) {
        console.log('init > slice ...');
        obj.list = this.listOrigin.slice(0, 9);
        this.setData(obj, () => {
          obj.list = this.listOrigin;
          console.log('obj.list.length: ', obj.list.length);
          this.delayRenderTimer = setTimeout(() => {
            this.setData(obj);
          }, 200);
        });
      } else {
        obj.list = this.listOrigin;
      }

      console.log('obj: ', obj);
      this.setData(obj);
      callback && callback();
    },


    /*
    getUrl111(type) {

      const getCircleAlbumUrl = `/circle/circle_new_interface.jsp?act=single_album`;
      const {
        listIndex = 0,
        cur_page = 1,
        filterImg = '',
        filterTag = [],
        isCirclePersonal = false,
      } = this.data;
      // console.log('isCirclePersonal: ', isCirclePersonal);
      const baseUrl = [`/service/album/get_album_themes_list.jsp?act=single_album${this.getSearchDate(type)}`, getCircleAlbumUrl];
      let getUrl = [];
      let url = '';

      if (!isCirclePersonal) {
        getUrl = [`${baseUrl[0]}`, `${baseUrl[0]}&query_type=new`, `${baseUrl[0]}&query_type=video`, `${baseUrl[0]}&query_type=img`];
        url = `${getUrl[listIndex]}&shop_id=${this.shop_id}&search_img=${filterImg}&tag=${encodeURIComponent(JSON.stringify(filterTag))}&page_index=${cur_page}`;
        // url = `${getUrl[listIndex]}&shop_id=${this.shop_id}&search_img=${filterImg}&page_index=${cur_page}`;
      } else {
        getUrl = [`${baseUrl[1]}`];
        url = `${getUrl[0]}&shop_id=${this.shop_id}&category=${this.currTabIndex}`;
      }

      const {
        top,
        bottom
      } = this.getTimestamp(type);

      switch (type) {
        case 'top':
          url = `${url}&slip_type=0&time_stamp=${top}`;
          break;

        case 'bottom':
          url = `${url}&slip_type=1&time_stamp=${bottom}`;
          break;
      }

      console.log('getUrl----------------url: ', url);
      // url = `/album/personal/all?albumId=${this.shop_id}&searchValue=&searchImg=&startDate=&endDate=&sourceId=&requestDataType=`;
      return url;
    },

    getTimeList(list = []) {
      return list.map(item => item.time_stamp).filter(item => item);
    },

    
    getTimestamp(type) {
      if (!this.listOrigin || this.listOrigin.length == 0) {
        return { top: '', bottom: '' };
      }
      const { filterText, listIndex = 1000 } = this.properties;
      const timeList = this.getTimeList(this.listOrigin);
      let tList = [];

      if (listIndex == 0) {
        if (type == 'top' || !!filterText) {
          tList = timeList;
        } else {
          tList = this.listOrigin.filter(item => item.isTop !== 1);
          tList = this.getTimeList(tList);
        }
      } else {
        tList = timeList;
      }
      // console.log('tList: ', tList);
      if (!!filterText) {
        const len = tList.length;

        if (len > 0) {
          const first = tList[0];
          const last = tList[len - 1];
          first < 0 && last > 0 && (tList = tList.filter(item => item > 0));
        }
      }

      tList.sort((a, b) => b - a);
      const len = tList.length;
      const latest = tList[0] || '';
      const oldest = tList[len - 1] || 1; // 全部为置顶时，list为空[]，min=1停止加载

      // console.log(`latest: ${latest}|${this.listOrigin[0].time_stamp}, oldest: ${oldest}|${this.listOrigin[this.listOrigin.length - 1].time_stamp}`);
      console.log('latest-oldest=', latest - oldest);

      return { top: latest, bottom: oldest };
    },

    getSearchDate(type) {
      console.log('getSearchDate, type: ', type);

      return '';
      //liu disabled

      if (type == 'bottom') {
        const d = new Date(Date.now() - 24 * 3600000 * 7);
        const yy = d.getFullYear();
        const mm = d.getMonth() + 1 + '';
        const dd = d.getDate() + '';
        return `&start_date=${yy}-${mm.padStart(2, '0')}-${dd.padStart(2, '0')}`; // return 'start_date=2021-03-11&end_date=2021-03-12';
      } else {
        return '';
      }
    },*/



  },




});
