// ui-components/foldtext/index.js
const circleUtil = require('../../utils/circle-util.js');

Component({
    options: {
        addGlobalClass: true,
    },
    /**
     * 组件的属性列表
     */
    properties: {
        category: {
            type: Number,
            value: 0,
        },
        title: {
            type: String,
            value: '',
        },
        filterText: {
            type: String,
            value: '',
        },
        // textInfo: {
        //     type: Object,
        //     value: {texts:[], title:''}
        // },
    },

    /**
     * 组件的初始数据
     */
    data: {
        clamp: 6,
        texts: [],
        isUnfold: false,
        btnText: '全文'
    },

    /**
     * 组件的方法列表
     */
    methods: {

        onNumberTap(e) {
            const { index } = e.currentTarget.dataset;
            const { texts } = this.data;
            console.log('onNumberTap...', texts[index]);

            wx.makePhoneCall({
                phoneNumber: texts[index].text
            });
        },

        onFoldTap() {
            const { clamp } = this.data;
            this.setData({
                clamp: clamp == 6 ? 60 : 6,
                btnText: clamp == 6 ? '收起' : '全文',
            });
        },

        onTitleLongPress(e) {
            // this.titleTap(e);
            const { title } = this.properties;

            // console.log('onTitleLongPress...', title);
            wx.setClipboardData({
                data: title,
                success(res) {
                    wx.getClipboardData({
                        success(res) {
                            // console.log(res.data); // data
                        }
                    });
                }
            });
        },

        async selectorQuery() {
            const { title, category, filterText } = this.properties;
            const numbers = title.match(/1(3|4|5|7|8|9|6)\d{9}/g);

            const query = this.createSelectorQuery();
            query.select('#the-cal-text').boundingClientRect();
            query.exec((res) => {
                if (res[0]) {
                    const { height } = res[0];
                    const isUnfold = height > 120;
                    // console.log('attached: ', height, isUnfold);
                    if (!numbers && !filterText) {
                        this.setData({ isUnfold });
                        return;
                    }
                    const texts = circleUtil.handleFoldText(title, filterText, numbers);
                    this.setData({ isUnfold, texts });
                } else {
                    console.log('this._queryTimerId=', this._queryTimerId);
                    if (!this._queryTimerId) {
                        this._queryTimerId = setTimeout(() => {
                            this.selectorQuery();
                        }, 100);
                    }
                }

            });
        },
    },

    attached: function () {
        this.selectorQuery();
    },

    detached: function () {

    },
});
