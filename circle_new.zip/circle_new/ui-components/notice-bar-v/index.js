// ui-components/custom-title-bar/index.js
const circleUtil = require('../../utils/circle-util.js');


Component({
    /**
     * 组件的属性列表
     */
    properties: {
        // goods: Object
        notices: {
            type: Array,
            value: []
        }
    },

    /**
     * 组件的初始数据
     */
    data: {
        background: [' ', ' ', ' '],
        indicatorDots: false,
        vertical: true,
        autoplay: true,
        circular: true,
        interval: 2000,
        duration: 500,
        previousMargin: 0,
        nextMargin: 0,

    },


    /**
     * 组件的方法列表
     */
    methods: {
        onBackTap() {
            console.log('onBackTap...');
            this.triggerEvent('backTap', {}, {});
        },
        bindchange(e) {
            // console.log("bindchange", e)
        },
        bindtransition(e) {
            // console.log("bindtransition", e)
        },

        getNextText() {
            const text = this.allTexts[this.textIndex++];
            if (this.textIndex >= this.allTexts.length) {
                this.textIndex = 0;
            }
            // console.log('this.allTexts ', this.textIndex, this.allTexts);
            // console.log('textIndex ', textIndex, text.replace(/\s+/g, ' ').split(' '));
            return text;
        },
        setBackground(current) {
            const {
                background
            } = this.data;
            if (current == 1) {
                background[0] = this.getNextText();
                this.setData({
                    background
                });
            } else if (current == 2) {
                background[1] = this.getNextText();
                this.setData({
                    background
                });
            } else if (current == 0 && this.textIndex > 0) {
                background[2] = this.getNextText();
                this.setData({
                    background
                });
            }
        },
        bindanimationfinish(e) {
            // console.log("bindanimationfinish", e.detail.current);
            const {
                current
            } = e.detail;
            this.setBackground(current);
        }
    },

    attached() {
        const { notices } = this.properties;
        // console.log("notices: ", notices);
        this.allTexts = [];
        this.textIndex = 0;
        for (let index = 0; index < notices.length; index++) {
            const element = notices[index];
            this.allTexts.push(element.replace(/\s+/g, ' ').split(' '));
        }
        // console.log("this.allTexts: ", this.allTexts);
        this.setData({
            background: [this.getNextText(), this.getNextText(), this.getNextText()]
        });
    }
});


