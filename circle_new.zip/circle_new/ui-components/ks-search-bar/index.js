// ui-components/custom-title-bar/index.js
Component({
  options: {
    addGlobalClass: true
  },
  /**
   * 组件的属性列表
   */
  properties: {
    placeholder: {
      type: String,
      value: '搜索',
    },
  },

  /**
   * 组件的初始数据
   */
  data: {
    // placeholder: '搜索',
    inputShowed: false,
    inputVal: "",
    searchImg: "",
  },

  /**
   * 组件的方法列表
   */
  methods: {
    bindConfirm(e) {
      console.log('bindConfirm: ', e);
      this.setData({
        inputVal: e.detail.value
      }, () => {
        this.search();
      });
    },

    bindInput(e) {
      let iptVal = e.detail.value;
      console.log('bindInput: ', iptVal);

      // this.setData({
      //   inputVal: e.detail.value
      // }, () => {
      //   this.search();
      // });
    },

    clearInput() {
      console.log('clearInput...',);
      this.setData({
        inputVal: "",
        searchImg: ""
      }, () => {
        this.search();
      });
    },

    search() {
      // const searchData = this.getComponentData();
      // typeof options.searchHandler === `function` && options.searchHandler(searchData.inputVal.trim(), searchData.searchImg);

      const {
        inputVal,
        searchImg,
      } = this.data;

      // this.searchHandler(inputVal, searchImg);
      this.setData({
        inputShowed: false
      });

      //...
      this.triggerEvent("searchconfirm", { inputVal, searchImg }, { bubbles: true, composed: false });
    },

  },

  attached() { }

});
