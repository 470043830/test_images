// ui-components/custom-title-bar/index.js
const util = require('../../utils/util.js');
const circleUtil = require('../../utils/circle-util.js');

Component({
    /**
     * 组件的属性列表
     */
    properties: {
        boothList: Array
    },

    /**
     * 组件的初始数据
     */
    data: {

    },

    /**
     * 组件的方法列表
     */
    methods: {
        onBoothTap(ev){
            console.log('onBoothTap ', ev.currentTarget.dataset);
            const {shopid} = ev.currentTarget.dataset;
            circleUtil.onShopItemTap(shopid, true);
        },
    },

    attached() {

    }
});
